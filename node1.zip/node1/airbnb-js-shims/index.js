'use strict';

require('./target/es5');
