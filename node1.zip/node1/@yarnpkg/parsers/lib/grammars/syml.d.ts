export declare const parse: (code: string) => {[key: string]: any};
