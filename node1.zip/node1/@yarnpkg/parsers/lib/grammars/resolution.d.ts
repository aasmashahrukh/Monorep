export declare const parse: (code: string) => Object;
