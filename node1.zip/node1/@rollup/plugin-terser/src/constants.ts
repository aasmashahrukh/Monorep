export const taskInfo = Symbol('taskInfo');
export const freeWorker = Symbol('freeWorker');
export const workerPoolWorkerFlag = 'WorkerPoolWorker';
