const VERSION = "4.2.4";
export {
  VERSION
};
