export declare const VERSION = "3.1.0";
