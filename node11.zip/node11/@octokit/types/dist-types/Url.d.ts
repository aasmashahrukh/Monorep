/**
 * Relative or absolute URL. Examples: `'/orgs/{org}'`, `https://example.com/foo/bar`
 */
export type Url = string;
