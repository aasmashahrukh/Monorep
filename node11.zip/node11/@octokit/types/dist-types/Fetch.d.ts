/**
 * Browser's fetch method (or compatible such as fetch-mock)
 */
export type Fetch = any;
