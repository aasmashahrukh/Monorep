# Contributing

Please do not edit the `ghe-*/*.json` files directly, they are generated
 automatically from [`@octokit/routes`](https://github.com/octokit/routes). If there
is a problem e.g. with the parameters or description, please submit an issue to
https://github.com/octokit/routes instead.

Please note that this project is released with a [Contributor Code of Conduct][coc].
By participating in this project you agree to abide by its terms.

[coc]: ./CODE_OF_CONDUCT.md
