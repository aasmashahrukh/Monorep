# DO NOT EDIT FILES IN THIS DIRECTORY

All files are generated automatically and will be overwritten next time [octokit/routes](https://github.com/octokit/routes/) has a new release. If you find a problem, please file an issue.
