module.exports = octokit => octokit.registerEndpoints(require("./all.json"));
