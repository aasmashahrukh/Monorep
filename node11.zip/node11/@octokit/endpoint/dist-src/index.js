import { withDefaults } from "./with-defaults";
import { DEFAULTS } from "./defaults";
const endpoint = withDefaults(null, DEFAULTS);
export {
  endpoint
};
