const VERSION = "7.0.6";
export {
  VERSION
};
