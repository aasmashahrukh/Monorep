import { merge } from "./merge";
import { parse } from "./parse";
function endpointWithDefaults(defaults, route, options) {
  return parse(merge(defaults, route, options));
}
export {
  endpointWithDefaults
};
