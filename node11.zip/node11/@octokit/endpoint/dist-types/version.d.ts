export declare const VERSION = "7.0.6";
