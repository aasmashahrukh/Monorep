export declare function addQueryParameters(url: string, parameters: {
    [x: string]: string | undefined;
    q?: string;
}): string;
