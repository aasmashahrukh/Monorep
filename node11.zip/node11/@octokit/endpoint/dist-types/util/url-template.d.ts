export declare function parseUrl(template: string): {
    expand: (context: object) => string;
};
