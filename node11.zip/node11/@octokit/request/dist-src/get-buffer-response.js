function getBufferResponse(response) {
  return response.arrayBuffer();
}
export {
  getBufferResponse as default
};
