const VERSION = "6.2.8";
export {
  VERSION
};
