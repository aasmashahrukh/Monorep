export declare const request: import("@octokit/types").RequestInterface<object>;
