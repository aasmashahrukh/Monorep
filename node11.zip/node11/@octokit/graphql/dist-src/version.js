const VERSION = "5.0.6";
export {
  VERSION
};
