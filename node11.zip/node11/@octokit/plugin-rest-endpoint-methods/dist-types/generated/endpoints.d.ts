import { EndpointsDefaultsAndDecorations } from "../types";
declare const Endpoints: EndpointsDefaultsAndDecorations;
export default Endpoints;
