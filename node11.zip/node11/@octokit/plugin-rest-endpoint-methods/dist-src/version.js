export const VERSION = "6.8.1";
