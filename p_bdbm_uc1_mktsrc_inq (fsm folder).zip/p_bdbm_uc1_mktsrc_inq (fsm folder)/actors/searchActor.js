const {createMachine,assign, spawn, sendParent } = require("xstate");
const { FetchActor, trigger, getToken, getLogger,handler } = require("@teresol-v2/fsm");


const service = require("../urls.js");
const crsSetupConfig = service.get("crsSetupConfig");
const crsReportDetail = service.get("crsReportDetail");


const SearchActor = createMachine({
    initial:"Idle",
    predictableActionArguments:true,

    context:{
        header: {},
        mBoolean: false,
        errorMessage: "",
        partialCtx: {},
        searchResponseAPI:{},
        searchAPI_1Parameters:{
            branchCode:"5005",
        },
        searchAPI_2Parameters: {
            isActive: 0,
            authStatus:"E",
            branchCode: "5001",
            branchCd: 1001,
            loginBranchCd: 1001,
            forwardTo: 4,
            accountId:"10010095178928013",
            createdBy: "MF07483",
            crsCustomerTypeDescription: "Individual",
            DateFromTextBox1: new Date().toISOString().split('T')[0], 
            DateToTextBox1: new Date().toISOString().split('T')[0],
        },
        searchAPI_3Parameters:{
            branchCode: "5001",
            isActive: 0,
            iban: "PK63BAHL1001007103111950",
            isIban: 1
        },
        searchAPI_4Parameters:{
            branchCode: "5001",
            crsIsActive1: 0,
            crsIsActive2: 0,
            authStatus1: "E",
            authStatus2: "E",
            accountId1: "10180095021958013",
            accountId2: "10180095021958013",
        },
        searchAPI_5Parameters:{
            branchCode: "5005",
            IsActive:1
        },

    },
    
    states:{
        Idle:{
            on:{
                INIT:{
                    actions:["getDataFromParent"],
                    target:"SearchAPI_3",
                }
            }
        },

        // SearchAPI_1:{
        //     entry:[
        //         "spawnFetch",
        //         async (ctx) => {
        //             trigger(
        //                 ctx,
        //                 crsSetupConfig,
        //                 "GET",
        //             {
        //                 branchCode: ctx.searchAPI_1Parameters.branchCode,
        //             },
        //             {
        //                 "Content-Type": "application/json",
        //                 Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
        //             },
        //                 "FETCH_SUCCESS",
        //                 "FETCH_FAILURE"
        //             )
                    
        //         }
        //     ],
        //     on:{
        //         FETCH_SUCCESS:{
        //             actions:["getSearchResponseFromAPI","updatePartialCtx","sendPartialCtx"],
        //             target:"SearchAPI_2",
        //         },
        //         FETCH_FAILURE:{
        //             actions:["receiveErrorMessage", "sendPartialCtx"],
        //             target:"Final",
        //         },
        //     },
        // },


        // SearchAPI_2:{
        //     entry:[
        //         "spawnFetch",
        //         async (ctx) => {
        //             trigger(
        //                 ctx,
        //                 crsSetupConfig,
        //                 "GET",
        //             {
        //                 branchCode: ctx.searchAPI_2Parameters.branchCode,
        //                 authStatus: ctx.searchAPI_2Parameters.authStatus,
        //                 branchCd: ctx.searchAPI_2Parameters.branchCd,
        //                 createdBy: ctx.searchAPI_2Parameters.createdBy,
        //                 dateTo: ctx.searchAPI_2Parameters.DateToTextBox1,
        //                 dateFrom: ctx.searchAPI_2Parameters.DateFromTextBox1,
        //                 forwardTo: ctx.searchAPI_2Parameters.forwardTo,
        //                 isActive:  ctx.searchAPI_2Parameters.isActive,
        //                 loginBranchCd: ctx.searchAPI_2Parameters.loginBranchCd,
        //                 accountId: ctx.searchAPI_2Parameters.accountId,
        //                 crsCustomerTypeDescription: ctx.searchAPI_2Parameters.crsCustomerTypeDescription,
        //             },
        //             {
        //                 "Content-Type": "application/json",
        //                 Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
        //             },
        //                 "FETCH_SUCCESS",
        //                 "FETCH_FAILURE"
        //             )
                    
        //         }
        //     ],
        //     on:{
        //         FETCH_SUCCESS:{
        //             actions:["getSearchResponseFromAPI","updatePartialCtx","sendToParent"],
        //             target:"Final",
        //         },
        //         FETCH_FAILURE:{
        //             actions:["receiveErrorMessage", "sendErrorMessageToParent"],
        //             target:"Final",
        //         },
        //     },
        // },

        SearchAPI_3:{
            entry:[
                "spawnFetch",
                async (ctx) => {
                    trigger(
                        ctx,
                        crsReportDetail,
                        "GET",
                    {
                        branchCode: ctx.searchAPI_3Parameters.branchCode,
                        isActive: ctx.searchAPI_3Parameters.isActive,
                        iban: ctx.searchAPI_3Parameters.iban,
                        isIban: ctx.searchAPI_3Parameters.isIban
                    },
                    {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
                    },
                        "FETCH_SUCCESS",
                        "FETCH_FAILURE"
                    )
                    
                }
            ],
            on:{
                    FETCH_SUCCESS:{
                        actions:["getSearchResponseFromAPI","sendToParent"],
                        target:"Final",
                    },
                    FETCH_FAILURE:{
                        actions:["receiveErrorMessage", "sendErrorMessageToParent"],
                        target:"Final",
                    },
            },
        },

        // SearchAPI_4:{
        //     entry:[
        //         "spawnFetch",
        //         async (ctx) => {
        //             trigger(
        //                 ctx,
        //                 crsReportDetail,
        //                 "GET",
        //             {
        //                 branchCode: ctx.searchAPI_4Parameters.branchCode,
        //                 crsIsActive1: ctx.searchAPI_4Parameters.crsIsActive1,
        //                 crsIsActive2: ctx.searchAPI_4Parameters.crsIsActive2,
        //                 authStatus1: ctx.searchAPI_4Parameters.authStatus1,
        //                 authStatus2: ctx.searchAPI_4Parameters.authStatus2,
        //                 accountId1: ctx.searchAPI_4Parameters.accountId1,
        //                 accountId2: ctx.searchAPI_4Parameters.accountId2,
        //             },
        //             {
        //                 "Content-Type": "application/json",
        //                 Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
        //             },
        //                 "FETCH_SUCCESS",
        //                 "FETCH_FAILURE"
        //             )
                    
        //         }
        //     ],
        //     on:{
        //         FETCH_SUCCESS:{
        //             actions:["updatePartialCtx","sendPartialCtx"],
        //             target:"SearchAPI_5",
        //         },
        //         FETCH_FAILURE:{
        //             actions:["receiveErrorMessage", "sendPartialCtx"],
        //             target:"Final",
        //         },
        //     },
        // },

        // SearchAPI_5:{
        //     entry:[
        //         "spawnFetch",
        //         async (ctx) => {
        //             trigger(
        //                 ctx,
        //                 crsSetupConfig,
        //                 "GET",
        //             {
        //                 branchCode: ctx.searchAPI_5Parameters.branchCode,
        //                 IsActive: ctx.searchAPI_5Parameters.IsActive,
        //             },
        //             {
        //                 "Content-Type": "application/json",
        //                 Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
        //             },
        //                 "FETCH_SUCCESS",
        //                 "FETCH_FAILURE"
        //             )
                    
        //         }
        //     ],
        //     on:{
        //         FETCH_SUCCESS:{
        //             actions:["updatePartialCtx","sendPartialCtx"],
        //             target:"Final",
        //         },
        //         FETCH_FAILURE:{
        //             actions:["receiveErrorMessage", "sendPartialCtx"],
        //             target:"Final",
        //         },
        //     },
        // },


        Final: {
            type: "final",
            entry: ["sendPartialCtx"],
        },
    },

},

{

    actions:{
    // ================================= *Generic Actions* ===========================
        spawnFetch: assign({
            fetch: () => spawn(FetchActor),
        }),

        receiveErrorMessage: assign({
            partialCtx: (context, event) => {
                let partialCtxClone = Object.assign({}, context.partialCtx);
                partialCtxClone.errorMessage = event.errorMessage;
                partialCtxClone.mBoolean = event.mBoolean;
                console.log("Error Message: ", partialCtxClone);
                return partialCtxClone;
            },
        }),


    // ================================= *CRS - Actions* ==============================
        getDataFromParent: assign({
            header: (context,event) => {
                console.log("getDataFromParent:", event.header);
                return event.header
            }
        }),

        getSearchResponseFromAPI: assign({
            searchResponseAPI: (context,event) => {
                debugger
                console.log("getSearchResponseFromAPI:", event.result);
                return event.result
            }
        }),

        sendToParent: sendParent((context, event) => ({
            ...context,
            type: "FETCH_SUCCESS",
        })),

        sendErrorMessageToParent:sendParent((context, event) => ({
            ...context,
            type: "FETCH_FAILURE",
        })), 
    },

})

exports.SearchActor = SearchActor;
