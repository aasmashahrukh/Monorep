const { MegaSet17Actor } = require("./megaSet17Actor");
const { MegaSet18Actor} = require("./megaSet18Actor");
const {SearchActor} = require("./searchActor");

module.exports = {
	// MegaSet17Actor,
	// MegaSet18Actor,
	SearchActor
};