const {createMachine} = require("xstate");
const { FetchActor, trigger, getToken, getLogger } = require("@teresol-v2/fsm");


const service = require("../urls.js");


const SaveActor = createMachine(
    {
        initial:"Idle",
        predictableActionArguments:true,
        
        context:{
            header:{},
            mBoolean:false,
            errorMessage:"",
            partialCtx:{},
            saveResponseAPI:{},
            saveAPI_1Parameters:{},
            saveAPI_2Parameters:{},
            saveAPI_3Parameters:{},
            saveAPI_4Parameters:{},
        },

        states:{
            Idle:{
                on:{
                    INIT:{
                        actions:["getDataFromParent"],
                        target:"saveAPI_1",
                    },
                },
            },

            // API Calling.....
            saveAPI_1:{
                entry:[
                    "spawnFetch",
                    async (ctx) => {
                        trigger(
                            ctx,
                            API_CALL,
                            "GET",
                            {
                                branchCode:"5001",
                            },
                            {
                                "Content-Type": "application/json",
                                Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
                            },
                                "FETCH_SUCCESS",
                                "FETCH_FAILURE"
                        )
                    }
                ],
                on:{
                    FETCH_SUCCESS:{
                        actions:["getSaveResponseFromAPI","sendToParent"],
                        target:"saveAPI_2",
                    },
                    FETCH_FAILURE:{
                        actions:["receiveErrorMessage", "sendErrorMessageToParent"],
                        target:"Final",
                    },
                },
            },

            saveAPI_2:{
                entry:[
                    "spawnFetch",
                    async (ctx) => {
                        trigger(
                            ctx,
                            API_CALL,
                            "GET",
                            {
                                branchCode:"5001",
                            },
                            {
                                "Content-Type": "application/json",
                                Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
                            },
                                "FETCH_SUCCESS",
                                "FETCH_FAILURE"
                        )
                    }
                ],
                on:{
                    FETCH_SUCCESS:{
                        actions:["getSaveResponseFromAPI","sendToParent"],
                        target:"saveAPI_3",
                    },
                    FETCH_FAILURE:{
                        actions:["receiveErrorMessage", "sendErrorMessageToParent"],
                        target:"Final",
                    },
                },
            },

            saveAPI_3:{
                entry:[
                    "spawnFetch",
                    async (ctx) => {
                        trigger(
                            ctx,
                            API_CALL,
                            "GET",
                            {
                                branchCode:"5001",
                            },
                            {
                                "Content-Type": "application/json",
                                Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
                            },
                                "FETCH_SUCCESS",
                                "FETCH_FAILURE"
                        )
                    }
                ],
                on:{
                    FETCH_SUCCESS:{
                        actions:["getSaveResponseFromAPI","sendToParent"],
                        target:"saveAPI_3",
                    },
                    FETCH_FAILURE:{
                        actions:["receiveErrorMessage", "sendErrorMessageToParent"],
                        target:"Final",
                    },
                },
            },

            saveAPI_4:{
                entry:[
                    "spawnFetch",
                    async (ctx) => {
                        trigger(
                            ctx,
                            API_CALL,
                            "GET",
                            {
                                branchCode:"5001",
                            },
                            {
                                "Content-Type": "application/json",
                                Authorization: `Bearer ${await getToken(process.env.CORE_API_CRS)}`,
                            },
                                "FETCH_SUCCESS",
                                "FETCH_FAILURE"
                        )
                    }
                ],
                on:{
                    FETCH_SUCCESS:{
                        actions:["getSaveResponseFromAPI","sendToParent"],
                        target:"Final",
                    },
                    FETCH_FAILURE:{
                        actions:["receiveErrorMessage", "sendErrorMessageToParent"],
                        target:"Final",
                    },
                },
            },

            // Final-Step
            Final:{
                type:"final",
                entry:["sendPartialCtx"]
            },
        },
    },

    {
        actions:{
        // ================================= *Generic Actions* ===========================

            spawnFetch: assign({
                fetch: () => spawn(FetchActor),
            }),
    
            receiveErrorMessage: assign({
                partialCtx: (context, event) => {
                    let partialCtxClone = Object.assign({}, context.partialCtx);
                    partialCtxClone.errorMessage = event.errorMessage;
                    partialCtxClone.mBoolean = event.mBoolean;
                    console.log("Error Message: ", partialCtxClone);
                    return partialCtxClone;
                },
            }),

        // ================================= *CRS - Actions* ==============================
        
            getDataFromParent: assign({
                header: (event, context) => {
                    console.log("getDataFromParent: ", context.header);
                    return context.header;
                }
            }),

            getSaveResponseFromAPI: assign({
                saveResponseAPI: (context,event) => {
                    console.log("getSaveResponseFromAPI: ", event.result);
                    return event.result;
                }
            }),

            sendToParent: sendParent((context, event) => ({
                ...context,
                type: "FETCH_SUCCESS",
            })),
    
            sendErrorMessageToParent:sendParent((context, event) => ({
                ...context,
                type: "FETCH_FAILURE",
            })), 

        },
    })

    exports.SaveActor = SaveActor;