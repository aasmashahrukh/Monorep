const { createMachine, assign, spawn } = require("xstate");
const { FetchActor, trigger, getToken, getLogger } = require("@teresol-v2/fsm");
// const { combineAccountFromParts } = require("./functions.utility.js");
const service = require("./urls.js");
const accountDetail = service.get("accountDetail");
const accountIBANDetail = service.get("accountIBANDetail");
const userDetail = service.get("userDetail");

const padLeadingZeros = (num, size) => {
  let s = num + "";
  while (s.length < size) s = "0" + s;
  return s;
}
const combineAccountFromParts = (brnCode,acType,custNo,runNo,chkDigit) => {
  return `${padLeadingZeros(brnCode,4)}${padLeadingZeros(acType,4)}${padLeadingZeros(custNo,6)}${padLeadingZeros(runNo,2)}${padLeadingZeros(chkDigit,1)}`; 
}

const P_BDBM_UC1_MKTSRC_INQ = createMachine(
  {
    id: "P_BDBM_UC1_MKTSRC_INQ",
    initial: "Idle",
    predictableActionArguments: true,

    context: {
      header: {
        loginBranch: 0,
        loginUserId: "",
        loginUserBatch: 0,
        loginUserIp: "",
        activityCode: "",
        subActivityCode: "",
        loginBranchDate: "",
        currencyCode: 0,
      },
      mBoolean: false,
      errorMessage: "",
      partialCtx: {},
      authStatus: false, // For Check Account
      isAccountActive: false,

      // Payloads
      reqPayloadData: {},
      recResUserGpCd: {},
      recResAccNoIBAN:{},
      warningForAccNotFound:{},
      AccountDetails: null,
      ResponseAPIAuthStatusPending: null,
      ResponseAPIAuthStatusActive: null,

      // API Response
      ResponseAPISearchBtn: null,
    },

    states: {
      Idle: {
        on: {
          INIT: {
            actions: ["receiveHeader","sendHeaderFrntEnd", "sendPartialCtx"], //"sendPartialCtx"
            target: "MegaSet909",
          },
        },
      },

      MegaSet909: {
        on: {
          SEARCH_BTN: {
            actions: ["reqPayloadData"], 
            target: "CheckConditionCodes",
          },
          CHK_USER_GRPCD: {
            actions: ["reqPayloadData"],
            target: "CHK_USER_GRPCD",
          },
          EXIT_BTN: {
            target: "Final",
          },
          GET_ACC_NO_FRM_IBAN:{
            actions: ["reqPayloadData"], 
            target: "GetAccNoFromIBAN", 
          },
          KILL: "Final",
        },
      },
      Final: {
        type: "final",
        entry: ["sendPartialCtx"],
      },
      CHK_USER_GRPCD: {
        entry: [
          "spawnFetch",
          async (ctx) => {
            const parameters = {
              req_userId: ctx.header.loginUserId,
              req_branchCode: ctx.header.loginBranch,
              response: "res_groupCode"
            };
            trigger(
              ctx,
              userDetail,
              "GET",
              parameters,
              {
                "Content-Type": "application/json",
                Authorization: `Bearer ${await getToken(
                  process.env.CORE_API_USER
                )}`,
              },
              "FETCH_SUCCESS",
              "FETCH_FAILURE"
            );
          },
        ],
        on: {
          FETCH_SUCCESS: {
            actions: ["recResUserGpCd", "updateUserGrpCdCtx", "sendPartialCtx"],
            target: "MegaSet909",
          },
          FETCH_FAILURE: {
            actions: ["receiveErrorMessage", "sendPartialCtx"],
            target: "MegaSet909",
          },
        },
      },
      CheckConditionCodes: {
        // ACCCA-A01-12
        entry: [
          "spawnFetch",
          async (ctx) => {
            const parameters = {
              branchCode: ctx.reqPayloadData.branchCode,
              accountType: ctx.reqPayloadData.accountType,
              customerNumber: ctx.reqPayloadData.customerNumber,
              runNumber: ctx.reqPayloadData.runNumber,
              checkDigit: ctx.reqPayloadData.checkDigit,
              conditionCode: "13,14,15,16,17,95,500,501,502,503,504",
              response: "conditionCode",
            };
            // if(ctx.reqPayloadData && ctx.reqPayloadData.accountType){
            //   parameters['accountType'] = ctx.reqPayloadData.accountType
            // }
            // if(ctx.reqPayloadData && ctx.reqPayloadData.runNumber){
            //   parameters['runNumber'] = ctx.reqPayloadData.runNumber
            // }
            // if(ctx.reqPayloadData && ctx.reqPayloadData.checkDigit){
            //   parameters['checkDigit'] = ctx.reqPayloadData.checkDigit
            // }
            console.log("Condition Code Parameters*****************", parameters)
            trigger(
              ctx,
              accountDetail,
              "GET",
              parameters,
              {
                "Content-Type": "application/json",
                Authorization: `Bearer ${await getToken(
                  process.env.CORE_API_ACCOUNT
                )}`,
              },
              "FETCH_SUCCESS",
              "FETCH_FAILURE"
            );
          },
        ],
        on: {
          FETCH_SUCCESS: {
            // If Condition Code Exist then Account not active
            actions: ["checkAccountActive"], // ,"updatePartialCtx","sendPartialCtx"
            target: "CheckConditionCodesForAuthority",
          },
          FETCH_FAILURE:
          [
            { 
              cond: (context, event) => {
                // return event.httpStatus == 200;
                if(event.httpStatus == 200 && event.errorMessage.includes('No condition code found against the given branch code')){
                  return true;
                }
                else{
                  return false;
                }
              },
              actions: ["checkAccountActive"], //,"sendPartialCtx"
              target: "CheckConditionCodesForAuthority",
            },
            { // Condition Code Not Found
              actions: ["receiveErrorMessage","sendPartialCtx"],
              target: "MegaSet909",
            }
          ] ,
          KILL: "Final",
        },
      },
      CheckConditionCodesForAuthority:{
        always: [
          { // A/c not Active
            cond: (context, event) => context.isAccountActive == false,
            actions: ["warningForAccountNotActive","receiveErrorMessageFromCtx","sendPartialCtx"], // "warningForConditionCodeNotMatch","updatePartialCtx","sendPartialCtx"
            target: "MegaSet909",            
          },
          { // A/c is Active
            cond: (context, event) => context.isAccountActive == true,
            actions: ["resetWarningForAccountNotActive"],
            target: "APISearchSummaryForAccount", //"APIValidateAuthorityLevel",            
          },
          {
            target: 'Final'
          }
        ],
      },
      APISearchSummaryForAccount: {
        entry: [
          "spawnFetch",
          async (ctx) => {

            const parameters = {
              branchCode: ctx.reqPayloadData.branchCode,
              customerNumber: ctx.reqPayloadData.customerNumber,
              // accountType: ctx.reqPayloadData.accountType,
              // runNumber: ctx.reqPayloadData.runNumber,
              // checkDigit: ctx.reqPayloadData.checkDigit,
              response:
                "branchCode,accountType,customerNumber,runNumber,checkDigit,iban,accountTitle,serialNumber,marketSource,bdu,label,customerName,accountOpeningDate",
              // response:"branchCode,accountType,customerNumber,runNumber,checkDigit,iban,accountTitle,serialNumber,marketSource,bdu,label,customerName,accountOpeningDate",
              // authStatus: "U",
            };
            if(ctx.reqPayloadData && ctx.reqPayloadData.accountType){
              parameters['accountType'] = ctx.reqPayloadData.accountType
            }
            if(ctx.reqPayloadData && ctx.reqPayloadData.runNumber){
              parameters['runNumber'] = ctx.reqPayloadData.runNumber
            }
            if(ctx.reqPayloadData && ctx.reqPayloadData.checkDigit){
              parameters['checkDigit'] = ctx.reqPayloadData.checkDigit
            }
            console.log("Parameters****************************", parameters)
            trigger(
              ctx,
              accountDetail, // URL
              "GET", // Request
              parameters, // Parameters
              {
                "Content-Type": "application/json",
                Authorization: `Bearer ${await getToken(
                  process.env.CORE_API_ACCOUNT
                )}`,
              },
              "FETCH_SUCCESS",
              "FETCH_FAILURE"
            );
          },
        ],
        on: {
          FETCH_SUCCESS: {
            actions: [
              "receivedResponseToSearchBtn",
              "updateResSearchBtnCtx",
              "sendPartialCtx",
            ], // ,"updatePartialCtx","sendPartialCtx"]
            target: "MegaSet909", //CheckFinalSearchResult
          },
          FETCH_FAILURE: {
            actions: [
              "receiveErrorMessage",
              "updatePartialCtx",
              "sendPartialCtx",
            ],
            target: "MegaSet909",
          },
          KILL: "Final",
        },
      },
      //ACCCA-A05-01
      GetAccNoFromIBAN: {
        entry: [
          "spawnFetch",
          async (ctx) => {
            const parameters = {
              branchCode: ctx.reqPayloadData.brnCd,
              IBAN: ctx.reqPayloadData.iban,
              response:"accountTitle,branchCode,accountType,customerNumber,runNumber,checkDigit",
            };
            console.log("GetAccNoFromIBAN Payload****************", parameters)
            trigger(
              ctx,
              accountIBANDetail, // URL
              "GET", // Request
              parameters, // Parameters
              {
                "Content-Type": "application/json",
                Authorization: `Bearer ${await getToken(
                  process.env.CORE_API_ACCOUNT
                )}`,
              },
              "FETCH_SUCCESS",
              "FETCH_FAILURE"
            );
          },
        ],
        on: {
          FETCH_SUCCESS: {
            actions: [
              "recResAccNoIBAN",
              "updateResAccNoIBANCtx",
              "sendPartialCtx",
            ],
            target: "MegaSet909", 
          },
          FETCH_FAILURE: {
            actions: [
              "receiveErrorMessage",
              "updatePartialCtx",
              "sendPartialCtx",
            ],
            target: "MegaSet909",
          },
          KILL: "Final",
        },
      },

      Final: {
        type: "final",
        entry: ["sendPartialCtx"],
      },
    },
  },
  {
    actions: {
      // ================================= *Generic Actions* ===========================
      receiveHeader: assign({
        header: (context, event) => {
          return event.header;
        },
      }),
      recResUserGpCd: assign({
        recResUserGpCd: (ctx, event) => {
          return event.result;
        },
      }),
      sendHeaderFrntEnd: assign({
        partialCtx: (context, event) => {
          let partialCtxClone = Object.assign({}, context.partialCtx);
          partialCtxClone.header = context.header;
          return partialCtxClone;
        },
      }),

      // Get Data From FE
      reqPayloadData: assign({
        reqPayloadData: (ctx, event) => {
          return event;
        },
      }),
      loadResSearchBtn: assign({
        partialCtx: (context, event) => {
          let partialCtxClone = Object.assign({}, context.partialCtx);
          partialCtxClone.reqPayloadData = context.reqPayloadData;
          return partialCtxClone.reqPayloadData;
        },
      }),

      updateResSearchBtnCtx: assign({
        partialCtx: (context, event) => {
          let partialCtxClone = Object.assign({}, context.partialCtx);
          partialCtxClone.ResponseAPISearchBtn = context.ResponseAPISearchBtn;
          return partialCtxClone.ResponseAPISearchBtn;
        },
      }),
      updateUserGrpCdCtx: assign({
        partialCtx: (context, event) => {
          let partialCtxClone = Object.assign({}, context.partialCtx);
          partialCtxClone.recResUserGpCd = context.recResUserGpCd;
          return partialCtxClone.recResUserGpCd;
        },
      }),
      updateResAccNoIBANCtx: assign({
        partialCtx: (context, event) => {
          let partialCtxClone = Object.assign({}, context.partialCtx);
          partialCtxClone.AccNoIBAN = context.recResAccNoIBAN;
          return partialCtxClone.AccNoIBAN;
        },
      }),

      receivedResponseForAccountVerification: assign({
        AccountDetails: (ctx, event) => {
          if (Object.keys(event.result).length) {
            return event.result;
          }
          return null;
        },
      }),

      receivedResponseAccountAuthStatusPending: assign({
        ResponseAPIAuthStatusPending: (ctx, event) => {
          if (Object.keys(event.result).length) {
            return event.result;
          }
          return null;
        },
      }),

      receivedResponseAccountAuthStatusActive: assign({
        ResponseAPIAuthStatusActive: (ctx, event) => {
          if (Object.keys(event.result).length) {
            return event.result;
          }
          return null;
        },
      }),
      recResAccNoIBAN: assign({
        recResAccNoIBAN: (ctx, event) => {
          return event.result[0];
        },
      }),

      checkAccountActive: assign({
        isAccountActive: (ctx, event) => {
          const validConditionCodes = [
            13, 14, 15, 16, 17, 95, 500, 501, 502, 503, 504,
          ];
          let result = true;
          if (Object.keys(event.result).length) {
            const allConditionCodesMatch = event.result.every((item) =>
              validConditionCodes.includes(item.conditionCode)
            );
            if (allConditionCodesMatch) {
              result = false;
            }
          }
          return result;
        },
      }),

      warningForActiveAccount: assign({
        // Call on Validaate Authority Level
        errorMessage: () =>
          "Your role is not authorized for this action. The record must first be modified by a Department user.",
        mBoolean: () => true,
      }),
      resetWarningForAccountNotActive: assign({
        errorMessage: () => "",
        mBoolean: () => false,
      }),

      warningForConditionCodeNotMatch: assign({
        // If Acount not Active
        errorMessage: () =>
          "The Account Market Source has already been modified and is currently pending in Authorization",
        mBoolean: () => true,
      }),

      warningForCutoffDate: assign({
        // Cuttoff Date 2017-08-22 YYYY-MM-DD
        errorMessage: () =>
          "The Account Market Source has already been modified and is currently pending in Authorization",
        mBoolean: () => true,
      }),

      warningForAccountNotActive: assign({
        errorMessage: (ctx, event) => {
          return 'not an active account'
        },
        mBoolean: () => true,
      }),

      receivedResponseToSearchBtn: assign({
        ResponseAPISearchBtn: (ctx, event) => {
          if (Object.keys(event.result).length) {
            return event.result;
          }
          return null;
        },
      }),

      // CONTEXT to PartialCtx Transfer For FE - MegaSet909FetchDataAPI
      updatePartialCtx: assign({
        partialCtx: (ctx, event) => {
          let data = { ...ctx.partialCtx };
          if (ctx.mBoolean) {
            data.errorMessage = ctx.errorMessage;
            data.mBoolean = ctx.mBoolean;
          } else {
            data.isAccountActive = ctx.isAccountActive;
            data.ResponseAPIAuthStatusPending =
              ctx.ResponseAPIAuthStatusPending;
            data.ResponseAPIAuthStatusActive = ctx.ResponseAPIAuthStatusActive;
            data.ResponseAPISearchBtn = ctx.ResponseAPISearchBtn;
          }

          return data;
        },
      }),

      spawnFetch: assign({
        fetch: () => spawn(FetchActor),
      }),

      setmbooleanFalse: assign({
        errorMessage: () => "",
        mBoolean: () => false,
      }),

      receiveErrorMessageFromCtx: assign({
        partialCtx: (context, event) => {
          let partialCtxClone = Object.assign({}, context.partialCtx);
          partialCtxClone.errorMessage = context.errorMessage;
          partialCtxClone.mBoolean = context.mBoolean;
          return partialCtxClone;
        },
      }),

      receiveErrorMessage: assign({
        partialCtx: (context, event) => {
          let partialCtxClone = Object.assign({}, context.partialCtx);
          partialCtxClone.errorMessage = event.errorMessage;
          partialCtxClone.mBoolean = event.mBoolean;
          return partialCtxClone;
        },
      }),

      checkAuthStatus: assign({
        authStatus: (ctx, event) => event.httpStatus == 200,
        errorMessage: (ctx, event) => event.errorMessage,
        mBoolean: (ctx, event) => false,
      }),

      failedAPI: assign({
        mBoolean: (ctx, event) => true,
        errorMessage: (ctx, event) => event.errorMessage,
      })
    },
  }
);

module.exports = P_BDBM_UC1_MKTSRC_INQ;
