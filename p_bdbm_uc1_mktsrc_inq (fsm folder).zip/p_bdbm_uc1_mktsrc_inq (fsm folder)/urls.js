
const { Service } = require("@teresol-v2/fsm");
const service = new Service();

service.addList([
    /**
     * ["core-api-branch", "branchDetail"],
     * ["core-api-currency", "currencyDetail"]
     */
    // Temp TieUp
    // ["core-api-tieup", "tieupDetailInfo"],

    // Page Load
    // ["core-api-crs", "crsTaxIdentificationNumberInfo"],
    // ["core-api-crs", "crsSigningCapacityConfig"],
    // ["core-api-crs","crsAuditLog"],

    // Search Button
    // ["core-api-crs","crsReportDetail"],
    // ["core-api-crs","crsSetupDetail"],
    // ["core-api-crs","crsSetupConfig"],
    ["core-api-account","accountDetail"],
    ["core-api-account","accountIBANDetail"],
    ["core-api-user","userDetail"],

    // Save Button
    // ["core-api-crs","crsSetupAuth"],
    // ["core-api-branch", "branchDetail"],

]);

module.exports = service;