
const padLeadingZeros = (num, size) => {
    let s = num + "";
    while (s.length < size) s = "0" + s;
    return s;
}
const combineAccountFromParts = (brnCode,acType,custNo,runNo,chkDigit) => {
    return `${padLeadingZeros(brnCode,4)}${padLeadingZeros(acType,4)}${padLeadingZeros(custNo,6)}${padLeadingZeros(runNo,2)}${padLeadingZeros(chkDigit,1)}`; 
}