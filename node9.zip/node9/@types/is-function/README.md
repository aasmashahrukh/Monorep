# Installation
> `npm install --save @types/is-function`

# Summary
This package contains type definitions for is-function (https://github.com/grncdr/js-is-function).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/is-function.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/is-function/index.d.ts)
````ts
export = isFunction;
declare function isFunction(fn?: any): boolean;

````

### Additional Details
 * Last updated: Tue, 07 Nov 2023 03:09:37 GMT
 * Dependencies: none

# Credits
These definitions were written by [Evangelos Zotos](https://github.com/evangeloszotos).
