export = isFunction;
declare function isFunction(fn?: any): boolean;
