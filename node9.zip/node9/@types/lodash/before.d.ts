import { before } from "./index";
export = before;
