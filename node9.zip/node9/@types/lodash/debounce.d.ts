import { debounce } from "./index";
export = debounce;
