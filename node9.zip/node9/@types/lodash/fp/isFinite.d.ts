import { isFinite } from "../fp";
export = isFinite;
