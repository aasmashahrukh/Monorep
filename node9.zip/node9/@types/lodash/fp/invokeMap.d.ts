import { invokeMap } from "../fp";
export = invokeMap;
