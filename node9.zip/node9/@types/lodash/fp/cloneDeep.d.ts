import { cloneDeep } from "../fp";
export = cloneDeep;
