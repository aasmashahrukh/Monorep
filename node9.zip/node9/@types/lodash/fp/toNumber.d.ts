import { toNumber } from "../fp";
export = toNumber;
