import { stubTrue } from "../fp";
export = stubTrue;
