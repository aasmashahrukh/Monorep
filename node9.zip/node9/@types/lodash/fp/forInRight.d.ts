import { forInRight } from "../fp";
export = forInRight;
