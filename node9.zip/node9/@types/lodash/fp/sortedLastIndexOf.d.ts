import { sortedLastIndexOf } from "../fp";
export = sortedLastIndexOf;
