import { toLength } from "../fp";
export = toLength;
