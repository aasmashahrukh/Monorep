import { cond } from "../fp";
export = cond;
