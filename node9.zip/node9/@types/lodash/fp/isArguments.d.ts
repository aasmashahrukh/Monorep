import { isArguments } from "../fp";
export = isArguments;
