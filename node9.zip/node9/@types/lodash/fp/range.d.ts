import { range } from "../fp";
export = range;
