import { isObject } from "../fp";
export = isObject;
