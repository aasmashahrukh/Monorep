import { camelCase } from "../fp";
export = camelCase;
