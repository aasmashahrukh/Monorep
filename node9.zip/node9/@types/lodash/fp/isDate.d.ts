import { isDate } from "../fp";
export = isDate;
