import { subtract } from "../fp";
export = subtract;
