import { assignAll } from "../fp";
export = assignAll;
