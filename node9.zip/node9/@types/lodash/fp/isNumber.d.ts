import { isNumber } from "../fp";
export = isNumber;
