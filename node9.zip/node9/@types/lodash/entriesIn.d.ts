import { entriesIn } from "./index";
export = entriesIn;
