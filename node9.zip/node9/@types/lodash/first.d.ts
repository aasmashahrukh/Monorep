import { first } from "./index";
export = first;
