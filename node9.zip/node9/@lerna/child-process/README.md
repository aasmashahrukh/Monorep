# `lerna child-process`

> Lerna's internal child_process wrapper

## Usage

You probably shouldn't.

Install [lerna](https://www.npmjs.com/package/lerna) for access to the `lerna` CLI.
