const config = {}
const data = ""
const errorMessage = ""
const headers = {}
const request = null
const status = 200
const statusText = ""

const payloadData = {}

export const dto = {
    payloadData: payloadData,
    errorMessage: errorMessage,
}
