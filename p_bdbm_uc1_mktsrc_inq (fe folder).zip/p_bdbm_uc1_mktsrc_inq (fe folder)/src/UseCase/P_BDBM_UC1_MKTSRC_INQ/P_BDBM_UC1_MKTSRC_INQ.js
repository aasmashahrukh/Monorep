import { ref, watch } from "vue";
import {
  FsmAjax,
  useUseCaseViewManager,
  defineUseCaseComponent,
  defineUseCaseLoader,
} from "@teresol-v2/usecase-hoc/utils";
import helper from "@teresol-v2/usecase-hoc/helper";
import { isEmpty } from "../../utilities/machineUtils";
import { ElLoader } from "../../utilities/Loading";
import {
  combineAccountFromParts,
  splitCompleteAccountIntoParts,
} from "../../utilities/formatting.utility.js";
import { ElMessageBox } from "element-plus";
import { confirmOptions } from "../../../src/mixins/alertOption.js";
import MegaSet909 from "@teresol-v2/mega-set909";

const hocName = "P_BDBM_UC1_MKTSRC_INQ";

FsmAjax.prototype.getInquiryDetails = function (data) {   
  return this.post("SEARCH_BTN", data);
};
FsmAjax.prototype.getAccNoFromIBAN = function (data) {
  return this.post("GET_ACC_NO_FRM_IBAN", data);
};
FsmAjax.prototype.exitBtn = function () {
  return this.post("EXIT_BTN");
};
function hocSetup(props, { attrs, slots, emit, expose }) {
  const hocConfig = {
    fsmUrl: props.fsmUrl,
    batchRequired: false,
    activityCode: "BDBMINQY",
    // activityCode: "CRCARDI",
    subActivityCode: "",
  };

  // FSM AJAX helper
  const fsm = new FsmAjax(hocConfig);

  const ms909 = { 
    AccountNoIBANNo: ref("0"),
    isSrcBtnVisible: ref(true),
    AccountNoIBANNoList: ref([
      { value: "0", option: "--Select--" },
      { value: "1", option: "Account No" },
      { value: "2", option: "IBAN" },
    ]),
    IbanNoSearch: ref(""),
    userGrpCd: ref(""),
    header: {},
    AccountNoSearch: ref(""),
    AccountNo: ref(""),
    AccountTitle: ref(""),
    CustomerName: ref(""),
    AccountOpeningSource: ref(""),
    CurrentMarketSource: ref(""),
    CurrentBusinessDevelopmentForce: ref(""),
    isDisabled: ref(true),
    isEditable: ref(false),
    isAccNumVisible: ref(false),
    showDetail: ref(false),
    isInquiryDetail: ref(false),
    searchResult(val) {
      this.isAccNumVisible.value = true;
      this.isInquiryDetail.value = true;
      this.isSrcBtnVisible.value = false;
      ms909.AccountNo.value = combineAccountFromParts(
        val.branchCode,
        val.accountType,
        val.customerNumber,
        val.runNumber,
        val.checkDigit
      );
      ms909.AccountTitle.value = val.accountTitle;
      ms909.CustomerName.value = val.customerName;
      ms909.AccountOpeningSource.value = val.label;
      ms909.CurrentMarketSource.value = val.marketSource;
      ms909.CurrentBusinessDevelopmentForce.value = val.bdu;
    },
    isValidAccFormat(accNum) {
      const regex = new RegExp("^\\d{4}-\\d{4}-\\d{6}-\\d{2}-\\d{1}$");
      return regex.test(accNum);
    },
    formatAccNumOnBlur(accNum) {
      let a = accNum.replace(/\D/g, "");
      if (a.length === 17) {
        a = `${a.slice(0, 4)}-${a.slice(4, 8)}-${a.slice(8, 14)}-${a.slice(
          14,
          16
        )}-${a.slice(16)}`;
      }
      return a;
    },
    resetForm() {
      this.isSrcBtnVisible.value = true;
      this.isAccNumVisible.value = false;
    },
    isValidBranch(brnCd) {
      if (ms909.userGrpCd.value === "BDBMGRPSU") {
        return true;
      }
      if (brnCd === this.header.loginBranch) {
        return true;
      }
      if (brnCd.startsWith("5") && this.header.loginBranch.startsWith("5")) {
        return true;
      }
      if (
        this.header.loginBranch === "8888" &&
        parseInt(brnCd) >= 1 &&
        parseInt(brnCd) <= 4999
      ) {
        return true;
      }
      if (brnCd === "1001" && this.header.loginBranch === "1001") {
        return true;
      }
      if (
        parseInt(brnCd) >= 1 &&
        parseInt(brnCd) <= 4999 &&
        parseInt(this.header.loginBranch) >= 1 &&
        parseInt(this.header.loginBranch) <= 4999
      ) {
        return true;
      }

      return false;
    },
  };

  const ms909Config = ref({
    screenTitle: "Portal_Business Development Business Monitoring",
    componentProps: {
      isInquiryDetail: {
        isVisible: ms909.isInquiryDetail,
      },
      MarketSourceInquiryLabel: {
        value: "Market Source Inquiry",
        isVisible: true,
      },
      MarketSourceModLabel: {
        value: "Market Source Modify",
        isVisible: false,
      },
      AccountNoIBANNoDropdown: {
        dropDownLabel: "Account No / IBAN No.",
        colorLabel: "",
        isDisabled: false,
        isMandatory: true,
        defaultValue: ms909.AccountNoIBANNo,
        AccountNoIBANNoDropdownValues: ms909.AccountNoIBANNoList,
        isVisible: true,
      },
      IBANNoTextBoxNoLabel: {
        isDisabled: false,
        isVisible: ms909.AccountNoIBANNo.value === "2",
        IBANNoTextBoxNoLabelValue: ms909.IbanNoSearch,
        placeholder: "****_****_****_****_****_****", //IBAN
      },
      AccountNumberPrimary: {
        isDisabled: false,
        isVisible: ms909.AccountNoIBANNo.value === "1",
        AccountNumberPrimaryValue: ms909.AccountNoSearch,
        placeholder: "****-****-******-**-*", //ACCOUNT NUMBER
      },
      AccountNumber: {
        label: "Account Number",
        isDisabled: true,
        isVisible: ms909.isAccNumVisible,
        mandatory: false,
        AccountNumberValue: ms909.AccountNo,
      },
      AccountTitle: {
        label: "Account Title",
        isDisabled: true,
        mandatory: false,
        AccountTitleValue: ms909.AccountTitle,
        isVisible: true,
      },
      CustomerName: {
        label: "Customer Name",
        isDisabled: true,
        mandatory: false,
        CustomerNameValue: ms909.CustomerName,
        isVisible: true,
      },
      AccountOpeningSource: {
        label: "Account Opening Source",
        isDisabled: true,
        mandatory: false,
        AccountOpeningSourceValue: ms909.AccountOpeningSource,
        isVisible: true,
      },
      CurrentMarketSource: {
        label: "Current Market Source",
        isDisabled: true,
        mandatory: false,
        CurrentMarketSourceValue: ms909.CurrentMarketSource,
        isVisible: true,
      },
      CurrentBusinessDevelopmentForce: {
        label: "Current Business Development Force",
        isDisabled: true,
        CurrentBusinessDevelopmentForceValue:
          ms909.CurrentBusinessDevelopmentForce,
        isVisible: true,
        mandatory: false,
      },
      AccountOpeningSourceDropDown: {
        dropDownLabel: "Account Opening Source *",
        colorLabel: "",
        isDisabled: false,
        mandatory: true,
        defaultValue: "",
        CurrentBusinessDevelopmentForceDropDownValues: [],
        isVisible: false,
      },
      CurrentMarketSourceDropDown: {
        dropDownLabel: "Current Market Source *",
        colorLabel: "",
        isDisabled: false,
        mandatory: true,
        defaultValue: "",
        CurrentBusinessDevelopmentForceDropDownValues: [],
        isVisible: false,
      },
      CurrentBusinessDevelopmentForceDropDown: {
        dropDownLabel: "Current Business Development Force *",
        colorLabel: "",
        isDisabled: false,
        mandatory: true,
        defaultValue: "",
        CurrentBusinessDevelopmentForceDropDownValues: [],
        isVisible: false,
      },
      OldMarketSource: {
        label: "Old Market Source",
        isDisabled: true,
        isVisible: false,
      },
      OldBusinessDevelopmentForce: {
        label: "Old Business Development Force",
        isDisabled: true,
        isVisible: false,
      },
      Remarks: {
        label: "Remarks *",
        isDisabled: false,
        isVisible: false,
      },

      // Buttons
      SearchButton: {
        label: "Search",
        isVisible: ms909.isSrcBtnVisible,
        nativeType: "button",
        isDisabled: false,
      },
      ModifyButton: {
        label: "Modify",
        isVisible: false,
        isDisabled: false,
      },
      AuthorizeButton: {
        label: "Authorize",
        isVisible: false,
        isDisabled: false,
      },
      RejectButton: {
        label: "Reject",
        isVisible: false,
        isDisabled: false,
      },
      ExitButton: {
        label: "Exit",
        isVisible: true,
        isDisabled: false,
      },
    },
  });

  const ms909Handlers = {
    "AccountNoIBANNoDropdown-onChange": (val) => {
      ms909.resetForm();
      ms909.AccountNoIBANNo.value = val;
    },
    "IBANNoTextBoxNoLabel-onBlur": (val) => {
      ms909.IbanNoSearch.value = val;
    },
    "AccountNumberPrimary-onBlur": (val) => {
      // let formattedVal = "";
      // formattedVal = ms909.formatAccNumOnBlur(val);
      ms909.AccountNoSearch.value = val;
    },
    "AccountNumber-onBlur": (val) => {
      ms909.AccountNo.value = val;
    },
    "AccountTitle-onBlur": (val) => {
      ms909.AccountTitle.value = val;
    },
    "CustomerName-onBlur": (val) => {
      ms909.CustomerName.value = val;
    },
    "AccountOpeningSource-onBlur": (val) => {
      ms909.AccountOpeningSource.value = val;
    },
    "CurrentMarketSource-onBlur": (val) => {
      ms909.CurrentMarketSource.value = val;
    },
    "CurrentBusinessDevelopmentForce-onBlur": (val) => {
      ms909.CurrentBusinessDevelopmentForce.value = val;
    },
    "AccountOpeningSourceDropDown-onChange": (val) => {
      ms909.AccountOpeningSource.value = val;
    },
    "CurrentMarketSourceDropDown-onChange": (val) => {
      ms909.CurrentMarketSource.value = val;
    },
    "CurrentBusinessDevelopmentForceDropDown-onChange": (val) => {
      ms909.CurrentBusinessDevelopmentForce.value = val;
    },
    "SearchButton-onClick": async () => {
      let loadingIndicator = ElLoader();
      try {
        if (ms909.AccountNoIBANNo.value == 1) {
          // For Account No ms909.AccountNoSearch.value
          if (!isEmpty(ms909.AccountNoSearch.value)) {
            if (!ms909.isValidAccFormat(ms909.AccountNoSearch.value.trim())) {
              helper.alert(
                "Account number is not in correct format e.g.(XXXX-XXXX-XXXXXX-XX-X)",
                "Warning"
              );
              loadingIndicator.close();
              ms909.resetForm();
              return;
            }
            const a = splitCompleteAccountIntoParts(
              ms909.AccountNoSearch.value
            );

            if (!ms909.isValidBranch(a.branchCode)) {
              helper.alert(
                `Invalid Login branch ${ms909.header.loginBranch} and Account branch ${a.branchCode}`,
                "Warning"
              );
              loadingIndicator.close();
              return;
            }

            const payload = {};
            payload.branchCode = a.branchCode;
            payload.accountType = a.accountType;
            payload.customerNumber = a.customerNo;
            payload.runNumber = a.runningNo;
            payload.checkDigit = a.checkDigit;
            let res = await fsm.getInquiryDetails(payload);
            if (!isEmpty(res)) {
              ms909.searchResult(res[0]);
            }
          } else {
            helper.alert("Please Enter Account number", "Warning");
          }
        } else if (ms909.AccountNoIBANNo.value == 2) {
          // For IBAN
          if (!isEmpty(ms909.IbanNoSearch.value)) {
            if (ms909.IbanNoSearch.value.trim().length < 24) {
              helper.alert("IBAN is not in correct format", "Warning");
              loadingIndicator.close();
              ms909.resetForm();
              return;
            }
            const branchCode = ms909.IbanNoSearch.value.slice(8, 12);
            const a = await fsm.post("GET_ACC_NO_FRM_IBAN", {
              iban: ms909.IbanNoSearch.value,
              brnCd: branchCode
            });
            console.log("IBAN TO ACC*****",a)
            if (
              a.errorMessage &&
              a.errorMessage.includes(
                "No account detail found against the given"
              )
            ) {
              helper.alert(
                `The Account ${ms909.IbanNoSearch.value
                  .split("-")
                  .join("")} was not found.`,
                "Warning"
              );
              loadingIndicator.close();
              return;
            }
            // const branchCode = ms909.IbanNoSearch.value.slice(8, 12);
            const payload = {};
            payload.branchCode = branchCode;
            payload.accountType = a.accountType;
            payload.customerNumber = a.customerNumber;
            payload.runNumber = a.runNumber;
            payload.checkDigit = a.checkDigit;

            if (!ms909.isValidBranch(branchCode)) {
              helper.alert(
                `Invalid Login branch ${ms909.header.loginBranch} and Account branch ${branchCode}`,
                "Warning"
              );
              loadingIndicator.close();
              return;
            }

            let res = await fsm.getInquiryDetails(payload);
            if (!isEmpty(res)) {
              ms909.searchResult(res[0]);
            }
          } else {
            helper.alert("Please Enter IBAN No.", "Warning");
          }
        } else {
          helper.alert("Please select Account Type", "Warning");
        }
      } catch (error) {
        ms909.resetForm();
        console.log("Error:", error);
        console.log("Error message:", error.message);
        console.log("Error as string:", error.toString());
        if (
          error
            .toString()
            .includes("No account detail found against the given") ||
          error.toString().includes("No Account Detail found against the given")
        ) {
          const AccIBANNumber = ms909.IbanNoSearch.value
            ? ms909.IbanNoSearch.value
            : ms909.AccountNoSearch.value;
          helper.alert(
            `The Account ${AccIBANNumber.split("-").join("")} was not found.`,
            "Warning"
          );
        } else {
          if (error.toString().includes("not an active account")) {
            const AccIBANNumber = ms909.IbanNoSearch.value
              ? ms909.IbanNoSearch.value
              : ms909.AccountNoSearch.value;
            helper.alert(
              `The Account ${AccIBANNumber.split("-").join(
                ""
              )} is not an active Account.`,
              "Warning"
            );
            loadingIndicator.close();
            return;
          }
          helper.alert(error, "Warning");
        }
      }
      loadingIndicator.close();
    },
    "ModifyButton-onClick": () => {
      try {
        ms909.isEditable.value = true;
      } catch (error) {
        helper.alert(error, "Message");
      }
    },
    "ExitButton-onClick": async () => {
      ElMessageBox.confirm(
        "Are You Sure, You Want To Exit!",
        "Message",
        confirmOptions
      )
        .then(async () => {
          await fsm.exitBtn();
          CallbackExit();
        })
        .catch(() => {
          return false;
        });
    },
  };

  watch(ms909.AccountNoIBANNo, (newValue) => {
    ms909Config.value.componentProps.IBANNoTextBoxNoLabel.isVisible =
      newValue === "2";
    ms909Config.value.componentProps.AccountNumberPrimary.isVisible =
      newValue === "1";

    // Assign correct values
    ms909Config.value.componentProps.IBANNoTextBoxNoLabel.IBANNoTextBoxNoLabelValue =
      newValue === "2" ? ms909.IbanNoSearch : "";
    ms909Config.value.componentProps.AccountNumberPrimary.AccountNumberPrimaryValue =
      newValue === "1" ? ms909.AccountNoSearch : "";
  });
  // UseCase Views
  const views = [
    {
      name: "MegaSet909",
      title: ms909Config.value.screenTitle,
      component: MegaSet909,
      props: { configObj: ms909Config },
      handlers: ms909Handlers,
    },
  ];
  const { activateView, close, render, activeView, $refs } =
    useUseCaseViewManager(hocConfig, views, onInitialized, onError);

  async function checkUserGrpCd() {
    const res = await fsm.post("CHK_USER_GRPCD");
    if (res.mBoolean == false) {
      ms909.userGrpCd.value = res.groupCode;
    }
    console.log("CHK_USER_GRPCD************************", res);
  }
  function onInitialized(res) {
    ms909.header = res.header;
    checkUserGrpCd();
    activateView("MegaSet909");
  }

  function onError(error, source) {
    helper.alert(error, `${source} - Error`);
  }

  // Return render function
  function Callback(view) {
    activateView(view);
  }

  function CallbackExit() {
    close(false);
  }
  return render;
}
const UseCaseLoader = defineUseCaseLoader(hocName, hocSetup);
export default UseCaseLoader;
