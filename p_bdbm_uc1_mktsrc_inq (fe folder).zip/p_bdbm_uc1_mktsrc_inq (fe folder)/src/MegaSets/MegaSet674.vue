<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row :lg="24" :md="24">
      <el-col :lg="12" :md="12">
        <label class="headingStyle2">{{ configObject.FieldSetLabel.label }}</label>
      </el-col>
      <el-col :lg="7" :md="7">
      </el-col>
      <el-col :lg="5" :md="5">
        <BackButton
            @GenericButton-onClick="
              (val) => {
                $emit('BackButton-onClick', val);
              }
            "
            v-bind="{ ...BackButton, ...configObject.BackButton }"
            name="BackButton"
            ref="RefBackButton"
            v-if="configObject.BackButton.isVisible"
        ></BackButton>
      </el-col>
  </el-row>
    <fieldset>
      <!-- <legend>{{ configObject.FieldSetLabel.label }}</legend> -->
      <el-row :lg="24" :md="24">
        <el-col :lg="12" :md="12">
          <AccountTypeDropDown
            @GenericDropDown-onChange="
              (val) => $emit('AccountTypeDropDown-onChange', val)
            "
            v-bind="{
              ...AccountTypeDropDown,
              ...configObject.AccountTypeDropDown,
            }"
            :values="configObject.AccountTypeDropDown.values"
            name="AccountTypeDropDown"
            ref="RefAccountType"
            v-if="configObject.AccountTypeDropDown.isVisible"
          >
          </AccountTypeDropDown>
        </el-col>
        <el-col :lg="12" :md="12">
          <AccountNumber
            @AccountNumberNumericDashes21-onBlur="
              (val) => $emit('AccountNumber-onBlur', val)
            "
            v-bind="{ ...AccountNumber, ...configObject.AccountNumber }"
            name="AccountNumber"
            ref="RefAccountNumber"
            v-if="configObject.AccountNumber.isVisible"
          >
          </AccountNumber>
          <Iban
            @IbanAlphaNumeric24-onBlur="(val) => $emit('Iban-onBlur', val)"
            v-bind="{ ...Iban, ...configObject.Iban }"
            name="Iban"
            ref="RefIban"
            v-if="configObject.Iban.isVisible"
          >
          </Iban>
        </el-col>
      </el-row>

      <br />
      <el-row :lg="24" :md="24">
        <el-col :lg="5" :md="5">
          <SearchButton
            @GenericButton-onClick="
              (val) => {
                $emit('SearchButton-onClick', val);
              }
            "
            v-bind="{ ...SearchButton, ...configObject.SearchButton }"
            name="SearchButton"
            ref="RefSearchButton"
            v-if="configObject.SearchButton.isVisible"
          ></SearchButton>
        </el-col>
      </el-row>
      <br />
      <el-row :lg="24" :md="24">
        <el-col :lg="24" :md="24">
          <AccountDetailTable
            name="AccountDetailTable"
            @GenericSortableTableView-onCurrentRow="
              (val) => {
                $emit('AccountDetailTable-onCurrentRow', val);
              }
            "
            @GenericSortableTableView-onClickRow="
              (val) => {
                $emit('AccountDetailTable-onClick', val);
              }
            "
            @GenericSortableTableView-onDoubleClickRow="
              (val) => {
                $emit('AccountDetailTable-onDoubleClickRow', val);
              }
            "
            v-bind="{
              ...AccountDetailTable,
              ...configObject.AccountDetailTable,
            }"
            ref="RefAccountDetailTable"
            v-if="configObject.AccountDetailTable.isVisible"
          />
        </el-col>
      </el-row>
    </fieldset>
  </Form>
</template>
<script>
import { Form, useForm } from "vee-validate";
import { reactive } from "vue";
import {
  AccountNumberNumericDashes21 as AccountNumber,
  IbanAlphaNumeric24 as Iban,
  GenericDropDown as AccountTypeDropDown,
  GenericButton as SearchButton,
  GenericButton as BackButton,
  GenericSortableTableView as AccountDetailTable,
} from "@teresol-v2/ui-components";
export default {
  name: "MegaSet674",

  components: {
    Form,
    BackButton,
    AccountTypeDropDown,
    AccountNumber,
    Iban,
    SearchButton,
    AccountDetailTable,
  },
  props: {
    configObj: {},
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit("onSubmit", values);
    }
    const configObject = reactive({
      ...props.configObj.componentProps,
    });

    return {
      onSubmit,
      configObject,
      AccountNumber: {
        textColor: "black",
        labelColor: "black",
        backgroundColor: "white",

        spanInputs: 12,
        spanLabels: 1,
        // label: 'Account Number',
        placeholder: "XXXX-XXXX-XXXXXX-XX-X",
      },

      Iban: {
        spanInputs: 12,
        spanLabels: 1,
        textColor: "black",
        labelColor: "black",
        backgroundColor: "white",
        // label: 'IBAN',
        placeholder: "****-****-****-****-****-****",
        toolTip: "Provide IBAN",
        // tooltip:true,XXXX-XXXX-XXXX-XXXX-XXXX-XXXX
      },
      AccountTypeDropDown: {
        spanInputs: 10,
        spanLabels: 7,
        dropDownLabel: "Account No /IBAN No",
      },

      SearchButton: {
        nativeType: "submit",
        // spanLabels: 20,
        spanInputs: 10,
        backgroundColor: "green",
        fontSizeLabel: "bolder",

        // label: 'Search'
      },
      BackButton:{
        nativeType: "button",
        // spanLabels: 20,
        spanInputs: 10,
        backgroundColor: "green",
        fontSizeLabel: "bolder",
      },
      AccountDetailTable: {
        textColor: "black",
        labelColor: "black",
        backgroundColor: "white",
        tableHeight: "150px",
      },
    };
  },
};
</script>
<style scoped>
.labelSize {
  font-size: 13px;
}

.headingStyle3 {
  display: block;
  font-size: 1.2rem;
  font-weight: bold;
  margin-bottom: 0.2rem;
  margin-top: 0.5rem;
}
.headingStyle2 {
  display: block;
  font-size: 1.2rem;
  font-weight: bold;
  margin-bottom: 0.3rem;
  margin-top: 0.5rem;
}
</style>