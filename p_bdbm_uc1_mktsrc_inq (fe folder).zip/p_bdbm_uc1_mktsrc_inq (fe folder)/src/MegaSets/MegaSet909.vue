<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row>
      <el-col :lg="24" :md="24">
        <el-col
          :lg="10"
          :md="10"
          v-if="configObject.MarketSourceInquiryLabel.isVisible"
        >
          <legend class="_custom_heading">
            {{ configObject.MarketSourceInquiryLabel.value }}
          </legend>
          <el-form-item></el-form-item>
        </el-col>
      </el-col>
      <el-col :lg="24" :md="24">
        <el-col
          :lg="10"
          :md="10"
          v-if="configObject.MarketSourceModLabel.isVisible"
        >
          <legend class="_custom_heading">
            {{ configObject.MarketSourceModLabel.value }}
          </legend>
          <el-form-item></el-form-item>
        </el-col>
      </el-col>
    </el-row>
    <fieldset>
      <el-row>
        <el-col :lg="12" :md="12">
          <AccountNoIBANNoDropdown
            v-bind="{
              ...AccountNoIBANNoDropdown,
              ...configObject.AccountNoIBANNoDropdown,
            }"
            :values="
              configObject.AccountNoIBANNoDropdown.AccountNoIBANNoDropdownValues
            "
            name="AccountNoIBANNoDropdown"
            ref="RefAccountNoIBANNoDropdown"
            v-if="configObject.AccountNoIBANNoDropdown.isVisible"
            @GenericDropDown-onChange="
              (val) => {
                $emit('AccountNoIBANNoDropdown-onChange', val);
              }
            "
          />
        </el-col>
        <el-col :lg="12" :md="12">
          <IbanAlphaNumeric24
            @IbanAlphaNumeric24-onBlur="
              (val) => {
                $emit('IBANNoTextBoxNoLabel-onBlur', val);
              }
            "
            @IbanAlphaNumeric24-onChange="
              (val) => {
                $emit('IBANNoTextBoxNoLabel-onChange', val);
              }
            "
            @IbanAlphaNumeric24-onKeypress="
              (val) => {
                $emit('IBANNoTextBoxNoLabel-onKeyPress', val);
              }
            "
            @IbanAlphaNumeric24-onKeyup="
              (val) => {
                $emit('IBANNoTextBoxNoLabel-onKeyUp', val);
              }
            "
            @IbanAlphaNumeric24-onFocus="
              (val) => {
                $emit('IBANNoTextBoxNoLabel-onFocus', val);
              }
            "
            v-bind="{
              ...IBANNoTextBoxNoLabel,
              ...configObject.IBANNoTextBoxNoLabel,
            }"
            :values="
              configObject.IBANNoTextBoxNoLabel.IBANNoTextBoxNoLabelValue
            "
            name="IBANNoTextBoxNoLabel"
            ref="RefIBANNoTextBoxNoLabel"
            v-if="configObject.IBANNoTextBoxNoLabel.isVisible"
          />

          <AccountNumberNumericDashes21
            @AccountNumberNumericDashes21-onChange="
              (val) => {
                $emit('AccountNumberPrimary-onChange', val);
              }
            "
            @AccountNumberNumericDashes21-onBlur="
              (val) => {
                $emit('AccountNumberPrimary-onBlur', val);
              }
            "
            @AccountNumberNumericDashes21-onKeyPress="
              (val) => {
                $emit('AccountNumberPrimary-onKeyPress', val);
              }
            "
            @AccountNumberNumericDashes21-onKeyUp="
              (val) => {
                $emit('AccountNumberPrimary-onKeyUp', val);
              }
            "
            @AccountNumberNumericDashes21-onFocus="
              (val) => {
                $emit('AccountNumberPrimary-onFocus', val);
              }
            "
            v-bind="{
              ...AccountNumberPrimary,
              ...configObject.AccountNumberPrimary,
            }"
            :values="
              configObject.AccountNumberPrimary.AccountNumberPrimaryValue
            "
            name="AccountNumberPrimary"
            ref="RefAccountNumberPrimary"
            v-if="configObject.AccountNumberPrimary.isVisible"
          />
        </el-col>
        <!-- <el-col :lg="4" :md="4">
          <AccSearchButton
            @AccSearchButton-onClick="
              (val) => {
                $emit('SearchButton-onClick');
              }
            "
            name="AccSearchButton"
            ref="RefAccSearchButton"
            v-bind="{ ...AccSearchButton, ...configObject.AccSearchButton }"
            v-if="configObject.AccSearchButton.isVisible"
          />
        </el-col> -->
      </el-row>

      <el-row>
        <el-col :lg="4" :md="4"></el-col>
      </el-row>
    </fieldset>
    <el-form-item></el-form-item>

    <!-- START: CONDITIONAL FORM -->
    <fieldset v-if="configObject.isInquiryDetail.isVisible">
      <el-row>
        <el-col :lg="24" :md="24" class="bordered-grid-ms909">
          <AccountNumberNumericDashes21
            @AccountNumberNumericDashes21-onChange="
              (val) => {
                $emit('AccountNumber-onChange', val);
              }
            "
            @AccountNumberNumericDashes21-onBlur="
              (val) => {
                $emit('AccountNumber-onBlur', val);
              }
            "
            @AccountNumberNumericDashes21-onKeyPress="
              (val) => {
                $emit('AccountNumber-onKeyPress', val);
              }
            "
            @AccountNumberNumericDashes21-onKeyUp="
              (val) => {
                $emit('AccountNumber-onKeyUp', val);
              }
            "
            @AccountNumberNumericDashes21-onFocus="
              (val) => {
                $emit('AccountNumber-onFocus', val);
              }
            "
            v-bind="{ ...AccountNumber, ...configObject.AccountNumber }"
            :values="configObject.AccountNumber.AccountNumberValue"
            name="AccountNumber"
            ref="RefAccountNumber"
            v-if="configObject.AccountNumber.isVisible"
          />
          <AccountTitleTextBox
            @AccountTitleTextBox-onChange="
              (val) => {
                $emit('AccountTitle-onChange', val);
              }
            "
            @AccountTitleTextBox-onBlur="
              (val) => {
                emit('AccountTitle-onBlur', val);
              }
            "
            @AccountTitleTextBox-onKeyPress="
              (val) => {
                $emit('AccountTitle-onKeyPress', val);
              }
            "
            @AccountTitleTextBox-onKeyUp="
              (val) => {
                $emit('AccountTitle-onKeyUp', val);
              }
            "
            @AccountTitleTextBox-onFocus="
              (val) => {
                $emit('AccountTitle-onFocus', val);
              }
            "
            v-bind="{ ...AccountTitle, ...configObject.AccountTitle }"
            :values="configObject.AccountTitle.AccountTitleValue"
            name="AccountTitle"
            ref="RefAccountTitle"
            v-if="configObject.AccountTitle.isVisible"
          />

          <CustomerNameTextBox
            @CustomerNameTextBox-onChange="
              (val) => {
                $emit('CustomerName-onChange', val);
              }
            "
            @CustomerNameTextBox-onBlur="
              (val) => {
                emit('CustomerName-onBlur', val);
              }
            "
            @CustomerNameTextBox-onKeyPress="
              (val) => {
                $emit('CustomerName-onKeyPress', val);
              }
            "
            @CustomerNameTextBox-onKeyUp="
              (val) => {
                $emit('CustomerName-onKeyUp', val);
              }
            "
            @CustomerNameTextBox-onFocus="
              (val) => {
                $emit('CustomerName-onFocus', val);
              }
            "
            v-bind="{ ...CustomerName, ...configObject.CustomerName }"
            :values="configObject.CustomerName.CustomerNameValue"
            name="CustomerName"
            ref="RefCustomerName"
            v-if="configObject.CustomerName.isVisible"
          />

          <AccountOpeningSourceTextBox
            @AccountOpeningSourceTextBox-onChange="
              (val) => {
                $emit('AccountOpeningSource-onChange', val);
              }
            "
            @AccountOpeningSourceTextBox-onBlur="
              (val) => {
                emit('AccountOpeningSource-onBlur', val);
              }
            "
            @AccountOpeningSourceTextBox-onKeyPress="
              (val) => {
                $emit('AccountOpeningSource-onKeyPress', val);
              }
            "
            @AccountOpeningSourceTextBox-onKeyUp="
              (val) => {
                $emit('AccountOpeningSource-onKeyUp', val);
              }
            "
            @AccountOpeningSourceTextBox-onFocus="
              (val) => {
                $emit('AccountOpeningSource-onFocus', val);
              }
            "
            v-bind="{
              ...AccountOpeningSource,
              ...configObject.AccountOpeningSource,
            }"
            :values="
              configObject.AccountOpeningSource.AccountOpeningSourceValue
            "
            name="AccountOpeningSource"
            ref="RefAccountOpeningSource"
            v-if="configObject.AccountOpeningSource.isVisible"
          />

          <CurrentMarketSourceTextBox
            @CurrentMarketSourceTextBox-onChange="
              (val) => {
                $emit('CurrentMarketSource-onChange', val);
              }
            "
            @CurrentMarketSourceTextBox-onBlur="
              (val) => {
                emit('CurrentMarketSource-onBlur', val);
              }
            "
            @CurrentMarketSourceTextBox-onKeyPress="
              (val) => {
                $emit('CurrentMarketSource-onKeyPress', val);
              }
            "
            @CurrentMarketSourceTextBox-onKeyUp="
              (val) => {
                $emit('CurrentMarketSource-onKeyUp', val);
              }
            "
            @CurrentMarketSourceTextBox-onFocus="
              (val) => {
                $emit('CurrentMarketSource-onFocus', val);
              }
            "
            v-bind="{
              ...CurrentMarketSource,
              ...configObject.CurrentMarketSource,
            }"
            :values="configObject.CurrentMarketSource.CurrentMarketSourceValue"
            name="CurrentMarketSource"
            ref="RefCurrentMarketSource"
            v-if="configObject.CurrentMarketSource.isVisible"
          />

          <CurrentBusinessDevelopmentForceTextBox
            @CurrentBusinessDevelopmentForceTextBox-onChange="
              (val) => {
                $emit('CurrentBusinessDevelopmentForce-onChange', val);
              }
            "
            @CurrentBusinessDevelopmentForceTextBox-onBlur="
              (val) => {
                emit('CurrentBusinessDevelopmentForce-onBlur', val);
              }
            "
            @CurrentBusinessDevelopmentForceTextBox-onKeyPress="
              (val) => {
                $emit('CurrentBusinessDevelopmentForce-onKeyPress', val);
              }
            "
            @CurrentBusinessDevelopmentForceTextBox-onKeyUp="
              (val) => {
                $emit('CurrentBusinessDevelopmentForce-onKeyUp', val);
              }
            "
            @CurrentBusinessDevelopmentForceTextBox-onFocus="
              (val) => {
                $emit('CurrentBusinessDevelopmentForce-onFocus', val);
              }
            "
            v-bind="{
              ...CurrentBusinessDevelopmentForce,
              ...configObject.CurrentBusinessDevelopmentForce,
            }"
            :values="
              configObject.CurrentBusinessDevelopmentForce
                .CurrentBusinessDevelopmentForceValue
            "
            name="CurrentBusinessDevelopmentForce"
            ref="RefCurrentBusinessDevelopmentForce"
            v-if="configObject.CurrentBusinessDevelopmentForce.isVisible"
          />

          <GenericDropDown
            v-bind="{
              ...AccountOpeningSourceDropDown,
              ...configObject.AccountOpeningSourceDropDown,
            }"
            :values="
              configObject.AccountOpeningSourceDropDown
                .AccountOpeningSourceDropDownValues
            "
            name="AccountOpeningSourceDropDown"
            ref="RefAccountOpeningSourceDropDown"
            v-if="configObject.AccountOpeningSourceDropDown.isVisible"
            @GenericDropDown-onChange="
              (val) => {
                $emit('AccountOpeningSourceDropDown-onChange', val);
              }
            "
          />

          <GenericDropDown
            v-bind="{
              ...CurrentMarketSourceDropDown,
              ...configObject.CurrentMarketSourceDropDown,
            }"
            :values="
              configObject.CurrentMarketSourceDropDown
                .CurrentMarketSourceDropDownValues
            "
            name="CurrentMarketSourceDropDown"
            ref="RefCurrentMarketSourceDropDown"
            v-if="configObject.CurrentMarketSourceDropDown.isVisible"
            @GenericDropDown-onChange="
              (val) => {
                $emit('CurrentMarketSourceDropDown-onChange', val);
              }
            "
          />

          <GenericDropDown
            v-bind="{
              ...CurrentBusinessDevelopmentForceDropDown,
              ...configObject.CurrentBusinessDevelopmentForceDropDown,
            }"
            :values="
              configObject.CurrentBusinessDevelopmentForceDropDown
                .CurrentBusinessDevelopmentForceDropDownValues
            "
            name="CurrentBusinessDevelopmentForceDropDown"
            ref="RefCurrentBusinessDevelopmentForceDropDown"
            v-if="
              configObject.CurrentBusinessDevelopmentForceDropDown.isVisible
            "
            @GenericDropDown-onChange="
              (val) => {
                $emit('CurrentBusinessDevelopmentForceDropDown-onChange', val);
              }
            "
          />

          <OldMarketSourceTextBox
            @OldMarketSourceTextBox-onChange="
              (val) => {
                $emit('OldMarketSource-onChange', val);
              }
            "
            @OldMarketSourceTextBox-onBlur="
              (val) => {
                emit('OldMarketSource-onBlur', val);
              }
            "
            @OldMarketSourceTextBox-onKeyPress="
              (val) => {
                $emit('OldMarketSource-onKeyPress', val);
              }
            "
            @OldMarketSourceTextBox-onKeyUp="
              (val) => {
                $emit('OldMarketSource-onKeyUp', val);
              }
            "
            @OldMarketSourceTextBox-onFocus="
              (val) => {
                $emit('OldMarketSource-onFocus', val);
              }
            "
            v-bind="{ ...OldMarketSource, ...configObject.OldMarketSource }"
            :values="configObject.OldMarketSource.OldMarketSourceValue"
            name="OldMarketSource"
            ref="RefOldMarketSource"
            v-if="configObject.OldMarketSource.isVisible"
          />

          <OldBusinessDevelopmentForceTextBox
            @OldBusinessDevelopmentForceTextBox-onChange="
              (val) => {
                $emit('OldBusinessDevelopmentForce-onChange', val);
              }
            "
            @OldBusinessDevelopmentForceTextBox-onBlur="
              (val) => {
                emit('OldBusinessDevelopmentForce-onBlur', val);
              }
            "
            @OldBusinessDevelopmentForceTextBox-onKeyPress="
              (val) => {
                $emit('OldBusinessDevelopmentForce-onKeyPress', val);
              }
            "
            @OldBusinessDevelopmentForceTextBox-onKeyUp="
              (val) => {
                $emit('OldBusinessDevelopmentForce-onKeyUp', val);
              }
            "
            @OldBusinessDevelopmentForceTextBox-onFocus="
              (val) => {
                $emit('OldBusinessDevelopmentForce-onFocus', val);
              }
            "
            v-bind="{
              ...OldBusinessDevelopmentForce,
              ...configObject.OldBusinessDevelopmentForce,
            }"
            :values="
              configObject.OldBusinessDevelopmentForce
                .OldBusinessDevelopmentForceValue
            "
            name="OldBusinessDevelopmentForce"
            ref="RefOldBusinessDevelopmentForce"
            v-if="configObject.OldBusinessDevelopmentForce.isVisible"
          />

          <RemarksTextArea
            v-bind="{ ...Remarks, ...configObject.Remarks }"
            :values="configObject.Remarks.RemarksValue"
            name="Remarks"
            ref="RefRemarks"
            v-if="configObject.Remarks.isVisible"
          />
        </el-col>
      </el-row>
    </fieldset>
    <el-form-item></el-form-item>
    <!-- End -->
    <!-- START: BUTTONS -->
    <el-row>
      <!-- <el-col :lg="2" :md="2"></el-col> -->
      <el-col :lg="4" :md="4">
        <GenericButton
          @GenericButton-onClick="(val) => {$emit('SearchButton-onClick')}"
          name="SearchButton"
          ref="RefSearchButton"
          v-bind="{ ...SearchButton, ...configObject.SearchButton }"
          v-if="configObject.SearchButton.isVisible"
        />
        <GenericButton
          @GenericButton-onClick="() => {$emit('ModifyButton-onClick')}"
          name="ModifyButton"
          ref="RefModifyButton"
          v-bind="{ ...ModifyButton, ...configObject.ModifyButton }"
          v-if="configObject.ModifyButton.isVisible"
        />
        <AuthorizeButton
          @AuthorizeButton-onClick="
            (val) => {
              $emit('AuthorizeButton-onClick');
            }
          "
          @AuthorizeButton-onFocus="
            (val) => {
              $emit('AuthorizeButton-onFocus');
            }
          "
          name="AuthorizeButton"
          ref="RefAuthorizeButton"
          v-bind="{ ...AuthorizeButton, ...configObject.AuthorizeButton }"
          v-if="configObject.AuthorizeButton.isVisible"
        />
      </el-col>
      <!-- <el-col :lg="16" :md="16"></el-col> -->
      <!-- <el-col :lg="4" :md="4" v-if="configObject.ModifyButton.isVisible">
        
      </el-col>
      <el-col :lg="4" :md="4" v-if="configObject.ModifyButton.isVisible || configObject.SearchButton.isVisible"></el-col>
      <el-col :lg="24" :md="24" v-if="configObject.SearchButton.isVisible && configObject.ModifyButton.isVisible && configObject.AuthorizeButton.isVisible"></el-col>
      <el-col :lg="4" :md="4">
        
      </el-col> -->

      <el-col :lg="4" :md="4">
        <RejectButton
          @RejectButton-onClick="
            (val) => {
              $emit('RejectButton-onClick');
            }
          "
          @RejectButton-onFocus="
            (val) => {
              $emit('RejectButton-onFocus');
            }
          "
          name="RejectButton"
          ref="RefRejectButton"
          v-bind="{ ...RejectButton, ...configObject.RejectButton }"
          v-if="configObject.RejectButton.isVisible"
        />
      </el-col>
      <el-col
        :lg="8"
        :md="8"
        v-if="configObject.AuthorizeButton.isVisible"
      ></el-col>
      <!-- <el-col :lg="4" :md="4"></el-col> -->
      <el-col :lg="4" :md="4">
        <GenericButton
          @GenericButton-onClick="() => {$emit('ExitButton-onClick')}"
          name="ExitButton"
          ref="RefExitButton"
          v-bind="{ ...ExitButton, ...configObject.ExitButton }"
          v-if="configObject.ExitButton.isVisible"
        />
      </el-col>
    </el-row>
  </Form>
</template>
<script>
import { Form, useForm } from "vee-validate";
import { reactive } from "vue";
import {
  GenericDropDown as AccountNoIBANNoDropdown,
  AccountNumberNumericDashes21,
  IbanAlphaNumeric24,
  // GlAccountNumberAlphaNumericSpecial18,
  // GenericTextBox,
  GenericDropDown,
  GenericTextBox as AccountTitleTextBox,
  GenericTextBox as CustomerNameTextBox,
  GenericTextBox as AccountOpeningSourceTextBox,
  GenericTextBox as CurrentMarketSourceTextBox,
  GenericTextBox as CurrentBusinessDevelopmentForceTextBox,
  GenericTextBox as OldMarketSourceTextBox,
  GenericTextBox as OldBusinessDevelopmentForceTextBox,
  // GenericDropDown as AccountOpeningSourceDropDown,
  // GenericDropDown as CurrentMarketSourceDropDown,
  // GenericDropDown as CurrentBusinessDevelopmentForceDropDown,
  GenericTextArea as RemarksTextArea,
  GenericButton,
  // GenericButton as SearchButton,
  // GenericButton as AccSearchButton,
  // GenericButton as ModifyButton,
  GenericButton as AuthorizeButton,
  GenericButton as RejectButton,
  // GenericButton as ExitButton,
} from "@teresol-v2/ui-components";

const LabelsColumn = 8;
const InputsColumn = 15;

export default {
  name: "MegaSet909",
  components: {
    Form,
    AccountNoIBANNoDropdown,
    // AccountOpeningSourceDropDown,
    // CurrentMarketSourceDropDown,
    // CurrentBusinessDevelopmentForceDropDown,
    AccountNumberNumericDashes21,
    IbanAlphaNumeric24,
    GenericDropDown,
    // GlAccountNumberAlphaNumericSpecial18,
    // GenericTextBox,
    AccountTitleTextBox,
    CustomerNameTextBox,
    AccountOpeningSourceTextBox,
    CurrentMarketSourceTextBox,
    OldMarketSourceTextBox,
    OldBusinessDevelopmentForceTextBox,
    CurrentBusinessDevelopmentForceTextBox,
    RemarksTextArea,
    GenericButton,
    // SearchButton,
    // AccSearchButton,
    // ModifyButton,
    AuthorizeButton,
    RejectButton,
    // ExitButton,
  },
  props: {
    configObj: {},
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit("onSubmit", values);
    }
    const configObject = reactive({
      ...props.configObj.componentProps,
    });

    return {
      onSubmit,
      configObject,
      MarketSourceInquiryLabel: {
        spanLabels: 8,
      },
      AccountNoIBANNoDropdown: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      IBANNoTextBoxNoLabel: {
        spanLabels: 0,
        spanInputs: InputsColumn,
      },
      AccountNumberPrimary: {
        spanLabels: 0,
        spanInputs: InputsColumn,
      },
      AccountNumber: {
        // AccountNumber
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      AccountTitle: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      CustomerName: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      AccountOpeningSource: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      CurrentMarketSource: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      CurrentBusinessDevelopmentForce: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      AccountOpeningSourceDropDown: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      CurrentMarketSourceDropDown: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      CurrentBusinessDevelopmentForceDropDown: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      OldMarketSource: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      OldBusinessDevelopmentForce: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      Remarks: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      SearchButton: {
        spanLabels: LabelsColumn,
        spanInputs: InputsColumn,
      },
      AccSearchButton: {
        spanInputs: InputsColumn,
      },
      ModifyButton: {
        spanInputs: InputsColumn,
      },
      AuthorizeButton: {
        spanInputs: InputsColumn,
      },
      RejectButton: {
        spanInputs: InputsColumn,
      },
      ExitButton: {
        spanInputs: InputsColumn,
      },
    };
  },
};
</script>
