var assertClassBrand = require("./assertClassBrand.js");
function _classPrivateMethodGet(s, a, r) {
  return assertClassBrand(a, s), r;
}
module.exports = _classPrivateMethodGet, module.exports.__esModule = true, module.exports["default"] = module.exports;