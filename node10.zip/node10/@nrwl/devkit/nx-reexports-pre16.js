"use strict";
/**
 * STOP! Do not change this file!
 *
 * If you need to export something from nx, it should go into nx/src/devkit-exports
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.cacheDir = exports.Hasher = exports.defaultTasksRunner = exports.getOutputsForTargetAndConfiguration = exports.readCachedProjectGraph = exports.createProjectGraphAsync = exports.reverse = exports.appRootPath = exports.workspaceRoot = exports.detectWorkspaceScope = exports.getImportPath = exports.normalizePath = exports.joinPathFragments = exports.stripIndents = exports.writeJsonFile = exports.readJsonFile = exports.stripJsonComments = exports.serializeJson = exports.parseJson = exports.updateJson = exports.writeJson = exports.readJson = exports.ProjectGraphBuilder = exports.DependencyType = exports.getWorkspacePath = exports.isStandaloneProject = exports.updateWorkspaceConfiguration = exports.readWorkspaceConfiguration = exports.updateNxJson = exports.readNxJson = exports.getProjects = exports.updateProjectConfiguration = exports.removeProjectConfiguration = exports.readProjectConfiguration = exports.addProjectConfiguration = exports.runExecutor = exports.getPackageManagerVersion = exports.detectPackageManager = exports.getPackageManagerCommand = exports.output = exports.logger = exports.workspaceLayout = exports.readAllWorkspaceConfiguration = exports.Workspaces = void 0;
/**
 * @category Workspace
 */
var workspaces_1 = require("nx/src/config/workspaces");
Object.defineProperty(exports, "Workspaces", { enumerable: true, get: function () { return workspaces_1.Workspaces; } });
// TODO (v16): Change this to export from 'nx/src/config/configuration'
var file_utils_1 = require("nx/src/project-graph/file-utils");
Object.defineProperty(exports, "readAllWorkspaceConfiguration", { enumerable: true, get: function () { return file_utils_1.readAllWorkspaceConfiguration; } });
Object.defineProperty(exports, "workspaceLayout", { enumerable: true, get: function () { return file_utils_1.workspaceLayout; } });
/**
 * @category Logger
 */
var logger_1 = require("nx/src/utils/logger");
Object.defineProperty(exports, "logger", { enumerable: true, get: function () { return logger_1.logger; } });
/**
 * @category Utils
 */
var output_1 = require("nx/src/utils/output");
Object.defineProperty(exports, "output", { enumerable: true, get: function () { return output_1.output; } });
/**
 * @category Package Manager
 */
var package_manager_1 = require("nx/src/utils/package-manager");
Object.defineProperty(exports, "getPackageManagerCommand", { enumerable: true, get: function () { return package_manager_1.getPackageManagerCommand; } });
Object.defineProperty(exports, "detectPackageManager", { enumerable: true, get: function () { return package_manager_1.detectPackageManager; } });
Object.defineProperty(exports, "getPackageManagerVersion", { enumerable: true, get: function () { return package_manager_1.getPackageManagerVersion; } });
/**
 * @category Commands
 */
var run_1 = require("nx/src/command-line/run");
Object.defineProperty(exports, "runExecutor", { enumerable: true, get: function () { return run_1.runExecutor; } });
/**
 * @category Generators
 */
var project_configuration_1 = require("nx/src/generators/utils/project-configuration");
Object.defineProperty(exports, "addProjectConfiguration", { enumerable: true, get: function () { return project_configuration_1.addProjectConfiguration; } });
Object.defineProperty(exports, "readProjectConfiguration", { enumerable: true, get: function () { return project_configuration_1.readProjectConfiguration; } });
Object.defineProperty(exports, "removeProjectConfiguration", { enumerable: true, get: function () { return project_configuration_1.removeProjectConfiguration; } });
Object.defineProperty(exports, "updateProjectConfiguration", { enumerable: true, get: function () { return project_configuration_1.updateProjectConfiguration; } });
Object.defineProperty(exports, "getProjects", { enumerable: true, get: function () { return project_configuration_1.getProjects; } });
/**
 * @category Generators
 */
var project_configuration_2 = require("nx/src/generators/utils/project-configuration");
Object.defineProperty(exports, "readNxJson", { enumerable: true, get: function () { return project_configuration_2.readNxJson; } });
Object.defineProperty(exports, "updateNxJson", { enumerable: true, get: function () { return project_configuration_2.updateNxJson; } });
Object.defineProperty(exports, "readWorkspaceConfiguration", { enumerable: true, get: function () { return project_configuration_2.readWorkspaceConfiguration; } });
Object.defineProperty(exports, "updateWorkspaceConfiguration", { enumerable: true, get: function () { return project_configuration_2.updateWorkspaceConfiguration; } });
Object.defineProperty(exports, "isStandaloneProject", { enumerable: true, get: function () { return project_configuration_2.isStandaloneProject; } });
Object.defineProperty(exports, "getWorkspacePath", { enumerable: true, get: function () { return project_configuration_2.getWorkspacePath; } });
/**
 * @category Project Graph
 */
var project_graph_1 = require("nx/src/config/project-graph");
Object.defineProperty(exports, "DependencyType", { enumerable: true, get: function () { return project_graph_1.DependencyType; } });
/**
 * @category Project Graph
 */
var project_graph_builder_1 = require("nx/src/project-graph/project-graph-builder");
Object.defineProperty(exports, "ProjectGraphBuilder", { enumerable: true, get: function () { return project_graph_builder_1.ProjectGraphBuilder; } });
/**
 * @category Utils
 */
var json_1 = require("nx/src/generators/utils/json");
Object.defineProperty(exports, "readJson", { enumerable: true, get: function () { return json_1.readJson; } });
Object.defineProperty(exports, "writeJson", { enumerable: true, get: function () { return json_1.writeJson; } });
Object.defineProperty(exports, "updateJson", { enumerable: true, get: function () { return json_1.updateJson; } });
/**
 * @category Utils
 */
var json_2 = require("nx/src/utils/json");
Object.defineProperty(exports, "parseJson", { enumerable: true, get: function () { return json_2.parseJson; } });
Object.defineProperty(exports, "serializeJson", { enumerable: true, get: function () { return json_2.serializeJson; } });
Object.defineProperty(exports, "stripJsonComments", { enumerable: true, get: function () { return json_2.stripJsonComments; } });
/**
 * @category Utils
 */
var fileutils_1 = require("nx/src/utils/fileutils");
Object.defineProperty(exports, "readJsonFile", { enumerable: true, get: function () { return fileutils_1.readJsonFile; } });
Object.defineProperty(exports, "writeJsonFile", { enumerable: true, get: function () { return fileutils_1.writeJsonFile; } });
/**
 * @category Utils
 */
var strip_indents_1 = require("nx/src/utils/strip-indents");
Object.defineProperty(exports, "stripIndents", { enumerable: true, get: function () { return strip_indents_1.stripIndents; } });
/**
 * @category Utils
 */
var path_1 = require("nx/src/utils/path");
Object.defineProperty(exports, "joinPathFragments", { enumerable: true, get: function () { return path_1.joinPathFragments; } });
Object.defineProperty(exports, "normalizePath", { enumerable: true, get: function () { return path_1.normalizePath; } });
Object.defineProperty(exports, "getImportPath", { enumerable: true, get: function () { return path_1.getImportPath; } });
Object.defineProperty(exports, "detectWorkspaceScope", { enumerable: true, get: function () { return path_1.detectWorkspaceScope; } });
// TODO(v16): Change this to export from 'nx/src/utils/workspace-root'
/**
 * @category Utils
 */
var app_root_1 = require("nx/src/utils/app-root");
Object.defineProperty(exports, "workspaceRoot", { enumerable: true, get: function () { return app_root_1.workspaceRoot; } });
Object.defineProperty(exports, "appRootPath", { enumerable: true, get: function () { return app_root_1.appRootPath; } });
/**
 * @category Utils
 */
var operators_1 = require("nx/src/project-graph/operators");
Object.defineProperty(exports, "reverse", { enumerable: true, get: function () { return operators_1.reverse; } });
/**
 * @category Utils
 */
var project_graph_2 = require("nx/src/project-graph/project-graph");
Object.defineProperty(exports, "createProjectGraphAsync", { enumerable: true, get: function () { return project_graph_2.createProjectGraphAsync; } });
Object.defineProperty(exports, "readCachedProjectGraph", { enumerable: true, get: function () { return project_graph_2.readCachedProjectGraph; } });
/**
 * @category Utils
 */
var utils_1 = require("nx/src/tasks-runner/utils");
Object.defineProperty(exports, "getOutputsForTargetAndConfiguration", { enumerable: true, get: function () { return utils_1.getOutputsForTargetAndConfiguration; } });
/**
 * @category Utils
 */
var default_tasks_runner_1 = require("nx/src/tasks-runner/default-tasks-runner");
Object.defineProperty(exports, "defaultTasksRunner", { enumerable: true, get: function () { return default_tasks_runner_1.defaultTasksRunner; } });
/**
 * @category Utils
 */
var hasher_1 = require("nx/src/hasher/hasher");
Object.defineProperty(exports, "Hasher", { enumerable: true, get: function () { return hasher_1.Hasher; } });
/**
 * @category Utils
 */
var cache_directory_1 = require("nx/src/utils/cache-directory");
Object.defineProperty(exports, "cacheDir", { enumerable: true, get: function () { return cache_directory_1.cacheDir; } });
// STOP! Do not export any new things from the nx package
//# sourceMappingURL=nx-reexports-pre16.js.map