/**
 * @category Ng CLI Adapter
 */
export { wrapAngularDevkitSchematic, overrideCollectionResolutionForTesting, mockSchematicsForTesting, NxScopedHost, } from 'nx/src/adapter/ngcli-adapter';
