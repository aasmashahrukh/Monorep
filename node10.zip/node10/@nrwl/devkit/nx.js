"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireNx = void 0;
function requireNx() {
    try {
        return require('nx/src/devkit-exports');
    }
    catch (_a) {
        return require('./nx-reexports-pre16');
    }
}
exports.requireNx = requireNx;
//# sourceMappingURL=nx.js.map