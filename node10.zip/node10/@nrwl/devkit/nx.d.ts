export declare function requireNx(): typeof import('nx/src/devkit-exports');
