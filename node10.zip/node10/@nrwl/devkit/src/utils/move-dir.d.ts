import type { Tree } from 'nx/src/generators/tree';
/**
 * Analogous to cp -r oldDir newDir
 */
export declare function moveFilesToNewDirectory(tree: Tree, oldDir: string, newDir: string): void;
