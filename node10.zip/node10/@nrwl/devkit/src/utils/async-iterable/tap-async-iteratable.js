"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tapAsyncIterable = void 0;
const tslib_1 = require("tslib");
const map_async_iteratable_1 = require("./map-async-iteratable");
function tapAsyncIterable(data, fn) {
    return tslib_1.__asyncGenerator(this, arguments, function* tapAsyncIterable_1() {
        return yield tslib_1.__await(yield tslib_1.__await(yield* tslib_1.__asyncDelegator(tslib_1.__asyncValues((0, map_async_iteratable_1.mapAsyncIterable)(data, (x) => {
            fn(x);
            return x;
        })))));
    });
}
exports.tapAsyncIterable = tapAsyncIterable;
//# sourceMappingURL=tap-async-iteratable.js.map