"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapAsyncIterable = void 0;
const tslib_1 = require("tslib");
function mapAsyncIterable(data, transform) {
    return tslib_1.__asyncGenerator(this, arguments, function* mapAsyncIterable_1() {
        function f() {
            return tslib_1.__asyncGenerator(this, arguments, function* f_1() {
                const generator = data[Symbol.asyncIterator] || data[Symbol.iterator];
                const iterator = generator.call(data);
                let index = 0;
                let item = yield tslib_1.__await(iterator.next());
                while (!item.done) {
                    yield yield tslib_1.__await(yield tslib_1.__await(transform(yield tslib_1.__await(item.value), index, data)));
                    index++;
                    item = yield tslib_1.__await(iterator.next());
                }
            });
        }
        return yield tslib_1.__await(yield tslib_1.__await(yield* tslib_1.__asyncDelegator(tslib_1.__asyncValues(f()))));
    });
}
exports.mapAsyncIterable = mapAsyncIterable;
//# sourceMappingURL=map-async-iteratable.js.map