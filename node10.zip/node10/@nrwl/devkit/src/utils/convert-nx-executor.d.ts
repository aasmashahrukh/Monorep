import type { Executor } from 'nx/src/config/misc-interfaces';
/**
 * Convert an Nx Executor into an Angular Devkit Builder
 *
 * Use this to expose a compatible Angular Builder
 */
export declare function convertNxExecutor(executor: Executor): any;
