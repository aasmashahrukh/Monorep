import type { Tree } from 'nx/src/generators/tree';
export declare function updateTsConfigsToJs(tree: Tree, options: {
    projectRoot: string;
}): void;
