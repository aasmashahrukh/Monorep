import type { Tree } from 'nx/src/generators/tree';
/**
 * Rename and transpile any new typescript files created to javascript files
 */
export declare function toJS(tree: Tree): void;
