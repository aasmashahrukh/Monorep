export declare function insertImport(): void;
