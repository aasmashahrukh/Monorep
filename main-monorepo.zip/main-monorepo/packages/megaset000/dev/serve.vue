<template>
  <div id="app">
    <router-view />
  </div>
</template>
<style>
body {
  overflow-x: hidden;
  background-color: rgb(160, 200, 168);
}
</style>
