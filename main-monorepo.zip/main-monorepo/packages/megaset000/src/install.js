import MegaSet000 from './MegaSet/MegaSet000.vue'

function install(Vue) {
	if (install.installed) return;
	install.installed = true;

	Vue.component("MegaSet000",MegaSet000);
}

const plugin = {
	install,
};

let GlobalVue = null;
if (typeof window !== "undefined") {
	GlobalVue = window.Vue;
} else if (typeof global !== "undefined") {
	GlobalVue = global.vue;
}
if (GlobalVue) {
	GlobalVue.use(plugin);
}

MegaSet000.install = install;

export default MegaSet000;