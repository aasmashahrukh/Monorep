<template>
  <Form as="el-form" @submit="onSubmit">
    <!-- Field Set Values -->

    <fieldset>
      <legend>
        {{ configObject.FieldSetLegend.values }}
      </legend>

      <el-row>
        <el-col :lg="12" :md="12">
          <FinancialInstrumentAlphaNumericSpecialDashes23
            @FinancialInstrumentAlphaNumericSpecialDashes23-onBlur="
              (val) => {
                $emit('FinancialInstrumentNoTextBox-onBlur', val);
              }
            "
            @FinancialInstrumentAlphaNumericSpecialDashes23-onChange="
              (val) => {
                $emit('FinancialInstrumentNoTextBox-onChange', val);
              }
            "
            @FinancialInstrumentAlphaNumericSpecialDashes23-onKeyPress="
              (val) => {
                $emit('FinancialInstrumentNoTextBox-onKeyPress', val);
              }
            "
            @FinancialInstrumentAlphaNumericSpecialDashes23-onKeyUp="
              (val) => {
                $emit('FinancialInstrumentNoTextBox-onKeyUp', val);
              }
            "
            @FinancialInstrumentAlphaNumericSpecialDashes23-onFocus="
              (val) => {
                $emit('FinancialInstrumentNoTextBox-onFocus', val);
              }
            "
            v-bind="{ ...FinancialInstrumentNoTextBox, ...configObject.FinancialInstrumentNoTextBox }"
            name="FinancialInstrumentNoTextBox"
            ref="RefFinancialInstrumentNoTextBox"
            :values="configObject.FinancialInstrumentNoTextBox.FinancialInstrumentNoTextBoxValue"
            v-if="configObject.FinancialInstrumentNoTextBox != undefined ? configObject.FinancialInstrumentNoTextBox.isVisible : false"
          />
        </el-col>

        <el-col :lg="12" :md="12">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('FinancialInstrumentAmountTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('FinancialInstrumentAmountTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('FinancialInstrumentAmountTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('FinancialInstrumentAmountTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('FinancialInstrumentAmountTextBox-onFocus', val);
              }
            "
            v-bind="{ ...FinancialInstrumentAmountTextBox, ...configObject.FinancialInstrumentAmountTextBox }"
            name="FinancialInstrumentAmountTextBox"
            ref="RefFinancialInstrumentAmountTextBox"
            :values="configObject.FinancialInstrumentAmountTextBox.FinancialInstrumentAmountTextBoxValue"
            v-if="configObject.FinancialInstrumentAmountTextBox != undefined ? configObject.FinancialInstrumentAmountTextBox.isVisible : false"
          />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <CurrencyAlphaNumericSpecial25
            @CurrencyAlphaNumericSpecial25-onBlur="
              (val) => {
                $emit('FinancialInstrumentInCurrencyTextBox-onBlur', val);
              }
            "
            @CurrencyAlphaNumericSpecial25-onChange="
              (val) => {
                $emit('FinancialInstrumentInCurrencyTextBox-onChange', val);
              }
            "
            @CurrencyAlphaNumericSpecial25-onKeyPress="
              (val) => {
                $emit('FinancialInstrumentInCurrencyTextBox-onKeyPress', val);
              }
            "
            @CurrencyAlphaNumericSpecial25-onKeyUp="
              (val) => {
                $emit('FinancialInstrumentInCurrencyTextBox-onKeyUp', val);
              }
            "
            @CurrencyAlphaNumericSpecial25-onFocus="
              (val) => {
                $emit('FinancialInstrumentInCurrencyTextBox-onFocus', val);
              }
            "
            v-bind="{ ...FinancialInstrumentInCurrencyTextBox, ...configObject.FinancialInstrumentInCurrencyTextBox }"
            name="FinancialInstrumentInCurrencyTextBox"
            ref="RefFinancialInstrumentInCurrencyTextBox"
            :values="configObject.FinancialInstrumentInCurrencyTextBox.FinancialInstrumentInCurrencyTextBoxValue"
            v-if="
              configObject.FinancialInstrumentInCurrencyTextBox != undefined ? configObject.FinancialInstrumentInCurrencyTextBox.isVisible : false
            "
          />
        </el-col>

        <el-col :lg="12" :md="12">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('SumOfGDConsValTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('SumOfGDConsValTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('SumOfGDConsValTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('SumOfGDConsValTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('SumOfGDConsValTextBox-onFocus', val);
              }
            "
            v-bind="{ ...SumOfGDConsValTextBox, ...configObject.SumOfGDConsValTextBox }"
            name="SumOfGDConsValTextBox"
            ref="RefSumOfGDConsValTextBox"
            :values="configObject.SumOfGDConsValTextBox.SumOfGDConsValTextBoxValue"
            v-if="configObject.SumOfGDConsValTextBox != undefined ? configObject.SumOfGDConsValTextBox.isVisible : false"
          />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="8" :md="8">
          <GenericDatePicker
            @GenericDatePicker-onBlur="
              (val) => {
                $emit('CertificationDateTextBox-onBlur', val);
              }
            "
            name="CertificationDateTextBox"
            ref="RefCertificationDateTextBox"
            v-bind="{
              ...CertificationDateTextBox,
              ...configObject.CertificationDateTextBox
            }"
            :values="configObject.CertificationDateTextBox.CertificationDateTextBoxValue"
            v-if="configObject.CertificationDateTextBox != undefined ? configObject.CertificationDateTextBox.isVisible : false"
          >
          </GenericDatePicker>
        </el-col>

        <el-col :lg="1" :md="1"></el-col>

        <el-col :lg="8" :md="8">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('TermOfContractTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('TermOfContractTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('TermOfContractTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('TermOfContractTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('TermOfContractTextBox-onFocus', val);
              }
            "
            v-bind="{ ...TermOfContractTextBox, ...configObject.TermOfContractTextBox }"
            name="TermOfContractTextBox"
            ref="RefTermOfContractTextBox"
            :values="configObject.TermOfContractTextBox.TermOfContractTextBoxValue"
            v-if="configObject.TermOfContractTextBox != undefined ? configObject.TermOfContractTextBox.isVisible : false"
          />
        </el-col>

        <el-col :lg="1" :md="1"></el-col>

        <el-col :lg="6" :md="6">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('TenorTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('TenorTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('TenorTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('TenorTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('TenorTextBox-onFocus', val);
              }
            "
            v-bind="{ ...TenorTextBox, ...configObject.TenorTextBox }"
            name="TenorTextBox"
            ref="RefTenorTextBox"
            :values="configObject.TenorTextBox.TenorTextBoxValue"
            v-if="configObject.TenorTextBox != undefined ? configObject.TenorTextBox.isVisible : false"
          />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12"><el-form-item>Share Percentage:</el-form-item></el-col>
      </el-row>

      <el-row>
        <el-col :lg="8" :md="8">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('TenorPercentTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('TenorPercentTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('TenorPercentTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('TenorPercentTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('TenorPercentTextBox-onFocus', val);
              }
            "
            v-bind="{ ...TenorPercentTextBox, ...configObject.TenorPercentTextBox }"
            name="TenorPercentTextBox"
            ref="RefTenorPercentTextBox"
            :values="configObject.TenorPercentTextBox.TenorPercentTextBoxValue"
            v-if="configObject.TenorPercentTextBox != undefined ? configObject.TenorPercentTextBox.isVisible : false"
          />
        </el-col>

        <el-col :lg="1" :md="1"></el-col>

        <el-col :lg="8" :md="8">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('SightDPTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('SightDPTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('SightDPTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('SightDPTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('SightDPTextBox-onFocus', val);
              }
            "
            v-bind="{ ...SightDPTextBox, ...configObject.SightDPTextBox }"
            name="SightDPTextBox"
            ref="RefSightDPTextBox"
            :values="configObject.SightDPTextBox.SightDPTextBoxValue"
            v-if="configObject.SightDPTextBox != undefined ? configObject.SightDPTextBox.isVisible : false"
          />
        </el-col>

        <el-col :lg="1" :md="1"></el-col>

        <el-col :lg="6" :md="6">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('UsanceDATextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('UsanceDATextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('UsanceDATextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('UsanceDATextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('UsanceDATextBox-onFocus', val);
              }
            "
            v-bind="{ ...UsanceDATextBox, ...configObject.UsanceDATextBox }"
            name="UsanceDATextBox"
            ref="RefUsanceDATextBox"
            :values="configObject.UsanceDATextBox.UsanceDATextBoxValue"
            v-if="configObject.UsanceDATextBox != undefined ? configObject.UsanceDATextBox.isVisible : false"
          />
        </el-col>
      </el-row>
    </fieldset>

    <br />

    <!-- 1st Table -->

    <el-row>
      <el-col :lg="24" :md="24">
        <GenericSortableTableView
          @GenericSortableTableView-onClickRow="
            (val) => {
              $emit('FinancialInInfoTable1-onClickRow', val);
            }
          "
          v-bind="{ ...FinancialInInfoTable1, ...configObject.FinancialInInfoTable1 }"
          name="FinancialInInfoTable1"
          ref="RefFinancialInInfoTable1"
          v-if="configObject.FinancialInInfoTable1 != undefined ? configObject.FinancialInInfoTable1.isVisible : false"
        />
      </el-col>
    </el-row>
    <!-- Buttons Fields -->

    <fieldset>
      <el-row>
        <el-col :lg="3" :md="3">
          <GenericButton
            @GenericButton-onClick="$emit('OkButton-onClick')"
            v-if="configObject.OkButton != undefined ? configObject.OkButton.isVisible : false"
            v-bind="{
              ...OkButton,
              ...configObject.OkButton
            }"
            name="OkButton"
            ref="RefOkButton"
          />
        </el-col>

        <el-col :lg="1" :md="1"></el-col>

        <el-col :lg="3" :md="3">
          <GenericButton
            @GenericButton-onClick="$emit('ExitButton-onClick')"
            v-if="configObject.ExitButton != undefined ? configObject.ExitButton.isVisible : false"
            v-bind="{
              ...ExitButton,
              ...configObject.ExitButton
            }"
            name="ExitButton"
            ref="RefExitButton"
          />
        </el-col>

        <el-col :lg="10" :md="10"></el-col>

        <el-col :lg="3" :md="3">
          <GenericButton
            @GenericButton-onClick="$emit('LinkButton-onClick')"
            v-if="configObject.LinkButton != undefined ? configObject.LinkButton.isVisible : false"
            v-bind="{
              ...LinkButton,
              ...configObject.LinkButton
            }"
            name="LinkButton"
            ref="RefLinkButton"
          />
        </el-col>

        <el-col :lg="1" :md="1"></el-col>

        <el-col :lg="3" :md="3">
          <GenericButton
            @GenericButton-onClick="$emit('UnLinkButton-onClick')"
            v-if="configObject.UnLinkButton != undefined ? configObject.UnLinkButton.isVisible : false"
            v-bind="{
              ...UnLinkButton,
              ...configObject.UnLinkButton
            }"
            name="UnLinkButton"
            ref="RefUnLinkButton"
          />
        </el-col>
      </el-row>
    </fieldset>




    <!-- ------------------------------------------------------------------- -->

    <el-row>
      <el-col :md="7" :lg="7"></el-col>
      <el-col :md="10" :lg="10">
        <fieldset v-if="configObject.Section1 != undefined ? configObject.Section1.isVisible : false">
             <el-form-item class="_custom_heading" v-if="configObject.LDBC_No != undefined ? configObject.LDBC_No.isVisible : false">
            <legend>{{ configObject.LDBC_No.LDBCText }}</legend></el-form-item
          >
        </fieldset>
      </el-col>
    </el-row>
   
    <el-row>
      <el-col :md="24" :lg="24">
        <fieldset v-if="configObject.CustomerInformationSection != undefined ? configObject.CustomerInformationSection.isVisible : false">
          <legend>Customer Information</legend>
          <el-row>
            <el-col :md="24" :lg="24">
              <el-row>
                <el-col :md="12" :lg="12">
                  <AccountNumberWithoutBranchCodeNumericDashes16
                    @AccountNumberWithoutBranchCodeNumericDashes16-onChange="
                      (val) => {
                        $emit('AccountNumberTextBox-onChange', val);
                      }
                    "
                    @AccountNumberWithoutBranchCodeNumericDashes16-onBlur="
                      (val) => {
                        $emit('AccountNumberTextBox-onBlur', val);
                      }
                    "
                    @AccountNumberWithoutBranchCodeNumericDashes16-onFocus="
                      (val) => {
                        $emit('AccountNumberTextBox-onFocus', val);
                      }
                    "
                    v-bind="{
                      ...AccountNumberTextBox,
                      ...configObject.AccountNumberTextBox
                    }"
                    name="AccountNumberTextBox"
                    ref="RefAccountNumberTextBox"
                    :values="configObject.AccountNumberTextBox.AccountNumberTextBoxValue"
                    v-if="configObject.AccountNumberTextBox != undefined ? configObject.AccountNumberTextBox.isVisible : false"
                  />
                </el-col>
                <el-col :md="5" :lg="5"></el-col>
                <el-col :md="7" :lg="7">
                  <NtnNumericDashes9
                    @NtnNumericDashes9-onBlur="
                      (val) => {
                        $emit('NtnNumberTextBox-onBlur', val);
                      }
                    "
                    @NtnNumericDashes9-onChange="
                      (val) => {
                        $emit('NtnNumberTextBox-onChange', val);
                      }
                    "
                    @NtnNumericDashes9-onKeyPress="
                      (val) => {
                        $emit('NtnNumberTextBox-onKeyPress', val);
                      }
                    "
                    @NtnNumericDashes9-onKeyUp="
                      (val) => {
                        $emit('NtnNumberTextBox-onKeyUp', val);
                      }
                    "
                    @NtnNumericDashes9-onFocus="
                      (val) => {
                        $emit('NtnNumberTextBox-onFocus', val);
                      }
                    "
                    v-bind="{
                      ...NtnNumberTextBox,
                      ...configObject.NtnNumberTextBox
                    }"
                    name="NtnNumberTextBox"
                    ref="RefNtnNumberTextBox"
                    :values="configObject.NtnNumberTextBox.NtnNumberTextBoxValue"
                    v-if="configObject.NtnNumberTextBox != undefined ? configObject.NtnNumberTextBox.isVisible : false"
                  />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <AccountTitleString45
                    @AccountTitleString45-onBlur="
                      (val) => {
                        $emit('AccountTitleTextBox-onBlur', val);
                      }
                    "
                    @AccountTitleString45-onChange="
                      (val) => {
                        $emit('AccountTitleTextBox-onChange', val);
                      }
                    "
                    @AccountTitleString45-onFocus="
                      (val) => {
                        $emit('AccountTitleTextBox-onFocus', val);
                      }
                    "
                    v-bind="{
                      ...AccountTitleTextBox,
                      ...configObject.AccountTitleTextBox
                    }"
                    name="AccountTitleTextBox"
                    ref="RefAccountTitleTextBox"
                    :values="configObject.AccountTitleTextBox.AccountTitleTextBoxValue"
                    v-if="configObject.AccountTitleTextBox != undefined ? configObject.AccountTitleTextBox.isVisible : false"
                  />
                </el-col>
                <el-col :md="5" :lg="5"></el-col>
                <el-col :md="7" :lg="7">
                  <GenericTextBox
                    @GenericTextBox-onBlur="
                      (val) => {
                        $emit('CCINumberTextBox-onBlur', val);
                      }
                    "
                    @GenericTextBox-onChange="
                      (val) => {
                        $emit('CCINumberTextBox-onChange', val);
                      }
                    "
                    @GenericTextBox-onKeyPress="
                      (val,event) => {
                        $emit('CCINumberTextBox-onKeyPress', val,event);
                      }
                    "
                    @GenericTextBox-onKeyUp="
                      (val) => {
                        $emit('CCINumberTextBox-onKeyUp', val);
                      }
                    "
                    @GenericTextBox-onFocus="
                      (val) => {
                        $emit('CCINumberTextBox-onFocus', val);
                      }
                    "
                    v-bind="{
                      ...CCINumberTextBox,
                      ...configObject.CCINumberTextBox
                    }"
                    name="CCINumberTextBox"
                    ref="RefCCINumberTextBox"
                    :values="configObject.CCINumberTextBox.CCINumberTextBoxValue"
                    v-if="configObject.CCINumberTextBox != undefined ? configObject.CCINumberTextBox.isVisible : false"
                  />
                </el-col>
              </el-row>
            </el-col>
          </el-row>
        </fieldset>
      </el-col>
    </el-row>

    <el-row>
      <el-col :md="24" :lg="24">
        <el-tabs v-model="configObject.TabPane.activeName" type="card" @update:model-value="($event) => $emit('handleTabClick', $event)">
          <el-tab-pane :label="configObject.BillInfoTab.label" name="BillInfoTab">
            <el-row>
              <el-col :md="24" :lg="24">
                <fieldset v-if="configObject.Section2 != undefined ? configObject.Section2.isVisible : false">
                  <el-row>
                    <el-col :md="5" :lg="5">
                      <el-form-item  v-if="configObject.LDBCNo != undefined ? configObject.LDBCNo.isVisible : false"
                        >{{ configObject.LDBCNo.LDBCText }}</el-form-item
                      >
                    </el-col>
                    <el-col :md="12" :lg="12"></el-col>
                    <el-col :md="7" :lg="7">
                      <AccountNumberWithoutBranchCodeNumericDashes16
                        @AccountNumberWithoutBranchCodeNumericDashes16-onBlur="
                          (val) => {
                            $emit('LDBC_AccountNumberTextBox-onBlur', val);
                          }
                        "
                        @AccountNumberWithoutBranchCodeNumericDashes16-onFocus="
                          (val) => {
                            $emit('LDBC_AccountNumberTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...LDBC_AccountNumberTextBox,
                          ...configObject.LDBC_AccountNumberTextBox
                        }"
                        name="LDBC_AccountNumberTextBox"
                        ref="RefLDBC_AccountNumberTextBox"
                        :values="configObject.LDBC_AccountNumberTextBox.LDBC_AccountNumberTextBoxValue"
                        v-if="configObject.LDBC_AccountNumberTextBox != undefined ? configObject.LDBC_AccountNumberTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>

            <el-row>
              <el-col :md="24" :lg="24">
                <fieldset v-if="configObject.Section3 != undefined ? configObject.Section3.isVisible : false">
                  <el-row>
                    <el-col :md="5" :lg="5">
                      <el-form-item  v-if="configObject.LDBP_No != undefined ? configObject.LDBP_No.isVisible : false"
                        >LDBP : {{ configObject.LDBP_No.LDBPText }}</el-form-item
                      >
                    </el-col>
                    <el-col :md="12" :lg="12"></el-col>
                    <el-col :md="7" :lg="7">
                      <AccountNumberWithoutBranchCodeNumericDashes16
                        @AccountNumberWithoutBranchCodeNumericDashes16-onFocus="
                          (val) => {
                            $emit('LDBP_AccountNumberTextBox-onFocus', val);
                          }
                        "
                        @AccountNumberWithoutBranchCodeNumericDashes16-onBlur="
                          (val) => {
                            $emit('LDBP_AccountNumberTextBox-onBlur', val);
                          }
                        "
                        v-bind="{ ...LDBP_AccountNumberTextBox, ...configObject.LDBP_AccountNumberTextBox }"
                        name="LDBP_AccountNumberTextBox"
                        ref="RefLDBP_AccountNumberTextBox"
                        :values="configObject.LDBP_AccountNumberTextBox.LDBP_AccountNumberTextBoxValue"
                        v-if="configObject.LDBP_AccountNumberTextBox != undefined ? configObject.LDBP_AccountNumberTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>

            <el-row>
              <el-col :md="24" :lg="24">
                <fieldset v-if="configObject.Section4 != undefined ? configObject.Section4.isVisible : false">
                  <el-row>
                    <el-col :md="5" :lg="5">
                      <DateDdMmYyyy
                        @DateDdMmYyyy-onBlur="
                          (val) => {
                            $emit('DateTextBox-onBlur', val);
                          }
                        "
                        @DateDdMmYyyy-onChange="
                          (val) => {
                            $emit('DateTextBox-onChange', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyPress="
                          (val) => {
                            $emit('DateTextBox-onKeyPress', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyUp="
                          (val) => {
                            $emit('DateTextBox-onKeyUp', val);
                          }
                        "
                        @DateDdMmYyyy-onFocus="
                          (val) => {
                            $emit('DateTextBox-onFocus', val);
                          }
                        "
                        v-bind="{ ...DateTextBox, ...configObject.DateTextBox }"
                        name="DateTextBox"
                        ref="RefDateTextBox"
                        :values="configObject.DateTextBox.DateTextBoxValue"
                        v-if="configObject.DateTextBox != undefined ? configObject.DateTextBox.isVisible : false"
                      />
                    </el-col>
                    <el-col :md="1" :lg="1"></el-col>
                    <el-col :md="4" :lg="4">
                      <GenericRadioButton
                        @GenericRadioButton-onChange="
                          (val) => {
                            $emit('ContractLCRadioButton-onChange', val);
                          }
                        "
                        @GenericRadioButton-onClick="
                          (val) => {
                            $emit('ContractLCRadioButton-onClick', val);
                          }
                        "
                        @GenericRadioButton-onFocus="
                          (val) => {
                            $emit('ContractLCRadioButton-onFocus', val);
                          }
                        "
                        v-bind="{ ...ContractLCRadioButton, ...configObject.ContractLCRadioButton }"
                        name="ContractLCRadioButton"
                        ref="RefContractLCRadioButton"
                        :values="configObject.ContractLCRadioButton.ContractLCRadioButtonValue"
                        v-if="configObject.ContractLCRadioButton != undefined ? configObject.ContractLCRadioButton.isVisible : false"
                      />
                    </el-col>
                    <el-col :md="1" :lg="1"></el-col>

                    <el-col :md="4" :lg="4">
                      <GenericRadioButton
                        @GenericRadioButton-onChange="
                          (val) => {
                            $emit('ExportSalesRadioButton-onChange', val);
                          }
                        "
                        @GenericRadioButton-onClick="
                          (val) => {
                            $emit('ExportSalesRadioButton-onClick', val);
                          }
                        "
                        @GenericRadioButton-onFocus="
                          (val) => {
                            $emit('ExportSalesRadioButton-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...ExportSalesRadioButton,
                          ...configObject.ExportSalesRadioButton
                        }"
                        name="ExportSalesRadioButton"
                        ref="RefExportSalesRadioButton"
                        :values="configObject.ExportSalesRadioButton.ExportSalesRadioButtonValue"
                        v-if="configObject.ExportSalesRadioButton != undefined ? configObject.ExportSalesRadioButton.isVisible : false"
                      />
                    </el-col>

                    <el-col :md="5" :lg="5">
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('TermTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('TermTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('TermTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('TermTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('TermTextBox-onFocus', val);
                          }
                        "
                        v-bind="{ ...TermTextBox, ...configObject.TermTextBox }"
                        name="TermTextBox"
                        ref="RefTermTextBox"
                        :values="configObject.TermTextBox.TermTextBoxValue"
                        v-if="configObject.TermTextBox != undefined ? configObject.TermTextBox.isVisible : false"
                      />
                    </el-col>
                    <el-col :md="2" :lg="2"></el-col>

                    <el-col :md="2" :lg="2">
                      <el-form-item class="_custom_heading" v-if="configObject.UsanceLabel != undefined ? configObject.UsanceLabel.isVisible : false">
                        USANCE {{ configObject.UsanceLabel.UsanceText }}</el-form-item
                      >
                      <el-form-item class="_custom_heading" v-if="configObject.SightLabel != undefined ? configObject.SightLabel.isVisible : false">
                        SIGHT {{ configObject.SightLabel.SightText }}</el-form-item
                      >
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>

            <el-row>
              <el-col :md="4" :lg="4">
                <fieldset v-if="configObject.Section5 != undefined ? configObject.Section5.isVisible : false">
                  <legend>Tenor</legend>
                  <el-row>
                    <el-col :md="23" :lg="23">
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('TenorDaysTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('TenorDaysTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('TenorDaysTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('TenorDaysTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('TenorDaysTextBox-onFocus', val);
                          }
                        "
                        v-bind="{ ...TenorDaysTextBox, ...configObject.TenorDaysTextBox }"
                        name="TenorDaysTextBox"
                        ref="RefTenorDaysTextBox"
                        :values="configObject.TenorDaysTextBox.TenorDaysTextBoxValue"
                        v-if="configObject.TenorDaysTextBox != undefined ? configObject.TenorDaysTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>

              <el-col :md="20" :lg="20">
                <fieldset v-if="configObject.Section6 != undefined ? configObject.Section6.isVisible : false">
                  <el-row>
                    <el-col :md="6" :lg="6">
                      <GenericRadioButton
                        @GenericRadioButton-onChange="
                          (val) => {
                            $emit('DateRadioButton-onChange', val);
                          }
                        "
                        @GenericRadioButton-onClick="
                          (val) => {
                            $emit('DateRadioButton-onClick', val);
                          }
                        "
                        @GenericRadioButton-onFocus="
                          (val) => {
                            $emit('DateRadioButton-onFocus', val);
                          }
                        "
                        v-bind="{ ...DateRadioButton, ...configObject.DateRadioButton }"
                        name="DateRadioButton"
                        ref="RefDateRadioButton"
                        :values="configObject.DateRadioButton.DateRadioButtonValue"
                        v-if="configObject.DateRadioButton != undefined ? configObject.DateRadioButton.isVisible : false"
                      />
                    </el-col>
                    <el-col :md="2" :lg="2"></el-col>
                    <el-col :md="6" :lg="6">
                      <DateDdMmYyyy
                        @DateDdMmYyyy-onBlur="
                          (val) => {
                            $emit('ShipDateTextBox-onBlur', val);
                          }
                        "
                        @DateDdMmYyyy-onChange="
                          (val) => {
                            $emit('ShipDateTextBox-onChange', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyPress="
                          (val) => {
                            $emit('ShipDateTextBox-onKeyPress', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyUp="
                          (val) => {
                            $emit('ShipDateTextBox-onKeyUp', val);
                          }
                        "
                        @DateDdMmYyyy-onFocus="
                          (val) => {
                            $emit('ShipDateTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...ShipDateTextBox,
                          ...configObject.ShipDateTextBox
                        }"
                        name="ShipDateTextBox"
                        ref="RefShipDateTextBox"
                        :values="configObject.ShipDateTextBox.ShipDateTextBoxValue"
                        v-if="configObject.ShipDateTextBox != undefined ? configObject.ShipDateTextBox.isVisible : false"
                      />
                    </el-col>
                    <el-col :md="4" :lg="4"></el-col>
                    <el-col :md="6" :lg="6">
                      <DateDdMmYyyy
                        @DateDdMmYyyy-onBlur="
                          (val) => {
                            $emit('DueDateTextBox-onBlur', val);
                          }
                        "
                        @DateDdMmYyyy-onChange="
                          (val) => {
                            $emit('DueDateTextBox-onChange', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyPress="
                          (val) => {
                            $emit('DueDateTextBox-onKeyPress', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyUp="
                          (val) => {
                            $emit('DueDateTextBox-onKeyUp', val);
                          }
                        "
                        @DateDdMmYyyy-onFocus="
                          (val) => {
                            $emit('DueDateTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...DueDateTextBox,
                          ...configObject.DueDateTextBox
                        }"
                        name="DueDateTextBox"
                        ref="RefDueDateTextBox"
                        :values="configObject.DueDateTextBox.DueDateTextBoxValue"
                        v-if="configObject.DueDateTextBox != undefined ? configObject.DueDateTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>

            <el-row>
              <el-col :md="12" :lg="12">
                <fieldset v-if="configObject.Section7 != undefined ? configObject.Section7.isVisible : false">
                  <legend>Bank/Branch Info</legend>
                  <el-row>
                    <el-col :md="24" :lg="24">
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('BankTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('BankTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('BankTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('BankTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('BankTextBox-onFocus', val);
                          }
                        "
                        v-bind="{ ...BankTextBox, ...configObject.BankTextBox }"
                        name="BankTextBox"
                        ref="RefBankTextBox"
                        :values="configObject.BankTextBox.BankTextBoxValue"
                        v-if="configObject.BankTextBox != undefined ? configObject.BankTextBox.isVisible : false"
                      />

                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('BranchTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('BranchTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('BranchTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('BranchTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('BranchTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...BranchTextBox,
                          ...configObject.BranchTextBox
                        }"
                        name="BranchTextBox"
                        ref="RefBranchTextBox"
                        :values="configObject.BranchTextBox.BranchTextBoxValue"
                        v-if="configObject.BranchTextBox != undefined ? configObject.BranchTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
              <el-col :md="4" :lg="4">
                <fieldset v-if="configObject.Section8 != undefined ? configObject.Section8.isVisible : false">
                  <legend>Charges On</legend>
                  <el-row>
                    <el-col :md="1" :lg="1"></el-col>
                    <el-col :md="23" :lg="23">
                      <GenericRadioButton
                        @GenericRadioButton-onChange="
                          (val) => {
                            $emit('BeneficiaryBuyerRadioButton-onChange', val);
                          }
                        "
                        @GenericRadioButton-onClick="
                          (val) => {
                            $emit('BeneficiaryBuyerRadioButton-onClick', val);
                          }
                        "
                        @GenericRadioButton-onFocus="
                          (val) => {
                            $emit('BeneficiaryBuyerRadioButton-onFocus', val);
                          }
                        "
                        v-bind="{ ...BeneficiaryBuyerRadioButton, ...configObject.BeneficiaryBuyerRadioButton }"
                        name="BeneficiaryBuyerRadioButton"
                        ref="RefBeneficiaryBuyerRadioButton"
                        :values="configObject.BeneficiaryBuyerRadioButton.BeneficiaryBuyerRadioButtonValue"
                        v-if="configObject.BeneficiaryBuyerRadioButton != undefined ? configObject.BeneficiaryBuyerRadioButton.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
                <fieldset v-if="configObject.Section9 != undefined ? configObject.Section9.isVisible : false">
                  <legend>Carrier Mode</legend>
                  <el-row>
                    <el-col :md="1" :lg="1"></el-col>
                    <el-col :md="23" :lg="23">
                      <GenericRadioButton
                        @GenericRadioButton-onChange="
                          (val) => {
                            $emit('RoadRailRadioButton-onChange', val);
                          }
                        "
                        @GenericRadioButton-onClick="
                          (val) => {
                            $emit('RoadRailRadioButton-onClick', val);
                          }
                        "
                        @GenericRadioButton-onFocus="
                          (val) => {
                            $emit('RoadRailRadioButton-onFocus', val);
                          }
                        "
                        v-bind="{ ...RoadRailRadioButton, ...configObject.RoadRailRadioButton }"
                        name="RoadRailRadioButton"
                        ref="RefRoadRailRadioButton"
                        :values="configObject.RoadRailRadioButton.RoadRailRadioButtonValue"
                        v-if="configObject.RoadRailRadioButton != undefined ? configObject.RoadRailRadioButton.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>

              <el-col :md="8" :lg="8">
                <fieldset v-if="configObject.Section10 != undefined ? configObject.Section10.isVisible : false">
                  <legend>Discount Info</legend>
                  <el-row>
                    <el-col :md="1" :lg="1"></el-col>
                    <el-col :md="23" :lg="23">
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('DiscountInfoDays-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('DiscountInfoDays-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('DiscountInfoDays-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('DiscountInfoDays-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('DiscountInfoDays-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...DiscountInfoDays,
                          ...configObject.DiscountInfoDays
                        }"
                        name="DiscountInfoDays"
                        ref="RefDiscountInfoDays"
                        :values="configObject.DiscountInfoDays.DiscountInfoDaysValue"
                        v-if="configObject.DiscountInfoDays != undefined ? configObject.DiscountInfoDays.isVisible : false"
                      />
                      <RateNumericDecimal3Point2
                        @RateNumericDecimal3Point2-onBlur="
                          (val) => {
                            $emit('RateTextBox-onBlur', val);
                          }
                        "
                        @RateNumericDecimal3Point2-onChange="
                          (val) => {
                            $emit('RateTextBox-onChange', val);
                          }
                        "
                        @RateNumericDecimal3Point2-onKeyPress="
                          (val) => {
                            $emit('RateTextBox-onKeyPress', val);
                          }
                        "
                        @RateNumericDecimal3Point2-onKeyUp="
                          (val) => {
                            $emit('RateTextBox-onKeyUp', val);
                          }
                        "
                        @RateNumericDecimal3Point2-onFocus="
                          (val) => {
                            $emit('RateTextBox-onFocus', val);
                          }
                        "
                        v-bind="{ ...RateTextBox, ...configObject.RateTextBox }"
                        name="RateTextBox"
                        ref="RefRateTextBox"
                        :values="configObject.RateTextBox.RateTextBoxValue"
                        v-if="configObject.RateTextBox != undefined ? configObject.RateTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>

            <el-row>
              <el-col :md="13" :lg="13">
                <fieldset v-if="configObject.Section11 != undefined ? configObject.Section11.isVisible : false">
                  <legend>Other Info.</legend>
                  <el-row>
                    <el-col :md="24" :lg="24">
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('BuyerTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('BuyerTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('BuyerTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('BuyerTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('BuyerTextBox-onFocus', val);
                          }
                        "
                        v-bind="{ ...BuyerTextBox, ...configObject.BuyerTextBox }"
                        name="BuyerTextBox"
                        ref="RefBuyerTextBox"
                        :values="configObject.BuyerTextBox.BuyerTextBoxValue"
                        v-if="configObject.BuyerTextBox != undefined ? configObject.BuyerTextBox.isVisible : false"
                      />
                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('BillAmountTextBox1-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onChange="
                          (val) => {
                            $emit('BillAmountTextBox1-onChange', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('BillAmountTextBox1-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyUp="
                          (val) => {
                            $emit('BillAmountTextBox1-onKeyUp', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('BillAmountTextBox1-onFocus', val);
                          }
                        "
                        v-bind="{ ...BillAmountTextBox1, ...configObject.BillAmountTextBox1 }"
                        name="BillAmountTextBox1"
                        ref="RefBillAmountTextBox1"
                        :values="configObject.BillAmountTextBox1.BillAmountTextBox1Value"
                        v-if="configObject.BillAmountTextBox1 != undefined ? configObject.BillAmountTextBox1.isVisible : false"
                      />
                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('BalanceAmountTextBox1-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onChange="
                          (val) => {
                            $emit('BalanceAmountTextBox1-onChange', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('BalanceAmountTextBox1-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyUp="
                          (val) => {
                            $emit('BalanceAmountTextBox1-onKeyUp', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('BalanceAmountTextBox1-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...BalanceAmountTextBox1,
                          ...configObject.BalanceAmountTextBox1
                        }"
                        name="BalanceAmountTextBox1"
                        ref="RefBalanceAmountTextBox1"
                        :values="configObject.BalanceAmountTextBox1.BalanceAmountTextBox1Value"
                        v-if="configObject.BalanceAmountTextBox1 != undefined ? configObject.BalanceAmountTextBox1.isVisible : false"
                      />
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('CommodityTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('CommodityTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('CommodityTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('CommodityTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('CommodityTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...CommodityTextBox,
                          ...configObject.CommodityTextBox
                        }"
                        name="CommodityTextBox"
                        ref="RefCommodityTextBox"
                        :values="configObject.CommodityTextBox.CommodityTextBoxValue"
                        v-if="configObject.CommodityTextBox != undefined ? configObject.CommodityTextBox.isVisible : false"
                      />
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('OriginTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('OriginTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('OriginTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('OriginTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('OriginTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...OriginTextBox,
                          ...configObject.OriginTextBox
                        }"
                        name="OriginTextBox"
                        ref="RefOriginTextBox"
                        :values="configObject.OriginTextBox.OriginTextBoxValue"
                        v-if="configObject.OriginTextBox != undefined ? configObject.OriginTextBox.isVisible : false"
                      />
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('DestinationTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('DestinationTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('DestinationTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('DestinationTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('DestinationTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...DestinationTextBox,
                          ...configObject.DestinationTextBox
                        }"
                        name="DestinationTextBox"
                        ref="RefDestinationTextBox"
                        :values="configObject.DestinationTextBox.DestinationTextBoxValue"
                        v-if="configObject.DestinationTextBox != undefined ? configObject.DestinationTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>

              <el-col :md="11" :lg="11">
                <fieldset v-if="configObject.Section12 != undefined ? configObject.Section12.isVisible : false">
                  <legend>Invoice Info.</legend>
                  <el-row>
                    <el-col :md="24" :lg="24">
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('InvoiveNumberTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('InvoiveNumberTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('InvoiveNumberTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('InvoiveNumberTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('InvoiveNumberTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...InvoiveNumberTextBox,
                          ...configObject.InvoiveNumberTextBox
                        }"
                        name="InvoiveNumberTextBox"
                        ref="RefInvoiveNumberTextBox"
                        :values="configObject.InvoiveNumberTextBox.InvoiveNumberTextBoxValue"
                        v-if="configObject.InvoiveNumberTextBox != undefined ? configObject.InvoiveNumberTextBox.isVisible : false"
                      />

                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('InvoiceAmountTextBox-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onChange="
                          (val) => {
                            $emit('InvoiceAmountTextBox-onChange', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('InvoiceAmountTextBox-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyUp="
                          (val) => {
                            $emit('InvoiceAmountTextBox-onKeyUp', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('InvoiceAmountTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...InvoiceAmountTextBox,
                          ...configObject.InvoiceAmountTextBox
                        }"
                        name="InvoiceAmountTextBox"
                        ref="RefInvoiceAmountTextBox"
                        :values="configObject.InvoiceAmountTextBox.InvoiceAmountTextBoxValue"
                        v-if="configObject.InvoiceAmountTextBox != undefined ? configObject.InvoiceAmountTextBox.isVisible : false"
                      />
                    </el-col>

                    <el-col :md="24" :lg="24">
                      <DateDdMmYyyy
                        @DateDdMmYyyy-onBlur="
                          (val) => {
                            $emit('InvoiceDateTextBox-onBlur', val);
                          }
                        "
                        @DateDdMmYyyy-onChange="
                          (val) => {
                            $emit('InvoiceDateTextBox-onChange', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyPress="
                          (val) => {
                            $emit('InvoiceDateTextBox-onKeyPress', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyUp="
                          (val) => {
                            $emit('InvoiceDateTextBox-onKeyUp', val);
                          }
                        "
                        @DateDdMmYyyy-onFocus="
                          (val) => {
                            $emit('InvoiceDateTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...InvoiceDateTextBox,
                          ...configObject.InvoiceDateTextBox
                        }"
                        name="InvoiceDateTextBox"
                        ref="RefInvoiceDateTextBox"
                        :values="configObject.InvoiceDateTextBox.InvoiceDateTextBoxValue"
                        v-if="configObject.InvoiceDateTextBox != undefined ? configObject.InvoiceDateTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
                <fieldset v-if="configObject.Section13 != undefined ? configObject.Section13.isVisible : false">
                  <legend>Courier Info.</legend>
                  <el-row>
                    <el-col :md="24" :lg="24">
                      <GenericTextBox
                        @GenericTextBox-onBlur="
                          (val) => {
                            $emit('CourierRefTextBox-onBlur', val);
                          }
                        "
                        @GenericTextBox-onChange="
                          (val) => {
                            $emit('CourierRefTextBox-onChange', val);
                          }
                        "
                        @GenericTextBox-onKeyPress="
                          (val,event) => {
                            $emit('CourierRefTextBox-onKeyPress', val,event);
                          }
                        "
                        @GenericTextBox-onKeyUp="
                          (val) => {
                            $emit('CourierRefTextBox-onKeyUp', val);
                          }
                        "
                        @GenericTextBox-onFocus="
                          (val) => {
                            $emit('CourierRefTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...CourierRefTextBox,
                          ...configObject.CourierRefTextBox
                        }"
                        name="CourierRefTextBox"
                        ref="RefCourierRefTextBox"
                        :values="configObject.CourierRefTextBox.CourierRefTextBoxValue"
                        v-if="configObject.CourierRefTextBox != undefined ? configObject.CourierRefTextBox.isVisible : false"
                      />

                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('CourierAmountTextBox-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onChange="
                          (val) => {
                            $emit('CourierAmountTextBox-onChange', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('CourierAmountTextBox-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyUp="
                          (val) => {
                            $emit('CourierAmountTextBox-onKeyUp', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('CourierAmountTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...CourierAmountTextBox,
                          ...configObject.CourierAmountTextBox
                        }"
                        name="CourierAmountTextBox"
                        ref="RefCourierAmountTextBox"
                        :values="configObject.CourierAmountTextBox.CourierAmountTextBoxValue"
                        v-if="configObject.CourierAmountTextBox != undefined ? configObject.CourierAmountTextBox.isVisible : false"
                      />
                    </el-col>

                    <el-col :md="24" :lg="24">
                      <DateDdMmYyyy
                        @DateDdMmYyyy-onBlur="
                          (val) => {
                            $emit('CourierDateTextBox-onBlur', val);
                          }
                        "
                        @DateDdMmYyyy-onChange="
                          (val) => {
                            $emit('CourierDateTextBox-onChange', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyPress="
                          (val) => {
                            $emit('CourierDateTextBox-onKeyPress', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyUp="
                          (val) => {
                            $emit('CourierDateTextBox-onKeyUp', val);
                          }
                        "
                        @DateDdMmYyyy-onFocus="
                          (val) => {
                            $emit('CourierDateTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...CourierDateTextBox,
                          ...configObject.CourierDateTextBox
                        }"
                        name="CourierDateTextBox"
                        ref="RefCourierDateTextBox"
                        :values="configObject.CourierDateTextBox.CourierDateTextBoxValue"
                        v-if="configObject.CourierDateTextBox != undefined ? configObject.CourierDateTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>

            <el-row>
              <el-col :md="10" :lg="10">
                <DateDdMmYyyy
                  @DateDdMmYyyy-onBlur="
                    (val) => {
                      $emit('MaturityTextBox-onBlur', val);
                    }
                  "
                  @DateDdMmYyyy-onChange="
                    (val) => {
                      $emit('MaturityTextBox-onChange', val);
                    }
                  "
                  @DateDdMmYyyy-onKeyPress="
                    (val) => {
                      $emit('MaturityTextBox-onKeyPress', val);
                    }
                  "
                  @DateDdMmYyyy-onKeyUp="
                    (val) => {
                      $emit('MaturityTextBox-onKeyUp', val);
                    }
                  "
                  @DateDdMmYyyy-onFocus="
                    (val) => {
                      $emit('MaturityTextBox-onFocus', val);
                    }
                  "
                  v-bind="{ ...MaturityTextBox, ...configObject.MaturityTextBox }"
                  name="MaturityTextBox"
                  ref="RefMaturityTextBox"
                  :values="configObject.MaturityTextBox.MaturityTextBoxValue"
                  v-if="configObject.MaturityTextBox != undefined ? configObject.MaturityTextBox.isVisible : false"
                />
              </el-col>
            </el-row>

            <el-row>
              <el-col :md="10" :lg="10">
                <AmountNumericDecimal15Point2
                  @AmountNumericDecimal15Point2-onBlur="
                    (val) => {
                      $emit('BillAmountTextBox3-onBlur', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onChange="
                    (val) => {
                      $emit('BillAmountTextBox3-onChange', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onKeyPress="
                    (val) => {
                      $emit('BillAmountTextBox3-onKeyPress', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onKeyUp="
                    (val) => {
                      $emit('BillAmountTextBox3-onKeyUp', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onFocus="
                    (val) => {
                      $emit('BillAmountTextBox3-onFocus', val);
                    }
                  "
                  v-bind="{ ...BillAmountTextBox3, ...configObject.BillAmountTextBox3 }"
                  name="BillAmountTextBox3"
                  ref="RefBillAmountTextBox3"
                  :values="configObject.BillAmountTextBox3.BillAmountTextBox3Value"
                  v-if="configObject.BillAmountTextBox3 != undefined ? configObject.BillAmountTextBox3.isVisible : false"
                />
              </el-col>
              <el-col :md="3" :lg="3"></el-col>
              <el-col  :md="11" :lg="11">
                <AmountNumericDecimal15Point2
                  @AmountNumericDecimal15Point2-onBlur="
                    (val) => {
                      $emit('ReversedAmountTextBox-onBlur', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onChange="
                    (val) => {
                      $emit('ReversedAmountTextBox-onChange', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onKeyPress="
                    (val) => {
                      $emit('ReversedAmountTextBox-onKeyPress', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onKeyUp="
                    (val) => {
                      $emit('ReversedAmountTextBox-onKeyUp', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onFocus="
                    (val) => {
                      $emit('ReversedAmountTextBox-onFocus', val);
                    }
                  "
                  v-bind="{ ...ReversedAmountTextBox, ...configObject.ReversedAmountTextBox }"
                  name="ReversedAmountTextBox"
                  ref="RefReversedAmountTextBox"
                  :values="configObject.ReversedAmountTextBox.ReversedAmountTextBoxValue"
                  v-if="configObject.ReversedAmountTextBox != undefined ? configObject.ReversedAmountTextBox.isVisible : false"
                />
              </el-col>
            </el-row>

            <el-row>
              <el-col :md="10" :lg="10">
                <AmountNumericDecimal15Point2
                  @AmountNumericDecimal15Point2-onBlur="
                    (val) => {
                      $emit('ConvertedAmountTextBox-onBlur', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onChange="
                    (val) => {
                      $emit('ConvertedAmountTextBox-onChange', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onKeyPress="
                    (val) => {
                      $emit('ConvertedAmountTextBox-onKeyPress', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onKeyUp="
                    (val) => {
                      $emit('ConvertedAmountTextBox-onKeyUp', val);
                    }
                  "
                  @AmountNumericDecimal15Point2-onFocus="
                    (val) => {
                      $emit('ConvertedAmountTextBox-onFocus', val);
                    }
                  "
                  v-bind="{ ...ConvertedAmountTextBox, ...configObject.ConvertedAmountTextBox }"
                  name="ConvertedAmountTextBox"
                  ref="RefConvertedAmountTextBox"
                  :values="configObject.ConvertedAmountTextBox.ConvertedAmountTextBoxValue"
                  v-if="configObject.ConvertedAmountTextBox != undefined ? configObject.ConvertedAmountTextBox.isVisible : false"
                />
              </el-col>
            </el-row>
          </el-tab-pane>

          <el-tab-pane
            :label="configObject.InstrumentInfoTab.label"
            v-if="configObject.InstrumentInfoTab != undefined ? configObject.InstrumentInfoTab.isVisible : false"
            name="InstrumentInfo"
          >
            <el-row>
              <el-col :md="24" :lg="24">
                <fieldset v-if="configObject.Section14 != undefined ? configObject.Section14.isVisible : false">
                  <el-row>
                    <el-col :md="10" :lg="10">
                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('BillAmountTextBox2-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('BillAmountTextBox2-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('BillAmountTextBox2-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...BillAmountTextBox2,
                          ...configObject.BillAmountTextBox2
                        }"
                        name="BillAmountTextBox2"
                        ref="RefBillAmountTextBox2"
                        :values="configObject.BillAmountTextBox2.BillAmountTextBox2Value"
                        v-if="configObject.BillAmountTextBox2 != undefined ? configObject.BillAmountTextBox2.isVisible : false"
                      />
                    </el-col>
                    <el-col :md="4" :lg="4"></el-col>
                    <el-col :md="10" :lg="10">
                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('BalanceAmountTextBox2-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('BalanceAmountTextBox2-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('BalanceAmountTextBox2-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...BalanceAmountTextBox2,
                          ...configObject.BalanceAmountTextBox2
                        }"
                        name="BalanceAmountTextBox2"
                        ref="RefBalanceAmountTextBox2"
                        :values="configObject.BalanceAmountTextBox2.BalanceAmountTextBox2Value"
                        v-if="configObject.BalanceAmountTextBox2 != undefined ? configObject.BalanceAmountTextBox2.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :md="10" :lg="10">
                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('InstrumentBalAmountTextBox-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('InstrumentBalAmountTextBox-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('InstrumentBalAmountTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...InstrumentBalAmountTextBox,
                          ...configObject.InstrumentBalAmountTextBox
                        }"
                        name="InstrumentBalAmountTextBox"
                        ref="RefInstrumentBalAmountTextBox"
                        :values="configObject.InstrumentBalAmountTextBox.InstrumentBalAmountTextBoxValue"
                        v-if="configObject.InstrumentBalAmountTextBox != undefined ? configObject.InstrumentBalAmountTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :md="24" :lg="24">
                      <fieldset
                        v-if="configObject.InstrumentInformationSection != undefined ? configObject.InstrumentInformationSection.isVisible : false"
                      >
                        <legend>Instrument Info</legend>
                        <el-row>
                          <el-col :md="3" :lg="3"></el-col>
                          <el-col :md="4" :lg="4">
                            <GenericRadioButton
                              @GenericRadioButton-onChange="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onChange', val);
                                }
                              "
                              @GenericRadioButton-onClick="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onClick', val);
                                }
                              "
                              @GenericRadioButton-onFocus="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onFocus', val);
                                }
                              "
                              name="SBPChequeDDPORadioButton"
                              ref="RefSBPChequeDDPORadioButton"
                              v-bind="{ ...SBPChequeDDPORadioButton, ...configObject.SBPChequeDDPORadioButton }"
                              :values="configObject.SBPChequeDDPORadioButton.SBPChequeDDPORadioButtonValue"
                              v-if="configObject.SBPChequeDDPORadioButton != undefined ? configObject.SBPChequeDDPORadioButton.isVisible : false"
                              :radioGroup="configObject.SBPChequeDDPORadioButton.list1"
                            />
                          </el-col>
                          <el-col :md="3" :lg="3"></el-col>

                          <el-col :md="4" :lg="4">
                            <GenericRadioButton
                              @GenericRadioButton-onChange="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onChange', val);
                                }
                              "
                              @GenericRadioButton-onClick="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onClick', val);
                                }
                              "
                              @GenericRadioButton-onFocus="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onFocus', val);
                                }
                              "
                              name="SBPChequeDDPORadioButton"
                              ref="RefSBPChequeDDPORadioButton"
                              v-bind="{ ...SBPChequeDDPORadioButton, ...configObject.SBPChequeDDPORadioButton }"
                              :values="configObject.SBPChequeDDPORadioButton.SBPChequeDDPORadioButtonValue"
                              v-if="configObject.SBPChequeDDPORadioButton != undefined ? configObject.SBPChequeDDPORadioButton.isVisible : false"
                              :radioGroup="configObject.SBPChequeDDPORadioButton.list2"
                            />
                          </el-col>
                          <el-col :md="3" :lg="3"></el-col>

                          <el-col :md="4" :lg="4">
                            <GenericRadioButton
                              @GenericRadioButton-onChange="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onChange', val);
                                }
                              "
                              @GenericRadioButton-onClick="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onClick', val);
                                }
                              "
                              @GenericRadioButton-onFocus="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onFocus', val);
                                }
                              "
                              name="SBPChequeDDPORadioButton"
                              ref="RefSBPChequeDDPORadioButton"
                              v-bind="{ ...SBPChequeDDPORadioButton, ...configObject.SBPChequeDDPORadioButton }"
                              :values="configObject.SBPChequeDDPORadioButton.SBPChequeDDPORadioButtonValue"
                              v-if="configObject.SBPChequeDDPORadioButton != undefined ? configObject.SBPChequeDDPORadioButton.isVisible : false"
                              :radioGroup="configObject.SBPChequeDDPORadioButton.list3"
                            />
                          </el-col>
                        </el-row>
                        <el-row>
                          <el-col :md="8" :lg="8"></el-col>
                          <el-col :md="9" :lg="9">
                            <GenericTextBox
                              @GenericTextBox-onBlur="
                                (val) => {
                                  $emit('InstTypeTextBox-onBlur', val);
                                }
                              "
                              @GenericTextBox-onChange="
                                (val) => {
                                  $emit('InstTypeTextBox-onChange', val);
                                }
                              "
                              @GenericTextBox-onKeyPress="
                                (val,event) => {
                                  $emit('InstTypeTextBox-onKeyPress', val,event);
                                }
                              "
                              @GenericTextBox-onKeyUp="
                                (val) => {
                                  $emit('InstTypeTextBox-onKeyUp', val);
                                }
                              "
                              @GenericTextBox-onFocus="
                                (val) => {
                                  $emit('InstTypeTextBox-onFocus', val);
                                }
                              "
                              v-bind="{
                                ...InstTypeTextBox,
                                ...configObject.InstTypeTextBox
                              }"
                              name="InstTypeTextBox"
                              ref="RefInstTypeTextBox"
                              :values="configObject.InstTypeTextBox.InstTypeTextBoxValue"
                              v-if="configObject.InstTypeTextBox != undefined ? configObject.InstTypeTextBox.isVisible : false"
                            />
                          </el-col>
                        </el-row>
                        <el-row>
                          <el-col :md="6" :lg="6">
                            <GenericTextBox
                              @GenericTextBox-onBlur="
                                (val) => {
                                  $emit('InstNoTextBox-onBlur', val);
                                }
                              "
                              @GenericTextBox-onChange="
                                (val) => {
                                  $emit('InstNoTextBox-onChange', val);
                                }
                              "
                              @GenericTextBox-onKeyPress="
                                (val,event) => {
                                  $emit('InstNoTextBox-onKeyPress', val,event);
                                }
                              "
                              @GenericTextBox-onKeyUp="
                                (val) => {
                                  $emit('InstNoTextBox-onKeyUp', val);
                                }
                              "
                              @GenericTextBox-onFocus="
                                (val) => {
                                  $emit('InstNoTextBox-onFocus', val);
                                }
                              "
                              v-bind="{
                                ...InstNoTextBox,
                                ...configObject.InstNoTextBox
                              }"
                              name="InstNoTextBox"
                              ref="RefInstNoTextBox"
                              :values="configObject.InstNoTextBox.InstNoTextBoxValue"
                              v-if="configObject.InstNoTextBox != undefined ? configObject.InstNoTextBox.isVisible : false"
                            />
                          </el-col>
                          <el-col :md="2" :lg="2"></el-col>
                          <el-col :md="9" :lg="9">
                            <AmountNumericDecimal15Point2
                              @AmountNumericDecimal15Point2-onBlur="
                                (val) => {
                                  $emit('InstAmountTextBox-onBlur', val);
                                }
                              "
                              @AmountNumericDecimal15Point2-onKeyPress="
                                (val) => {
                                  $emit('InstAmountTextBox-onKeyPress', val);
                                }
                              "
                              @AmountNumericDecimal15Point2-onFocus="
                                (val) => {
                                  $emit('InstAmountTextBox-onFocus', val);
                                }
                              "
                              v-bind="{
                                ...InstAmountTextBox,
                                ...configObject.InstAmountTextBox
                              }"
                              name="InstAmountTextBox"
                              ref="RefInstAmountTextBox"
                              :values="configObject.InstAmountTextBox.InstAmountTextBoxValue"
                              v-if="configObject.InstAmountTextBox != undefined ? configObject.InstAmountTextBox.isVisible : false"
                            />
                          </el-col>
                          <el-col :md="1" :lg="1"></el-col>
                          <el-col :md="6" :lg="6">
                            <DateDdMmYyyy
                              @DateDdMmYyyy-onBlur="
                                (val) => {
                                  $emit('InstDateTextBox-onBlur', val);
                                }
                              "
                              @DateDdMmYyyy-onChange="
                                (val) => {
                                  $emit('InstDateTextBox-onChange', val);
                                }
                              "
                              @DateDdMmYyyy-onKeyUp="
                                (val) => {
                                  $emit('InstDateTextBox-onKeyUp', val);
                                }
                              "
                              @DateDdMmYyyy-onKeyPress="
                                (val) => {
                                  $emit('InstDateTextBox-onKeyPress', val);
                                }
                              "
                              @DateDdMmYyyy-onFocus="
                                (val) => {
                                  $emit('InstDateTextBox-onFocus', val);
                                }
                              "
                              name="InstDateTextBox"
                              ref="RefInstDateTextBox"
                              v-bind="{ ...InstDateTextBox, ...configObject.InstDateTextBox }"
                              :values="configObject.InstDateTextBox.InstDateTextBoxValue"
                              v-if="configObject.InstDateTextBox != undefined ? configObject.InstDateTextBox.isVisible : false"
                            />
                          </el-col>
                        </el-row>
                      </fieldset>
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>
          </el-tab-pane>
        </el-tabs>
      </el-col>
    </el-row>

    <el-row>
      <el-col :md="24" :lg="24">
        <fieldset v-if="configObject.Section15 != undefined ? configObject.Section15.isVisible : false">
          <el-row>
            <el-col :md="2" :lg="2">
              <GenericButton
                @GenericButton-onClick="$emit('OKButton-onClick')"
                @GenericButton-onFocus="$emit('OKButton-onFocus')"
                name="OKButton"
                ref="RefOKButton"
                v-if="configObject.OKButton != undefined ? configObject.OKButton.isVisible : false"
                v-bind="{ ...OKButton, ...configObject.OKButton }"
              />
              <GenericButton
                @GenericButton-onClick="$emit('ReturnButton-onClick')"
                @GenericButton-onFocus="$emit('ReturnButton-onFocus')"
                name="ReturnButton"
                ref="RefReturnButton"
                v-if="configObject.ReturnButton != undefined ? configObject.ReturnButton.isVisible : false"
                v-bind="{ ...ReturnButton, ...configObject.ReturnButton }"
              />
              <GenericButton
                @GenericButton-onClick="$emit('CancelButton-onClick')"
                @GenericButton-onFocus="$emit('CancelButton-onFocus')"
                name="CancelButton"
                ref="RefCancelButton"
                v-if="configObject.CancelButton != undefined ? configObject.CancelButton.isVisible : false"
                v-bind="{ ...CancelButton, ...configObject.CancelButton }"
              />
            </el-col>
            <el-col :md="18" :lg="18"></el-col>
            <el-col :md="2" :lg="2">
              <GenericButton
                @GenericButton-onClick="$emit('BackButton-onClick')"
                @GenericButton-onFocus="$emit('BackButton-onFocus')"
                name="BackButton"
                ref="RefBackButton"
                v-if="configObject.BackButton != undefined ? configObject.BackButton.isVisible : false"
                v-bind="{ ...BackButton, ...configObject.BackButton }"
              />
            </el-col>
            <el-col :md="2" :lg="2">
              <GenericButton
                @GenericButton-onClick="$emit('ExitButton-onClick')"
                @GenericButton-onFocus="$emit('ExitButton-onFocus')"
                name="ExitButton"
                ref="RefExitButton"
                v-if="configObject.ExitButton != undefined ? configObject.ExitButton.isVisible : false"
                v-bind="{ ...ExitButton, ...configObject.ExitButton }"
              />
            </el-col>
          </el-row>
        </fieldset>
      </el-col>
    </el-row>

    <br/>
    <br/>
    <br/>
    <el-row>
    <el-col :lg="24" :md="24">
      <GenericCompositeAlphaNumericSpecialWithButton name="AlphaNumericSpecialWithButton"/>
    </el-col>
    </el-row>

    <!-- --------------------------------------------------------------------- -->
    <br/>
    <br/>
    <br/>
    <el-row>
      <el-col :lg="24" :md="24">
        <fieldset v-if="configObject.Section1.isVisible">
          <legend>CDR Information</legend>
          <el-row>
            <el-col :lg="1" :md="1"></el-col>
            <el-col :lg="20" :md="20">
              <GenericTextBox
                ref="RefDuplicateCDRNoTextBox"
                name="DuplicateCDRNoTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('DuplicateCDRNoTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...DuplicateCDRNoTextBox, ...configObject.DuplicateCDRNoTextBox }"
                :values="configObject.DuplicateCDRNoTextBox.DuplicateCDRNoTextBoxValue"
                v-if="configObject.DuplicateCDRNoTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefCDRNoTextBox"
                name="CDRNoTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('CDRNoTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...CDRNoTextBox, ...configObject.CDRNoTextBox }"
                :values="configObject.CDRNoTextBox.CDRNoTextBoxValue"
                v-if="configObject.CDRNoTextBox.isVisible"
              />
              <DateDdMmYyyy
                ref="RefIssuingDate"
                name="IssuingDate"
                @DateDdMmYyyy-onBlur="
                  (val) => {
                    $emit('IssuingDate-onBlur', val);
                  }
                "
                v-bind="{ ...IssuingDate, ...configObject.IssuingDate }"
                :values="configObject.IssuingDate.IssuingDateValue"
                v-if="configObject.IssuingDate.isVisible"
              />
              <AmountNumericDecimal11Point3
                ref="RefAmountTextBox"
                name="AmountTextBox"
                @AmountNumericDecimal11Point3-onBlur="
                  (val) => {
                    $emit('AmountTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...AmountTextBox, ...configObject.AmountTextBox }"
                :values="configObject.AmountTextBox.AmountTextBoxValue"
                v-if="configObject.AmountTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefBeneficiaryTextBox"
                name="BeneficiaryTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('BeneficiaryTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...BeneficiaryTextBox, ...configObject.BeneficiaryTextBox }"
                :values="configObject.BeneficiaryTextBox.BeneficiaryTextBoxValue"
                v-if="configObject.BeneficiaryTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefRemarksTextBox"
                name="RemarksTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('RemarksTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...RemarksTextBox, ...configObject.RemarksTextBox }"
                :values="configObject.RemarksTextBox.RemarksTextBoxValue"
                v-if="configObject.RemarksTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefNoLabelTextBox"
                name="NoLabelTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('NoLabelTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...NoLabelTextBox, ...configObject.NoLabelTextBox }"
                :values="configObject.NoLabelTextBox.NoLabelTextBoxValue"
                v-if="configObject.NoLabelTextBox.isVisible"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
        </fieldset>
        <fieldset v-if="configObject.Section2.isVisible">
          <legend>Status Information</legend>
          <el-row>
            <el-col :lg="1" :md="1"></el-col>
            <el-col :lg="20" :md="20">
              <GenericTextBox
                ref="RefStatusTextBox"
                name="StatusTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('StatusTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...StatusTextBox, ...configObject.StatusTextBox }"
                :values="configObject.StatusTextBox.StatusTextBoxValue"
                v-if="configObject.StatusTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefStatusIDTextBox"
                name="StatusIDTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('StatusIDTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...StatusIDTextBox, ...configObject.StatusIDTextBox }"
                :values="configObject.StatusIDTextBox.StatusIDTextBoxValue"
                v-if="configObject.StatusIDTextBox.isVisible"
              />
              <DateDdMmYyyy
                ref="RefStatusDate"
                name="StatusDate"
                @DateDdMmYyyy-onBlur="
                  (val) => {
                    $emit('StatusDate-onBlur', val);
                  }
                "
                v-bind="{ ...StatusDate, ...configObject.StatusDate }"
                :values="configObject.StatusDate.StatusDateValue"
                v-if="configObject.StatusDate.isVisible"
              />
              <GenericTextBox
                ref="RefRenewedTextBox"
                name="RenewedTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('RenewedTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...RenewedTextBox, ...configObject.RenewedTextBox }"
                :values="configObject.RenewedTextBox.RenewedTextBoxValue"
                v-if="configObject.RenewedTextBox.isVisible"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
        </fieldset>
        <fieldset v-if="configObject.Section3.isVisible">
          <legend>Mode Of Payment</legend>
          <el-row>
            <el-col :lg="6" :md="6"></el-col>
            <el-col :lg="6" :md="6">
              <GenericRadioButton
                ref="RefMdeOfPayment"
                name="MdeOfPayment"
                @GenericRadioButton-onChange="
                   (val) => {
                    $emit('MdeOfPayment-onChange', val);
                  }
                "
                v-bind="{ ...MdeOfPayment, ...configObject.MdeOfPayment }"
                :values="configObject.MdeOfPayment.MdeOfPaymentValue"
                v-if="configObject.MdeOfPayment.isVisible"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
        </fieldset>
        <fieldset v-if="configObject.Section4.isVisible">
          <el-row>
            <el-col :lg="5" :md="5">
              <GenericButton
                ref="RefProcessOrgButton"
                name="ProcessOrgButton"
                @GenericButton-onClick="
                    $emit('ProcessOrgButton-onClick');"
                v-bind="{ ...ProcessOrgButton, ...configObject.ProcessOrgButton }"
                v-if="configObject.ProcessOrgButton.isVisible"
              />
              <GenericButton
                ref="RefProcessDupCDRButton"
                name="ProcessDupCDRButton"
                @GenericButton-onClick="
                    $emit('ProcessDupCDRButton-onClick');"
                v-bind="{ ...ProcessDupCDRButton, ...configObject.ProcessDupCDRButton }"
                v-if="configObject.ProcessDupCDRButton.isVisible"
              />
            </el-col>
            <el-col :lg="4" :md="4">
              <GenericButton
                ref="RefProcessDupButton"
                name="ProcessDupButton"
                @GenericButton-onClick="
                    $emit('ProcessDupButton-onClick');"
                v-bind="{ ...ProcessDupButton, ...configObject.ProcessDupButton }"
                v-if="configObject.ProcessDupButton.isVisible"
              />
           
            </el-col>
            <el-col :lg="8" :md="8"></el-col>
            <el-col :lg="3" :md="3">
              <GenericButton
                ref="RefBackButton"
                name="BackButton"
                @GenericButton-onClick="
                    $emit('BackButton-onClick');"
                v-bind="{ ...BackButton, ...configObject.BackButton }"
                v-if="configObject.BackButton.isVisible"
              />
             
            </el-col>
            <el-col :lg="3" :md="3">
             
              <GenericButton
                ref="RefExitButton"
                name="ExitButton"
                @GenericButton-onClick="
                    $emit('ExitButton-onClick');
                "
                v-bind="{ ...ExitButton, ...configObject.ExitButton }"
                v-if="configObject.ExitButton.isVisible"
              />
            </el-col>
          </el-row>
        </fieldset>
      </el-col>
    </el-row>

    
  </Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import {
  GenericTextBox,
  GenericButton,
  GenericDatePicker,
  CurrencyAlphaNumericSpecial25,
  GenericSortableTableView,
  FinancialInstrumentAlphaNumericSpecialDashes23,
  AccountNumberWithoutBranchCodeNumericDashes16,
  NtnNumericDashes9,
  AccountTitleString45,
  AmountNumericDecimal15Point2,
  GenericRadioButton,
  DateDdMmYyyy,
  RateNumericDecimal3Point2,
  AmountNumericDecimal11Point3,
  GenericCompositeAlphaNumericSpecialWithButton
} from '@teresol-v2/ui-components';
import { reactive } from 'vue';

export default {
  name: 'MegaSet000',

  components: {
    Form,
    GenericTextBox,
    GenericDatePicker,
    CurrencyAlphaNumericSpecial25,
    GenericSortableTableView,
    GenericButton,
    FinancialInstrumentAlphaNumericSpecialDashes23,
    AccountNumberWithoutBranchCodeNumericDashes16,
    NtnNumericDashes9,
    AccountTitleString45,
    AmountNumericDecimal15Point2,
    GenericRadioButton,
    DateDdMmYyyy,
    RateNumericDecimal3Point2,
    AmountNumericDecimal11Point3,
    GenericCompositeAlphaNumericSpecialWithButton
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    function onInvalidSubmit({ values, errors, results }) {
      let keyValueString = '';
      for (const key in errors) {
        let label = configObject[key].label;
        if (label == undefined) {
          label = configObject[key].dropDownLabel;
        }
        if (label == undefined) {
          label = configObject[key].datePickerLabel;
        }
        if (label == undefined) {
          label = configObject[key].checkBoxLabel;
        }
        if (label == undefined) {
          label = configObject[key].radioLabel;
        }
        keyValueString += `<b>${label}</b>: "${errors[key]}"<br>`;
      }

      keyValueString = keyValueString.slice(0, -2);
      ElMessageBox.alert(keyValueString, 'Message', {
        draggable: true,
        showClose: false,
        autofocus: true,
        closeOnClickModal: false,
        closeOnPressEscape: false,
        dangerouslyUseHTMLString: true,
        customClass: 'errorClass'
      });
    }
    const configObject = reactive(props.configObj.componentProps);

    return {
      onSubmit,
      configObject,
      onInvalidSubmit,
      FinancialInstrumentNoTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      FinancialInstrumentAmountTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      FinancialInstrumentInCurrencyTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      SumOfGDConsValTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      CertificationDateTextBox: {
        spanInputs: 12,
        spanLabels: 12
      },
      TermOfContractTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      TenorTextBox: {
        spanInputs: 9,
        spanLabels: 13
      },
      TenorPercentTextBox: {
        spanInputs: 12,
        spanLabels: 12
      },
      Advance: {
        spanInputs: 15,
        spanLabels: 8
      },
      SightDPTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      UsanceDATextBox: {
        spanInputs: 9,
        spanLabels: 13
      },
      FinancialInInfoTable1: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 0,
        tableHeight: '200px',
        tableWidth: '100',
        tableLabel: ''
      },
      FinancialInInfoTable2: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 0,
        tableHeight: '200px',
        tableWidth: '100',
        tableLabel: ''
      },
      OkButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      ExitButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      LinkButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      UnLinkButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      // ////////////////////////////////////////////////////////////////
      AccountNumberTextBox: {
        spanInputs: 16,
        spanLabel: 2
      },
      NtnNumberTextBox: {
        spanInputs: 15,
        spanLabels: 9
      },
      AccountTitleTextBox: {
        spanInputs: 16,
        spanLabel: 2
      },
      CCINumberTextBox: {
        spanInputs: 15,
        spanLabels: 9
      },
      //bills info tab
      LDBC_AccountNumberTextBox: {
        spanInputs: 15,
        spanLabels: 9
      },

      LDBP_AccountNumberTextBox: {
        spanInputs: 15,
        spanLabels: 9
      },
      DateTextBox: {
        spanInputs: 14,
        spanLabels: 5
      },
      ContractLCRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },

      ExportSalesRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },
      TermTextBox: {
        spanInputs: 18,
        spanLabels: 5
      },

      TenorDaysTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },

      DateRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },
      ShipDateTextBox: {
        spanInputs: 14,
        spanLabels: 10
      },

      DueDateTextBox: {
        spanInputs: 14,
        spanLabels: 10
      },

      BankTextBox: {
        spanInputs: 20,
        spanLabels: 4
      },
      BranchTextBox: {
        spanInputs: 20,
        spanLabels: 4
      },

      BeneficiaryBuyerRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },
      RoadRailRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },

      DiscountInfoDays: {
        spanInputs: 12,
        spanLabels: 7
      },

      RateTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },

      BuyerTextBox: {
        spanInputs: 17,
        spanLabels: 6
      },

      BillAmountTextBox1: {
        spanInputs: 17,
        spanLabels: 6
      },

      BalanceAmountTextBox1: {
        spanInputs: 17,
        spanLabels: 6
      },
      CommodityTextBox: {
        spanInputs: 17,
        spanLabels: 6
      },

      OriginTextBox: {
        spanInputs: 17,
        spanLabels: 6
      },

      DestinationTextBox: {
        spanInputs: 17,
        spanLabels: 6
      },
      InvoiveNumberTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },

      InvoiceAmountTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      InvoiceDateTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },

      CourierRefTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      CourierAmountTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      CourierDateTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      //Instrument Info tab
      BillAmountTextBox2: {
        spanInputs: 16,
        spanLabels: 8
      },
      BalanceAmountTextBox2: {
        spanInputs: 16,
        spanLabels: 8
      },
      InstrumentBalAmountTextBox: {
        spanInputs: 16,
        spanLabels: 8
      },
      SBPChequeDDPORadioButton: {
        spanInputs: 23,
        spanLabels: 1
      },
      InstTypeTextBox: {
        spanInputs: 18,
        spanLabels: 6
      },
      InstNoTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      InstAmountTextBox: {
        spanInputs: 18,
        spanLabels: 6
      },
      InstDateTextBox: {
        spanInputs: 16,
        spanLabels: 8
      },
      MaturityTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      BillAmountTextBox3: {
        spanInputs: 12,
        spanLabels: 8
      },
      ReversedAmountTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      ConvertedAmountTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      OKButton: {
        spanInputs: 23
      },
      BackButton: {
        spanInputs: 23
      },
      ExitButton: {
        spanInputs: 24
      },
      ReturnButton: {
        spanInputs: 23
      },
      CancelButton: {
        spanInputs: 23
      },
      DuplicateCDRNoTextBox: { spanInputs: 12, spanLabels: 6 },
      CDRNoTextBox: { spanInputs: 12, spanLabels: 6 },
      IssuingDate: { spanInputs: 12, spanLabels: 6 },
      AmountTextBox: { spanInputs: 12, spanLabels: 6 },
      BeneficiaryTextBox: { spanInputs: 17, spanLabels: 6 },
      RemarksTextBox: { spanInputs: 17, spanLabels: 6 },
      NoLabelTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusIDTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusDate: { spanInputs: 17, spanLabels: 6 },
      RenewedTextBox: { spanInputs: 17, spanLabels: 6 },
      ModeOfPayment: { spanInputs: 17, spanLabels: 6 },
      ProcessOrgButton: { spanInputs: 21 },
      ProcessDupButton: { spanInputs: 23 },
      ProcessDupCDRButton: { spanInputs: 23 },
      BackButton: { spanInputs: 23 },
      ExitButton: { spanInputs: 23 },
    };
  }
};
</script>
<style scoped>
:deep(.errorClass .el-message-box__title) {
  text-align: center !important;
}
:deep(.errorClass.el-message-box) {
  max-width: 30% !important;
  text-align: left !important;
}
</style>
