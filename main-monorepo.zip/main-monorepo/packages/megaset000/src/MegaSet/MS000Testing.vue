<template>
  <MegaSet000
    :configObj="configurationObject"
    @onSubmit="onSubmit"
    @handleTabClick="TabClicked"
    @AccountNumberTextBox-onBlur="AccountNumberTextBoxOnBlur"
    @NtnNumberTextBox-onBlur="NtnNumberTextBoxOnBlur"
    @AccountTitleTextBox-onBlur="AccountTitleTextBoxOnBlur"
    @CCINumberTextBox-onBlur="CCINumberTextBoxOnBlur"
    @BillAmountTextBox1-onBlur="BillAmountTextBox1OnBlur"
    @ContractLCRadioButton-onChange="ContractLCRadioButtonOnChange"
    @DateTextBox-onBlur="DateTextBoxOnBlur"
    @OKButton-onClick="OKButtonOnClick"
    @RateTextBox-onBlur="RateTextBoxOnBlur"
  />
</template>
<script>
import MegaSet000 from '../MegaSet/MegaSet000.vue';
import { reactive } from 'vue';
export default {
  components: {
    MegaSet000
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    },
    TabClicked(val) {
      console.log('TabClicked', val);
    },
    AccountNumberTextBoxOnBlur(val) {
      console.log('AccountNumberTextBoxOnBlur', val);
    },
    NtnNumberTextBoxOnBlur(val) {
      console.log('NtnNumberTextBoxOnBlur', val);
    },
    AccountTitleTextBoxOnBlur(val) {
      console.log('AccountTitleTextBoxOnBlur', val);
    },
    CCINumberTextBoxOnBlur(val) {
      console.log('CCINumberTextBoxOnBlur', val);
    },
    BillAmountTextBox1OnBlur(val) {
      console.log('BillAmountTextBox1OnBlur', val);
    },
    ContractLCRadioButtonOnChange(val) {
      console.log('ContractLCRadioButtonOnChange', val);
    },
    DateTextBoxOnBlur(val) {
      console.log('DateTextBoxOnBlur', val);
    },
    OKButtonOnClick() {
      console.log('OKButtonOnClick');
    },
    RateTextBoxOnBlur(val) {
      console.log('RateTextBoxOnBlur', val);
    }
  },
  setup() {
    return reactive({
      configurationObject: {
        screenTitle: 'Megaset000',
        componentProps: {
          FieldSetLegend: {
            values: 'Financial Instrument Information'
          },
          OkButton: {
            label: 'OK',
            isDisabled: false,
            isVisible: true
          },
          ExitButton: {
            label: 'Exit',
            isDisabled: false,
            isVisible: true
          },
          LinkButton: {
            label: 'Link',
            isDisabled: false,
            isVisible: true
          },
          UnLinkButton: {
            label: 'UnLink',
            isDisabled: false,
            isVisible: true
          },
          FinancialInstrumentNoTextBox: {
            FinancialInstrumentNoTextBoxValue: '',
            isVisible: true,
            label: 'Financial Inst. No',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            backgroundColor: 'white',
            textAlignment: 'left'
          },
          FinancialInstrumentAmountTextBox: {
            FinancialInstrumentAmountTextBoxValue: '',
            isVisible: true,
            label: 'Financial Inst. Amt',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: 'left'
          },
          FinancialInstrumentInCurrencyTextBox: {
            FinancialInstrumentInCurrencyTextBoxValue: '',
            isVisible: true,
            label: 'Financial Inst. CCY',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            backgroundColor: 'white',
            textAlignment: 'left'
          },
          SumOfGDConsValTextBox: {
            SumOfGDConsValTextBoxValue: '',
            isVisible: true,
            label: 'Sum of GD Cons. Val',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: 'left'
          },
          CertificationDateTextBox: {
            CertificationDateTextBoxValue: '',
            isVisible: true,
            datePickerLabel: 'Certification Date',
            isDisabled: false
          },
          TermOfContractTextBox: {
            TermOfContractTextBoxValue: '',
            isVisible: true,
            label: 'Term Of Contract',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: 'left'
          },
          TenorTextBox: {
            TenorTextBoxValue: '',
            isVisible: true,
            label: 'Tenor',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: 'left'
          },
          TenorPercentTextBox: {
            TenorPercentTextBoxValue: '',
            isVisible: true,
            label: 'Tenor',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: 'left'
          },
          Advance: {
            values: '',
            isVisible: true,
            label: 'Advance %',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: 'left'
          },
          SightDPTextBox: {
            SightDPTextBoxValue: '',
            isVisible: true,
            label: 'Sight DP %',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: 'left'
          },
          UsanceDATextBox: {
            UsanceDATextBoxValue: '',
            isVisible: true,
            label: 'Usance DA %',
            dataType: 'alphaNumericSpecial',
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: 'left'
          },
          FinancialInInfoTable1: {
            isVisible: true,
            tableData: [
              {
                GD_Number: '0101.3000',
                HS_Code: 'UGANDA-800',
                Description: 'Live Horses',
                Amount_Utilized: '5000.00',
                Qty_Utilized: 'N',
                Item_No: 'N'
              }
            ],
            tableColumns: [
              {
                prop: 'GD_Number',
                label: 'GD Number',
                align: 'left',
                columnsWidth: '10'
              },
              {
                prop: 'HS_Code',
                label: 'HS Code',
                align: 'left',
                columnsWidth: '8'
              },
              {
                prop: 'Description',
                label: 'Description',
                align: 'left',
                columnsWidth: '10'
              },
              {
                prop: 'Amount_Utilized',
                label: 'Amount Utilized',
                align: 'left',
                columnsWidth: '10'
              },
              {
                prop: 'Qty_Utilized',
                label: 'Qty Utilized',
                align: 'left',
                columnsWidth: '8'
              },
              {
                prop: 'Item_No',
                label: 'Item No',
                align: 'center',
                columnsWidth: '6'
              }
            ],
            currentRow: {}
          },

          FinancialInInfoTable2: {
            isVisible: true,
            tableData: [
              {
                hs_code: '83021010',
                description: 'One of a kind',
                qty: '1000',
                unit_price: '1054.00',
                uom: '1000',
                amount: '1054.00',
                country_of_origin: 'Pakistan - 586',
                ship_qty: '1',
                lodg_util_amount: '1054.0',
                item_no: '1'
              }
            ],
            tableColumns: [
              {
                prop: 'hs_code',
                label: 'HS Code',
                align: 'left',
                columnsWidth: '8'
              },
              {
                prop: 'description',
                label: 'Description',
                align: 'left',
                columnsWidth: '10'
              },
              {
                prop: 'qty',
                label: 'Qty',
                align: 'left',
                columnsWidth: '8'
              },
              {
                prop: 'unit_price',
                label: 'Unit Price',
                align: 'left',
                columnsWidth: '8'
              },
              {
                prop: 'uom',
                label: 'UOM',
                align: 'left',
                columnsWidth: '8'
              },
              {
                prop: 'amount',
                label: 'Amount',
                align: 'center',
                columnsWidth: '8'
              },
              {
                prop: 'country_of_origin',
                label: 'Country Of Origin',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'ship_qty',
                label: 'Ship Qty',
                align: 'center',
                columnsWidth: '8'
              },
              {
                prop: 'lodg_util_amount',
                label: 'Lodg Util Amount',
                align: 'center',
                columnsWidth: '8'
              },
              {
                prop: 'item_no',
                label: 'Item No',
                align: 'center',
                columnsWidth: '8'
              }
            ],
            currentRow: {}
          },
          AccountNumberTextBox: {
            label: 'A/C No.',
            isDisabled: false,
            isVisible: true,
            AccountNumberTextBoxValue: '60010124000192019',
            backgroundColor: 'white',
            mandatory: false
          },
          AccountTitleTextBox: {
            label: 'A/C Title.',
            isDisabled: false,
            isVisible: true,
            AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
            backgroundColor: 'white',
            mandatory: false
          },

          NtnNumberTextBox: {
            label: 'NTN No.',
            isDisabled: false,
            isVisible: true,
            NtnNumberTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          CCINumberTextBox: {
            label: 'CCI No',
            isDisabled: false,
            isVisible: true,
            CCINumberTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'alphaNumeric',
            mandatory: false
          },

          TabPane: {
            activeName: 'BillInfoTab'
          },
          BillInfoTab: {
            isDisabled: false,
            label: 'Bill Info'
          },
          InstrumentInfoTab: {
            isDisabled: false,
            isVisible: true,
            label: 'Instrument Info'
          },

          CustomerInformationSection: {
            isVisible: true
          },
          Section1: {
            isDisabled: false,
            isVisible: true
          },
          Section2: {
            isDisabled: false,
            isVisible: true
          },
          ///Bills Info
          LDBCNo: {
            LDBCText: 'LDBC 101001/2024',
            isVisible: true
          },
          LDBCAccountNumberTextBox: {
            label: 'LDBC A/C No.',
            isDisabled: false,
            isVisible: true,
            LDBCAccountNumberTextBoxValue: '0338149840011',
            backgroundColor: 'white',
            mandatory: false
          },
          //Instrument Info tab
          Section3: {
            isDisabled: false,
            isVisible: true
          },
          BillAmountTextBox1: {
            label: 'Bill Amount',
            isDisabled: false,
            isVisible: true,
            BillAmountTextBox1Value: '',
            backgroundColor: 'white',
            mandatory: false
          },
          BalanceAmountTextBox1: {
            label: 'Balance Amount',
            isDisabled: false,
            isVisible: true,
            BalanceAmountTextBox1Value: '',
            backgroundColor: 'white',
            mandatory: false
          },
          InstrumentBalAmountTextBox: {
            label: 'Instrument Bal',
            isDisabled: false,
            isVisible: true,
            InstrumentBalAmountTextBoxValue: '',
            backgroundColor: 'white',
            mandatory: false
          },
          InstrumentInformationSection: {
            isVisible: true
          },
          SBPChequeDDPORadioButton: {
            isDisabled: false,
            values: '',
            isVisible: true,
            SBPChequeDDPORadioButtonValue: 'Discrepancy',
            list1: [
              {
                value: 'SBP Cheque',
                label: 'SBP Cheque',
                isDisabled: false
              }
            ],
            list2: [
              {
                value: 'DD',
                label: 'DD',
                isDisabled: false
              }
            ],
            list3: [
              {
                value: 'PO',
                label: 'PO',
                isDisabled: false
              }
            ]
          },
          InstTypeTextBox: {
            label: 'Inst. Type',
            isDisabled: false,
            isVisible: true,
            InstTypeTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'alphaNumeric',
            mandatory: false
          },
          InstNoTextBox: {
            label: 'Inst. No',
            isDisabled: false,
            isVisible: true,
            InstNoTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          InstAmountTextBox: {
            label: 'Inst. Amount',
            isDisabled: false,
            isVisible: true,
            InstAmountTextBoxValue: '',
            backgroundColor: 'white',
            mandatory: false
          },
          InstDateTextBox: {
            InstDateTextBoxValue: '',
            isVisible: true,
            label: 'Inst. Date',
            backgroundColor: 'White',
            isDisabled: false
          },
          //bills info tab
          BillInfoTab: {
            isDisabled: false,
            label: 'Bill Info'
          },
          SalesTaxTab: {
            isDisabled: false,
            label: 'Sales Tax'
          },

          CustomerInformationSection: {
            isVisible: true
          },
          Section4: {
            isDisabled: false,
            isVisible: true
          },
          Section5: {
            isDisabled: false,
            isVisible: true
          },
          Section6: {
            isDisabled: false,
            isVisible: true
          },
          Section7: {
            isDisabled: false,
            isVisible: true
          },
          Section8: {
            isDisabled: false,
            isVisible: true
          },

          Section9: {
            isDisabled: false,
            isVisible: true
          },
          Section10: {
            isDisabled: false,
            isVisible: true
          },
          Section11: {
            isDisabled: false,
            isVisible: true
          },
          Section12: {
            isDisabled: false,
            isVisible: true
          },
          Section13: {
            isDisabled: false,
            isVisible: true
          },
          Section14: {
            isDisabled: false,
            isVisible: true
          },
          Section15: {
            isDisabled: false,
            isVisible: true
          },
          ///Bills Info
          LDBC_No: {
            LDBCText: 'LDBP No. / LDBC No. Year: 101001/2024',
            isVisible: true
          },

          LDBP_No: {
            LDBPText: '101001/2024',
            isVisible: true
          },

          LDBC_AccountNumberTextBox: {
            label: 'LDBC A/C No.',
            isDisabled: false,
            isVisible: true,
            LDBC_AccountNumberTextBoxValue: '60010124000192019',
            backgroundColor: 'white',
            mandatory: false
          },

          LDBP_AccountNumberTextBox: {
            label: 'LDBP A/C No.',
            isDisabled: false,
            isVisible: true,
            LDBP_AccountNumberTextBoxValue: '60010124000192019',
            backgroundColor: 'white',
            mandatory: false
          },
          DateTextBox: {
            label: 'Date',
            isDisabled: false,
            isVisible: true,
            DateTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          ContractLCRadioButton: {
            isDisabled: false,
            ContractLCRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'Contract',
                label: 'Contract',
                isDisabled: false
              },
              {
                value: 'LC',
                label: 'L/C',
                isDisabled: false
              }
            ]
          },

          ExportSalesRadioButton: {
            isDisabled: false,
            ExportSalesRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'Export',
                label: 'Export',
                isDisabled: false
              },
              {
                value: 'Sales',
                label: 'Sales',
                isDisabled: false
              }
            ]
          },

          TermTextBox: {
            label: 'Term',
            isDisabled: false,
            isVisible: true,
            TermTextBoxValue: 'SIGHT -1 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          SightLabel: {
            SightText: '',
            isVisible: true
          },
          UsanceLabel: {
            UsanceText: '',
            isVisible: true
          },

          TenorDaysTextBox: {
            label: 'Days',
            isDisabled: false,
            isVisible: true,
            TenorDaysTextBoxValue: '1 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          DateRadioButton: {
            isDisabled: false,
            DateRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'FromShipDate',
                label: 'From Ship. Date',
                isDisabled: false
              },
              {
                value: 'AfterShipDate',
                label: 'After Ship. Date',
                isDisabled: false
              },
              {
                value: 'NegotiationDate',
                label: 'Negotiation Date',
                isDisabled: false
              }
            ]
          },

          ShipDateTextBox: {
            label: 'Ship Date',
            isDisabled: false,
            isVisible: true,
            ShipDateTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          DueDateTextBox: {
            label: 'Due Date',
            isDisabled: false,
            isVisible: true,
            DueDateTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          BankTextBox: {
            label: 'Bank',
            isDisabled: false,
            isVisible: true,
            BankTextBoxValue: 'ISLAMIC BANK',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          BranchTextBox: {
            label: 'Branch',
            isDisabled: false,
            isVisible: true,
            BranchTextBoxValue: 'Karachi-0006 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          BeneficiaryBuyerRadioButton: {
            isDisabled: false,
            BeneficiaryBuyerRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'ByBeneficiary',
                label: 'By Beneficiary',
                isDisabled: false
              },
              {
                value: 'Buyer',
                label: 'Buyer',
                isDisabled: false
              }
            ]
          },

          RoadRailRadioButton: {
            isDisabled: false,
            RoadRailRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'ByRoad',
                label: 'By Road',
                isDisabled: false
              },
              {
                value: 'ByRail',
                label: 'By Rail',
                isDisabled: false
              }
            ]
          },

          DiscountInfoDays: {
            label: 'Days',
            isDisabled: false,
            isVisible: true,
            DiscountInfoDaysValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          RateTextBox: {
            label: 'Rate',
            isDisabled: false,
            isVisible: true,
            RateTextBoxValue: '52.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          BuyerTextBox: {
            label: 'Buyer',
            isDisabled: false,
            isVisible: true,
            BuyerTextBoxValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          BillAmountTextBox2: {
            label: 'Bill Amount ',
            isDisabled: false,
            isVisible: true,
            BillAmountTextBox2Value: '200.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          BalanceAmountTextBox2: {
            label: 'Balance Amount ',
            isDisabled: false,
            isVisible: true,
            BalanceAmountTextBox2Value: '200.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          CommodityTextBox: {
            label: 'Commodity',
            isDisabled: false,
            isVisible: true,
            CommodityTextBoxValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          OriginTextBox: {
            label: 'Origin',
            isDisabled: false,
            isVisible: true,
            OriginTextBoxValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          DestinationTextBox: {
            label: 'Destination',
            isDisabled: false,
            isVisible: true,
            DestinationTextBoxValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          InvoiveNumberTextBox: {
            label: 'Invoice No',
            isDisabled: false,
            isVisible: true,
            InvoiveNumberTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          InvoiceAmountTextBox: {
            label: 'Invoice Amount ',
            isDisabled: false,
            isVisible: true,
            InvoiceAmountTextBoxValue: '200.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          InvoiceDateTextBox: {
            label: 'Invoice Date ',
            isDisabled: false,
            isVisible: true,
            InvoiceDateTextBoxValue: '04/11/2024',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          CourierRefTextBox: {
            label: 'Courier Ref',
            isDisabled: false,
            isVisible: true,
            CourierRefTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          CourierAmountTextBox: {
            label: 'Courier Amount ',
            isDisabled: false,
            isVisible: true,
            CourierAmountTextBoxValue: '200.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          CourierDateTextBox: {
            label: 'Courier Date ',
            isDisabled: false,
            isVisible: true,
            CourierDateTextBoxValue: '04/11/2024',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          MaturityTextBox: {
            MaturityTextBoxValue: '',
            isVisible: true,
            label: 'Maturity Date',
            backgroundColor: 'White',
            isDisabled: false
          },
          BillAmountTextBox3: {
            label: 'Bill Amount',
            isDisabled: false,
            isVisible: true,
            BillAmountTextBox3Value: '',
            backgroundColor: 'white',
            mandatory: false
          },
          ReversedAmountTextBox: {
            label: 'Reversed Amount',
            isDisabled: false,
            isVisible: true,
            ReversedAmountTextBoxValue: '',
            backgroundColor: 'white',
            mandatory: false
          },
          ConvertedAmountTextBox: {
            label: 'Converted Amount',
            isDisabled: false,
            isVisible: true,
            ConvertedAmountTextBoxValue: '',
            backgroundColor: 'white',
            mandatory: false
          },
          //bttons field
          OKButton: {
            isVisible: true,
            label: 'OK',
            isDisabled: false,
            nativeType: 'submit'
          },
          BackButton: {
            isVisible: true,
            label: 'Back',
            isDisabled: false
          },
          ViewLodgeVoucherButton: {
            isVisible: true,
            label: 'View Lodge Voucher',
            isDisabled: false
          },
          ExitButton: {
            isVisible: true,
            label: 'Exit',
            isDisabled: false
          },
          ReturnButton: {
            isVisible: true,
            label: 'Return',
            isDisabled: false
          },
          CancelButton: {
            isVisible: true,
            label: 'Cancel',
            isDisabled: false
          },
          DuplicateCDRNoTextBox: {
            label: 'DupCDRNo',
            isVisible: true,
            isDisabled: false,
            dataType: 'numeric',
            inputLength: '10',
            backgroundColor: 'white',
            DuplicateCDRNoTextBoxValue: '98'
          },
          CDRNoTextBox: {
            label: 'CDR No',
            isVisible: true,
            isDisabled: false,
            dataType: 'numeric',
            inputLength: '10',
            backgroundColor: 'white',
            CDRNoTextBoxValue: '98'
          },
          IssuingDate: {
            label: 'Issuing Date',
            isVisible: true,
            isDisabled: false,
            backgroundColor: 'white',
            IssuingDateValue: ''
          },
          AmountTextBox: {
            label: 'Amount',
            isVisible: true,
            isDisabled: false,
            dataType: 'numeric',
            inputLength: '10',
            backgroundColor: 'white',
            AmountTextBoxValue: '98'
          },
          BeneficiaryTextBox: {
            label: 'Beneficiary',
            isVisible: true,
            isDisabled: false,
            dataType: 'alphaneumeric',
            inputLength: '100',
            backgroundColor: 'white',
            BeneficiaryTextBoxValue: '98'
          },
          RemarksTextBox: {
            label: 'Remarks',
            isVisible: true,
            isDisabled: false,
            dataType: 'alphaneumeric',
            inputLength: '100',
            backgroundColor: 'white',
            RemarksTextBoxValue: 'Remarks'
          },
          NoLabelTextBox: {
            label: '',
            isVisible: true,
            isDisabled: false,
            dataType: 'alphaneumeric',
            inputLength: '100',
            backgroundColor: 'white',
            NoLabelTextBoxValue: 'NoLabelTextBox'
          },
          StatusTextBox: {
            label: 'Status',
            isVisible: true,
            isDisabled: false,
            dataType: 'alphaneumeric',
            inputLength: '100',
            backgroundColor: 'white',
            StatusTextBoxValue: 'Issued'
          },
          StatusIDTextBox: {
            label: 'Status ID',
            isVisible: true,
            isDisabled: false,
            dataType: 'alphaneumeric',
            inputLength: '100',
            backgroundColor: 'white',
            StatusIDTextBoxValue: ''
          },
          StatusDate: {
            label: 'Status Date',
            isVisible: true,
            isDisabled: false,
            backgroundColor: 'white',
            IssuingDateValue: ''
          },
          RenewedTextBox: {
            label: 'Renewed',
            isVisible: true,
            isDisabled: false,
            dataType: 'alphaneumeric',
            inputLength: '100',
            backgroundColor: 'white',
            RenewedTextBox: ''
          },
          MdeOfPayment: {
            label: 'Renewed',
            isVisible: true,
            isDisabled: false,
            radioGroup: [
              {
                value: 'Credit to A/C',
                label: 'Credit to A/C',
                isVisible: true,
                isDisabled: false
              }
            ]
          },
          ProcessOrgButton: {
            label: 'Process Org',
            isVisible: true,
            isDisabled: false
          },
          ProcessDupButton: {
            label: 'Process Dup',
            isVisible: true,
            isDisabled: false
          },
          ProcessDupCDRButton: {
            label: 'Process Duplicate CDR',
            isVisible: true,
            isDisabled: false
          },
          ExitButton: {
            label: 'Exit',
            isVisible: true,
            isDisabled: false
          },
          BackButton: {
            label: 'Back',
            isVisible: true,
            isDisabled: false
          },
          Section1: {
            isVisible: true
          },
          Section2: {
            isVisible: true
          },
          Section3: {
            isVisible: true
          },
          Section4: {
            isVisible: true
          }
        }
      }
    });
  }
};
</script>
