import { createApp } from 'vue';
import Dev from './serve.vue';
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import MegaSet1172 from '../src/install';
import "../../../assets/style.css"
// To register individual components where they are used (serve.vue) instead of using the
// library as a whole, comment/remove this import and it's corresponding "app.use" call
import Maska from 'maska'
import Megaset1172 from '../src/install';
import { VueMaskDirective } from 'v-mask';
import router from '../src/router'
import PrimeVue from 'primevue/config';
import 'primevue/resources/themes/saga-blue/theme.css'
import 'primevue/resources/primevue.min.css'
import 'primeicons/primeicons.css'
import 'primeflex/primeflex.css'
const vMaskV2 = VueMaskDirective;
const vMaskV3 = {
    beforeMount: vMaskV2.bind,
    updated: vMaskV2.componentUpdated,
    unmounted: vMaskV2.unbind
}; 
const app = createApp(Dev).use(router);
app.config.devtools = true
app.use(ElementPlus);
app.use(PrimeVue)
app.use(Maska)
app.use(Megaset1172);
app.directive('mask', vMaskV3)
app.mount('#app');
