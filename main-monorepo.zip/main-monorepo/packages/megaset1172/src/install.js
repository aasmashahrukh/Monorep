import MegaSet1172 from './MegaSet/MegaSet1172.vue'

function install(Vue) {
	if (install.installed) return;
	install.installed = true;

	Vue.component("MegaSet1172",MegaSet1172);
}

const plugin = {
	install,
};

let GlobalVue = null;
if (typeof window !== "undefined") {
	GlobalVue = window.Vue;
} else if (typeof global !== "undefined") {
	GlobalVue = global.vue;
}
if (GlobalVue) {
	GlobalVue.use(plugin);
}

MegaSet1172.install = install;

export default MegaSet1172;