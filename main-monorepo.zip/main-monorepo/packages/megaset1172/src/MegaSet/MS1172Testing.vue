<template>
<MegaSet1172 :configObj="MS_1172_ConfigurationObject"
  @onSubmit="onSubmit" />
</template>
<script>
import MegaSet1172 from '../MegaSet/MegaSet1172.vue';
import { reactive } from 'vue';
export default {
  components: {
    MegaSet1172
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    },
  },
  setup() {
    return reactive({
       MS_1172_ConfigurationObject:{
        screenTitle: "Megaset1172",
        componentProps:{
          FieldSetLegend:{
            values:'Financial Instrument Information'
          },
          OkButton: {
              label: 'OK',
              isDisabled: false,
              isVisible: true
            },
          ExitButton: {
              label: 'Exit',
              isDisabled: false,
              isVisible: true
            },
          LinkButton: {
              label: 'Link',
              isDisabled: false,
              isVisible: true
            },
          UnLinkButton: {
              label: 'UnLink',
              isDisabled: false,
              isVisible: true
            },
          FinancialInstrumentNoTextBox:{
            FinancialInstrumentNoTextBoxValue:"",
            isVisible:true,
            label: "Financial Inst. No",
            dataType: "alphaNumericSpecial",
            inputLength: 10,            
            isDisabled: false,            
            mandatory: true,
            backgroundColor: "white",            
            textAlignment: "left"
          },
          FinancialInstrumentAmountTextBox:{
            FinancialInstrumentAmountTextBoxValue:"",
            isVisible:true,
            label: "Financial Inst. Amt",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,            
            mandatory: true,
            textAlignment: "left"
          },
          FinancialInstrumentInCurrencyTextBox:{
            FinancialInstrumentInCurrencyTextBoxValue:"",
            isVisible:true,
            label: "Financial Inst. CCY",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,            
            mandatory: true,
            backgroundColor: "white",
            textAlignment: "left"
          },
          SumOfGDConsValTextBox:{
            SumOfGDConsValTextBoxValue:"",
            isVisible:true,
            label: "Sum of GD Cons. Val",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,            
            mandatory: true,
            textAlignment: "left"
          },
          CertificationDateTextBox:{
            CertificationDateTextBoxValue:"",
            isVisible:true,
            datePickerLabel: "Certification Date",
            isDisabled: false,            
          },
          TermOfContractTextBox:{
            TermOfContractTextBoxValue:"",
            isVisible:true,
            label: "Term Of Contract",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,            
            mandatory: true,
            textAlignment: "left"
          },
          TenorTextBox:{
            TenorTextBoxValue:"",
            isVisible:true,
            label: "Tenor",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,            
            mandatory: true,
            textAlignment: "left"
          },
          TenorPercentTextBox:{
            TenorPercentTextBoxValue:"",
            isVisible:true,
            label: "Tenor",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: "left"
          },
          Advance:{
            values:"",
            isVisible:true,
            label: "Advance %",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,            
            mandatory: true,
            textAlignment: "left"
      },
      SightDPTextBox:{
        SightDPTextBoxValue:"",
            isVisible:true,
            label: "Sight DP %",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,          
            mandatory: true,
            textAlignment: "left"
      },
      UsanceDATextBox:{
        UsanceDATextBoxValue:"",
            isVisible:true,
            label: "Usance DA %",
            dataType: "alphaNumericSpecial",
            inputLength: 10,
            isDisabled: false,
            mandatory: true,
            textAlignment: "left"
      },
      FinancialInInfoTable1: {
            isVisible: true,
            tableData: [
              {
                GD_Number: "0101.3000",
                HS_Code: "UGANDA-800",
                Description: "Live Horses",
                Amount_Utilized: "5000.00",
                Qty_Utilized: "N",
                Item_No: "N",
              },
            ],
            tableColumns: [
              {
                prop: "GD_Number",
                label: "GD Number",
                align: "left",
                columnsWidth: "10",
              },
              {
                prop: "HS_Code",
                label: "HS Code",
                align: "left",
                columnsWidth: "8",
              },
              {
                prop: "Description",
                label: "Description",
                align: "left",
                columnsWidth: "10",
              },
              {
                prop: "Amount_Utilized",
                label: "Amount Utilized",
                align: "left",
                columnsWidth: "10",
              },
              {
                prop: "Qty_Utilized",
                label: "Qty Utilized",
                align: "left",
                columnsWidth: "8",
              },
              {
                prop: "Item_No",
                label: "Item No",
                align: "center",
                columnsWidth: "6",
              },
              
            ],
            currentRow: {},
          },
        
      FinancialInInfoTable2: {
            isVisible: true,
            tableData: [
              {
                hs_code: "83021010",
                description: "One of a kind",
                qty: "1000",
                unit_price: "1054.00",
                uom:"1000",
                amount:"1054.00",
                country_of_origin:"Pakistan - 586",
                ship_qty:"1",
                lodg_util_amount:"1054.0",
                item_no: "1",
              },
            ],
            tableColumns: [
             
              {
                prop: "hs_code",
                label: "HS Code",
                align: "left",
                columnsWidth: "8",
              },
              {
                prop: "description",
                label: "Description",
                align: "left",
                columnsWidth: "10",
              },              
              {
                prop: "qty",
                label: "Qty",
                align: "left",
                columnsWidth: "8",
              },
              {
                prop: "unit_price",
                label: "Unit Price",
                align: "left",
                columnsWidth: "8",
              },
              {
                prop: "uom",
                label: "UOM",
                align: "left",
                columnsWidth: "8",
              },
              {
                prop: "amount",
                label: "Amount",
                align: "center",
                columnsWidth: "8",
              },
              {
                prop: "country_of_origin",
                label: "Country Of Origin",
                align: "center",
                columnsWidth: "10",
              },
              {
                prop: "ship_qty",
                label: "Ship Qty",
                align: "center",
                columnsWidth: "8",
              },
              {
                prop: "lodg_util_amount",
                label: "Lodg Util Amount",
                align: "center",
                columnsWidth: "8",
              },
              {
                prop: "item_no",
                label: "Item No",
                align: "center",
                columnsWidth: "8",
              },
              
            ],
            currentRow: {},
          },
        }

        }
    });
  }
};
</script>