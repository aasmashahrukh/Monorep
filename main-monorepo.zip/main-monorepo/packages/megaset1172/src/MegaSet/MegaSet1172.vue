<template>
  <Form as="el-form" @submit="onSubmit">

    <!-- Field Set Values -->

    <fieldset>

      <legend>
        {{ configObject.FieldSetLegend.values }}
      </legend>

      <el-row>

        <el-col :lg="12" :md="12">
          <FinancialInstrumentAlphaNumericSpecialDashes23 @FinancialInstrumentAlphaNumericSpecialDashes23-onBlur="(val) => {
              $emit('FinancialInstrumentNoTextBox-onBlur', val);
            }
            " @FinancialInstrumentAlphaNumericSpecialDashes23-onChange="(val) => {
            $emit('FinancialInstrumentNoTextBox-onChange', val);
          }
          " @FinancialInstrumentAlphaNumericSpecialDashes23-onKeyPress="(val) => {
            $emit('FinancialInstrumentNoTextBox-onKeyPress', val);
          }
          " @FinancialInstrumentAlphaNumericSpecialDashes23-onKeyUp="(val) => {
            $emit('FinancialInstrumentNoTextBox-onKeyUp', val);
          }
          " @FinancialInstrumentAlphaNumericSpecialDashes23-onFocus="(val) => {
            $emit('FinancialInstrumentNoTextBox-onFocus', val);
          }
          " v-bind="{ ...FinancialInstrumentNoTextBox, ...configObject.FinancialInstrumentNoTextBox }" name="FinancialInstrumentNoTextBox" ref="RefFinancialInstrumentNoTextBox"
            :values="configObject.FinancialInstrumentNoTextBox.FinancialInstrumentNoTextBoxValue"

            v-if="configObject.FinancialInstrumentNoTextBox!=undefined ? configObject.FinancialInstrumentNoTextBox.isVisible : false" />
        </el-col>

        <el-col :lg="12" :md="12">
          <GenericTextBox @GenericTextBox-onBlur="(val) => {
              $emit('FinancialInstrumentAmountTextBox-onBlur', val);
            }
            " @GenericTextBox-onChange="(val) => {
            $emit('FinancialInstrumentAmountTextBox-onChange', val);
          }
          " @GenericTextBox-onKeyPress="(val) => {
            $emit('FinancialInstrumentAmountTextBox-onKeyPress', val);
          }
          " @GenericTextBox-onKeyUp="(val) => {
            $emit('FinancialInstrumentAmountTextBox-onKeyUp', val);
          }
          " @GenericTextBox-onFocus="(val) => {
            $emit('FinancialInstrumentAmountTextBox-onFocus', val);
          }
          " v-bind="{ ...FinancialInstrumentAmountTextBox, ...configObject.FinancialInstrumentAmountTextBox }" name="FinancialInstrumentAmountTextBox" ref="RefFinancialInstrumentAmountTextBox"
          :values="configObject.FinancialInstrumentAmountTextBox.FinancialInstrumentAmountTextBoxValue"

            v-if="configObject.FinancialInstrumentAmountTextBox!=undefined ? configObject.FinancialInstrumentAmountTextBox.isVisible : false" />
        </el-col>

      </el-row>

      <el-row>

        <el-col :lg="12" :md="12">
          <CurrencyAlphaNumericSpecial25 @CurrencyAlphaNumericSpecial25-onBlur="(val) => {
              $emit('FinancialInstrumentInCurrencyTextBox-onBlur', val);
            }
            " @CurrencyAlphaNumericSpecial25-onChange="(val) => {
            $emit('FinancialInstrumentInCurrencyTextBox-onChange', val);
          }
          " @CurrencyAlphaNumericSpecial25-onKeyPress="(val) => {
            $emit('FinancialInstrumentInCurrencyTextBox-onKeyPress', val);
          }
          " @CurrencyAlphaNumericSpecial25-onKeyUp="(val) => {
            $emit('FinancialInstrumentInCurrencyTextBox-onKeyUp', val);
          }
          " @CurrencyAlphaNumericSpecial25-onFocus="(val) => {
            $emit('FinancialInstrumentInCurrencyTextBox-onFocus', val);
          }
          " v-bind="{ ...FinancialInstrumentInCurrencyTextBox, ...configObject.FinancialInstrumentInCurrencyTextBox }" name="FinancialInstrumentInCurrencyTextBox" ref="RefFinancialInstrumentInCurrencyTextBox"
          :values="configObject.FinancialInstrumentInCurrencyTextBox.FinancialInstrumentInCurrencyTextBoxValue"

            v-if="configObject.FinancialInstrumentInCurrencyTextBox!=undefined ? configObject.FinancialInstrumentInCurrencyTextBox.isVisible : false" />
        </el-col>

        <el-col :lg="12" :md="12">
          <GenericTextBox @GenericTextBox-onBlur="(val) => {
              $emit('SumOfGDConsValTextBox-onBlur', val);
            }
            " @GenericTextBox-onChange="(val) => {
            $emit('SumOfGDConsValTextBox-onChange', val);
          }
          " @GenericTextBox-onKeyPress="(val) => {
            $emit('SumOfGDConsValTextBox-onKeyPress', val);
          }
          " @GenericTextBox-onKeyUp="(val) => {
            $emit('SumOfGDConsValTextBox-onKeyUp', val);
          }
          " @GenericTextBox-onFocus="(val) => {
            $emit('SumOfGDConsValTextBox-onFocus', val);
          }
          " v-bind="{ ...SumOfGDConsValTextBox, ...configObject.SumOfGDConsValTextBox }" name="SumOfGDConsValTextBox" ref="RefSumOfGDConsValTextBox"
                      :values="configObject.SumOfGDConsValTextBox.SumOfGDConsValTextBoxValue"
            v-if="configObject.SumOfGDConsValTextBox!=undefined ? configObject.SumOfGDConsValTextBox.isVisible : false" />
        </el-col>
        
      </el-row>

      <el-row>

        <el-col :lg="8" :md="8">
          <GenericDatePicker @GenericDatePicker-onBlur="(val) => {
              $emit('CertificationDateTextBox-onBlur', val);
            }
            " name="CertificationDateTextBox" ref="RefCertificationDateTextBox" v-bind="{
                        ...CertificationDateTextBox,
                        ...configObject.CertificationDateTextBox,
                      }"
 :values="configObject.CertificationDateTextBox.CertificationDateTextBoxValue"

                                            v-if="configObject.CertificationDateTextBox!=undefined ? configObject.CertificationDateTextBox.isVisible : false">
          </GenericDatePicker>
        </el-col>

        <el-col :lg="1" :md="1"></el-col>


        <el-col :lg="8" :md="8">
          <GenericTextBox @GenericTextBox-onBlur="(val) => {
              $emit('TermOfContractTextBox-onBlur', val);
            }
            " @GenericTextBox-onChange="(val) => {
            $emit('TermOfContractTextBox-onChange', val);
          }
          " @GenericTextBox-onKeyPress="(val) => {
            $emit('TermOfContractTextBox-onKeyPress', val);
          }
          " @GenericTextBox-onKeyUp="(val) => {
            $emit('TermOfContractTextBox-onKeyUp', val);
          }
          " @GenericTextBox-onFocus="(val) => {
            $emit('TermOfContractTextBox-onFocus', val);
          }
          " v-bind="{ ...TermOfContractTextBox, ...configObject.TermOfContractTextBox }" name="TermOfContractTextBox" ref="RefTermOfContractTextBox"
            :values="configObject.TermOfContractTextBox.TermOfContractTextBoxValue"

           v-if="configObject.TermOfContractTextBox!=undefined ? configObject.TermOfContractTextBox.isVisible : false" />
        </el-col>

        <el-col :lg="1" :md="1"></el-col>

        <el-col :lg="6" :md="6">
          <GenericTextBox @GenericTextBox-onBlur="(val) => {
              $emit('TenorTextBox-onBlur', val);
            }
            " @GenericTextBox-onChange="(val) => {
            $emit('TenorTextBox-onChange', val);
          }
          " @GenericTextBox-onKeyPress="(val) => {
            $emit('TenorTextBox-onKeyPress', val);
          }
          " @GenericTextBox-onKeyUp="(val) => {
            $emit('TenorTextBox-onKeyUp', val);
          }
          " @GenericTextBox-onFocus="(val) => {
            $emit('TenorTextBox-onFocus', val);
          }
          " v-bind="{ ...TenorTextBox, ...configObject.TenorTextBox }" name="TenorTextBox" ref="RefTenorTextBox"
            :values="configObject.TenorTextBox.TenorTextBoxValue"

            v-if="configObject.TenorTextBox!=undefined ? configObject.TenorTextBox.isVisible : false" />
        </el-col>

      </el-row>

      <el-row>
        <el-col :lg="12" :md="12"><el-form-item>Share Percentage:</el-form-item></el-col>
      </el-row>

      <el-row>

        <el-col :lg="8" :md="8">
          <GenericTextBox @GenericTextBox-onBlur="(val) => {
              $emit('TenorPercentTextBox-onBlur', val);
            }
            " @GenericTextBox-onChange="(val) => {
            $emit('TenorPercentTextBox-onChange', val);
          }
          " @GenericTextBox-onKeyPress="(val) => {
            $emit('TenorPercentTextBox-onKeyPress', val);
          }
          " @GenericTextBox-onKeyUp="(val) => {
            $emit('TenorPercentTextBox-onKeyUp', val);
          }
          " @GenericTextBox-onFocus="(val) => {
            $emit('TenorPercentTextBox-onFocus', val);
          }
          " v-bind="{ ...TenorPercentTextBox, ...configObject.TenorPercentTextBox }" name="TenorPercentTextBox" ref="RefTenorPercentTextBox"
            :values="configObject.TenorPercentTextBox.TenorPercentTextBoxValue"

            v-if="configObject.TenorPercentTextBox!=undefined ? configObject.TenorPercentTextBox.isVisible : false" />
        </el-col>

        <el-col :lg="1" :md="1"></el-col> 

        <el-col :lg="8" :md="8">
          <GenericTextBox @GenericTextBox-onBlur="(val) => {
              $emit('SightDPTextBox-onBlur', val);
            }
            " @GenericTextBox-onChange="(val) => {
            $emit('SightDPTextBox-onChange', val);
          }
          " @GenericTextBox-onKeyPress="(val) => {
            $emit('SightDPTextBox-onKeyPress', val);
          }
          " @GenericTextBox-onKeyUp="(val) => {
            $emit('SightDPTextBox-onKeyUp', val);
          }
          " @GenericTextBox-onFocus="(val) => {
            $emit('SightDPTextBox-onFocus', val);
          }
          " v-bind="{ ...SightDPTextBox, ...configObject.SightDPTextBox }" name="SightDPTextBox" ref="RefSightDPTextBox"
          :values="configObject.SightDPTextBox.SightDPTextBoxValue"

            v-if="configObject.SightDPTextBox!=undefined ? configObject.SightDPTextBox.isVisible : false" />
        </el-col>

        <el-col :lg="1" :md="1"></el-col> 

        <el-col :lg="6" :md="6">
          <GenericTextBox @GenericTextBox-onBlur="(val) => {
              $emit('UsanceDATextBox-onBlur', val);
            }
            " @GenericTextBox-onChange="(val) => {
            $emit('UsanceDATextBox-onChange', val);
          }
          " @GenericTextBox-onKeyPress="(val) => {
            $emit('UsanceDATextBox-onKeyPress', val);
          }
          " @GenericTextBox-onKeyUp="(val) => {
            $emit('UsanceDATextBox-onKeyUp', val);
          }
          " @GenericTextBox-onFocus="(val) => {
            $emit('UsanceDATextBox-onFocus', val);
          }
          " v-bind="{ ...UsanceDATextBox, ...configObject.UsanceDATextBox }" name="UsanceDATextBox" ref="RefUsanceDATextBox"
            :values="configObject.UsanceDATextBox.UsanceDATextBoxValue"

           v-if="configObject.UsanceDATextBox != undefined? configObject.UsanceDATextBox.isVisible : false" />
        </el-col>

      </el-row>

    </fieldset>


    <br />
    
    <!-- 1st Table -->

    <el-row>
      <el-col :lg="24" :md="24">
        <GenericSortableTableView @GenericSortableTableView-onClickRow="(val) => {
            $emit('FinancialInInfoTable1-onClickRow', val);
          }
          " v-bind="{ ...FinancialInInfoTable1, ...configObject.FinancialInInfoTable1 }" name="FinancialInInfoTable1"
          ref="RefFinancialInInfoTable1" v-if="configObject.FinancialInInfoTable1 != undefined ? configObject.FinancialInInfoTable1.isVisible : false" />
      </el-col>
    </el-row>

    <br />

    <!-- 2nd Table -->

    <el-row>
      <el-col :lg="24" :md="24">
        <GenericSortableTableView @GenericSortableTableView-onClickRow="(val) => {
            $emit('FinancialInInfoTable2-onClickRow', val);
          }
          " v-bind="{ ...FinancialInInfoTable2, ...configObject.FinancialInInfoTable2 }" name="FinancialInInfoTable2"
          ref="RefFinancialInInfoTable2" v-if="configObject.FinancialInInfoTable2 != undefined ? configObject.FinancialInInfoTable2.isVisible :false" />
      </el-col>
    </el-row>

    <br />

    <!-- Buttons Fields -->
  
    <fieldset>

    <el-row>

      <el-col :lg="3" :md="3">
        <GenericButton @GenericButton-onClick="
            $emit('OkButton-onClick');
          "
           v-if="configObject.OkButton != undefined ? configObject.OkButton.isVisible : false" v-bind="{
              ...OkButton,
              ...configObject.OkButton
            }" name="OkButton" ref="RefOkButton" />
      </el-col>

      <el-col :lg="1" :md="1"></el-col>

      <el-col :lg="3" :md="3">
        <GenericButton @GenericButton-onClick="$emit('ExitButton-onClick');
          " v-if="configObject.ExitButton != undefined ? configObject.ExitButton.isVisible : false" v-bind="{
              ...ExitButton,
              ...configObject.ExitButton
            }" name="ExitButton" ref="RefExitButton" />
      </el-col>

      <el-col :lg="10" :md="10"></el-col>

      <el-col :lg="3" :md="3">
        <GenericButton @GenericButton-onClick="
            $emit('LinkButton-onClick')
          
          " v-if="configObject.LinkButton != undefined ? configObject.LinkButton.isVisible :false" v-bind="{
              ...LinkButton,
              ...configObject.LinkButton
            }" name="LinkButton" ref="RefLinkButton" />
      </el-col>

      <el-col :lg="1" :md="1"></el-col>

      <el-col :lg="3" :md="3">
        <GenericButton @GenericButton-onClick="
            $emit('UnLinkButton-onClick')
          
          " v-if="configObject.UnLinkButton != undefined ? configObject.UnLinkButton.isVisible :false" v-bind="{
              ...UnLinkButton,
              ...configObject.UnLinkButton
            }" name="UnLinkButton" ref="RefUnLinkButton" />
      </el-col>

    </el-row>

  </fieldset>
  
  </Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import {
 
  GenericTextBox,
  GenericButton,
  GenericDatePicker,
  CurrencyAlphaNumericSpecial25,
  GenericSortableTableView,
  FinancialInstrumentAlphaNumericSpecialDashes23

} from '@teresol-v2/ui-components';

import { reactive } from 'vue';
export default {
  name: 'MegaSet1172',

  components: {
    Form,
    GenericTextBox,
    GenericDatePicker,
    CurrencyAlphaNumericSpecial25,
    GenericSortableTableView,
    GenericButton,
    FinancialInstrumentAlphaNumericSpecialDashes23
  },

  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive(
      props.configObj.componentProps
    );

    return {
      onSubmit,
      configObject,
      FinancialInstrumentNoTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      FinancialInstrumentAmountTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      FinancialInstrumentInCurrencyTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      SumOfGDConsValTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      CertificationDateTextBox: {
        spanInputs: 12,
        spanLabels: 12
      },
      TermOfContractTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      TenorTextBox: {
        spanInputs: 9,
        spanLabels: 13
      },
      TenorPercentTextBox: {
        spanInputs: 12,
        spanLabels: 12
      },
      Advance: {
        spanInputs: 15,
        spanLabels: 8
      },
      SightDPTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      UsanceDATextBox: {
        spanInputs: 9,
        spanLabels: 13
      },
      FinancialInInfoTable1: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 0,
        tableHeight: '200px',
        tableWidth: '100',
        tableLabel: '',
      },
      FinancialInInfoTable2: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 0,
        tableHeight: '200px',
        tableWidth: '100',
        tableLabel: ''
      },
      OkButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      ExitButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      LinkButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      UnLinkButton: {
        spanInputs: 24,
        nativeType: 'button'
      }

    };
  }
};
</script>

