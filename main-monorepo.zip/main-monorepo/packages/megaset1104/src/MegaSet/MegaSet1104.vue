<template>
  <Form as="el-form" @submit="onSubmit">

    <fieldset>
      <el-row>
        <el-col :lg="12" :md="12">
          <GenericTextBox @GenericTextBox-onBlur="(val) => {
            $emit('BranchTextBox-onBlur', val);
          }
            " @GenericTextBox-onChange="(val) => {
              $emit('BranchTextBox-onChange', val);
            }
              " @GenericTextBox-onKeyPress="(val) => {
                $emit('BranchTextBox-onKeyPress', val);
              }
                " @GenericTextBox-onKeyUp="(val) => {
                  $emit('BranchTextBox-onKeyUp', val);
                }
                  " @GenericTextBox-onFocus="(val) => {
                    $emit('BranchTextBox-onFocus', val);
                  }
                    " name="BranchTextBox" ref="RefBranchTextBox" 
            v-if="configObject.BranchTextBox != undefined ? configObject.BranchTextBox.isVisible : false"
            :values="configObject.BranchTextBox.BranchTextBoxValue" v-bind="{
              ...BranchTextBox,
              ...configObject.BranchTextBox,
            }" />
        </el-col>
        <el-col :lg="12" :md="12">
          <LcNumberWithNumericDashes10 @LcNumberWithNumericDashes10-onBlur="(val) => {
            $emit('AdvisingNoTextBox-onBlur', val);
          }
            " @LcNumberWithNumericDashes10-onChange="(val) => {
              $emit('AdvisingNoTextBox-onChange', val);
            }
              " @LcNumberWithNumericDashes10-onKeyPress="(val) => {
                $emit('AdvisingNoTextBox-onKeyPress', val);
              }
                " @LcNumberWithNumericDashes10-onKeyUp="(val) => {
                  $emit('AdvisingNoTextBox-onKeyUp', val);
                }
                  " @LcNumberWithNumericDashes10-onFocus="(val) => {
                    $emit('AdvisingNoTextBox-onFocus', val);
                  }
                    " name="AdvisingNoTextBox" ref="RefAdvisingNoTextBox"
            v-if="configObject.AdvisingNoTextBox != undefined ? configObject.AdvisingNoTextBox.isVisible : false"
            :values="configObject.AdvisingNoTextBox.AdvisingNoTextBoxValue" v-bind="{
              ...AdvisingNoTextBox,
              ...configObject.AdvisingNoTextBox,
            }" />
        </el-col>
      </el-row>
      <fieldset>
        <el-row>
          <el-col :lg="24" :md="24">
            <el-row>
                <el-col :lg="4" :md="4">
                <el-form-item v-if="configObject.ApplicantNameLabel != undefined ? configObject.ApplicantNameLabel.isVisible : false">
                  {{
                  configObject.ApplicantNameLabel != undefined ? configObject.ApplicantNameLabel.label : "Applicant's Name"
                  }}</el-form-item>
              </el-col>
              <el-col :lg="1" :md="1">
                <GenericButton @GenericButton-onClick="$emit('ApplicantNameButton-onClick')"
                  @GenericButton-onFocus="$emit('ApplicantNameButton-onFocus')" name="ApplicantNameButton"
                  ref="RefApplicantNameButton" v-bind="{ ...ApplicantNameButton, ...configObject.ApplicantNameButton }"
                  v-if="configObject.ApplicantNameButton != undefined ? configObject.ApplicantNameButton.isVisible : false" 
                />
              </el-col>
              <el-col :lg="19" :md="19">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('ApplicantNameTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('ApplicantNameTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('ApplicantNameTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('ApplicantNameTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('ApplicantNameTextBox-onFocus', val);
                        }
                          " name="ApplicantNameTextBox" ref="RefApplicantNameTextBox"
                  v-if="configObject.ApplicantNameTextBox != undefined ? configObject.ApplicantNameTextBox.isVisible : false"
                  :values="configObject.ApplicantNameTextBox.ApplicantNameTextBoxValue" v-bind="{
                    ...ApplicantNameTextBox,
                    ...configObject.ApplicantNameTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="24" :md="24">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('LCOpeningBnkTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('LCOpeningBnkTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('LCOpeningBnkTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('LCOpeningBnkTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('LCOpeningBnkTextBox-onFocus', val);
                        }
                          " name="LCOpeningBnkTextBox" ref="RefLCOpeningBnkTextBox"
                  v-if="configObject.LCOpeningBnkTextBox != undefined ? configObject.LCOpeningBnkTextBox.isVisible : false"
                  :values="configObject.LCOpeningBnkTextBox.LCOpeningBnkTextBoxValue" v-bind="{
                    ...LCOpeningBnkTextBox,
                    ...configObject.LCOpeningBnkTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="24" :md="24">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('LCOriginatingBnkTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('LCOriginatingBnkTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('LCOriginatingBnkTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('LCOriginatingBnkTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('LCOriginatingBnkTextBox-onFocus', val);
                        }
                          " name="LCOriginatingBnkTextBox" ref="RefLCOriginatingBnkTextBox"
                  v-if="configObject.LCOriginatingBnkTextBox != undefined ? configObject.LCOriginatingBnkTextBox.isVisible : false"
                  :values="configObject.LCOriginatingBnkTextBox.LCOriginatingBnkTextBoxValue" v-bind="{
                    ...LCOriginatingBnkTextBox,
                    ...configObject.LCOriginatingBnkTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="24" :md="24">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('LCOpeningBnkAddressTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('LCOpeningBnkAddressTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('LCOpeningBnkAddressTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('LCOpeningBnkAddressTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('LCOpeningBnkAddressTextBox-onFocus', val);
                        }
                          " name="LCOpeningBnkAddressTextBox" ref="RefLCOpeningBnkAddressTextBox"
                  v-if="configObject.LCOpeningBnkAddressTextBox != undefined ? configObject.LCOpeningBnkAddressTextBox.isVisible : false"
                  :values="configObject.LCOpeningBnkAddressTextBox.LCOpeningBnkAddressTextBoxValue" v-bind="{
                    ...LCOpeningBnkAddressTextBox,
                    ...configObject.LCOpeningBnkAddressTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="3" :md="3">
                <el-form-item v-if="configObject.CountryLabel != undefined ? configObject.CountryLabel.isVisible : false">
                  {{
                  configObject.CountryLabel != undefined ? configObject.CountryLabel.label : "Country"
                  }}</el-form-item>
              </el-col>
              <el-col :lg="1" :md="1">
                <GenericButton @GenericButton-onClick="$emit('CountryButton-onClick')"
                  @GenericButton-onFocus="$emit('CountryButton-onFocus')" name="CountryButton"
                  ref="RefCountryButton" v-bind="{ ...CountryButton, ...configObject.CountryButton }"
                  v-if="configObject.BranchTextBox != undefined ? configObject.CountryButton.isVisible : false" 
                />
              </el-col>
              <el-col :lg="12" :md="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => {
                  $emit('CountryDropDown-onChange', val);
                }
                  " @GenericDropDown-onClick="(val) => {
                    $emit('CountryDropDown-onClick', val);
                  }
                    " @GenericDropDown-onBlur="(val) => {
                      $emit('CountryDropDown-onBlur', val);
                    }
                      " @GenericDropDown-onFocus="(val) => {
                        $emit('CountryDropDown-onFocus', val);
                      }
                        " name="CountryDropDown" ref="RefCountryDropDown"
                  :values="configObject.CountryDropDown.CountryDropDownList"
                  v-if="configObject.CountryDropDown != undefined ? configObject.CountryDropDown.isVisible : false" v-bind="{
                    ...CountryDropDown,
                    ...configObject.CountryDropDown,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="3" :md="3">
                <el-form-item v-if="configObject.LCNumberlabel != undefined ? configObject.LCNumberlabel.isVisible : false">
                  {{
                  configObject.LCNumberlabel != undefined ? configObject.LCNumberlabel.label : "LC Number"
                  }}</el-form-item>
              </el-col>
              <el-col :lg="1" :md="1">
                <GenericButton @GenericButton-onClick="$emit('LCNumberButton-onClick')"
                  @GenericButton-onFocus="$emit('LCNumberButton-onFocus')" name="LCNumberButton"
                  ref="RefLCNumberButton" v-bind="{ ...LCNumberButton, ...configObject.LCNumberButton }"
                  v-if="configObject.LCNumberButton != undefined ? configObject.LCNumberButton.isVisible : false" 
                />
              </el-col>
              <el-col :lg="12" :md="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('LCNumberTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('LCNumberTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('LCNumberTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('LCNumberTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('LCNumberTextBox-onFocus', val);
                        }
                          " name="LCNumberTextBox" ref="RefLCNumberTextBox"
                  v-if="configObject.LCNumberTextBox != undefined ? configObject.LCNumberTextBox.isVisible : false"
                  :values="configObject.LCNumberTextBox.LCNumberTextBoxValue" v-bind="{
                    ...LCNumberTextBox,
                    ...configObject.LCNumberTextBox,
                  }" />
              </el-col>
              <el-col :lg="8" :md="8">
                <el-row>
                  <el-col :lg="24" :md="24">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('CountryTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('CountryTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('CountryTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('CountryTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('CountryTextBox-onFocus', val);
                        }
                          " name="CountryTextBox" ref="RefCountryTextBox" 
                  v-if="configObject.CountryTextBox != undefined ? configObject.CountryTextBox.isVisible : false"
                  :values="configObject.CountryTextBox.CountryTextBoxValue" v-bind="{
                    ...CountryTextBox,
                    ...configObject.CountryTextBox,
                  }" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="9" :md="9">
                <el-form-item v-if="configObject.IssuanceDateLabel != undefined ? configObject.IssuanceDateLabel.isVisible : false">
                  {{
                  configObject.IssuanceDateLabel != undefined ? configObject.IssuanceDateLabel.label : "Issuance Date"
                  }}</el-form-item>
              </el-col>
              <el-col :lg="3" :md="3">
                <GenericButton @GenericButton-onClick="$emit('IssuanceDateButton-onClick')"
                  @GenericButton-onFocus="$emit('IssuanceDateButton-onFocus')" name="IssuanceDateButton"
                  ref="RefIssuanceDateButton" v-bind="{ ...IssuanceDateButton, ...configObject.IssuanceDateButton }"
                  v-if="configObject.IssuanceDateButton != undefined ? configObject.IssuanceDateButton.isVisible : false" 
                />
              </el-col>
                  <el-col :lg="12" :md="12">
                    <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                  $emit('IssuanceDateTextBox-onBlur', val);
                }
                  " @DateDdMmYyyy-onChange="(val) => {
                    $emit('IssuanceDateTextBox-onChange', val);
                  }
                    " @DateDdMmYyyy-onKeyPress="(val) => {
                      $emit('IssuanceDateTextBox-onKeyPress', val);
                    }
                      " @DateDdMmYyyy-onKeyUp="(val) => {
                        $emit('IssuanceDateTextBox-onKeyUp', val);
                      }
                        " @DateDdMmYyyy-onFocus="(val) => {
                          $emit('IssuanceDateTextBox-onFocus', val);
                        }
                          " name="IssuanceDateTextBox" ref="RefIssuanceDateTextBox"
                  v-if="configObject.IssuanceDateTextBox != undefined ? configObject.IssuanceDateTextBox.isVisible : false"
                  :values="configObject.IssuanceDateTextBox.IssuanceDateTextBoxValue" v-bind="{
                    ...IssuanceDateTextBox,
                    ...configObject.IssuanceDateTextBox,
                  }" />
                  </el-col>
                </el-row>
                
                
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="8" :md="8">
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                  $emit('IssuanceDateTextBox2-onBlur', val);
                }
                  " @DateDdMmYyyy-onChange="(val) => {
                    $emit('IssuanceDateTextBox2-onChange', val);
                  }
                    " @DateDdMmYyyy-onKeyPress="(val) => {
                      $emit('IssuanceDateTextBox2-onKeyPress', val);
                    }
                      " @DateDdMmYyyy-onKeyUp="(val) => {
                        $emit('IssuanceDateTextBox2-onKeyUp', val);
                      }
                        " @DateDdMmYyyy-onFocus="(val) => {
                          $emit('IssuanceDateTextBox2-onFocus', val);
                        }
                          " name="IssuanceDateTextBox2" ref="RefIssuanceDateTextBox2"
                  v-if="configObject.IssuanceDateTextBox2 != undefined ? configObject.IssuanceDateTextBox2.isVisible : false"
                  :values="configObject.IssuanceDateTextBox2.IssuanceDateTextBox2Value" v-bind="{
                    ...IssuanceDateTextBox2,
                    ...configObject.IssuanceDateTextBox2,
                  }" />
              </el-col>

              <el-col :lg="8" :md="8">
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                  $emit('ExpiryDateTextBox-onBlur', val);
                }
                  " @DateDdMmYyyy-onChange="(val) => {
                    $emit('ExpiryDateTextBox-onChange', val);
                  }
                    " @DateDdMmYyyy-onKeyPress="(val) => {
                      $emit('ExpiryDateTextBox-onKeyPress', val);
                    }
                      " @DateDdMmYyyy-onKeyUp="(val) => {
                        $emit('ExpiryDateTextBox-onKeyUp', val);
                      }
                        " @DateDdMmYyyy-onFocus="(val) => {
                          $emit('ExpiryDateTextBox-onFocus', val);
                        }
                          " name="ExpiryDateTextBox" ref="RefExpiryDateTextBox"
                  v-if="configObject.ExpiryDateTextBox != undefined ? configObject.ExpiryDateTextBox.isVisible : false"
                  :values="configObject.ExpiryDateTextBox.ExpiryDateTextBoxValue" v-bind="{
                    ...ExpiryDateTextBox,
                    ...configObject.ExpiryDateTextBox,
                  }" />
              </el-col>
              

              <el-col :lg="8" :md="8">
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                  $emit('ShipmentDateTextBox-onBlur', val);
                }
                  " @DateDdMmYyyy-onChange="(val) => {
                    $emit('ShipmentDateTextBox-onChange', val);
                  }
                    " @DateDdMmYyyy-onKeyPress="(val) => {
                      $emit('ShipmentDateTextBox-onKeyPress', val);
                    }
                      " @DateDdMmYyyy-onKeyUp="(val) => {
                        $emit('ShipmentDateTextBox-onKeyUp', val);
                      }
                        " @DateDdMmYyyy-onFocus="(val) => {
                          $emit('ShipmentDateTextBox-onFocus', val);
                        }
                          " name="ShipmentDateTextBox" ref="RefShipmentDateTextBox"
                  v-if="configObject.ShipmentDateTextBox != undefined ? configObject.ShipmentDateTextBox.isVisible : false"
                  :values="configObject.ShipmentDateTextBox.ShipmentDateTextBoxValue" v-bind="{
                    ...ShipmentDateTextBox,
                    ...configObject.ShipmentDateTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="3" :md="3">
                <el-form-item v-if="configObject.ShipmentDateTextBox2Label != undefined ? configObject.ShipmentDateTextBox2Label.isVisible : false">
                  {{
                  configObject.ShipmentDateTextBox2Label != undefined ? configObject.ShipmentDateTextBox2Label.label : "Shipment Date"
                  }}</el-form-item>
              </el-col>
              <el-col :lg="1" :md="1">
                <GenericButton @GenericButton-onClick="$emit('ShipmentDate2Button-onClick')"
                  @GenericButton-onFocus="$emit('ShipmentDate2Button-onFocus')" name="ShipmentDate2Button"
                  ref="RefShipmentDate2Button" v-bind="{ ...ShipmentDate2Button, ...configObject.ShipmentDate2Button }"
                  v-if="configObject.ShipmentDate2Button != undefined ? configObject.ShipmentDate2Button.isVisible : false" 
                />
              </el-col>
              <el-col :lg="4" :md="4">
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                  $emit('ShipmentDateTextBox2-onBlur', val);
                }
                  " @DateDdMmYyyy-onChange="(val) => {
                    $emit('ShipmentDateTextBox2-onChange', val);
                  }
                    " @DateDdMmYyyy-onKeyPress="(val) => {
                      $emit('ShipmentDateTextBox2-onKeyPress', val);
                    }
                      " @DateDdMmYyyy-onKeyUp="(val) => {
                        $emit('ShipmentDateTextBox2-onKeyUp', val);
                      }
                        " @DateDdMmYyyy-onFocus="(val) => {
                          $emit('ShipmentDateTextBox2-onFocus', val);
                        }
                          " name="ShipmentDateTextBox2" ref="RefShipmentDateTextBox2"
                  v-if="configObject.BranchTextBox != undefined ? configObject.ShipmentDateTextBox2.isVisible : false"
                  :values="configObject.ShipmentDateTextBox2.ShipmentDateTextBox2Value" v-bind="{
                    ...ShipmentDateTextBox2,
                    ...configObject.ShipmentDateTextBox2,
                  }" />
              </el-col>
              <el-col :lg="8" :md="8"></el-col>
              <el-col :lg="3" :md="3">
                <el-form-item v-if="configObject.ExpiryDateTextBox2Label != undefined ? configObject.ExpiryDateTextBox2Label.isVisible : false">
                  {{
                  configObject.ExpiryDateTextBox2Label != undefined ? configObject.ExpiryDateTextBox2Label.label : "Expiry Date"
                  }}</el-form-item>
              </el-col>
              <el-col :lg="1" :md="1">
                <GenericButton @GenericButton-onClick="$emit('ExpiryDate2Button-onClick')"
                  @GenericButton-onFocus="$emit('ExpiryDate2Button-onFocus')" name="ExpiryDate2Button"
                  ref="RefExpiryDate2Button" v-bind="{ ...ExpiryDate2Button, ...configObject.ExpiryDate2Button }"
                  v-if="configObject.ExpiryDate2Button != undefined ? configObject.ExpiryDate2Button.isVisible : false" 
                />
              </el-col>
              <!-- <el-col :lg="1" :md="1"></el-col> -->
              <el-col :lg="4" :md="4">
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                  $emit('ExpiryDateTextBox2-onBlur', val);
                }
                  " @DateDdMmYyyy-onChange="(val) => {
                    $emit('ExpiryDateTextBox2-onChange', val);
                  }
                    " @DateDdMmYyyy-onKeyPress="(val) => {
                      $emit('ExpiryDateTextBox2-onKeyPress', val);
                    }
                      " @DateDdMmYyyy-onKeyUp="(val) => {
                        $emit('ExpiryDateTextBox2-onKeyUp', val);
                      }
                        " @DateDdMmYyyy-onFocus="(val) => {
                          $emit('ExpiryDateTextBox2-onFocus', val);
                        }
                          " name="ExpiryDateTextBox2" ref="RefExpiryDateTextBox2"
                  v-if="configObject.ExpiryDateTextBox2 != undefined ? configObject.ExpiryDateTextBox2.isVisible : false"
                  :values="configObject.ExpiryDateTextBox2.ExpiryDateTextBox2Value" v-bind="{
                    ...ExpiryDateTextBox2,
                    ...configObject.ExpiryDateTextBox2,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="16" :md="16">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('SecondAdvBankTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('SecondAdvBankTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('SecondAdvBankTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('SecondAdvBankTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('SecondAdvBankTextBox-onFocus', val);
                        }
                          " name="SecondAdvBankTextBox" ref="RefSecondAdvBankTextBox"
                  v-if="configObject.SecondAdvBankTextBox != undefined ? configObject.SecondAdvBankTextBox.isVisible : false"
                  :values="configObject.SecondAdvBankTextBox.SecondAdvBankTextBoxValue" v-bind="{
                    ...SecondAdvBankTextBox,
                    ...configObject.SecondAdvBankTextBox,
                  }" />
              </el-col>
              <el-col :lg="4" :md="4"></el-col>
              <el-col :lg="4" :md="4">
                <GenericButton @GenericButton-onClick="$emit('AddressButton-onClick')"
                  @GenericButton-onFocus="$emit('AddressButton-onFocus')" name="AddressButton" ref="RefAddressButton"
                  v-bind="{ ...AddressButton, ...configObject.AddressButton }"
                  v-if="configObject.AddressButton != undefined ? configObject.AddressButton.isVisible : false" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="3" :md="3">
                <el-form-item v-if="configObject.ValueTextBoxLabel != undefined ? configObject.ValueTextBoxLabel.isVisible : false">
                  {{
                  configObject.ValueTextBoxLabel != undefined ? configObject.ValueTextBoxLabel.label : "Value"
                  }}</el-form-item>
              </el-col>
              <el-col :lg="1" :md="1">
                <GenericButton @GenericButton-onClick="$emit('ValueTextBoxButton-onClick')"
                  @GenericButton-onFocus="$emit('ValueTextBoxButton-onFocus')" name="ValueTextBoxButton"
                  ref="RefValueTextBoxButton" v-bind="{ ...ValueTextBoxButton, ...configObject.ValueTextBoxButton }"
                  v-if="configObject.ValueTextBoxButton != undefined ? configObject.ValueTextBoxButton.isVisible : false" 
                />
              </el-col>
              <el-col :lg="8" :md="8">
                <AmountNumericDecimal15Point2 @AmountNumericDecimal15Point2-onBlur="(val) => {
                  $emit('ValueTextBox-onBlur', val);
                }
                  " @AmountNumericDecimal15Point2-onChange="(val) => {
                    $emit('ValueTextBox-onChange', val);
                  }
                    " @AmountNumericDecimal15Point2-onKeyPress="(val) => {
                        $emit('ValueTextBox-onKeyPress', val);
                      }
                        " @AmountNumericDecimal15Point2-onKeyUp="(val) => {
                          $emit('ValueTextBox-onKeyUp', val);
                        }
                          " @AmountNumericDecimal15Point2-onFocus="(val) => {
                            $emit('ValueTextBox-onFocus', val);
                          }
                            " name="ValueTextBox" ref="RefValueTextBox" 
                  v-if="configObject.ValueTextBox != undefined ? configObject.ValueTextBox.isVisible : false"
                  :values="configObject.ValueTextBox.ValueTextBoxValue" v-bind="{
                    ...ValueTextBox,
                    ...configObject.ValueTextBox,
                  }" />
              </el-col>
              <el-col :lg="12" :md="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('CurrencyTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('CurrencyTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                  $emit('CurrencyTextBox-onKeyPress', val);
                }
                  " @GenericTextBox-onKeyUp="(val) => {
                    $emit('CurrencyTextBox-onKeyUp', val);
                  }
                    " @GenericTextBox-onFocus="(val) => {
                      $emit('CurrencyTextBox-onFocus', val);
                    }
                      " name="CurrencyTextBox" ref="RefCurrencyTextBox" 
                  v-if="configObject.CurrencyTextBox != undefined ? configObject.CurrencyTextBox.isVisible : false"
                  :values="configObject.CurrencyTextBox.CurrencyTextBoxValue" v-bind="{
                    ...CurrencyTextBox,
                    ...configObject.CurrencyTextBox,
                  }" />
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                  $emit('CurrencyDropDown-onChange', val);
                }
                  " @GenericDropDown-onClick="(val) => {
                    $emit('CurrencyDropDown-onClick', val);
                  }
                    " @GenericDropDown-onBlur="(val) => {
                      $emit('CurrencyDropDown-onBlur', val);
                    }
                      " @GenericDropDown-onFocus="(val) => {
                        $emit('CurrencyDropDown-onFocus', val);
                      }
                        " name="CurrencyDropDown" ref="RefCurrencyDropDown"
                  :values="configObject.CurrencyDropDown.CurrencyDropDownList"
                  v-if="configObject.CurrencyDropDown != undefined ? configObject.CurrencyDropDown.isVisible : false" v-bind="{
                    ...CurrencyDropDown,
                    ...configObject.CurrencyDropDown,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="3" :md="3">
                <el-form-item v-if="configObject.BeneficiaryLabel != undefined ? configObject.BeneficiaryLabel.isVisible : false">
                  {{
                  configObject.BeneficiaryLabel != undefined ? configObject.BeneficiaryLabel.label : "Beneficiary"
                  }}</el-form-item>
              </el-col>
              <el-col :lg="1" :md="1">
                <GenericButton @GenericButton-onClick="$emit('BeneficiaryButton-onClick')"
                  @GenericButton-onFocus="$emit('BeneficiaryButton-onFocus')" name="BeneficiaryButton"
                  ref="RefBeneficiaryButton" v-bind="{ ...BeneficiaryButton, ...configObject.BeneficiaryButton }"
                  v-if="configObject.BeneficiaryButton != undefined ? configObject.BeneficiaryButton.isVisible : false" 
                />
              </el-col>
              <el-col :lg="12" :md="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('BeneficiaryTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('BeneficiaryTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                  $emit('BeneficiaryTextBox-onKeyPress', val);
                }
                  " @GenericTextBox-onKeyUp="(val) => {
                    $emit('BeneficiaryTextBox-onKeyUp', val);
                  }
                    " @GenericTextBox-onFocus="(val) => {
                      $emit('BeneficiaryTextBox-onFocus', val);
                    }
                      " name="BeneficiaryTextBox" ref="RefBeneficiaryTextBox"
                  v-if="configObject.BeneficiaryTextBox != undefined ? configObject.BeneficiaryTextBox.isVisible : false"
                  :values="configObject.BeneficiaryTextBox.BeneficiaryTextBoxValue" v-bind="{
                    ...BeneficiaryTextBox,
                    ...configObject.BeneficiaryTextBox,
                  }" />
              </el-col>
              <el-col :lg="4" :md="4"></el-col>
              <el-col :lg="4" :md="4">
                <GenericButton @GenericButton-onClick="$emit('AddressButton2-onClick')"
                  @GenericButton-onFocus="$emit('AddressButton2-onFocus')" name="AddressButton2" ref="RefAddressButton2"
                  v-bind="{ ...AddressButton2, ...configObject.AddressButton2 }"
                  v-if="configObject.AddressButton2 != undefined ? configObject.AddressButton2.isVisible : false" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="3" :md="3"></el-col>
              <el-col :lg="1" :md="1">
                <GenericButton @GenericButton-onClick="$emit('AddressRedButton-onClick')"
                  @GenericButton-onFocus="$emit('AddressRedButton-onFocus')" name="AddressRedButton"
                  ref="RefAddressRedButton" v-bind="{ ...AddressRedButton, ...configObject.AddressRedButton }"
                  v-if="configObject.AddressRedButton != undefined ? configObject.AddressRedButton.isVisible : false" 
                />
              </el-col>
              <el-col :lg="4" :md="4">
                <GenericButton @GenericButton-onClick="$emit('AddressButton3-onClick')"
                  @GenericButton-onFocus="$emit('AddressButton3-onFocus')" name="AddressButton3" ref="RefAddressButton3"
                  v-bind="{ ...AddressButton3, ...configObject.AddressButton3 }"
                  v-if="configObject.AddressButton3 != undefined ? configObject.AddressButton3.isVisible : false" />
              </el-col>
              <el-col :lg="16" :md="16">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('LCOriginatingBnkTextBox2-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('LCOriginatingBnkTextBox2-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('LCOriginatingBnkTextBox2-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('LCOriginatingBnkTextBox2-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('LCOriginatingBnkTextBox2-onFocus', val);
                        }
                          " name="LCOriginatingBnkTextBox2" ref="RefLCOriginatingBnkTextBox2"
                  v-if="configObject.LCOriginatingBnkTextBox2 != undefined ? configObject.LCOriginatingBnkTextBox2.isVisible : false"
                  :values="configObject.LCOriginatingBnkTextBox2.LCOriginatingBnkTextBox2Value" v-bind="{
                    ...LCOriginatingBnkTextBox2,
                    ...configObject.LCOriginatingBnkTextBox2,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="8" :md="8">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('LCConfirmedTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('LCConfirmedTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('LCConfirmedTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('LCConfirmedTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('LCConfirmedTextBox-onFocus', val);
                        }
                          " name="LCConfirmedTextBox" ref="RefLCConfirmedTextBox"
                  v-if="configObject.LCConfirmedTextBox != undefined ? configObject.LCConfirmedTextBox.isVisible : false"
                  :values="configObject.LCConfirmedTextBox.LCConfirmedTextBoxValue" v-bind="{
                    ...LCConfirmedTextBox,
                    ...configObject.LCConfirmedTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="8" :md="8">
                <CustomerNumberNumeric6 @CustomerNumberNumeric6-onBlur="(val) => {
                  $emit('CustomerNoTextBox-onBlur', val);
                }
                  " @CustomerNumberNumeric6-onChange="(val) => {
                    $emit('CustomerNoTextBox-onChange', val);
                  }
                    " @CustomerNumberNumeric6-onKeyPress="(val) => {
                        $emit('CustomerNoTextBox-onKeyPress', val);
                      }
                        " @CustomerNumberNumeric6-onKeyUp="(val) => {
                          $emit('CustomerNoTextBox-onKeyUp', val);
                        }
                          " @CustomerNumberNumeric6-onFocus="(val) => {
                            $emit('CustomerNoTextBox-onFocus', val);
                          }
                            " name="CustomerNoTextBox" ref="RefCustomerNoTextBox"
                  v-if="configObject.CustomerNoTextBox != undefined ? configObject.CustomerNoTextBox.isVisible : false"
                  :values="configObject.CustomerNoTextBox.CustomerNoTextBoxValue" v-bind="{
                    ...CustomerNoTextBox,
                    ...configObject.CustomerNoTextBox,
                  }" />
              </el-col>
              <el-col :lg="16" :md="16">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('AccountTitleTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('AccountTitleTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                        $emit('AccountTitleTextBox-onKeyPress', val);
                      }
                        " @GenericTextBox-onKeyUp="(val) => {
                          $emit('AccountTitleTextBox-onKeyUp', val);
                        }
                          " @GenericTextBox-onFocus="(val) => {
                            $emit('AccountTitleTextBox-onFocus', val);
                          }
                            " name="AccountTitleTextBox" ref="RefAccountTitleTextBox"
                  v-if="configObject.AccountTitleTextBox != undefined ? configObject.AccountTitleTextBox.isVisible : false"
                  :values="configObject.AccountTitleTextBox.AccountTitleTextBoxValue" v-bind="{
                    ...AccountTitleTextBox,
                    ...configObject.AccountTitleTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="8" :md="8">
                <AmountNumericDecimal15Point2 @AmountNumericDecimal15Point2-onBlur="(val) => {
                  $emit('ChargesTextBox-onBlur', val);
                }
                  " @AmountNumericDecimal15Point2-onChange="(val) => {
                    $emit('ChargesTextBox-onChange', val);
                  }
                    " @AmountNumericDecimal15Point2-onKeyPress="(val) => {
                  $emit('ChargesTextBox-onKeyPress', val);
                }
                  " @AmountNumericDecimal15Point2-onKeyUp="(val) => {
                    $emit('ChargesTextBox-onKeyUp', val);
                  }
                    " @AmountNumericDecimal15Point2-onFocus="(val) => {
                      $emit('ChargesTextBox-onFocus', val);
                    }
                      " name="ChargesTextBox" ref="RefChargesTextBox" 
                  v-if="configObject.ChargesTextBox != undefined ? configObject.ChargesTextBox.isVisible : false"
                  :values="configObject.ChargesTextBox.ChargesTextBoxValue" v-bind="{
                    ...ChargesTextBox,
                    ...configObject.ChargesTextBox,
                  }" />
              </el-col>
              <el-col :lg="8" :md="8">
                <AmountNumericDecimal15Point2 @AmountNumericDecimal15Point2-onBlur="(val) => {
                  $emit('FedAmountTextBox-onBlur', val);
                }
                  " @AmountNumericDecimal15Point2-onChange="(val) => {
                    $emit('FedAmountTextBox-onChange', val);
                  }
                    " @AmountNumericDecimal15Point2-onKeyPress="(val) => {
                    $emit('FedAmountTextBox-onKeyPress', val);
                  }
                    " @AmountNumericDecimal15Point2-onKeyUp="(val) => {
                        $emit('FedAmountTextBox-onKeyUp', val);
                      }
                        " @AmountNumericDecimal15Point2-onFocus="(val) => {
                            $emit('FedAmountTextBox-onFocus', val);
                          }
                            " name="FedAmountTextBox" ref="RefFedAmountTextBox"
                  v-if="configObject.FedAmountTextBox != undefined ? configObject.FedAmountTextBox.isVisible : false"
                  :values="configObject.FedAmountTextBox.FedAmountTextBoxValue" v-bind="{
                    ...FedAmountTextBox,
                    ...configObject.FedAmountTextBox,
                  }" />
              </el-col>
              <el-col :lg="8" :md="8">
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                  $emit('AdvisingDateTextBox-onBlur', val);
                }
                  " @DateDdMmYyyy-onChange="(val) => {
                    $emit('AdvisingDateTextBox-onChange', val);
                  }
                    " @DateDdMmYyyy-onKeyPress="(val) => {
                      $emit('AdvisingDateTextBox-onKeyPress', val);
                    }
                      " @DateDdMmYyyy-onKeyUp="(val) => {
                        $emit('AdvisingDateTextBox-onKeyUp', val);
                      }
                        " @DateDdMmYyyy-onFocus="(val) => {
                          $emit('AdvisingDateTextBox-onFocus', val);
                        }
                          " name="AdvisingDateTextBox" ref="RefAdvisingDateTextBox"
                  v-if="configObject.AdvisingDateTextBox != undefined ? configObject.AdvisingDateTextBox.isVisible : false"
                  :values="configObject.AdvisingDateTextBox.AdvisingDateTextBoxValue" v-bind="{
                    ...AdvisingDateTextBox,
                    ...configObject.AdvisingDateTextBox,
                  }" />
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                  $emit('AmendmentDateTextBox-onBlur', val);
                }
                  " @DateDdMmYyyy-onChange="(val) => {
                    $emit('AmendmentDateTextBox-onChange', val);
                  }
                    " @DateDdMmYyyy-onKeyPress="(val) => {
                        $emit('AmendmentDateTextBox-onKeyPress', val);
                      }
                        " @DateDdMmYyyy-onKeyUp="(val) => {
                          $emit('AmendmentDateTextBox-onKeyUp', val);
                        }
                          " @DateDdMmYyyy-onFocus="(val) => {
                            $emit('AmendmentDateTextBox-onFocus', val);
                          }
                            " name="AmendmentDateTextBox" ref="RefAmendmentDateTextBox"
                  v-if="configObject.AmendmentDateTextBox != undefined ? configObject.AmendmentDateTextBox.isVisible : false"
                  :values="configObject.AmendmentDateTextBox.AmendmentDateTextBoxValue" v-bind="{
                    ...AmendmentDateTextBox,
                    ...configObject.AmendmentDateTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="16" :md="16">
                <el-row>
                  <el-col :lg="6" :md="6"></el-col>
                  <el-col :lg="6" :md="6">
                    <GenericButton @GenericButton-onClick="$emit('RemarksButton-onClick')"
                      @GenericButton-onFocus="$emit('RemarksButton-onFocus')" name="RemarksButton" ref="RefRemarksButton"
                      v-bind="{ ...RemarksButton, ...configObject.RemarksButton }"
                      v-if="configObject.RemarksButton != undefined ? configObject.RemarksButton.isVisible : false" 
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('RemarksTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('RemarksTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('RemarksTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('RemarksTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('RemarksTextBox-onFocus', val);
                        }
                          " name="RemarksTextBox" ref="RefRemarksTextBox" 
                  v-if="configObject.RemarksTextBox != undefined ? configObject.RemarksTextBox.isVisible : false"
                  :values="configObject.RemarksTextBox.RemarksTextBoxValue" v-bind="{
                    ...RemarksTextBox,
                    ...configObject.RemarksTextBox,
                  }" />
                  </el-col>
                </el-row>
              </el-col>
              <el-col :lg="8" :md="8">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('PostByTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('PostByTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('PostByTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('PostByTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('PostByTextBox-onFocus', val);
                        }
                          " name="PostByTextBox" ref="RefPostByTextBox" 
                  v-if="configObject.PostByTextBox != undefined ? configObject.PostByTextBox.isVisible : false"
                  :values="configObject.PostByTextBox.PostByTextBoxValue" v-bind="{
                    ...PostByTextBox,
                    ...configObject.PostByTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="8" :md="8">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('LCConfirmedTextBox2-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('LCConfirmedTextBox2-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('LCConfirmedTextBox2-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('LCConfirmedTextBox2-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('LCConfirmedTextBox2-onFocus', val);
                        }
                          " name="LCConfirmedTextBox2" ref="RefLCConfirmedTextBox2"
                  v-if="configObject.LCConfirmedTextBox2 != undefined ? configObject.LCConfirmedTextBox2.isVisible : false"
                  :values="configObject.LCConfirmedTextBox2.LCConfirmedTextBox2Value" v-bind="{
                    ...LCConfirmedTextBox2,
                    ...configObject.LCConfirmedTextBox2,
                  }" />
              </el-col>
              <el-col :lg="16" :md="16">
                <GenericTextBox @GenericTextBox-onBlur="(val) => {
                  $emit('CountryOfOriginTextBox-onBlur', val);
                }
                  " @GenericTextBox-onChange="(val) => {
                    $emit('CountryOfOriginTextBox-onChange', val);
                  }
                    " @GenericTextBox-onKeyPress="(val) => {
                      $emit('CountryOfOriginTextBox-onKeyPress', val);
                    }
                      " @GenericTextBox-onKeyUp="(val) => {
                        $emit('CountryOfOriginTextBox-onKeyUp', val);
                      }
                        " @GenericTextBox-onFocus="(val) => {
                          $emit('CountryOfOriginTextBox-onFocus', val);
                        }
                          " name="CountryOfOriginTextBox" ref="RefCountryOfOriginTextBox"
                  v-if="configObject.CountryOfOriginTextBox != undefined ? configObject.CountryOfOriginTextBox.isVisible : false"
                  :values="configObject.CountryOfOriginTextBox.CountryOfOriginTextBoxValue" v-bind="{
                    ...CountryOfOriginTextBox,
                    ...configObject.CountryOfOriginTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="12" :md="12">
                <AmountNumericDecimal15Point2 @AmountNumericDecimal15Point2-onBlur="(val) => {
                  $emit('OutstandingLiabilityTextBox-onBlur', val);
                }
                  " @AmountNumericDecimal15Point2-onChange="(val) => {
                    $emit('OutstandingLiabilityTextBox-onChange', val);
                  }
                    " @AmountNumericDecimal15Point2-onKeyPress="(val) => {
                      $emit('OutstandingLiabilityTextBox-onKeyPress', val);
                    }
                      " @AmountNumericDecimal15Point2-onKeyUp="(val) => {
                        $emit('OutstandingLiabilityTextBox-onKeyUp', val);
                      }
                        " @AmountNumericDecimal15Point2-onFocus="(val) => {
                          $emit('OutstandingLiabilityTextBox-onFocus', val);
                        }
                          " name="OutstandingLiabilityTextBox" ref="RefOutstandingLiabilityTextBox"
                  v-if="configObject.OutstandingLiabilityTextBox != undefined ? configObject.OutstandingLiabilityTextBox.isVisible : false"
                  :values="configObject.OutstandingLiabilityTextBox.OutstandingLiabilityTextBoxValue" v-bind="{
                    ...OutstandingLiabilityTextBox,
                    ...configObject.OutstandingLiabilityTextBox,
                  }" />
              </el-col>
              <el-col :lg="12" :md="12">
                <AmountNumericDecimal16Point3 @AmountNumericDecimal16Point3-onBlur="(val) => {
                  $emit('LiabilityRevAmtTextBox-onBlur', val);
                }
                  " @AmountNumericDecimal16Point3-onChange="(val) => {
                    $emit('LiabilityRevAmtTextBox-onChange', val);
                  }
                    " @AmountNumericDecimal16Point3-onKeyPress="(val) => {
                      $emit('LiabilityRevAmtTextBox-onKeyPress', val);
                    }
                      " @AmountNumericDecimal16Point3-onKeyUp="(val) => {
                        $emit('LiabilityRevAmtTextBox-onKeyUp', val);
                      }
                        " @AmountNumericDecimal16Point3-onFocus="(val) => {
                          $emit('LiabilityRevAmtTextBox-onFocus', val);
                        }
                          " name="LiabilityRevAmtTextBox" ref="RefLiabilityRevAmtTextBox"
                  v-if="configObject.LiabilityRevAmtTextBox != undefined ? configObject.LiabilityRevAmtTextBox.isVisible : false"
                  :values="configObject.LiabilityRevAmtTextBox.LiabilityRevAmtTextBoxValue" v-bind="{
                    ...LiabilityRevAmtTextBox,
                    ...configObject.LiabilityRevAmtTextBox,
                  }" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="12" :md="12">
                <GenericCheckBox @GenericCheckBox-onChange="$emit('LCConfirmChargeCheckBox-onChange')"
                  name="LCConfirmChargeCheckBox" ref="RefLCConfirmChargeCheckBox" v-bind="{
                    ...LCConfirmChargeCheckBox,
                    ...configObject.LCConfirmChargeCheckBox,
                  }" v-if="configObject.LCConfirmChargeCheckBox != undefined ? configObject.LCConfirmChargeCheckBox.isVisible : false" />
              </el-col>
            </el-row>

            <el-row>
              <el-col :lg="6" :md="6">
                
              </el-col>
            </el-row>

          </el-col>
        </el-row>
      </fieldset>
    </fieldset>

    <el-row>
      <el-col :lg="24" :md="24">
        <legend class="_custom_heading">{{
          configObject.TableLabel ? configObject.TableLabel.label : "Transactions"
        }}</legend>
      </el-col>
    </el-row>
    <el-row>
      <el-col :lg="24" :md="24">
        <GenericSortableTableView
          @GenericSortableTableView-onCurrentRow="(val) => { $emit('TransactionTable-onCurrentRow', val); }"
          @GenericSortableTableView-onClickRow="(val) => { $emit('TransactionTable-onClickRow', val); }"
          @GenericSortableTableView-onDoubleClickRow="(val) => { $emit('TransactionTable-onDoubleClickRow', val); }"
          name="TransactionTable" ref="RefTransactionTable" v-bind="{ ...TransactionTable, ...configObject.TransactionTable }"
          v-if="configObject.TransactionTable != undefined ? configObject.TransactionTable.isVisible : false" />
      </el-col>
    </el-row>

    <fieldset>
      <el-row >
        <el-col :lg="4" :md="4">
          <GenericButton @GenericButton-onClick="$emit('AuthorizeButton-onClick')"
                @GenericButton-onFocus="$emit('AuthorizeButton-onFocus')" name="AuthorizeButton"
                ref="RefAuthorizeButton" v-bind="{ ...AuthorizeButton, ...configObject.AuthorizeButton }"
                v-if="configObject.BranchTextBox != undefined ? configObject.AuthorizeButton.isVisible : false" 
          />
          <GenericButton @GenericButton-onClick="$emit('CancelButton-onClick')"
                @GenericButton-onFocus="$emit('CancelButton-onFocus')" name="CancelButton"
                ref="RefCancelButton" v-bind="{ ...CancelButton, ...configObject.CancelButton }"
                v-if="configObject.CancelButton != undefined ? configObject.CancelButton.isVisible : false" 
          />
        </el-col>
        <el-col :lg="4" :md="4">
          <GenericButton @GenericButton-onClick="$emit('ExceptionsButton-onClick')"
                @GenericButton-onFocus="$emit('ExceptionsButton-onFocus')" name="ExceptionsButton"
                ref="RefExceptionsButton" v-bind="{ ...ExceptionsButton, ...configObject.ExceptionsButton }"
                v-if="configObject.ExceptionsButton != undefined ? configObject.ExceptionsButton.isVisible : false" />
        </el-col>
        <el-col :lg="6" :md="6">
          <GenericButton @GenericButton-onClick="$emit('AmendmentHistoryButton-onClick')"
                @GenericButton-onFocus="$emit('AmendmentHistoryButton-onFocus')" name="AmendmentHistoryButton"
                ref="RefAmendmentHistoryButton" v-bind="{ ...AmendmentHistoryButton, ...configObject.AmendmentHistoryButton }"
                v-if="configObject.AmendmentHistoryButton != undefined ? configObject.AmendmentHistoryButton.isVisible : false" />
        </el-col>
        <el-col :lg="6" :md="6">
          <el-row>
            <el-col :lg="24" :md="24">
              <GenericButton @GenericButton-onClick="$emit('ViewMessageButton-onClick')"
                @GenericButton-onFocus="$emit('ViewMessageButton-onFocus')" name="ViewMessageButton"
                ref="RefViewMessageButton" v-bind="{ ...ViewMessageButton, ...configObject.ViewMessageButton }"
                v-if="configObject.ViewMessageButton != undefined ? configObject.ViewMessageButton.isVisible : false" />
            </el-col>
          </el-row>
        </el-col>
        <el-col :lg="4" :md="4">
          <el-row>
            <el-col :lg="24" :md="24">
              <GenericButton @GenericButton-onClick="$emit('BackButton-onClick')"
                @GenericButton-onFocus="$emit('BackButton-onFocus')" name="BackButton"
                ref="RefBackButton" v-bind="{ ...BackButton, ...configObject.BackButton }"
                v-if="configObject.BackButton != undefined ? configObject.BackButton.isVisible : false" />
            </el-col>
          </el-row>
        </el-col>
      </el-row>
    </fieldset>


  </Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import { reactive } from 'vue';

import {
  GenericButton,
  GenericTextBox,
  AmountNumericDecimal15Point2,
  DateDdMmYyyy,
  GenericDropDown,
  AmountNumericDecimal16Point3,
  GenericCheckBox,
  GenericSortableTableView,
  LcNumberWithNumericDashes10,
  CustomerNumberNumeric6

} from "@teresol-v2/ui-components";

export default {
  name: 'MegaSet1104',

  components: {
    Form,
    GenericTextBox,
    DateDdMmYyyy,
    GenericButton,
    AmountNumericDecimal15Point2,
    GenericDropDown,
    AmountNumericDecimal16Point3,
    GenericCheckBox,
    GenericSortableTableView,
    LcNumberWithNumericDashes10,
    CustomerNumberNumeric6
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive(props.configObj.componentProps);

    return {
      onSubmit,
      configObject,

      BranchTextBox: {
        spanInputs: 17,
        spanLabels: 6,
      },
      AdvisingNoTextBox: {
        spanInputs: 17,
        spanLabels: 6,
      },
      ApplicantNameTextBox: {
        spanInputs: 24,
        spanLabels: 0,
      },
      LCOpeningBnkTextBox: {
        spanInputs: 19,
        spanLabels: 5,
      },
      LCOriginatingBnkTextBox: {
        spanInputs: 19,
        spanLabels: 5,
      },
      LCOpeningBnkAddressTextBox: {
        spanInputs: 19,
        spanLabels: 5,
      },
      CountryDropDown: {
        spanInputs: 14,
        spanLabels: 0,
      },
      CountryButton: {
        spanInputs: 18,
      },
      ApplicantNameButton:{
        spanInputs:18,
      },
      CountryTextBox: {
        spanInputs: 18,
        spanLabels: 6,
      },
      LCNumberButton:{
        spanInputs: 18,
      },
      LCNumberTextBox: {
        spanInputs: 14,
        spanLabels: 0,
      },
      IssuanceDateButton:{
        spanInputs: 14,
      },
      IssuanceDateTextBox: {
        spanInputs: 24,
        spanLabels: 0,
      },
      IssuanceDateTextBox2: {
        spanInputs: 11,
        spanLabels: 12,
      },
      ExpiryDateTextBox: {
        spanInputs: 12,
        spanLabels: 9,
      },
      ShipmentDateTextBox: {
        spanInputs: 12,
        spanLabels: 12,
      },
      ShipmentDate2Button:{
        spanInputs: 18,
      },
      ShipmentDateTextBox2: {
        spanInputs: 22,
        spanLabels: 0,
      },
      ExpiryDate2Button:{
        spanInputs: 14,
      },
      ExpiryDateTextBox2: {
        spanInputs: 24,
        spanLabels: 0,
      },
      SecondAdvBankTextBox: {
        spanInputs: 18,
        spanLabels: 6,
      },
      AddressButton: {
        spanInputs: 24,
      },
      ValueTextBoxButton:{
        spanInputs: 18,
      },
      ValueTextBox: {
        spanInputs: 18,
        spanLabels: 0,
      },
      CurrencyTextBox: {
        spanInputs: 18,
        spanLabels: 6,
      },
      CurrencyDropDown: {
        spanInputs: 18,
        spanLabels: 6,
      },
      BeneficiaryButton:{
        spanInputs: 18,
      },
      BeneficiaryTextBox: {
        spanInputs: 18,
        spanLabels: 0,
      },
      AddressButton2: {
        spanInputs: 24,
      },
      AddressRedButton:{
        spanInputs: 18,
      },
      AddressButton3: {
        spanInputs: 22,
      },
      LCOriginatingBnkTextBox2: {
        spanInputs: 18,
        spanLabels: 6,
      },
      LCConfirmedTextBox: {
        spanInputs: 11,
        spanLabels: 12,
      },
      CustomerNoTextBox: {
        spanInputs: 11,
        spanLabels: 12,
      },
      AccountTitleTextBox: {
        spanInputs: 21,
        spanLabels: 3,
      },
      ChargesTextBox: {
        spanInputs: 11,
        spanLabels: 12,
      },
      FedAmountTextBox: {
        spanInputs: 16,
        spanLabels: 6,
      },
      AdvisingDateTextBox: {
        spanInputs: 14,
        spanLabels: 10,
      },
      AmendmentDateTextBox: {
        spanInputs: 14,
        spanLabels: 10,
      },
      PostByTextBox: {
        spanInputs: 14,
        spanLabels: 10,
      },
      RemarksTextBox: {
        spanInputs: 17,
        spanLabels: 6,
      },
      LCConfirmedTextBox2: {
        spanInputs: 11,
        spanLabels: 12,
      },
      CountryOfOriginTextBox: {
        spanInputs: 19,
        spanLabels: 5,
      },
      OutstandingLiabilityTextBox: {
        spanInputs: 15,
        spanLabels: 8,
      },
      LiabilityRevAmtTextBox: {
        spanInputs: 16,
        spanLabels: 8,
      },
      LCConfirmChargeCheckBox: {
        spanInputs: 6,
        spanLabels: 2,
      },
      RemarksButton: {
        spanInputs: 22,
      },
      TransactionTable: {
        spanInputs: 24,
        spanLabels: 0,
      },
      AuthorizeButton: {
        spanInputs: 23,
      },
      CancelButton: {
        spanInputs: 23,
      },
      ExceptionsButton: {
        spanInputs: 23,
      },
      AmendmentHistoryButton: {
        spanInputs: 23,
      },
      ViewMessageButton: {
        spanInputs: 23,
      },
      BackButton: {
        spanInputs: 24,
      },
      
    };
  }
};
</script>


<style>

</style>
