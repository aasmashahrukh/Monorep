<template>
  <Form as="el-form" @submit="onSubmit">
      <el-row>
        <legend>BCA Info Data</legend>
      </el-row>
      <br/>
      <el-row>
        <el-col :lg="12" :md="12">
          <BCAUniqueIdenNo 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('BCAUniqueIdenNo-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('BCAUniqueIdenNo-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('BCAUniqueIdenNo-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('BCAUniqueIdenNo-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.BCAUniqueIdenNo, ...BCAUniqueIdenNo }"
            :values="configObject.BCAUniqueIdenNo.BCAUniqueIdenNoValue" name="BCAUniqueIdenNo" ref="refBCAUniqueIdenNo"
            v-if="configObject.BCAUniqueIdenNo != undefined ? configObject.BCAUniqueIdenNo.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <ExporterIban 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('ExporterIban-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('ExporterIban-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('ExporterIban-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('ExporterIban-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.ExporterIban, ...ExporterIban }"
            :values="configObject.ExporterIban.ExporterIbanValue" name="ExporterIban" ref="refExporterIban"
            v-if="configObject.ExporterIban != undefined ? configObject.ExporterIban.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <ExporterNtn 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('ExporterNtn-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('ExporterNtn-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('ExporterNtn-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('ExporterNtn-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.ExporterNtn, ...ExporterNtn }"
            :values="configObject.ExporterNtn.ExporterNtnValue" name="ExporterNtn" ref="refExporterNtn"
            v-if="configObject.ExporterNtn != undefined ? configObject.ExporterNtn.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <ModeOfExportPayment 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('ModeOfExportPayment-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('ModeOfExportPayment-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('ModeOfExportPayment-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('ModeOfExportPayment-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.ModeOfExportPayment, ...ModeOfExportPayment }"
            :values="configObject.ModeOfExportPayment.ModeOfExportPaymentValue" name="ModeOfExportPayment" ref="refModeOfExportPayment"
            v-if="configObject.ModeOfExportPayment != undefined ? configObject.ModeOfExportPayment.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <ExporterName 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('ExporterName-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('ExporterName-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('ExporterName-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('ExporterName-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.ExporterName, ...ExporterName }"
            :values="configObject.ExporterName.ExporterNameValue" name="ExporterName" ref="refExporterName"
            v-if="configObject.ExporterName != undefined ? configObject.ExporterName.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <FinancialInstruUniqueNo 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('FinancialInstruUniqueNo-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('FinancialInstruUniqueNo-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('FinancialInstruUniqueNo-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('FinancialInstruUniqueNo-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.FinancialInstruUniqueNo, ...FinancialInstruUniqueNo }"
            :values="configObject.FinancialInstruUniqueNo.FinancialInstruUniqueNoValue" name="FinancialInstruUniqueNo" ref="refFinancialInstruUniqueNo"
            v-if="configObject.FinancialInstruUniqueNo != undefined ? configObject.FinancialInstruUniqueNo.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        BCA Details;
      </el-row>
      
      <el-row>
        <el-col :lg="12" :md="12">
          <BcaEventName 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('BcaEventName-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('BcaEventName-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('BcaEventName-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('BcaEventName-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.BcaEventName, ...BcaEventName }"
            :values="configObject.BcaEventName.BcaEventNameValue" name="BcaEventName" ref="refBcaEventName"
            v-if="configObject.BcaEventName != undefined ? configObject.BcaEventName.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <BillNo 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('BillNo-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('BillNo-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('BillNo-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('BillNo-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.BillNo, ...BillNo }"
            :values="configObject.BillNo.BillNoValue" name="BillNo" ref="refBillNo"
            v-if="configObject.BillNo != undefined ? configObject.BillNo.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <EventDate
           @DateDdMmYyyy-onBlur="(val,event) => {
            $emit('EventDate-onBlur', val,event);
          }
          "
          @DateDdMmYyyy-onChange="(val) => {
            $emit('EventDate-onChange', val);
          }
          " 
          @DateDdMmYyyy-onFocus="(val) => {
            $emit('EventDate-onFocus', val);
          }
          " 
         v-bind="{ ...configObject.EventDate, ...EventDate }" :values="configObject.EventDate.EventDateValue" name="EventDate"
            v-if="configObject.EventDate != undefined ? configObject.EventDate.isVisible :false" />
          </el-col>
        <el-col :lg="12" :md="12">
          <BillDated 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('BillDated-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('BillDated-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('BillDated-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('BillDated-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.BillDated, ...BillDated }"
            :values="configObject.BillDated.BillDatedValue" name="BillDated" ref="refBillDated"
            v-if="configObject.BillDated != undefined ? configObject.BillDated.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <RunningSerialNo 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('RunningSerialNo-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('RunningSerialNo-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('RunningSerialNo-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('RunningSerialNo-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.RunningSerialNo, ...RunningSerialNo }"
            :values="configObject.RunningSerialNo.RunningSerialNoValue" name="RunningSerialNo" ref="refRunningSerialNo"
            v-if="configObject.RunningSerialNo != undefined ? configObject.RunningSerialNo.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <BillAmount 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('BillAmount-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('BillAmount-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('BillAmount-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('BillAmount-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.BillAmount, ...BillAmount }"
            :values="configObject.BillAmount.BillAmountValue" name="BillAmount" ref="refBillAmount"
            v-if="configObject.BillAmount != undefined ? configObject.BillAmount.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <SwiftReference 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('SwiftReference-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('SwiftReference-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('SwiftReference-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('SwiftReference-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.SwiftReference, ...SwiftReference }"
            :values="configObject.SwiftReference.SwiftReferenceValue" name="SwiftReference" ref="refSwiftReference"
            v-if="configObject.SwiftReference != undefined ? configObject.SwiftReference.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <InvoiceAmount 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('InvoiceAmount-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('InvoiceAmount-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('InvoiceAmount-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('InvoiceAmount-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.InvoiceAmount, ...InvoiceAmount }"
            :values="configObject.InvoiceAmount.InvoiceAmountValue" name="InvoiceAmount" ref="refInvoiceAmount"
            v-if="configObject.InvoiceAmount != undefined ? configObject.InvoiceAmount.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <InvoiceNo 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('InvoiceNo-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('InvoiceNo-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('InvoiceNo-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('InvoiceNo-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.InvoiceNo, ...InvoiceNo }"
            :values="configObject.InvoiceNo.InvoiceNoValue" name="InvoiceNo" ref="refInvoiceNo"
            v-if="configObject.InvoiceNo != undefined ? configObject.InvoiceNo.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <!-- <InvoiceDated  -->
          <InvoiceDated @DateDdMmYyyy-onBlur="(val,event) => {
            $emit('InvoiceDated-onBlur', val,event);
          }
          "
          @DateDdMmYyyy-onChange="(val) => {
            $emit('InvoiceDated-onChange', val);
          }
          " 
          @DateDdMmYyyy-onFocus="(val) => {
            $emit('InvoiceDated-onFocus', val);
          }
          " 
           v-bind="{ ...configObject.InvoiceDated, ...InvoiceDated }" :values="configObject.InvoiceDated.InvoiceDatedValue" name="InvoiceDated"
            ref="refInvoiceDated" 
            v-if="configObject.InvoiceDated != undefined ? configObject.InvoiceDated.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        Deductions;
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <ForeignBankCharges 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('ForeignBankCharges-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('ForeignBankCharges-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('ForeignBankCharges-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('ForeignBankCharges-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.ForeignBankCharges, ...ForeignBankCharges }"
            :values="configObject.ForeignBankCharges.ForeignBankChargesValue" name="ForeignBankCharges" ref="refForeignBankCharges"
            v-if="configObject.ForeignBankCharges != undefined ? configObject.ForeignBankCharges.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <WithholdingTax 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('WithholdingTax-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('WithholdingTax-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('WithholdingTax-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('WithholdingTax-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.WithholdingTax, ...WithholdingTax }"
            :values="configObject.WithholdingTax.WithholdingTaxValue" name="WithholdingTax" ref="refWithholdingTax"
            v-if="configObject.WithholdingTax != undefined ? configObject.WithholdingTax.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <AgentBrokerageCommission 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('AgentBrokerageCommission-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('AgentBrokerageCommission-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('AgentBrokerageCommission-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('AgentBrokerageCommission-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.AgentBrokerageCommission, ...AgentBrokerageCommission }"
            :values="configObject.AgentBrokerageCommission.AgentBrokerageCommissionValue" name="AgentBrokerageCommission" ref="refAgentBrokerageCommission"
            v-if="configObject.AgentBrokerageCommission != undefined ? configObject.AgentBrokerageCommission.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <Eds 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('Eds-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('Eds-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('Eds-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('Eds-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.Eds, ...Eds }"
            :values="configObject.Eds.EdsValue" name="Eds" ref="refEds"
            v-if="configObject.Eds != undefined ? configObject.Eds.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <EdsUniqueRefNo 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('EdsUniqueRefNo-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('EdsUniqueRefNo-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('EdsUniqueRefNo-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('EdsUniqueRefNo-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.EdsUniqueRefNo, ...EdsUniqueRefNo }"
            :values="configObject.EdsUniqueRefNo.EdsUniqueRefNoValue" name="EdsUniqueRefNo" ref="refEdsUniqueRefNo"
            v-if="configObject.EdsUniqueRefNo != undefined ? configObject.EdsUniqueRefNo.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        Net Amount Realized;
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <CurrencyOfRealization 
          @GenericDropDown-onChange="(val) => {
            $emit('CurrencyOfRealization-onChange', val);
          }
          " 
          @GenericDropDown-onFocus="(val) => {
            $emit('CurrencyOfRealization-onFocus', val);
          }
          "
          @GenericDropDown-onBlur="(val,event) => {
            $emit('CurrencyOfRealization-onBlur', val,event);
          }
          "
            v-bind="{ ...configObject.CurrencyOfRealization, ...CurrencyOfRealization }"
            :values="configObject.CurrencyOfRealization.CurrencyOfRealizationValue" name="CurrencyOfRealization" ref="refCurrencyOfRealization"
            v-if="configObject.CurrencyOfRealization != undefined ? configObject.CurrencyOfRealization.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <AllowedDiscount 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('AllowedDiscount-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('AllowedDiscount-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('AllowedDiscount-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('AllowedDiscount-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.AllowedDiscount, ...AllowedDiscount }"
            :values="configObject.AllowedDiscount.AllowedDiscountValue" name="AllowedDiscount" ref="refAllowedDiscount"
            v-if="configObject.AllowedDiscount != undefined ? configObject.AllowedDiscount.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <Currency 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('Currency-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('Currency-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('Currency-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('Currency-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.Currency, ...Currency }"
            :values="configObject.Currency.CurrencyValue" name="Currency" ref="refCurrency"
            v-if="configObject.Currency != undefined ? configObject.Currency.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <AllowedDiscountPercentage 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('AllowedDiscountPercentage-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('AllowedDiscountPercentage-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('AllowedDiscountPercentage-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('AllowedDiscountPercentage-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.AllowedDiscountPercentage, ...AllowedDiscountPercentage }"
            :values="configObject.AllowedDiscountPercentage.AllowedDiscountPercentageValue" name="AllowedDiscountPercentage" ref="refAllowedDiscountPercentage"
            v-if="configObject.AllowedDiscountPercentage != undefined ? configObject.AllowedDiscountPercentage.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <BcaAmount 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('BcaAmount-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('BcaAmount-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('BcaAmount-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('BcaAmount-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.BcaAmount, ...BcaAmount }"
            :values="configObject.BcaAmount.BcaAmountValue" name="BcaAmount" ref="refBcaAmount"
            v-if="configObject.BcaAmount != undefined ? configObject.BcaAmount.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <TotalBcaAmount 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('TotalBcaAmount-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('TotalBcaAmount-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('TotalBcaAmount-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('TotalBcaAmount-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.TotalBcaAmount, ...TotalBcaAmount }"
            :values="configObject.TotalBcaAmount.TotalBcaAmountValue" name="TotalBcaAmount" ref="refTotalBcaAmount"
            v-if="configObject.TotalBcaAmount != undefined ? configObject.TotalBcaAmount.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <FcyExchangeRate 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('FcyExchangeRate-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('FcyExchangeRate-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('FcyExchangeRate-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('FcyExchangeRate-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.FcyExchangeRate, ...FcyExchangeRate }"
            :values="configObject.FcyExchangeRate.FcyExchangeRateValue" name="FcyExchangeRate" ref="refFcyExchangeRate"
            v-if="configObject.FcyExchangeRate != undefined ? configObject.FcyExchangeRate.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <AmountRealized 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('AmountRealized-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('AmountRealized-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('AmountRealized-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('AmountRealized-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.AmountRealized, ...AmountRealized }"
            :values="configObject.AmountRealized.AmountRealizedValue" name="AmountRealized" ref="refAmountRealized"
            v-if="configObject.AmountRealized != undefined ? configObject.AmountRealized.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <Bca 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('Bca-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('Bca-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('Bca-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('Bca-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.Bca, ...Bca }"
            :values="configObject.Bca.BcaValue" name="Bca" ref="refBca"
            v-if="configObject.Bca != undefined ? configObject.Bca.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <Balance 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('Balance-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('Balance-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('Balance-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('Balance-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.Balance, ...Balance }"
            :values="configObject.Balance.BalanceValue" name="Balance" ref="refBalance"
            v-if="configObject.Balance != undefined ? configObject.Balance.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <DateOfRealized 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('DateOfRealized-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('DateOfRealized-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('DateOfRealized-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('DateOfRealized-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.DateOfRealized, ...DateOfRealized }"
            :values="configObject.DateOfRealized.DateOfRealizedValue" name="DateOfRealized" ref="refDateOfRealized"
            v-if="configObject.DateOfRealized != undefined ? configObject.DateOfRealized.isVisible :false" />
        </el-col>
        <el-col :lg="12" :md="12">
          <Remarks 
          @GenericTextBox-onKeyPress="(val,event) => {
            $emit('Remarks-onKeyPress', val,event);
          }
          "
          @GenericTextBox-onBlur="(val,event) => {
            $emit('Remarks-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('Remarks-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('Remarks-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.Remarks, ...Remarks }"
            :values="configObject.Remarks.RemarksValue" name="Remarks" ref="refRemarks"
            v-if="configObject.Remarks != undefined ? configObject.Remarks.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <AdjustmentFrom 
          @GenericTextBox-onBlur="(val,event) => {
            $emit('AdjustmentFrom-onBlur', val,event);
          }
          " 
          @GenericTextBox-onChange="(val) => {
            $emit('AdjustmentFrom-onChange', val);
          }
          " 
          @GenericTextBox-onFocus="(val) => {
            $emit('AdjustmentFrom-onFocus', val);
          }
          " 
            v-bind="{ ...configObject.AdjustmentFrom, ...AdjustmentFrom }"
            :values="configObject.AdjustmentFrom.AdjustmentFromValue" name="AdjustmentFrom" ref="refAdjustmentFrom"
            v-if="configObject.AdjustmentFrom != undefined ? configObject.AdjustmentFrom.isVisible :false" />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <FullAmount 
          @GenericDropDown-onChange="(val) => {
            $emit('FullAmount-onChange', val);
          }
          " 
          @GenericDropDown-onFocus="(val) => {
            $emit('FullAmount-onFocus', val);
          }
          "
          @GenericDropDown-onBlur="(val,event) => {
            $emit('FullAmount-onBlur', val,event);
          }
          "
            v-bind="{ ...configObject.FullAmount, ...FullAmount }"
            :values="configObject.FullAmount.FullAmountValue" name="FullAmount" ref="refFullAmount"
            v-if="configObject.FullAmount != undefined ? configObject.FullAmount.isVisible :false" />
        </el-col>
      </el-row>
      <el-row>
        <el-col :lg="22" :md="22">
          <fieldset v-if="configObject.section1 != undefined ? configObject.section1.isVisible : false">
            <el-row>
            <el-col :lg="21" :md="21">
            </el-col>

            <el-col :lg="2" :md="2">
          <ExitButton @GenericButton-onClick="(val) => {
            $emit('ExitButton-onClick', val);
          }
            " v-bind="{ ...configObject.ExitButton, ...ExitButton }" name="ExitButton" ref="refExitButton"
            v-if="configObject.ExitButton.isVisible" />
        </el-col>
      </el-row>
        </fieldset>
        </el-col>
      </el-row>


  </Form>
</template>

<script>
import { Form, useForm } from "vee-validate";
import { reactive, ref } from "vue";

import {
  GenericTextBox as BCAUniqueIdenNo,
  GenericTextBox as ExporterIban,
  GenericTextBox as ExporterNtn,
  GenericTextBox as ModeOfExportPayment,
  GenericTextBox as ExporterName,
  GenericTextBox as FinancialInstruUniqueNo,
  GenericTextBox as BcaEventName,
  GenericTextBox as BillNo,
  GenericTextBox as BillDated,
  GenericTextBox as RunningSerialNo,
  GenericTextBox as BillAmount,
  GenericTextBox as SwiftReference,
  GenericTextBox as InvoiceAmount,
  GenericTextBox as InvoiceNo,
  GenericTextBox as ForeignBankCharges,
  GenericTextBox as WithholdingTax,
  GenericTextBox as AgentBrokerageCommission,
  GenericTextBox as Eds,
  GenericTextBox as EdsUniqueRefNo,
  GenericTextBox as AllowedDiscount,
  GenericTextBox as Currency,
  GenericTextBox as AllowedDiscountPercentage,
  GenericTextBox as BcaAmount,
  GenericTextBox as TotalBcaAmount,
  GenericTextBox as FcyExchangeRate,
  GenericTextBox as AmountRealized,
  GenericTextBox as Bca,
  GenericTextBox as Balance,
  GenericTextBox as DateOfRealized,
  GenericTextBox as Remarks,
  GenericTextBox as AdjustmentFrom,



  GenericDropDown as CurrencyOfRealization,
  GenericDropDown as FullAmount,


  DateDdMmYyyy as EventDate,
  DateDdMmYyyy as InvoiceDated,
  GenericButton as ExitButton,


} from "@teresol-v2/ui-components";
export default {
  name: "MegaSet1153",
  components: {
    Form,
    BCAUniqueIdenNo,
    ExporterIban,
    ExporterNtn,
    ModeOfExportPayment,
    ExporterName,
    FinancialInstruUniqueNo,
    BcaEventName,
    BillNo,
    BillDated,
    RunningSerialNo,
    BillAmount,
    SwiftReference,
    InvoiceAmount,
    InvoiceNo,
    ForeignBankCharges,
    WithholdingTax,
    AgentBrokerageCommission,
    Eds,
    EdsUniqueRefNo,
    AllowedDiscount,
    Currency,
    AllowedDiscount,
    AllowedDiscountPercentage,
    BcaAmount,
    TotalBcaAmount,
    FcyExchangeRate,
    AmountRealized,
    Bca,
    Balance,
    DateOfRealized,
    Remarks,
    AdjustmentFrom,
    CurrencyOfRealization,
    FullAmount,
    EventDate,
    InvoiceDated,
    ExitButton
  },
  props: {
    configObj: {},
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit("onSubmit", values);
    }
    const configObject = reactive({
      title: props.configObj,
      ...props.configObj.componentProps

    });

    return {
      onSubmit,
      configObject,

      BCAUniqueIdenNo: { spanLabels: 10, spanInputs: 10 },
      ExporterIban: { spanLabels: 10, spanInputs: 10 },
      ExporterNtn: { spanLabels: 10, spanInputs: 10 },
      ModeOfExportPayment: { spanLabels: 10, spanInputs: 10 },
      ExporterName: { spanLabels: 10, spanInputs: 10 },
      FinancialInstruUniqueNo: { spanLabels: 10, spanInputs: 10 },
      BcaEventName: { spanLabels: 10, spanInputs: 10 },
      BillNo: { spanLabels: 10, spanInputs: 10 },
      BillDated: { spanLabels: 10, spanInputs: 10 },
      RunningSerialNo: { spanLabels: 10, spanInputs: 10 },
      BillAmount: { spanLabels: 10, spanInputs: 10 },
      SwiftReference: { spanLabels: 10, spanInputs: 10 },
      InvoiceAmount: { spanLabels: 10, spanInputs: 10 },
      InvoiceNo: { spanLabels: 10, spanInputs: 10 },
      ForeignBankCharges: { spanLabels: 14, spanInputs: 6 },
      WithholdingTax: { spanLabels: 10, spanInputs: 10 },
      AgentBrokerageCommission: { spanLabels: 14, spanInputs: 6 },
      Eds: { spanLabels: 10, spanInputs: 10 },
      EdsUniqueRefNo: { spanLabels: 14, spanInputs: 6 },
      AllowedDiscount: { spanLabels: 10, spanInputs: 10 },
      Currency: { spanLabels: 10, spanInputs: 10 },
      AllowedDiscount: { spanLabels: 10, spanInputs: 10 },
      AllowedDiscountPercentage: { spanLabels: 10, spanInputs: 10 },
      BcaAmount: { spanLabels: 10, spanInputs: 10 },
      TotalBcaAmount: { spanLabels: 10, spanInputs: 10 },
      FcyExchangeRate: { spanLabels: 10, spanInputs: 10 },
      AmountRealized: { spanLabels: 10, spanInputs: 10 },
      Bca: { spanLabels: 10, spanInputs: 10 },
      Balance: { spanLabels: 10, spanInputs: 10 },
      DateOfRealized: { spanLabels: 10, spanInputs: 10 },
      Remarks: { spanLabels: 10, spanInputs: 10 },
      AdjustmentFrom: { spanLabels: 10, spanInputs: 10 },
      CurrencyOfRealization: { spanLabels: 15, spanInputs: 5 },
      FullAmount: { spanLabels: 16, spanInputs: 4 },
      EventDate: { spanLabels: 10, spanInputs: 10 },
      InvoiceDated: { spanLabels: 10, spanInputs: 10 },
      ExitButton: { spanInputs: 24, nativeType: 'button' },

    };
  },
};
</script>