// MegaSet1153.stories.js

import MegaSet1153 from "../MegaSet/MegaSet1153.vue";
import { ref } from "vue";
import { action } from "@storybook/addon-actions";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "MegaSet1153",
  component: MegaSet1153,
};

const configurationObject = {
  screenTitle: "",
  componentProps: {

          BCAUniqueIdenNo: {

                  label:'BCA Unique identification No.',
                  dataType:'numeric',
                  inputLength: 12,
                  tabIndex: 1,
                  BCAUniqueIdenNoValue:'',
                  isDisabled: false,
                  textColor: '',
                  labelColor: '',
                  labelFontWeight: '',
                  mandatory: true,
                  isVisible: true,
                  backgroundColor:'white'
          },
          ExporterIban: {

          label:'Exporter IBAN',
          dataType:'alphaNumeric',
          inputLength: 24,
          tabIndex: 1,
          ExporterIbanValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ExporterNtn: {

          label:'Export NTN',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNtnValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },   
           ModeOfExportPayment: {

          label:'Mode of Export Payment',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ModeOfExportPaymentValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },  
          ExporterName: {

          label:'Export Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },              
          FinancialInstruUniqueNo: {

          label:'Financial Instru Unique No.',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FinancialInstruUniqueNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },               
          BcaEventName: {

          label:'BCA Event Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaEventNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },                
          BillNo: {

          label:'Bill No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          BillDated: {

          label:'Bill Dated',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillDatedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          RunningSerialNo: {

          label:'Running Serial No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RunningSerialNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BillAmount: {

          label:'Bill Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          SwiftReference: {

          label:'SWIFT Reference (20 Field)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          SwiftReferenceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceAmount: {

          label:'Invoice Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          InvoiceNo: {

          label:'Invoice No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ForeignBankCharges: {

          label:'Foreign Bank Charges (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ForeignBankChargesValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          WithholdingTax: {

          label:'Withholding Tax (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          WithholdingTaxValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AgentBrokerageCommission: {

          label:'Agent / Brokerage Commission (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AgentBrokerageCommissionValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Eds: {

          label:'EDS (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          EdsUniqueRefNo: {

          label:'Eds Unique Ref No:',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsUniqueRefNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscount: {

          label:'Allowed Discount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Currency: {

          label:'Currency',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          CurrencyValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscountPercentage: {

          label:'Allowed Discount %',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountPercentageValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BcaAmount: {

          label:'BCA Amount (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          TotalBcaAmount: {

          label:'Total BCA Amount (Financial Instrument FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          TotalBcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          FcyExchangeRate: {

          label:'FCY Exchange Rate',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FcyExchangeRateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AmountRealized: {

          label:'Amount Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AmountRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Bca: {

          label:'BCA (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Balance: {

          label:'Balance',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BalanceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          DateOfRealized: {

          label:'Date of Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          DateOfRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Remarks: {

          label:'Remarks',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RemarksValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AdjustmentFrom: {

          label:'Adjustment from - Special FCY Account (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AdjustmentFromValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          CurrencyOfRealization: {

          isDisabled: false,
          CurrencyOfRealizationValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Currency of Realization is different from financial Instrument Currency",
          mandatory: true,
          isVisible: true
          },
          FullAmount: {

          isDisabled: false,
          FullAmountValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Full Amount is not realized against this Export and the Remaining amount is settled with discount",
          mandatory: true,
          isVisible: true
          },
          EventDate: {
          label:'Event Date',
          tabIndex: 1,
          EventDateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceDated: {
              label:'Invoice Dated',
              tabIndex: 1,
              InvoiceDatedValue:'',
              isDisabled: false,
              textColor: '',
              labelColor: '',
              mandatory: true,
              isVisible: true,
              backgroundColor:'white'
          },
          ExitButton: {
              isVisible: true,
              isDisabled: false,
              label: "Exit"
          },

      section1: {
          isVisible: true,
      },

  },
};
const configurationObject_EXP_553 = {
  screenTitle: "",
  componentProps: {

          BCAUniqueIdenNo: {

                  label:'BCA Unique identification No.',
                  dataType:'numeric',
                  inputLength: 12,
                  tabIndex: 1,
                  BCAUniqueIdenNoValue:'',
                  isDisabled: false,
                  textColor: '',
                  labelColor: '',
                  labelFontWeight: '',
                  mandatory: true,
                  isVisible: true,
                  backgroundColor:'white'
          },
          ExporterIban: {

          label:'Exporter IBAN',
          dataType:'alphaNumeric',
          inputLength: 24,
          tabIndex: 1,
          ExporterIbanValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ExporterNtn: {

          label:'Export NTN',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNtnValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },   
           ModeOfExportPayment: {

          label:'Mode of Export Payment',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ModeOfExportPaymentValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },  
          ExporterName: {

          label:'Export Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },              
          FinancialInstruUniqueNo: {

          label:'Financial Instru Unique No.',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FinancialInstruUniqueNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },               
          BcaEventName: {

          label:'BCA Event Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaEventNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },                
          BillNo: {

          label:'Bill No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          BillDated: {

          label:'Bill Dated',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillDatedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          RunningSerialNo: {

          label:'Running Serial No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RunningSerialNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BillAmount: {

          label:'Bill Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          SwiftReference: {

          label:'SWIFT Reference (20 Field)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          SwiftReferenceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceAmount: {

          label:'Invoice Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          InvoiceNo: {

          label:'Invoice No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ForeignBankCharges: {

          label:'Foreign Bank Charges (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ForeignBankChargesValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          WithholdingTax: {

          label:'Withholding Tax (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          WithholdingTaxValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AgentBrokerageCommission: {

          label:'Agent / Brokerage Commission (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AgentBrokerageCommissionValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Eds: {

          label:'EDS (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          EdsUniqueRefNo: {

          label:'Eds Unique Ref No:',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsUniqueRefNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscount: {

          label:'Allowed Discount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Currency: {

          label:'Currency',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          CurrencyValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscountPercentage: {

          label:'Allowed Discount %',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountPercentageValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BcaAmount: {

          label:'BCA Amount (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          TotalBcaAmount: {

          label:'Total BCA Amount (Financial Instrument FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          TotalBcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          FcyExchangeRate: {

          label:'FCY Exchange Rate',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FcyExchangeRateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AmountRealized: {

          label:'Amount Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AmountRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Bca: {

          label:'BCA (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Balance: {

          label:'Balance',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BalanceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          DateOfRealized: {

          label:'Date of Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          DateOfRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Remarks: {

          label:'Remarks',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RemarksValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AdjustmentFrom: {

          label:'Adjustment from - Special FCY Account (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AdjustmentFromValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          CurrencyOfRealization: {

          isDisabled: false,
          CurrencyOfRealizationValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Currency of Realization is different from financial Instrument Currency",
          mandatory: true,
          isVisible: true
          },
          FullAmount: {

          isDisabled: false,
          FullAmountValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Full Amount is not realized against this Export and the Remaining amount is settled with discount",
          mandatory: true,
          isVisible: true
          },
          EventDate: {
          label:'Event Date',
          tabIndex: 1,
          EventDateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceDated: {
              label:'Invoice Dated',
              tabIndex: 1,
              InvoiceDatedValue:'',
              isDisabled: false,
              textColor: '',
              labelColor: '',
              mandatory: true,
              isVisible: true,
              backgroundColor:'white'
          },
          ExitButton: {
              isVisible: true,
              isDisabled: false,
              label: "Exit"
          },

      section1: {
          isVisible: true,
      },

  },
};
const configurationObject_EXP_297 = {
  screenTitle: "",
  componentProps: {

          BCAUniqueIdenNo: {

                  label:'BCA Unique identification No.',
                  dataType:'numeric',
                  inputLength: 12,
                  tabIndex: 1,
                  BCAUniqueIdenNoValue:'',
                  isDisabled: false,
                  textColor: '',
                  labelColor: '',
                  labelFontWeight: '',
                  mandatory: true,
                  isVisible: true,
                  backgroundColor:'white'
          },
          ExporterIban: {

          label:'Exporter IBAN',
          dataType:'alphaNumeric',
          inputLength: 24,
          tabIndex: 1,
          ExporterIbanValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ExporterNtn: {

          label:'Export NTN',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNtnValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },   
           ModeOfExportPayment: {

          label:'Mode of Export Payment',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ModeOfExportPaymentValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },  
          ExporterName: {

          label:'Export Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },              
          FinancialInstruUniqueNo: {

          label:'Financial Instru Unique No.',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FinancialInstruUniqueNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },               
          BcaEventName: {

          label:'BCA Event Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaEventNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },                
          BillNo: {

          label:'Bill No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          BillDated: {

          label:'Bill Dated',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillDatedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          RunningSerialNo: {

          label:'Running Serial No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RunningSerialNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BillAmount: {

          label:'Bill Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          SwiftReference: {

          label:'SWIFT Reference (20 Field)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          SwiftReferenceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceAmount: {

          label:'Invoice Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          InvoiceNo: {

          label:'Invoice No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ForeignBankCharges: {

          label:'Foreign Bank Charges (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ForeignBankChargesValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          WithholdingTax: {

          label:'Withholding Tax (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          WithholdingTaxValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AgentBrokerageCommission: {

          label:'Agent / Brokerage Commission (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AgentBrokerageCommissionValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Eds: {

          label:'EDS (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          EdsUniqueRefNo: {

          label:'Eds Unique Ref No:',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsUniqueRefNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscount: {

          label:'Allowed Discount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Currency: {

          label:'Currency',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          CurrencyValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscountPercentage: {

          label:'Allowed Discount %',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountPercentageValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BcaAmount: {

          label:'BCA Amount (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          TotalBcaAmount: {

          label:'Total BCA Amount (Financial Instrument FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          TotalBcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          FcyExchangeRate: {

          label:'FCY Exchange Rate',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FcyExchangeRateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AmountRealized: {

          label:'Amount Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AmountRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Bca: {

          label:'BCA (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Balance: {

          label:'Balance',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BalanceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          DateOfRealized: {

          label:'Date of Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          DateOfRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Remarks: {

          label:'Remarks',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RemarksValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AdjustmentFrom: {

          label:'Adjustment from - Special FCY Account (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AdjustmentFromValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          CurrencyOfRealization: {

          isDisabled: false,
          CurrencyOfRealizationValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Currency of Realization is different from financial Instrument Currency",
          mandatory: true,
          isVisible: true
          },
          FullAmount: {

          isDisabled: false,
          FullAmountValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Full Amount is not realized against this Export and the Remaining amount is settled with discount",
          mandatory: true,
          isVisible: true
          },
          EventDate: {
          label:'Event Date',
          tabIndex: 1,
          EventDateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceDated: {
              label:'Invoice Dated',
              tabIndex: 1,
              InvoiceDatedValue:'',
              isDisabled: false,
              textColor: '',
              labelColor: '',
              mandatory: true,
              isVisible: true,
              backgroundColor:'white'
          },
          ExitButton: {
              isVisible: true,
              isDisabled: false,
              label: "Exit"
          },

      section1: {
          isVisible: true,
      },

  },
};
const configurationObject_EXP_418 = {
  screenTitle: "",
  componentProps: {

          BCAUniqueIdenNo: {

                  label:'BCA Unique identification No.',
                  dataType:'numeric',
                  inputLength: 12,
                  tabIndex: 1,
                  BCAUniqueIdenNoValue:'',
                  isDisabled: false,
                  textColor: '',
                  labelColor: '',
                  labelFontWeight: '',
                  mandatory: true,
                  isVisible: true,
                  backgroundColor:'white'
          },
          ExporterIban: {

          label:'Exporter IBAN',
          dataType:'alphaNumeric',
          inputLength: 24,
          tabIndex: 1,
          ExporterIbanValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ExporterNtn: {

          label:'Export NTN',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNtnValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },   
           ModeOfExportPayment: {

          label:'Mode of Export Payment',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ModeOfExportPaymentValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },  
          ExporterName: {

          label:'Export Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },              
          FinancialInstruUniqueNo: {

          label:'Financial Instru Unique No.',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FinancialInstruUniqueNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },               
          BcaEventName: {

          label:'BCA Event Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaEventNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },                
          BillNo: {

          label:'Bill No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          BillDated: {

          label:'Bill Dated',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillDatedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          RunningSerialNo: {

          label:'Running Serial No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RunningSerialNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BillAmount: {

          label:'Bill Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          SwiftReference: {

          label:'SWIFT Reference (20 Field)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          SwiftReferenceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceAmount: {

          label:'Invoice Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          InvoiceNo: {

          label:'Invoice No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ForeignBankCharges: {

          label:'Foreign Bank Charges (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ForeignBankChargesValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          WithholdingTax: {

          label:'Withholding Tax (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          WithholdingTaxValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AgentBrokerageCommission: {

          label:'Agent / Brokerage Commission (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AgentBrokerageCommissionValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Eds: {

          label:'EDS (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          EdsUniqueRefNo: {

          label:'Eds Unique Ref No:',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsUniqueRefNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscount: {

          label:'Allowed Discount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Currency: {

          label:'Currency',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          CurrencyValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscountPercentage: {

          label:'Allowed Discount %',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountPercentageValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BcaAmount: {

          label:'BCA Amount (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          TotalBcaAmount: {

          label:'Total BCA Amount (Financial Instrument FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          TotalBcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          FcyExchangeRate: {

          label:'FCY Exchange Rate',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FcyExchangeRateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AmountRealized: {

          label:'Amount Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AmountRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Bca: {

          label:'BCA (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Balance: {

          label:'Balance',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BalanceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          DateOfRealized: {

          label:'Date of Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          DateOfRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Remarks: {

          label:'Remarks',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RemarksValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AdjustmentFrom: {

          label:'Adjustment from - Special FCY Account (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AdjustmentFromValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          CurrencyOfRealization: {

          isDisabled: false,
          CurrencyOfRealizationValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Currency of Realization is different from financial Instrument Currency",
          mandatory: true,
          isVisible: true
          },
          FullAmount: {

          isDisabled: false,
          FullAmountValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Full Amount is not realized against this Export and the Remaining amount is settled with discount",
          mandatory: true,
          isVisible: true
          },
          EventDate: {
          label:'Event Date',
          tabIndex: 1,
          EventDateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceDated: {
              label:'Invoice Dated',
              tabIndex: 1,
              InvoiceDatedValue:'',
              isDisabled: false,
              textColor: '',
              labelColor: '',
              mandatory: true,
              isVisible: true,
              backgroundColor:'white'
          },
          ExitButton: {
              isVisible: true,
              isDisabled: false,
              label: "Exit"
          },

      section1: {
          isVisible: true,
      },

  },
};
const configurationObject_EXP_466 = {
  screenTitle: "",
  componentProps: {

          BCAUniqueIdenNo: {

                  label:'BCA Unique identification No.',
                  dataType:'numeric',
                  inputLength: 12,
                  tabIndex: 1,
                  BCAUniqueIdenNoValue:'',
                  isDisabled: false,
                  textColor: '',
                  labelColor: '',
                  labelFontWeight: '',
                  mandatory: true,
                  isVisible: true,
                  backgroundColor:'white'
          },
          ExporterIban: {

          label:'Exporter IBAN',
          dataType:'alphaNumeric',
          inputLength: 24,
          tabIndex: 1,
          ExporterIbanValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ExporterNtn: {

          label:'Export NTN',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNtnValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },   
           ModeOfExportPayment: {

          label:'Mode of Export Payment',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ModeOfExportPaymentValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },  
          ExporterName: {

          label:'Export Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },              
          FinancialInstruUniqueNo: {

          label:'Financial Instru Unique No.',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FinancialInstruUniqueNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },               
          BcaEventName: {

          label:'BCA Event Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaEventNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },                
          BillNo: {

          label:'Bill No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          BillDated: {

          label:'Bill Dated',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillDatedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          RunningSerialNo: {

          label:'Running Serial No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RunningSerialNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BillAmount: {

          label:'Bill Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          SwiftReference: {

          label:'SWIFT Reference (20 Field)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          SwiftReferenceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceAmount: {

          label:'Invoice Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          InvoiceNo: {

          label:'Invoice No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ForeignBankCharges: {

          label:'Foreign Bank Charges (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ForeignBankChargesValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          WithholdingTax: {

          label:'Withholding Tax (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          WithholdingTaxValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AgentBrokerageCommission: {

          label:'Agent / Brokerage Commission (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AgentBrokerageCommissionValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Eds: {

          label:'EDS (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          EdsUniqueRefNo: {

          label:'Eds Unique Ref No:',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsUniqueRefNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscount: {

          label:'Allowed Discount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Currency: {

          label:'Currency',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          CurrencyValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscountPercentage: {

          label:'Allowed Discount %',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountPercentageValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BcaAmount: {

          label:'BCA Amount (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          TotalBcaAmount: {

          label:'Total BCA Amount (Financial Instrument FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          TotalBcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          FcyExchangeRate: {

          label:'FCY Exchange Rate',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FcyExchangeRateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AmountRealized: {

          label:'Amount Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AmountRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Bca: {

          label:'BCA (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Balance: {

          label:'Balance',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BalanceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          DateOfRealized: {

          label:'Date of Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          DateOfRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Remarks: {

          label:'Remarks',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RemarksValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AdjustmentFrom: {

          label:'Adjustment from - Special FCY Account (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AdjustmentFromValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          CurrencyOfRealization: {

          isDisabled: false,
          CurrencyOfRealizationValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Currency of Realization is different from financial Instrument Currency",
          mandatory: true,
          isVisible: true
          },
          FullAmount: {

          isDisabled: false,
          FullAmountValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Full Amount is not realized against this Export and the Remaining amount is settled with discount",
          mandatory: true,
          isVisible: true
          },
          EventDate: {
          label:'Event Date',
          tabIndex: 1,
          EventDateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceDated: {
              label:'Invoice Dated',
              tabIndex: 1,
              InvoiceDatedValue:'',
              isDisabled: false,
              textColor: '',
              labelColor: '',
              mandatory: true,
              isVisible: true,
              backgroundColor:'white'
          },
          ExitButton: {
              isVisible: true,
              isDisabled: false,
              label: "Exit"
          },

      section1: {
          isVisible: true,
      },

  },
};
const configurationObject_EXP_649 = {
  screenTitle: "",
  componentProps: {

          BCAUniqueIdenNo: {

                  label:'BCA Unique identification No.',
                  dataType:'numeric',
                  inputLength: 12,
                  tabIndex: 1,
                  BCAUniqueIdenNoValue:'',
                  isDisabled: false,
                  textColor: '',
                  labelColor: '',
                  labelFontWeight: '',
                  mandatory: true,
                  isVisible: true,
                  backgroundColor:'white'
          },
          ExporterIban: {

          label:'Exporter IBAN',
          dataType:'alphaNumeric',
          inputLength: 24,
          tabIndex: 1,
          ExporterIbanValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ExporterNtn: {

          label:'Export NTN',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNtnValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },   
           ModeOfExportPayment: {

          label:'Mode of Export Payment',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ModeOfExportPaymentValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },  
          ExporterName: {

          label:'Export Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ExporterNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },              
          FinancialInstruUniqueNo: {

          label:'Financial Instru Unique No.',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FinancialInstruUniqueNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },               
          BcaEventName: {

          label:'BCA Event Name',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaEventNameValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },                
          BillNo: {

          label:'Bill No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          BillDated: {

          label:'Bill Dated',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillDatedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          RunningSerialNo: {

          label:'Running Serial No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RunningSerialNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: 'blue',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BillAmount: {

          label:'Bill Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BillAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          SwiftReference: {

          label:'SWIFT Reference (20 Field)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          SwiftReferenceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceAmount: {

          label:'Invoice Amount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          InvoiceNo: {

          label:'Invoice No',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          InvoiceNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          ForeignBankCharges: {

          label:'Foreign Bank Charges (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          ForeignBankChargesValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          WithholdingTax: {

          label:'Withholding Tax (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          WithholdingTaxValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AgentBrokerageCommission: {

          label:'Agent / Brokerage Commission (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AgentBrokerageCommissionValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Eds: {

          label:'EDS (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          EdsUniqueRefNo: {

          label:'Eds Unique Ref No:',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          EdsUniqueRefNoValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscount: {

          label:'Allowed Discount',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Currency: {

          label:'Currency',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          CurrencyValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          AllowedDiscountPercentage: {

          label:'Allowed Discount %',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AllowedDiscountPercentageValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          BcaAmount: {

          label:'BCA Amount (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          TotalBcaAmount: {

          label:'Total BCA Amount (Financial Instrument FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          TotalBcaAmountValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          FcyExchangeRate: {

          label:'FCY Exchange Rate',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          FcyExchangeRateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AmountRealized: {

          label:'Amount Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AmountRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Bca: {

          label:'BCA (PKR)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BcaValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Balance: {

          label:'Balance',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          BalanceValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          DateOfRealized: {

          label:'Date of Realized',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          DateOfRealizedValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          Remarks: {

          label:'Remarks',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          RemarksValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          AdjustmentFrom: {

          label:'Adjustment from - Special FCY Account (FCY)',
          dataType:'numeric',
          inputLength: 12,
          tabIndex: 1,
          AdjustmentFromValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          labelFontWeight: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },

          CurrencyOfRealization: {

          isDisabled: false,
          CurrencyOfRealizationValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Currency of Realization is different from financial Instrument Currency",
          mandatory: true,
          isVisible: true
          },
          FullAmount: {

          isDisabled: false,
          FullAmountValue: [{
            value: "Y",
            option: "Y"
          },
          {
            value: "N",
            option: "N"
          }
          ],
          defaultValue: "",
          colorinput: "",
          colorLabel: "blue",
          dropDownLabel: "Full Amount is not realized against this Export and the Remaining amount is settled with discount",
          mandatory: true,
          isVisible: true
          },
          EventDate: {
          label:'Event Date',
          tabIndex: 1,
          EventDateValue:'',
          isDisabled: false,
          textColor: '',
          labelColor: '',
          mandatory: true,
          isVisible: true,
          backgroundColor:'white'
          },
          InvoiceDated: {
              label:'Invoice Dated',
              tabIndex: 1,
              InvoiceDatedValue:'',
              isDisabled: false,
              textColor: '',
              labelColor: '',
              mandatory: true,
              isVisible: true,
              backgroundColor:'white'
          },
          ExitButton: {
              isVisible: true,
              isDisabled: false,
              label: "Exit"
          },

      section1: {
          isVisible: true,
      },

  },
};
const Template = (args) => ({
  components: { MegaSet1153 },
  setup() {
    return { args };
  },
  template: `<MegaSet1153 v-bind="args" 
    @NameTextBox-onBlur="NameTextBox-onBlur" 
    @AddressTextBox-onBlur="AddressTextBox-onBlur"
    />`,
  methods: {
    "NameTextBox-onBlur": action("NameTextBox-onBlur"),
    "AddressTextBox-onBlur": action("AddressTextBox-onBlur"),
  },
});
const Sets_Template = (args) => ({
  components: { MegaSet1153 },
  template: `<MegaSet1153 v-bind="args" 
  />`,
  setup() {
    return { args };
  }
});
export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };
export const EXP_553 = Sets_Template.bind({});
EXP_553.args = { configObj: configurationObject_EXP_553 };
export const EXP_297 = Sets_Template.bind({});
EXP_297.args = { configObj: configurationObject_EXP_297 };
export const EXP_418 = Sets_Template.bind({});
EXP_418.args = { configObj: configurationObject_EXP_418 };
export const EXP_466 = Sets_Template.bind({});
EXP_466.args = { configObj: configurationObject_EXP_466 };
export const EXP_649 = Sets_Template.bind({});
EXP_649.args = { configObj: configurationObject_EXP_649 };