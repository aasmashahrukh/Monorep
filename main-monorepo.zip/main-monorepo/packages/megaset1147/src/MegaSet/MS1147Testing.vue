<template>
<MegaSet1147 :configObj="configurationObject"
  @onSubmit="onSubmit" />
</template>
<script>
import MegaSet1147 from '../MegaSet/MegaSet1147.vue';
import { reactive, ref } from "vue";

export default {
  components: {
    MegaSet1147
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    },
  },
  setup() {
    return reactive({
      configurationObject: {
        screenTitle: "CTF_EXPORTS - Advance",
            componentProps: {

              FIInfoSection: {
                isVisible: true
              },

              FIInfoValue: {
                value: 'FI NO Info'
              },

              BrnNameSection: {
                isVisible: true
              },

              BranchNameCode: {
                value: 'KARACHI MAIN - 1001'
              },

              ADVPNumberSection: {
                isVisible: true
              },

              ADVPNumber: {
                value: '44631/2023'
              },

              section1: {
                isVisible: true,
              },

              tradeProfileStatusSection:{
                isVisible: true
              },

              tradeProfileStatusValue: {
                value: 'NOT REGISTERED'
              },

              tradeProfileStatusColor:{
                color:"red"
              },

              PaymentModeSection:{
                isVisible: true
              },

              PaymentModeValue: {
                value: 'ModeOfPayemntVal'
              },

              PaymentModeColor:{
                color:"red"
              },

              section2: {
                isVisible: true,
              },

              AccountNumber: {
                tabIndex: "",
                isDisabled: false,
                AccountNumberValue: "10010124130001011",
                textColor: "",
                labelColor: "",
                labelFontWeight: "normal",
                mandatory: false,
                label: "A/C No.",
                backgroundColor: "white",
                autoFocusTextBox: "",
                isVisible: true
              },
              
              NTNNumber: {
                tabIndex: "",
                isDisabled: false,
                NTNNumberValue: "81613391",
                textColor: "",
                labelColor: "red",
                labelFontWeight: "normal",
                mandatory: false,
                label: "NTN No.",
                backgroundColor: "white",
                autoFocusTextBox: "",
                isVisible: true
              },

              AccTitleTextBox: {
                label:'A/C Title',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                AccTitleTextBoxValue:'Ahmed General Mills LLP',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              CCINoTextBox: {
                label:'CCI No.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                CCINoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              section3: {
                isVisible: true,
              },

              BankRadioBtn: {
                radioLabel: "",
                BankRadioBtnValue: "Bank",
                radioGroup: [
                  {
                    value: "Bank",
                     label: "Bank",
                     isDisabled: false,
                     leftMargin: 1
                  }    
                ],
                colorinput: {},
                colorLabel: {},
                radioDisplay: "inline",
                bottomMargin: '0.5',
                isVisible: true,
                isDisabled: false,
                mandatory: false,
              },

              PSWWebocRadioBtn: {
                radioLabel: "",
                PSWWebocRadioBtnValue: "",
                radioGroup: [
                  {
                    value: "PSW",
                     label: "PSW",
                     isDisabled: false,
                  },   
                  {
                    value: "Weboc",
                     label: "Weboc",
                     isDisabled: false,
                  }, 
                ],
                colorinput: {},
                colorLabel: {},
                radioDisplay: "inline",
                bottomMargin: '0.5',
                isVisible: true,
                isDisabled: false,
                mandatory: false,
              },

              ADVPUinNumberSection:{
                isVisible: true
              },

              ADVPUinNumberValue: {
                value: '23-1001-202203-87'
              },

              section4: {
                isVisible: true,
              },

              RedForFERadioBtn: {
                radioLabel: "",
                RedForFERadioBtnValue: "",
                radioGroup: [
                  {
                    value: "Ready",
                     label: "Ready",
                     isDisabled: false,
                     leftMargin: "0.4"

                  },   
                  {
                    value: "Forward",
                     label: "Forward",
                     isDisabled: false,
                     leftMargin:"3"

                  }, 
                  {
                    value: "FE-25 Loan/No Exposure",
                    label: "FE-25 Loan/No Exposure",
                    isDisabled: false,
                    leftMargin:"3"

                  }, 
                ],
                colorinput: {},
                colorLabel: {},
                radioDisplay: "inline",
                bottomMargin: '0.5',
                isVisible: true,
                isDisabled: false,
                mandatory: false,
              },

              EDSRefNumber:{
                isVisible: true
              },

              EDSRefNumberValue: {
                value: '1169APE220000014'
              },

              FwdRefNoTextBox: {
                label:'FWD Red No.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                FwdRefNoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              SettlementMethodDropDown: {
                isDisabled: false,
                SettlementMethodDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "Swift-01",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Settlement Method",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              section5: {
                isVisible: true,
              },

              TabPaneView: {
                isDisabled: false,
                isVisible: true
              },  

              TabPane: {
                activeName: 'AdvanceTab',
              },

              //FIRST TAB ADVANCE//

              AdvanceTab: {
                isDisabled: false,
                isVisible: true
              },


              Advance_CurrencyDropDown: {
                isDisabled: false,
                Advance_CurrencyDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Currency",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              Advance_TotalAmtTextBox: {
                label:'Total Amount',
                tabIndex: {},
                isDisabled: false,
                Advance_TotalAmtTextBoxValue: '',
                textColor: '',
                labelColor: {},
                mandatory: false,
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              Advance_NostroAmtTextBox: {
                label:'Nostro Amount',
                tabIndex: {},
                isDisabled: false,
                Advance_NostroAmtTextBoxValue: '',
                textColor: '',
                labelColor: {},
                mandatory: false,
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              Advance_ExchangeRateTextBox: {
                label:'Exchange Rate',
                tabIndex: {},
                isDisabled: false,
                Advance_ExchangeRateTextBoxValue: '',
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              Advance_AmtLCYTextBox: {
                label:'Amount LCY',
                tabIndex: {},
                isDisabled: false,
                Advance_AmtLCYTextBoxValue: '',
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              Advance_TreasuryRateTextBox: {
                label:'Treasury Rate',
                tabIndex: {},
                isDisabled: false,
                Advance_TreasuryRateTextBoxValue: '',
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              Advance_FOBValTextBox: {
                label:'FOB Value',
                Advance_FOBValTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              Advance_NostroBankTextBox: {
                label:'NOSTRO Bank',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_NostroBankTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              NostroListButton: {
                isVisible: true,
                isDisabled: false,
                label: "List"
              }, 
              
              Advance_AdviceNoTextBox: {
                label:'ADVICE NO',
                Advance_AdviceNoTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              Advance_CommFCYTextBox: {
                label:'Agent / Brokerage Comm (FCY)',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_CommFCYTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              Advance_IdentifyTypeDropDown: {
                isDisabled: false,
                Advance_IdentifyTypeDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "blue",
                dropDownLabel: "Identification Type",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              Advance_IdentifyNoTextBox: {
                label:'Identification No.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_IdentifyNoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'blue',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              Advance_RemmitInstTextBox: {
                label:'Name of Remmit. Inst.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_RemmitInstTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              Advance_IBAN_ACNoTextBox: {
                label:'IBAN/Account NO.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_IBAN_ACNoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'blue',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              Advance_SBPApprovalNoTextBox: {
                label:'SBP Approval No.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_SBPApprovalNoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },        

              Advance_SBPApprovalDateTextBox: {
                tabIndex: {},
                isDisabled: false,
                Advance_SBPApprovalDateTextBoxValue: '0309202024',
                textColor: '',
                labelColor: '',
                mandatory: false,
                label: 'SBP Approval Date',
                labelFontWeight: '',
                inputFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: '',
                toolTipText: '',
                isToolTipDisabled: '',
                isVisible: true,
              },

              Advance_BuyerTextBox: {
                label:'Buyer',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_BuyerTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              BuyerListButton: {
                isVisible: true,
                isDisabled: false,
                label: "List"
              }, 

              Advance_CountryReceiptTextBox: {
                label:'Country of Receipt',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_CountryReceiptTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              CountryReceiptListButton: {
                isVisible: true,
                isDisabled: false,
                label: "List"
              }, 

              Advance_CountryTextBox: {
                label:'Country',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_CountryTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              CountryListButton: {
                isVisible: true,
                isDisabled: false,
                label: "List"
              }, 

              Advance_CityDropDown: {
                isDisabled: false,
                Advance_CityDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "City",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              Advance_ReimbBankTextBox: {
                label:'Reimb. Bank',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_ReimbBankTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'blue',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              ReimbBankListButton: {
                isVisible: true,
                isDisabled: false,
                label: "List"
              }, 

              Advance_DestinationDropDown: {
                isDisabled: false,
                Advance_DestinationDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Destinantion",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              Advance_IncoTermsDropDown: {
                isDisabled: false,
                Advance_IncoTermsDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "INCO Terms.",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              Advance_SwftRefNoTextBox: {
                label:'Swift Ref No.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Advance_SwftRefNoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: 'bold',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              section6: {
                isVisible: true,
              },

              section7: {
                isVisible: true,
              },

              //SECOND TAB CHARGES//
              ChargesTab: {
                isDisabled: false,
                isVisible: true
              },

              ChargesTable: {
                isDisabled: false,
                isVisible: true,
                tableHeight: ref('14vw'),
                tableWidth: ref(100),
                tableData: [],
                tableColumns: [
                  {
                    prop: 'tran_code',
                    label: 'Tran Code',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'tran_desc',
                    label: 'Tran Desc',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'gl_account',
                    label: 'GL Account',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'perc',
                    label: 'Perc',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'amount',
                    label: 'Amount',
                    align: 'left',
                    columnsWidth: 10
                  },
                ]
              },

              GetChargesButton: {
                isVisible: true,
                isDisabled: false,
                label: "Get Charges"
              }, 

              ChangeChargesButton: {
                isVisible: true,
                isDisabled: false,
                label: "Change Charges"
              }, 

              //THIRD TAB SHORT PAYMENT//             
              ShortPaymentTab: {
                isDisabled: false,
                isVisible: true
              },

              ShortPay_ShortAmtTextBox: {
                label:'Short Amount',
                ShortPay_ShortAmtTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              ShortPay_ExchgRateTextBox: {
                label:'Exchange Rate',
                ShortPay_ExchgRateTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              ShortPay_AmtLCYTextBox: {
                label:'Amount LCY',
                ShortPay_AmtLCYTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              ShortPay_TreasuryRateTextBox: {
                label:'Treasury Rate',
                ShortPay_TreasuryRateTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              ShortPay_TotTranAmtTextBox: {
                label:'Tot Tran Amount',
                ShortPay_TotTranAmtTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },


              //FOURTH TAB REMARKS// 
              RemarksTab: {
                isDisabled: false,
                isVisible: true
              },

              RemarksTextArea: {
                inputLength: '',
                tabIndex: '1',
                textColor: 'black',
                labelColor: 'black',
                labelFontWeight: 'none',
                mandatory: true,
                backgroundColor: 'white',
                autoFocusTextBox: false,
                textAlignment: 'left',
                minRows: 6,
                maxRows: 4,
                label:"",
                RemarksTextAreaValue: '',
                isDisabled: false,
                isVisible: true
              },
            

              //FIFTH TAB EFORM// 
              EFormTab: {
                isDisabled: false,
                isVisible: true
              },

              Eform_AdvpNoTextBox: {
                label:'ADVP No.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Eform_AdvpNoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              Eform_DateTextBox: {
                tabIndex: {},
                isDisabled: false,
                Eform_DateTextBoxValue: '0309202024',
                textColor: '',
                labelColor: '',
                mandatory: false,
                label: 'Date',
                labelFontWeight: '',
                inputFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: '',
                toolTipText: '',
                isToolTipDisabled: '',
                isVisible: true,
              },

              Eform_CurrencyTextBox: {
                label:'Currency',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Eform_CurrencyTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              Eform_PRCAmtTextBox: {
                label:'PRC Amount',
                Eform_PRCAmtTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              Eform_BalanceTextBox: {
                label:'Balance',
                Eform_BalanceTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              EFormTable: {
                isDisabled: false,
                isVisible: true,
                tableHeight: ref('10vw'),
                tableWidth: ref(100),
                tableData: [],
                tableColumns: [
                  {
                    prop: 'eform_no',
                    label: 'E-Form No',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'cert_date',
                    label: 'Cert. Date',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'prc_util_amt',
                    label: 'PRC Util Amt',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'balance',
                    label: 'Balance',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'short_amount',
                    label: 'Short Amount',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'short_amt_bal',
                    label: 'Short Amt Bal',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'gd_number',
                    label: 'GD Number',
                    align: 'left',
                    columnsWidth: 10
                  },
                ]
              },

              //SIXTH TAB ITEM INFO// 
              ItemInfoTab: {
                isDisabled: false,
                isVisible: true
              },

              ItemInfo_HsCodeTextBox: {
                label:'HS Code',
                tabIndex: 1,
                ItemInfo_HsCodeTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              HSCodeListBtn: {
                isVisible: true,
                isDisabled: false,
                label: "List"
              }, 

              ItemSumAmtSection:{
                isVisible: true
              },

              ItemSumAmtValue: {
                value: '2500.00'
              },

              ItemInfo_CommDescTextBox: {
                label:'Commodity Description',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                ItemInfo_CommDescTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              ItemInfo_COODropDown: {
                isDisabled: false,
                ItemInfo_COODropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Country of Origin",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              ItemInfo_UnitsDropDown: {
                isDisabled: false,
                ItemInfo_UnitsDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Units",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              ItemInfo_CurrencyDropDown: {
                isDisabled: false,
                ItemInfo_CurrencyDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Currency",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              ItemInfo_AmtFCYTextBox: {
                label:'Amount FCY',
                ItemInfo_AmtFCYTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              ItemInfo_QuantityTextBox: {
                label:'Quantity',
                ItemInfo_QuantityTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              ItemInfo_UnitPriceTextBox: {
                label:'Unit Price',
                ItemInfo_UnitPriceTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              ItemInfo_AddItemBtn: {
                isVisible: true,
                isDisabled: false,
                label: "Add Item"
              }, 

              ItemInfo_ChngItemBtn: {
                isVisible: true,
                isDisabled: false,
                label: "Change Item"
              }, 

              ItemInfo_RemoveItemBtn: {
                isVisible: true,
                isDisabled: false,
                label: "Remove Item"
              }, 

              ItemInfoTable: {
                isDisabled: false,
                isVisible: true,
                tableHeight: ref('10vw'),
                tableWidth: ref(100),
                tableData: [],
                tableColumns: [
                  {
                    prop: 'hs_code',
                    label: 'HS Code',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'ctry_of_origin',
                    label: 'Country Of Origin',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'goods_desc',
                    label: 'Goods Description',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'units',
                    label: 'Units',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'quantity',
                    label: 'Quantity',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'rate',
                    label: 'Rate',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'currency',
                    label: 'Currency',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'amt_lcy',
                    label: 'Amount LCY',
                    align: 'left',
                    columnsWidth: 10
                  },
                ]
              },

              //SEVENTH TAB ACCUITY INFO// 
              AccuityInfoTab: {
                isDisabled: false,
                isVisible: true
              },

              AI_Bank_BICCodeTextBox: {
                label:'Any Other Bank Name Or BIC Code:',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                AI_Bank_BICCodeTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },
              
              AI_Port_AirportDropDown: {
                isDisabled: false,
                AI_Port_AirportDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Port or Airport of Discharge:",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },
              
              AI_AgentNameTextBox: {
                label:'Name of Agent if any:',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                AI_AgentNameTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },
      
              AI_OtherPartyTextBox: {
                label:'Any Other Party Involved in Transaction:',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                AI_OtherPartyTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },
      
              AI_OtherPartyAddrTextBox: {
                label:'Address of Other Party Name of Country only:',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                AI_OtherPartyAddrTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },
      
              AI_Comment_DescTextBox: {
                label:'Any Comment or Description Max 70 words:',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                AI_Comment_DescTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              //EIGHTH TAB PSWI INFORMATION// 
              PSWInformationTab: {
                isDisabled: false,
                isVisible: true
              },

              PSW_FinInstNoTextBox: {
                label:'Financial Instrument Unique No.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                PSW_FinInstNoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },
              
              PSW_FinInstDate: {
                tabIndex: {},
                isDisabled: false,
                PSW_FinInstDateValue: '',
                textColor: '',
                labelColor: '',
                mandatory: false,
                label: 'Financial Instrument Date',
                labelFontWeight: '',
                inputFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: '',
                toolTipText: '',
                isToolTipDisabled: '',
                isVisible: true,
              },
              
              PSW_ModePayTextBox: {
                label:'Mode of Payment',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                PSW_ModePayTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },
              
              PSW_FinInstExpDate: {
                tabIndex: {},
                isDisabled: false,
                PSW_FinInstExpDateValue: '',
                textColor: '',
                labelColor: '',
                mandatory: false,
                label: 'Financial Instrument Expiry Date',
                labelFontWeight: '',
                inputFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: '',
                toolTipText: '',
                isToolTipDisabled: '',
                isVisible: true,
              },
              
              PSW_ConsigneeIBANTextBox: {
                label:'Consignee IBAN',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                PSW_ConsigneeIBANTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'blue',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              //NINTH TAB M-FORM// 
              MFormTab: {
                isDisabled: false,
                isVisible: true
              },

              MForm_NoTextBox: {
                label:'M-Form No',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                MForm_NoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'blue',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              MForm_PurposeCdDropDown: {
                isDisabled: false,
                MForm_PurposeCdDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Purpose Code",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              MForm_DeptCdDropDown: {
                isDisabled: false,
                MForm_DeptCdDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "Dept Code",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              MForm_ShortAmtTextBox: {
                label:'Short Amount (ITRS)',
                MForm_ShortAmtTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },

              MFormTable: {
                isDisabled: false,
                isVisible: true,
                tableHeight: ref('10vw'),
                tableWidth: ref(100),
                tableData: [],
                tableColumns: [
                  {
                    prop: 'hs_code',
                    label: 'HS Code',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'ctry_of_origin',
                    label: 'Country Of Origin',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'goods_desc',
                    label: 'Goods Description',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'units',
                    label: 'Units',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'quantity',
                    label: 'Quantity',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'rate',
                    label: 'Rate',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'currency',
                    label: 'Currency',
                    align: 'left',
                    columnsWidth: 10
                  },
                  {
                    prop: 'amt_lcy',
                    label: 'Amount LCY',
                    align: 'left',
                    columnsWidth: 10
                  },
                ]
              },

              MForm_AddItemBtn: {
                isVisible: true,
                isDisabled: false,
                label: "Add Item"
              }, 

              MForm_ChngItemBtn: {
                isVisible: true,
                isDisabled: false,
                label: "Change Item"
              }, 

              MForm_RemoveItemBtn: {
                isVisible: true,
                isDisabled: false,
                label: "Remove Item"
              }, 


              //TENTH TAB RETURN// 
              ReturnTab: {
                isDisabled: false,
                isVisible: true
              },

              Return_AdvBalTextBox: {
                label:'Advance Payment Balance',
                Return_AdvBalTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
              
              Return_AmtTextBox: {
                label:'Return Amount',
                Return_AmtTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
              
              Return_ExchRateTextBox: {
                label:'Exchange Rate',
                Return_ExchRateTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
              
              Return_PKRTextBox: {
                label:'Equivalent PKR Amount',
                Return_PKRTextBoxValue: '',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
              
              Return_SBPNoTextBox: {
                label:'SBP Approval No.',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Return_SBPNoTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'blue',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },
              
              Return_SBPDate: {
                tabIndex: {},
                isDisabled: false,
                Return_SBPDateValue: '',
                textColor: '',
                labelColor: '',
                mandatory: false,
                label: 'SBP Approval Date',
                labelFontWeight: '',
                inputFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: '',
                toolTipText: '',
                isToolTipDisabled: '',
                isVisible: true,
              },

              //ELEVENTH TAB TRANSFER// 
              TransferTab: {
                isDisabled: false,
                isVisible: true
              },

              Trf_FCPercentTextBox: {
                label:'FC %',
                Trf_FCPercentTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
      
              Trf_AmtTextBox: {
                label:'Transfer Amount',
                Trf_AmtTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
      
              Trf_Date: {
                tabIndex: {},
                isDisabled: false,
                Trf_DateValue: '',
                textColor: '',
                labelColor: '',
                mandatory: false,
                label: 'Transfer Date',
                labelFontWeight: '',
                inputFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: '',
                toolTipText: '',
                isToolTipDisabled: '',
                isVisible: true,
              },
      
              Trf_CustNoTextBox: {
                label:'Cust No.',
                tabIndex: '',
                isDisabled: false,
                Trf_CustNoTextBoxValue: '',
                textColor: '',
                labelColor: '',
                mandatory: '',
                backgroundColor: 'white',
                textAlignment: '',
                autoFocusTextBox: '',
                labelFontWeight: "",
                isVisible: true
              },
      
              Trf_ExchRateTextBox: {
                label:'Exch Rate',
                Trf_ExchRateTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
      
              Trf_FCAccountDropDown: {
                isDisabled: false,
                Trf_FCAccountDropDownList: [{ option: 'Swift-01', value: 'Swift-01' }],
                defaultValue: "",
                colorinput: "",
                colorLabel: "",
                dropDownLabel: "FC A/C",
                mandatory: true,
                isVisible: true,
                backgroundColor: "White",
                labelFontWeight: "normal", 
                inputFontWeight: "normal",
                listItemsLabelColor: "black",
              },

              Trf_LocalEqvTextBox: {
                label:'Local Eqv',
                Trf_LocalEqvTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
      
              Trf_PRCBalTextBox: {
                label:'PRC Available Balance',
                Trf_PRCBalTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
      
              Trf_LowerAmtTextBox: {
                label:'Transfer Amount ',
                Trf_LowerAmtTextBoxValue:'',
                tabIndex: {},
                isDisabled: false,
                textColor: '',
                labelColor: {},
                mandatory: {},
                labelFontWeight: '',
                backgroundColor: 'white',
                autoFocusTextBox: {},
                inputLength: 5,
                decimalPlaces: 2,
                default0Flag: false,
                isVisible: true,
              },
      
              Trf_BankNameTextBox: {
                label:'Other Bank Name',
                dataType:'alphaNumericSpecial',
                inputLength: 15,
                inputMinLength: 20,
                tabIndex: 1,
                Trf_BankNameTextBoxValue:'',
                isDisabled: false,
                textColor: '',
                labelColor: 'black',
                labelFontWeight: '',
                inputFontWeight: '',
                mandatory: true,
                isVisible: true,
                backgroundColor:'white',
                autoFocusTextBox: true,
                textAlignment: 0,
              },

              section8: {
                isVisible: true,
              },

              section9: {
                isVisible: true,
              },

              // BUTTONS SECTION

              Ok_button: {
                isVisible: true,
                isDisabled: false,
                label: "OK"
              }, 

              Change_button: {
                isVisible: true,
                isDisabled: false,
                label: "Change"
              }, 

              Cancel_button: {
                isVisible: true,
                isDisabled: false,
                label: "Cancel"
              }, 
      
              ReInitiate_button: {
                isVisible: true,
                isDisabled: false,
                label: "Re-Initiate"
              }, 
      
              Reject_button: {
                isVisible: true,
                isDisabled: false,
                label: "Reject"
              }, 
      
              Return_button: {
                isVisible: true,
                isDisabled: false,
                label: "Return"
              }, 
      
              Modify_button: {
                isVisible: true,
                isDisabled: false,
                label: "Modify"
              }, 
      
              Exception_button: {
                isVisible: true,
                isDisabled: false,
                label: "Exception"
              }, 
      
              FXDetail_button: {
                isVisible: true,
                isDisabled: false,
                label: "FX Detail"
              }, 
      
              ViewDocs_button: {
                isVisible: true,
                isDisabled: false,
                label: "View Docs."
              }, 
      
              ViewVouch_button: {
                isVisible: true,
                isDisabled: false,
                label: "View Voucher"
              }, 
      
              Back_button: {
                isVisible: true,
                isDisabled: false,
                label: "Back"
              }, 
      
              Exit_button: {
                isVisible: true,
                isDisabled: false,
                label: "Exit"
              }, 

            },

      },
    });
  }
};
</script>