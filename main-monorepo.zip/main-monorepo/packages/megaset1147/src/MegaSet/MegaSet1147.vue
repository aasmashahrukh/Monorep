<template>
<Form as="el-form" @submit="onSubmit">

<el-row v-if=" configObject.section1 != undefined ? configObject.section1.isVisible : false">
  <el-col :lg="23" :md="23">
    <el-row>
        <el-col :lg="4" :md="4">
            <legend 
                    v-if="configObject.FIInfoSection != undefined ? configObject.FIInfoSection.isVisible : false">
                F.I No : &nbsp;&nbsp; {{ configObject.FIInfoValue.value }}
            </legend>
        </el-col>
        <el-col :lg="4" :md="4"></el-col>
        <el-col :lg="9" :md="9">
            <legend class="mainHeading" 
                    v-if="configObject.BrnNameSection != undefined ? configObject.BrnNameSection.isVisible : false">
                {{ configObject.BranchNameCode.value }}
            </legend>
        </el-col>
        <el-col :lg="7" :md="7">
            <legend class="mainHeading" 
                    v-if="configObject.ADVPNumberSection != undefined ? configObject.ADVPNumberSection.isVisible : false">
                ADVP No : &nbsp;&nbsp; {{ configObject.ADVPNumber.value }}
            </legend>
        </el-col>
    </el-row>
  </el-col>
  <el-col :lg="1" :md="1"></el-col>
</el-row>

<br>

<el-row v-if=" configObject.section2 != undefined ? configObject.section2.isVisible : false">
  <el-col :lg="23" :md="23">
    <el-row>
        <el-col :lg="8" :md="8">
            <legend class="mainHeading">Customer Information</legend>
        </el-col>
        <el-col :lg="6" :md="6">
            <el-form-item 
                    v-if="configObject.tradeProfileStatusSection != undefined ? configObject.tradeProfileStatusSection.isVisible : false">
                Profile Status: &nbsp;&nbsp;
                <span :class="configObject.tradeProfileStatusColor.color"  >
                    {{ configObject.tradeProfileStatusValue.value }}
                </span>
            </el-form-item>
        </el-col>
        <el-col :lg="3" :md="3"></el-col>
        <el-col :lg="7" :md="7">
            <el-form-item 
                    v-if="configObject.PaymentModeSection != undefined ? configObject.PaymentModeSection.isVisible : false" >
                Mode of Payment: &nbsp;&nbsp;
                <span :class="configObject.PaymentModeColor.color">
                    {{ configObject.PaymentModeValue.value }}
                </span>
            </el-form-item>
        </el-col>
    </el-row>
  </el-col>
  <el-col :lg="1" :md="1"></el-col>
</el-row>

<el-row v-if="configObject.section3 != undefined ? configObject.section3.isVisible : false">
  <el-col :lg="23" :md="23">
    <fieldset>
        <el-row>
            <el-col :lg="10" :md="10">
                <AccountNumber
                    @AccountNumberNumericDashes21-onChange="(val) => { $emit('AccountNumber-onChange', val); }"
                    @AccountNumberNumericDashes21-onFocus="(val) => { $emit('AccountNumber-onFocus', val); }"
                    @AccountNumberNumericDashes21-onBlur="(val) => { $emit('AccountNumber-onBlur', val); }"
                    @AccountNumberNumericDashes21-onKeyUp="(val) => { $emit('AccountNumber-onKeyUp', val); }"
                    @AccountNumberNumericDashes21-onKeyPress="(val) => { $emit('AccountNumber-onKeyPress', val); }"
                    v-bind="{ ...AccountNumber, ...configObject.AccountNumber }"
                    :values="configObject.AccountNumber.AccountNumberValue"
                    name="AccountNumber" ref="RefAccountNumber"
                    v-if="configObject.AccountNumber != undefined ? configObject.AccountNumber.isVisible : false"
                />
            </el-col>
            <el-col :lg="3" :md="3"></el-col>
            <el-col :lg="10" :md="10">
                <NTNNumber
                    @NtnNumericDashes9-onChange="(val) => { $emit('NTNNumber-onChange', val); }"
                    @NtnNumericDashes9-onFocus="(val) => { $emit('NTNNumber-onFocus', val); }"
                    @NtnNumericDashes9-onBlur="(val) => { $emit('NTNNumber-onBlur', val); }"
                    @NtnNumericDashes9-onKeyUp="(val) => { $emit('NTNNumber-onKeyUp', val); }"
                    @NtnNumericDashes9-onKeyPress="(val) => { $emit('NTNNumber-onKeyPress', val); }"
                    v-bind="{ ...NTNNumber, ...configObject.NTNNumber }"
                    :values="configObject.NTNNumber.NTNNumberValue"
                    name="NTNNumber" ref="RefNTNNumber"
                    v-if="configObject.NTNNumber != undefined ? configObject.NTNNumber.isVisible : false"
                />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
        </el-row>
        <el-row>
            <el-col :lg="10" :md="10">
                <AccTitleTextBox
                    @GenericTextBox-onBlur="(val) => { $emit('AccTitleTextBox-onBlur', val); }"
                    @GenericTextBox-onChange="(val) => { $emit('AccTitleTextBox-onChange', val); }"
                    @GenericTextBox-onFocus="(val) => { $emit('AccTitleTextBox-onFocus', val); }"
                    @GenericTextBox-onKeyPress="(val, event) => { $emit('AccTitleTextBox-onKeyPress', val, event); }"
                    @GenericTextBox-onKeyUp="(val, event) => { $emit('AccTitleTextBox-onKeyUp', val, event); }"
                    @GenericTextBox-onKeyDown="(val, event) => { $emit('AccTitleTextBox-onKeyDown', val, event); }"
                    @GenericTextBox-onInput="(val, event) => { $emit('AccTitleTextBox-onInput', val, event); }"
                    @GenericTextBox-onPaste="(event) => { $emit('AccTitleTextBox-onPaste', event); }"
                    v-bind="{ ...AccTitleTextBox, ...configObject.AccTitleTextBox }"
                    :values="configObject.AccTitleTextBox.AccTitleTextBoxValue"
                    name="AccTitleTextBox" ref="RefAccTitleTextBox"
                    v-if="configObject.AccTitleTextBox != undefined ? configObject.AccTitleTextBox.isVisible : false"
                />
            </el-col>
            <el-col :lg="3" :md="3"></el-col>
            <el-col :lg="10" :md="10">
                <CCINoTextBox
                    @GenericTextBox-onBlur="(val) => { $emit('CCINoTextBox-onBlur', val); }"
                    @GenericTextBox-onChange="(val) => { $emit('CCINoTextBox-onChange', val); }"
                    @GenericTextBox-onFocus="(val) => { $emit('CCINoTextBox-onFocus', val); }"
                    @GenericTextBox-onKeyPress="(val, event) => { $emit('CCINoTextBox-onKeyPress', val, event); }"
                    @GenericTextBox-onKeyUp="(val, event) => { $emit(' CCINoTextBox-onKeyUp', val, event); }"
                    @GenericTextBox-onKeyDown="(val, event) => { $emit('CCINoTextBox-onKeyDown', val, event); }"
                    @GenericTextBox-onInput="(val, event) => { $emit('CCINoTextBox-onInput', val, event); }"
                    @GenericTextBox-onPaste="(event) => { $emit('CCINoTextBox-onPaste', event); }"
                    v-bind="{ ...CCINoTextBox, ...configObject.CCINoTextBox }"
                    :values="configObject.CCINoTextBox.CCINoTextBoxValue"
                    name="CCINoTextBox" ref="RefCCINoTextBox"
                    v-if="configObject.CCINoTextBox != undefined ? configObject.CCINoTextBox.isVisible : false"
                />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
        </el-row>
    </fieldset>
  </el-col>
<el-col :lg="1" :md="1"></el-col>
</el-row>

<el-row v-if="configObject.section4 != undefined ? configObject.section4.isVisible : false">
  <el-col :lg="23" :md="23">
    <el-row>
        <el-col :lg="2" :md="2">
            <BankRadioBtn
                @GenericRadioButton-onChange="(val) => { $emit('BankRadioBtn-onChange', val); }"
                @GenericRadioButton-onFocus="(val) => { $emit('BankRadioBtn-onFocus', val); }"
                @GenericRadioButton-onBlur="(val) => { $emit('BankRadioBtn-onBlur', val); }"
                @GenericRadioButton-onClick="(val) => { $emit('BankRadioBtn-onClick', val); }"
                v-bind="{ ...BankRadioBtn, ...configObject.BankRadioBtn }"
                :values="configObject.BankRadioBtn.BankRadioBtnValue"
                name="BankRadioBtn"
                ref="RefBankRadioBtn"
                :radioGroup="configObject.BankRadioBtn.radioGroup"
                v-if="configObject.BankRadioBtn != undefined ? configObject.BankRadioBtn.isVisible : false"
            />
        </el-col>
        <el-col :lg="4" :md="4"></el-col>
        <el-col :lg="4" :md="4">
            <PSWWebocRadioBtn
                @GenericRadioButton-onChange="(val) => { $emit('PSWWebocRadioBtn-onChange', val); }"
                @GenericRadioButton-onFocus="(val) => { $emit('PSWWebocRadioBtn-onFocus', val); }"
                @GenericRadioButton-onBlur="(val) => { $emit('PSWWebocRadioBtn-onBlur', val); }"
                @GenericRadioButton-onClick="(val) => { $emit('PSWWebocRadioBtn-onClick', val); }"
                v-bind="{ ...PSWWebocRadioBtn, ...configObject.PSWWebocRadioBtn }"
                :values="configObject.PSWWebocRadioBtn.PSWWebocRadioBtnValue"
                name="PSWWebocRadioBtn"
                ref="RefPSWWebocRadioBtn"
                :radioGroup="configObject.PSWWebocRadioBtn.radioGroup"
                v-if="configObject.PSWWebocRadioBtn != undefined ? configObject.PSWWebocRadioBtn.isVisible : false"
            />
        </el-col>
        <el-col :lg="4" :md="4"></el-col>
        <el-col :lg="8" :md="8">
            <el-form-item
                class="font-bold"
                v-if="configObject.ADVPUinNumberSection != undefined ? configObject.ADVPUinNumberSection.isVisible : false"
            >
                ADVP UIN No: &nbsp;&nbsp; {{ configObject.ADVPUinNumberValue.value }}
            </el-form-item>
        </el-col>
        <el-col :lg="2" :md="2"></el-col>
    </el-row>
  </el-col>
  <el-col :lg="1" :md="1"></el-col>
</el-row>

<el-row v-if="configObject.section5 != undefined ? configObject.section5.isVisible : false">
  <el-col :lg="23" :md="23">
    <fieldset>
        <el-row>
            <el-col :lg="14" :md="14">
                <RedForFERadioBtn
                    @GenericRadioButton-onChange="(val) => { $emit('RedForFERadioBtn-onChange', val); }"
                    @GenericRadioButton-onFocus="(val) => { $emit('RedForFERadioBtn-onFocus', val); }"
                    @GenericRadioButton-onBlur="(val) => { $emit('RedForFERadioBtn-onBlur', val); }"
                    @GenericRadioButton-onClick="(val) => { $emit('RedForFERadioBtn-onClick', val); }"
                    v-bind="{ ...RedForFERadioBtn, ...configObject.RedForFERadioBtn }"
                    :values="configObject.RedForFERadioBtn.RedForFERadioBtnValue"
                    name="RedForFERadioBtn"
                    ref="RefRedForFERadioBtn"
                    :radioGroup="configObject.RedForFERadioBtn.radioGroup"
                    v-if="configObject.RedForFERadioBtn != undefined ? configObject.RedForFERadioBtn.isVisible : false"
                />
            </el-col>
            <el-col :lg="8" :md="8">
                <el-form-item
                    v-if="configObject.EDSRefNumber != undefined ? configObject.EDSRefNumber.isVisible : false"
                >
                    EDS Unique Ref No: &nbsp;&nbsp; {{ configObject.EDSRefNumberValue.value }}
                </el-form-item>
            </el-col>
            <el-col :lg="2" :md="2"></el-col>
        </el-row>
        <el-row>
            <el-col :lg="10" :md="10">
                <FwdRefNoTextBox
                    @GenericTextBox-onBlur="(val) => { $emit('FwdRefNoTextBox-onBlur', val); }"
                    @GenericTextBox-onChange="(val) => { $emit('FwdRefNoTextBox-onChange', val); }"
                    @GenericTextBox-onFocus="(val) => { $emit('FwdRefNoTextBox-onFocus', val); }"
                    @GenericTextBox-onKeyPress="(val, event) => { $emit('FwdRefNoTextBox-onKeyPress', val, event); }"
                    @GenericTextBox-onKeyUp="(val, event) => { $emit('FwdRefNoTextBox-onKeyUp', val, event); }"
                    @GenericTextBox-onKeyDown="(val, event) => { $emit('FwdRefNoTextBox-onKeyDown', val, event); }"
                    @GenericTextBox-onInput="(val, event) => { $emit('FwdRefNoTextBox-onInput', val, event); }"
                    @GenericTextBox-onPaste="(event) => { $emit('FwdRefNoTextBox-onPaste', event); }"
                    v-bind="{ ...FwdRefNoTextBox, ...configObject.FwdRefNoTextBox }"
                    :values="configObject.FwdRefNoTextBox.FwdRefNoTextBoxValue"
                    name="FwdRefNoTextBox"
                    ref="RefFwdRefNoTextBox"
                    v-if="configObject.FwdRefNoTextBox != undefined ? configObject.FwdRefNoTextBox.isVisible : false"
                />
            </el-col>
            <el-col :lg="4" :md="4"></el-col>
            <el-col :lg="10" :md="10">
                <SettlementMethodDropDown
                    @GenericDropDown-onChange="(val) => { $emit('SettlementMethodDropDown-onChange', val); }"
                    @GenericDropDown-onFocus="(val) => { $emit('SettlementMethodDropDown-onFocus', val); }"
                    @GenericDropDown-onBlur="(val) => { $emit('SettlementMethodDropDown-onBlur', val); }"
                    v-bind="{ ...SettlementMethodDropDown, ...configObject.SettlementMethodDropDown }"
                    :values="configObject.SettlementMethodDropDown.SettlementMethodDropDownList"
                    name="SettlementMethodDropDown"
                    ref="RefSettlementMethodDropDown"
                    v-if="configObject.SettlementMethodDropDown != undefined ? configObject.SettlementMethodDropDown.isVisible : false"
                />
            </el-col>
        </el-row>
    </fieldset>
  </el-col>
  <el-col :lg="1" :md="1"></el-col>
</el-row>

<br>


<!-- TABS SECTION -->

<el-row>
    <el-col :lg="23" :md="23">
      <el-tabs
        v-model="configObject.TabPane.activeName"
        v-if="configObject.TabPaneView != undefined ? configObject.TabPaneView.isVisible : false"
        class="demo-tabs"
        type="card"
        @tab-click="(value) => { $emit('tab-click', value.paneName); }"
      >

    <!-- FIRST TAB----ADVANCE -->
      <el-tab-pane
        :disabled="configObject.AdvanceTab.isDisabled"
        v-if="configObject.AdvanceTab != undefined ? configObject.AdvanceTab.isVisible : false"
        label="Advance"
        name="AdvanceTab"
        ref="RefAdvanceTab"
      >

      <el-row>
        <el-col :lg="24" :md="24">
          <el-row>
            <el-col :lg="12" :md="12">
              <fieldset v-if="configObject.section6 != undefined ? configObject.section6.isVisible : false">
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_CurrencyDropDown
                      @GenericDropDown-onChange="(val) => { $emit('Advance_CurrencyDropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('Advance_CurrencyDropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('Advance_CurrencyDropDown-onBlur', val); }"
                      v-bind="{ ...Advance_CrrencyDropDown, ...configObject.Advance_CurrencyDropDown }"
                      :values="configObject.Advance_CurrencyDropDown.Advance_CurrencyDropDownList"
                      name="Advance_CurrencyDropDown"
                      ref="RefAdvance_CurrencyDropDown"
                      v-if="configObject.Advance_CurrencyDropDown != undefined ? configObject.Advance_CurrencyDropDown.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="16" :md="16">
                    <Advance_TotalAmtTextBox
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Advance_TotalAmtTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Advance_TotalAmtTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Advance_TotalAmtTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Advance_TotalAmtTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Advance_TotalAmtTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Advance_TotalAmtTextBox, ...configObject.Advance_TotalAmtTextBox }"
                      :values="configObject.Advance_TotalAmtTextBox.Advance_TotalAmtTextBoxValue"
                      name="Advance_TotalAmtTextBox"
                      ref="RefAdvance_TotalAmtTextBox"
                      v-if="configObject.Advance_TotalAmtTextBox != undefined ? configObject.Advance_TotalAmtTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="8" :md="8">
                    <legend class="font-size">&nbsp;&nbsp;Excluding Short Amt. <br> &nbsp;&nbsp;If any</legend>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_NostroAmtTextBox
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Advance_NostroAmtTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Advance_NostroAmtTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Advance_NostroAmtTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Advance_NostroAmtTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Advance_NostroAmtTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Advance_NostroAmtTextBox, ...configObject.Advance_NostroAmtTextBox }"
                      :values="configObject.Advance_NostroAmtTextBox.Advance_NostroAmtTextBoxValue"
                      name="Advance_NostroAmtTextBox"
                      ref="RefAdvance_NostroAmtTextBox"
                      v-if="configObject.Advance_NostroAmtTextBox != undefined ? configObject.Advance_NostroAmtTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_ExchangeRateTextBox
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Advance_ExchangeRateTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Advance_ExchangeRateTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Advance_ExchangeRateTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Advance_ExchangeRateTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Advance_ExchangeRateTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Advance_ExchangeRateTextBox, ...configObject.Advance_ExchangeRateTextBox }"
                      :values="configObject.Advance_ExchangeRateTextBox.Advance_ExchangeRateTextBoxValue"
                      name="Advance_ExchangeRateTextBox"
                      ref="RefAdvance_ExchangeRateTextBox"
                      v-if="configObject.Advance_ExchangeRateTextBox !== undefined ? configObject.Advance_ExchangeRateTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_AmtLCYTextBox
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Advance_AmtLCYTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Advance_AmtLCYTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Advance_AmtLCYTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Advance_AmtLCYTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Advance_AmtLCYTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Advance_AmtLCYTextBox, ...configObject.Advance_AmtLCYTextBox }"
                      :values="configObject.Advance_AmtLCYTextBox.Advance_AmtLCYTextBoxValue"
                      name="Advance_AmtLCYTextBox"
                      ref="RefAdvance_AmtLCYTextBox"
                      v-if="configObject.Advance_AmtLCYTextBox !== undefined ? configObject.Advance_AmtLCYTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_TreasuryRateTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Advance_TreasuryRateTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Advance_TreasuryRateTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Advance_TreasuryRateTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Advance_TreasuryRateTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Advance_TreasuryRateTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Advance_TreasuryRateTextBox, ...configObject.Advance_TreasuryRateTextBox }"
                      :values="configObject.Advance_TreasuryRateTextBox.Advance_TreasuryRateTextBoxValue"
                      name="Advance_TreasuryRateTextBox"
                      ref="RefAdvance_TreasuryRateTextBox"
                      v-if="configObject.Advance_TreasuryRateTextBox !== undefined ? configObject.Advance_TreasuryRateTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_FOBValTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Advance_FOBValTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Advance_FOBValTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Advance_FOBValTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Advance_FOBValTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Advance_FOBValTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Advance_FOBValTextBox, ...configObject.Advance_FOBValTextBox }"
                      :values="configObject.Advance_FOBValTextBox.Advance_FOBValTextBoxValue"
                      name="Advance_FOBValTextBox"
                      ref="RefAdvance_FOBValTextBox"
                      v-if="configObject.Advance_FOBValTextBox !== undefined ? configObject.Advance_FOBValTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="18" :md="18">
                    <Advance_NostroBankTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_NostroBankTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_NostroBankTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_NostroBankTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_NostroBankTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_NostroBankTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_NostroBankTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_NostroBankTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_NostroBankTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_NostroBankTextBox, ...configObject.Advance_NostroBankTextBox }"
                      :values="configObject.Advance_NostroBankTextBox.Advance_NostroBankTextBoxValue"
                      name="Advance_NostroBankTextBox"
                      ref="RefAdvance_NostroBankTextBox"
                      v-if="configObject.Advance_NostroBankTextBox !== undefined ? configObject.Advance_NostroBankTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="4" :md="4">
                    <NostroListButton 
                      @GenericButton-onClick="$emit('NostroListButton-onClick')"
                      v-bind="{ ...NostroListButton, ...configObject.NostroListButton }"
                      name="NostroListButton"
                      ref="RefNostroListButton"
                      v-if="configObject.NostroListButton !== undefined ? configObject.NostroListButton.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="18" :md="18">
                    <Advance_AdviceNoTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Advance_AdviceNoTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Advance_AdviceNoTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Advance_AdviceNoTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Advance_AdviceNoTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Advance_AdviceNoTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Advance_AdviceNoTextBox, ...configObject.Advance_AdviceNoTextBox }"
                      :values="configObject.Advance_AdviceNoTextBox.Advance_AdviceNoTextBoxValue"
                      name="Advance_AdviceNoTextBox"
                      ref="RefAdvance_AdviceNoTextBox"
                      v-if="configObject.Advance_AdviceNoTextBox !== undefined ? configObject.Advance_AdviceNoTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="6" :md="6"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_CommFCYTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_CommFCYTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_CommFCYTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_CommFCYTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_CommFCYTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_CommFCYTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_CommFCYTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_CommFCYTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_CommFCYTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_CommFCYTextBox, ...configObject.Advance_CommFCYTextBox }"
                      :values="configObject.Advance_CommFCYTextBox.Advance_CommFCYTextBoxValue"
                      name="Advance_CommFCYTextBox"
                      ref="RefAdvance_CommFCYTextBox"
                      v-if="configObject.Advance_CommFCYTextBox !== undefined ? configObject.Advance_CommFCYTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_IdentifyTypeDropDown
                      @GenericDropDown-onChange="(val) => { $emit('Advance_IdentifyTypeDropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('Advance_IdentifyTypeDropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('Advance_IdentifyTypeDropDown-onBlur', val); }"
                      v-bind="{ ...Advance_IdentifyTypeDropDown, ...configObject.Advance_IdentifyTypeDropDown }"
                      :values="configObject.Advance_IdentifyTypeDropDown.Advance_IdentifyTypeDropDownList"
                      name="Advance_IdentifyTypeDropDown"
                      ref="RefAdvance_IdentifyTypeDropDown"
                      v-if="configObject.Advance_IdentifyTypeDropDown !== undefined ? configObject.Advance_IdentifyTypeDropDown.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_IdentifyNoTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_IdentifyNoTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_IdentifyNoTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_IdentifyNoTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_IdentifyNoTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_IdentifyNoTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_IdentifyNoTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_IdentifyNoTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_IdentifyNoTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_IdentifyNoTextBox, ...configObject.Advance_IdentifyNoTextBox }"
                      :values="configObject.Advance_IdentifyNoTextBox.Advance_IdentifyNoTextBoxValue"
                      name="Advance_IdentifyNoTextBox"
                      ref="RefAdvance_IdentifyNoTextBox"
                      v-if="configObject.Advance_IdentifyNoTextBox !== undefined ? configObject.Advance_IdentifyNoTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_RemmitInstTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_RemmitInstTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_RemmitInstTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_RemmitInstTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_RemmitInstTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_RemmitInstTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_RemmitInstTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_RemmitInstTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_RemmitInstTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_RemmitInstTextBox, ...configObject.Advance_RemmitInstTextBox }"
                      :values="configObject.Advance_RemmitInstTextBox.Advance_RemmitInstTextBoxValue"
                      name="Advance_RemmitInstTextBox"
                      ref="RefAdvance_RemmitInstTextBox"
                      v-if="configObject.Advance_RemmitInstTextBox !== undefined ? configObject.Advance_RemmitInstTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_IBAN_ACNoTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_IBAN_ACNoTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_IBAN_ACNoTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_IBAN_ACNoTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_IBAN_ACNoTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_IBAN_ACNoTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_IBAN_ACNoTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_IBAN_ACNoTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_IBAN_ACNoTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_IBAN_ACNoTextBox, ...configObject.Advance_IBAN_ACNoTextBox }"
                      :values="configObject.Advance_IBAN_ACNoTextBox.Advance_IBAN_ACNoTextBoxValue"
                      name="Advance_IBAN_ACNoTextBox"
                      ref="RefAdvance_IBAN_ACNoTextBox"
                      v-if="configObject.Advance_IBAN_ACNoTextBox !== undefined ? configObject.Advance_IBAN_ACNoTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_SBPApprovalNoTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_SBPApprovalNoTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_SBPApprovalNoTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_SBPApprovalNoTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_SBPApprovalNoTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_SBPApprovalNoTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_SBPApprovalNoTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_SBPApprovalNoTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_SBPApprovalNoTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_SBPApprovalNoTextBox, ...configObject.Advance_SBPApprovalNoTextBox }"
                      :values="configObject.Advance_SBPApprovalNoTextBox.Advance_SBPApprovalNoTextBoxValue"
                      name="Advance_SBPApprovalNoTextBox"
                      ref="RefAdvance_SBPApprovalNoTextBox"
                      v-if="configObject.Advance_SBPApprovalNoTextBox !== undefined ? configObject.Advance_SBPApprovalNoTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="24" :md="24">
                    <Advance_SBPApprovalDateTextBox
                      @DateDdMmYyyy-onBlur="(val) => { $emit('Advance_SBPApprovalDateTextBox-onBlur', val); }"
                      @DateDdMmYyyy-onChange="(val) => { $emit('Advance_SBPApprovalDateTextBox-onChange', val); }"
                      @DateDdMmYyyy-onFocus="(val) => { $emit('Advance_SBPApprovalDateTextBox-onFocus', val); }"
                      @DateDdMmYyyy-onKeyPress="(val, event) => { $emit('Advance_SBPApprovalDateTextBox-onKeyPress', val, event); }"
                      @DateDdMmYyyy-onKeyUp="(val, event) => { $emit('Advance_SBPApprovalDateTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Advance_SBPApprovalDateTextBox, ...configObject.Advance_SBPApprovalDateTextBox }"
                      :values="configObject.Advance_SBPApprovalDateTextBox.Advance_SBPApprovalDateTextBoxValue"
                      name="Advance_SBPApprovalDateTextBox"
                      ref="RefAdvance_SBPApprovalDateTextBox"
                      v-if="configObject.Advance_SBPApprovalDateTextBox !== undefined ? configObject.Advance_SBPApprovalDateTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
              </fieldset>
            </el-col>

            <el-col :lg="12" :md="12">
              <fieldset v-if="configObject.section7 != undefined ? configObject.section7.isVisible : false">
                <el-row>
                  <el-col :lg="16" :md="16">
                    <Advance_BuyerTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_BuyerTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_BuyerTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_BuyerTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_BuyerTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_BuyerTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_BuyerTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_BuyerTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_BuyerTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_BuyerTextBox, ...configObject.Advance_BuyerTextBox }"
                      :values="configObject.Advance_BuyerTextBox.Advance_BuyerTextBoxValue"
                      name="Advance_BuyerTextBox"
                      ref="RefAdvance_BuyerTextBox"
                      v-if="configObject.Advance_BuyerTextBox !== undefined ? configObject.Advance_BuyerTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="4" :md="4">
                    <BuyerListButton
                      @GenericButton-onClick=" $emit('BuyerListButton-onClick')"
                      v-bind="{ ...BuyerListButton, ...configObject.BuyerListButton }"
                      name="BuyerListButton"
                      ref="RefBuyerListButton"
                      v-if="configObject.BuyerListButton !== undefined ? configObject.BuyerListButton.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <br><br><br>
                <el-row>
                  <el-col :lg="16" :md="16">
                    <Advance_CountryReceiptTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_CountryReceiptTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_CountryReceiptTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_CountryReceiptTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_CountryReceiptTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_CountryReceiptTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_CountryReceiptTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_CountryReceiptTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_CountryReceiptTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_CountryReceiptTextBox, ...configObject.Advance_CountryReceiptTextBox }"
                      :values="configObject.Advance_CountryReceiptTextBox.Advance_CountryReceiptTextBoxValue"
                      name="Advance_CountryReceiptTextBox"
                      ref="RefAdvance_CountryReceiptTextBox"
                      v-if="configObject.Advance_CountryReceiptTextBox !== undefined ? configObject.Advance_CountryReceiptTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="4" :md="4">
                    <CountryReceiptListButton
                      @GenericButton-onClick=" $emit('CountryReceiptListButton-onClick')"
                      v-bind="{ ...CountryReceiptListButton, ...configObject.CountryReceiptListButton }"
                      name="CountryReceiptListButton"
                      ref="RefCountryReceiptListButton"
                      v-if="configObject.CountryReceiptListButton !== undefined ? configObject.CountryReceiptListButton.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="16" :md="16">
                    <Advance_CountryTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_CountryTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_CountryTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_CountryTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_CountryTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_CountryTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_CountryTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_CountryTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_CountryTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_CountryTextBox, ...configObject.Advance_CountryTextBox }"
                      :values="configObject.Advance_CountryTextBox.Advance_CountryTextBoxValue"
                      name="Advance_CountryTextBox"
                      ref="RefAdvance_CountryTextBox"
                      v-if="configObject.Advance_CountryTextBox !== undefined ? configObject.Advance_CountryTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="4" :md="4">
                    <CountryListButton
                      @GenericButton-onClick=" $emit('CountryListButton-onClick')"
                      v-bind="{ ...CountryListButton, ...configObject.CountryListButton }"
                      name="CountryListButton"
                      ref="RefCountryListButton"
                      v-if="configObject.CountryListButton !== undefined ? configObject.CountryListButton.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="22" :md="22">
                    <Advance_CityDropDown
                      @GenericDropDown-onChange="(val) => { $emit('Advance_CityDropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('Advance_CityDropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('Advance_CityDropDown-onBlur', val); }"
                      v-bind="{ ...Advance_CityDropDown, ...configObject.Advance_CityDropDown }"
                      :values="configObject.Advance_CityDropDown.Advance_CityDropDownList"
                      name="Advance_CityDropDown"
                      ref="RefAdvance_CityDropDown"
                      v-if="configObject.Advance_CityDropDown !== undefined ? configObject.Advance_CityDropDown.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="16" :md="16">
                    <Advance_ReimbBankTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_ReimbBankTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_ReimbBankTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_ReimbBankTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_ReimbBankTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_ReimbBankTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_ReimbBankTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_ReimbBankTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_ReimbBankTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_ReimbBankTextBox, ...configObject.Advance_ReimbBankTextBox }"
                      :values="configObject.Advance_ReimbBankTextBox.Advance_ReimbBankTextBoxValue"
                      name="Advance_ReimbBankTextBox"
                      ref="RefAdvance_ReimbBankTextBox"
                      v-if="configObject.Advance_ReimbBankTextBox !== undefined ? configObject.Advance_ReimbBankTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="4" :md="4">
                    <ReimbBankListButton
                      @GenericButton-onClick=" $emit('ReimbBankListButton-onClick')"
                      v-bind="{ ...ReimbBankListButton, ...configObject.ReimbBankListButton }"
                      name="ReimbBankListButton"
                      ref="RefReimbBankListButton"
                      v-if="configObject.ReimbBankListButton !== undefined ? configObject.ReimbBankListButton.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="22" :md="22">
                    <Advance_DestinationDropDown
                      @GenericDropDown-onChange="(val) => { $emit('Advance_DestinationDropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('Advance_DestinationDropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('Advance_DestinationDropDown-onBlur', val); }"
                      v-bind="{ ...Advance_DestinationDropDown, ...configObject.Advance_DestinationDropDown }"
                      :values="configObject.Advance_DestinationDropDown.Advance_DestinationDropDownList"
                      name="Advance_DestinationDropDown" ref="RefAdvance_DestinationDropDown"
                      v-if="configObject.Advance_DestinationDropDown !== undefined ? configObject.Advance_DestinationDropDown.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="22" :md="22">
                    <Advance_IncoTermsDropDown
                      @GenericDropDown-onChange="(val) => { $emit('Advance_IncoTermsDropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('Advance_IncoTermsDropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('Advance_IncoTermsDropDown-onBlur', val); }"
                      v-bind="{ ...Advance_IncoTermsDropDown, ...configObject.Advance_IncoTermsDropDown }"
                      :values="configObject.Advance_IncoTermsDropDown.Advance_IncoTermsDropDownList"
                      name="Advance_IncoTermsDropDown"
                      ref="RefAdvance_IncoTermsDropDown"
                      v-if="configObject.Advance_IncoTermsDropDown !== undefined ? configObject.Advance_IncoTermsDropDown.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                </el-row>
                <br><br>
                <el-row>
                  <el-col :lg="22" :md="22">
                    <Advance_SwftRefNoTextBox
                      @GenericTextBox-onBlur="(val) => { $emit('Advance_SwftRefNoTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('Advance_SwftRefNoTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Advance_SwftRefNoTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Advance_SwftRefNoTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Advance_SwftRefNoTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Advance_SwftRefNoTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Advance_SwftRefNoTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Advance_SwftRefNoTextBox-onPaste', event); }"
                      v-bind="{ ...Advance_SwftRefNoTextBox, ...configObject.Advance_SwftRefNoTextBox }"
                      :values="configObject.Advance_SwftRefNoTextBox.Advance_SwftRefNoTextBoxValue"
                      name="Advance_SwftRefNoTextBox"
                      ref="RefAdvance_SwftRefNoTextBox"
                      v-if="configObject.Advance_SwftRefNoTextBox !== undefined ? configObject.Advance_SwftRefNoTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                </el-row>
              </fieldset>
            </el-col>
          </el-row>
        </el-col>
      </el-row>

      </el-tab-pane>

    <!-- SECOND TAB----CHARGES -->
      <el-tab-pane
        :disabled="configObject.ChargesTab.isDisabled"
        v-if="configObject.ChargesTab != undefined ? configObject.ChargesTab.isVisible : false"
        label="Charges"
        name="ChargesTab"
        ref="RefChargesTab"
      >

      <el-row>
        <el-col :lg="24" :md="24">
          <el-row>
            <el-col :lg="24" :md="24">
              <el-row>
                <el-col :lg="24" :md="24">
                  <ChargesTable
                    @GenericSortableTableView-onCurrentRow="(val, event) => { $emit('ChargesTable-onCurrentRow', val, event); }"
                    @GenericSortableTableView-onDoubleClickRow="(val, event) => { $emit('ChargesTable-onDoubleClickRow', val, event); }"
                    ref="RefChargesTable" name="ChargesTable"
                    v-bind="{ ...ChargesTable, ...configObject.ChargesTable }"
                    v-if="configObject.ChargesTable != undefined ? configObject.ChargesTable.isVisible : false"
                  />
                </el-col>
              </el-row>                 
              <fieldset>
                <el-row>
                  <el-col :lg="4" :md="4">
                    <GetChargesButton
                      @GenericButton-onClick="$emit('GetChargesButton-onClick')"
                      v-bind="{ ...GetChargesButton, ...configObject.GetChargesButton }"
                      name="GetChargesButton" ref="RefGetChargesButton"
                      v-if="configObject.GetChargesButton !== undefined ? configObject.GetChargesButton.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="16" :md="16"></el-col>
                  <el-col :lg="4" :md="4">
                    <ChangeChargesButton
                      @GenericButton-onClick="$emit('ChangeChargesButton-onClick')"
                      v-bind="{ ...ChangeChargesButton, ...configObject.ChangeChargesButton }"
                      name="ChangeChargesButton" ref="RefChangeChargesButton"
                      v-if="configObject.ChangeChargesButton !== undefined ? configObject.ChangeChargesButton.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
              </fieldset>
            </el-col>
          </el-row>
        </el-col>
      </el-row>

      </el-tab-pane>

    <!-- THIRD TAB----SHORT PAYMENT -->
     <el-tab-pane
        :disabled="configObject.ShortPaymentTab.isDisabled"
        v-if="configObject.ShortPaymentTab != undefined ? configObject.ShortPaymentTab.isVisible : false"
        label="Short Payment"
        name="ShortPaymentTab"
        ref="RefShortPaymentTab"
      >

      <el-row>
        <el-col :lg="24" :md="24">    
          <el-row>    
            <el-col :lg="24" :md="24">    
              <fieldset>    
                <el-row>    
                  <el-col :lg="1" :md="1"></el-col>    
                  <el-col :lg="23" :md="23">    
                    <ShortPay_ShortAmtTextBox    
                      @AmountNumericDecimal-onBlur="(val) => { $emit('ShortPay_ShortAmtTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('ShortPay_ShortAmtTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('ShortPay_ShortAmtTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('ShortPay_ShortAmtTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('ShortPay_ShortAmtTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...ShortPay_ShortAmtTextBox, ...configObject.ShortPay_ShortAmtTextBox }"    
                      :values="configObject.ShortPay_ShortAmtTextBox.ShortPay_ShortAmtTextBoxValue"    
                      name="ShortPay_ShortAmtTextBox"    
                      ref="RefShortPay_ShortAmtTextBox"    
                      v-if="configObject.ShortPay_ShortAmtTextBox && configObject.ShortPay_ShortAmtTextBox.isVisible"    
                    />    
                  </el-col>    
                </el-row>    
                <el-row>    
                  <el-col :lg="1" :md="1"></el-col>    
                  <el-col :lg="23" :md="23">    
                    <ShortPay_ExchgRateTextBox
                      @AmountNumericDecimal-onBlur="(val) => { $emit('ShortPay_ExchgRateTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('ShortPay_ExchgRateTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('ShortPay_ExchgRateTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('ShortPay_ExchgRateTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('ShortPay_ExchgRateTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...ShortPay_ExchgRateTextBox, ...configObject.ShortPay_ExchgRateTextBox }"   
                      :values="configObject.ShortPay_ExchgRateTextBox.ShortPay_ExchgRateTextBoxValue"
                      name="ShortPay_ExchgRateTextBox"
                      ref="RefShortPay_ExchgRateTextBox"
                      v-if="configObject.ShortPay_ExchgRateTextBox && configObject.ShortPay_ExchgRateTextBox.isVisible"    
                    />   
                  </el-col>    
                </el-row>
                <el-row>    
                  <el-col :lg="1" :md="1"></el-col>    
                  <el-col :lg="23" :md="23">    
                    <ShortPay_AmtLCYTextBox    
                      @AmountNumericDecimal-onBlur="(val) => { $emit('ShortPay_AmtLCYTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('ShortPay_AmtLCYTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('ShortPay_AmtLCYTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('ShortPay_AmtLCYTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('ShortPay_AmtLCYTextBox-onKeyUp', val, event); }"   
                      v-bind="{ ...ShortPay_AmtLCYTextBox, ...configObject.ShortPay_AmtLCYTextBox }"    
                      :values="configObject.ShortPay_AmtLCYTextBox.ShortPay_AmtLCYTextBoxValue"
                      name="ShortPay_AmtLCYTextBox"
                      ref="RefShortPay_AmtLCYTextBox"    
                      v-if="configObject.ShortPay_AmtLCYTextBox && configObject.ShortPay_AmtLCYTextBox.isVisible"    
                    />    
                  </el-col>    
                </el-row>
                <el-row>                          
                  <el-col :lg="1" :md="1"></el-col>    
                  <el-col :lg="23" :md="23">    
                    <ShortPay_TreasuryRateTextBox                           
                      @AmountNumericDecimal-onBlur="(val) => { $emit('ShortPay_TreasuryRateTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('ShortPay_TreasuryRateTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('ShortPay_TreasuryRateTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('ShortPay_TreasuryRateTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('ShortPay_TreasuryRateTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...ShortPay_TreasuryRateTextBox, ...configObject.ShortPay_TreasuryRateTextBox }"    
                      :values="configObject.ShortPay_TreasuryRateTextBox.ShortPay_TreasuryRateTextBoxValue"    
                      name="ShortPay_TreasuryRateTextBox"    
                      ref="RefShortPay_TreasuryRateTextBox"    
                      v-if="configObject.ShortPay_TreasuryRateTextBox && configObject.ShortPay_TreasuryRateTextBox.isVisible"    
                    />    
                  </el-col>    
                </el-row>    
                <el-row>    
                  <el-col :lg="1" :md="1"></el-col>    
                  <el-col :lg="23" :md="23">    
                    <ShortPay_TotTranAmtTextBox    
                      @AmountNumericDecimal-onBlur="(val) => { $emit('ShortPay_TotTranAmtTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('ShortPay_TotTranAmtTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('ShortPay_TotTranAmtTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('ShortPay_TotTranAmtTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('ShortPay_TotTranAmtTextBox-onKeyUp', val, event); }"    
                      v-bind="{ ...ShortPay_TotTranAmtTextBox, ...configObject.ShortPay_TotTranAmtTextBox }"    
                      :values="configObject.ShortPay_TotTranAmtTextBox.ShortPay_TotTranAmtTextBoxValue"    
                      name="ShortPay_TotTranAmtTextBox"    
                      ref="RefShortPay_TotTranAmtTextBox"    
                      v-if="configObject.ShortPay_TotTranAmtTextBox && configObject.ShortPay_TotTranAmtTextBox.isVisible"    
                    />    
                  </el-col>    
                </el-row>    
              </fieldset>    
            </el-col>   
          </el-row>  
        </el-col>
      </el-row>

      </el-tab-pane>

    <!-- FOURTH TAB----REMARKS -->
       <el-tab-pane
        :disabled="configObject.RemarksTab.isDisabled"
        v-if="configObject.RemarksTab != undefined ? configObject.RemarksTab.isVisible : false"
        label="Remarks"
        name="RemarksTab"
        ref="RefRemarksTab"
      >

      <el-row>  
        <el-col :lg="24" :md="24">  
          <el-row>  
            <el-col :lg="24" :md="24">  
              <fieldset>  
                <br>  
                <el-row>  
                  <el-col :lg="1" :md="1"></el-col>  
                  <el-col :lg="22" :md="22">  
                    <RemarksTextArea 
                      @GenericTextArea-onBlur="(val) => { $emit('RemarksTextArea-onBlur', val); }"                        
                      @GenericTextArea-onChange="(val) => { $emit('RemarksTextArea-onChange', val); }"  
                      @GenericTextArea-onFocus="(val) => { $emit('RemarksTextArea-onFocus', val); }"
                      @GenericTextArea-onKeyPress="(val, event) => { $emit('RemarksTextArea-onKeyPress', val, event); }"                        
                      @GenericTextArea-onKeyUp="(val, event) => { $emit('RemarksTextArea-onKeyUp', val, event); }"                        
                      v-bind="{ ...RemarksTextArea, ...configObject.RemarksTextArea }"                        
                      :values="configObject.RemarksTextArea.RemarksTextAreaValue"                        
                      name="RemarksTextArea"               
                      ref="RefRemarksTextArea"               
                      v-if="configObject.RemarksTextArea != undefined ? configObject.RemarksTextArea.isVisible : false"             
                    />            
                  </el-col>            
                  <el-col :lg="1" :md="1"></el-col>          
                </el-row>        
              </fieldset>      
            </el-col>    
          </el-row>  
        </el-col>
      </el-row>

      </el-tab-pane>
           
      <!-- FIFTH TAB----E-FORM -->
      <el-tab-pane
        :disabled="configObject.EFormTab.isDisabled"
        v-if="configObject.EFormTab != undefined ? configObject.EFormTab.isVisible : false"
        label="E-Form"
        name="EFormTab"
        ref="RefEFormTab"
      >
      <el-row>  
        <el-col :lg="24" :md="24">
          <el-row>
            <el-col :lg="24" :md="24">
              <fieldset>
                <el-row>
                  <el-col :lg="8" :md="8">  
                    <Eform_AdvpNoTextBox   
                      @GenericTextBox-onBlur="(val) => { $emit('Eform_AdvpNoTextBox-onBlur', val); }"  
                      @GenericTextBox-onChange="(val) => { $emit('Eform_AdvpNoTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Eform_AdvpNoTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Eform_AdvpNoTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Eform_AdvpNoTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Eform_AdvpNoTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Eform_AdvpNoTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Eform_AdvpNoTextBox-onPaste', event); }"
                      v-bind="{ ...Eform_AdvpNoTextBox, ...configObject.Eform_AdvpNoTextBox }"
                      :values="configObject.Eform_AdvpNoTextBox.Eform_AdvpNoTextBoxValue"
                      name="Eform_AdvpNoTextBox"
                      ref="RefEform_AdvpNoTextBox"
                      v-if="configObject.Eform_AdvpNoTextBox != undefined ? configObject.Eform_AdvpNoTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="5" :md="5">
                    <Eform_DateTextBox 
                      @DateDdMmYyyy-onBlur="(val) => { $emit('Eform_DateTextBox-onBlur', val); }"
                      @DateDdMmYyyy-onChange="(val) => { $emit('Eform_DateTextBox-onChange', val); }"
                      @DateDdMmYyyy-onFocus="(val) => { $emit('Eform_DateTextBox-onFocus', val); }"
                      @DateDdMmYyyy-onKeyPress="(val, event) => { $emit('Eform_DateTextBox-onKeyPress', val, event); }"
                      @DateDdMmYyyy-onKeyUp="(val, event) => { $emit('Eform_DateTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Eform_DateTextBox, ...configObject.Eform_DateTextBox }"
                      :values="configObject.Eform_DateTextBox.Eform_DateTextBoxValue"
                      name="Eform_DateTextBox"
                      ref="RefEform_DateTextBox"
                      v-if="configObject.Eform_DateTextBox != undefined ? configObject.Eform_DateTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>  
                  <el-col :lg="8" :md="8">
                    <Eform_CurrencyTextBox 
                    @GenericTextBox-onBlur="(val) => { $emit('Eform_CurrencyTextBox-onBlur', val); }"
                    @GenericTextBox-onChange="(val) => { $emit('Eform_CurrencyTextBox-onChange', val); }"
                    @GenericTextBox-onFocus="(val) => { $emit('Eform_CurrencyTextBox-onFocus', val); }"
                    @GenericTextBox-onKeyPress="(val, event) => { $emit('Eform_CurrencyTextBox-onKeyPress', val, event); }"
                    @GenericTextBox-onKeyUp="(val, event) => { $emit('Eform_CurrencyTextBox-onKeyUp', val, event); }"
                    @GenericTextBox-onKeyDown="(val, event) => { $emit('Eform_CurrencyTextBox-onKeyDown', val, event); }"
                    @GenericTextBox-onInput="(val, event) => { $emit('Eform_CurrencyTextBox-onInput', val, event); }"
                    @GenericTextBox-onPaste="(event) => { $emit('Eform_CurrencyTextBox-onPaste', event); }"
                    v-bind="{ ...Eform_CurrencyTextBox, ...configObject.Eform_CurrencyTextBox }"                
                    :values="configObject.Eform_CurrencyTextBox.Eform_CurrencyTextBoxValue"                
                    name="Eform_CurrencyTextBox" ref="RefEform_CurrencyTextBox"                
                    v-if="configObject.Eform_CurrencyTextBox != undefined ? configObject.Eform_CurrencyTextBox.isVisible : false"
                    />            
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="8" :md="8">
                    <Eform_PRCAmtTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Eform_PRCAmtTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Eform_PRCAmtTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Eform_PRCAmtTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Eform_PRCAmtTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Eform_PRCAmtTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Eform_PRCAmtTextBox, ...configObject.Eform_PRCAmtTextBox }"
                      :values="configObject.Eform_PRCAmtTextBox.Eform_PRCAmtTextBoxValue"
                      name="Eform_PRCAmtTextBox"
                      ref="RefEform_PRCAmtTextBox"
                      v-if="configObject.Eform_PRCAmtTextBox != undefined ? configObject.Eform_PRCAmtTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="7" :md="7"></el-col>
                  <el-col :lg="8" :md="8">
                    <Eform_BalanceTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Eform_BalanceTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Eform_BalanceTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Eform_BalanceTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Eform_BalanceTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Eform_BalanceTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Eform_BalanceTextBox, ...configObject.Eform_BalanceTextBox }"
                      :values="configObject.Eform_BalanceTextBox.Eform_BalanceTextBoxValue"
                      name="Eform_BalanceTextBox"
                      ref="RefEform_BalanceTextBox"
                      v-if="configObject.Eform_BalanceTextBox != undefined ? configObject.Eform_BalanceTextBox.isVisible : false"
                    />
                  </el-col>  
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
              </fieldset>
              <br>
              <el-row>
                <el-col :lg="24" :md="24">
                  <EFormTable
                    @GenericSortableTableView-onCurrentRow="(val, event) => { $emit('EFormTable-onCurrentRow', val, event); }"
                    @GenericSortableTableView-onDoubleClickRow="(val, event) => { $emit('EFormTable-onDoubleClickRow', val, event); }"
                    ref="RefEFormTable" name="EFormTable"
                    v-bind="{ ...EFormTable, ...configObject.EFormTable }"
                    v-if="configObject.EFormTable != undefined ? configObject.EFormTable.isVisible : false"
                  />
                </el-col>
              </el-row>  
            </el-col>  
          </el-row>
        </el-col>
      </el-row>

      </el-tab-pane>
      
      <!-- SIXTH TAB----ITEM INFO-->
      <el-tab-pane
        :disabled="configObject.ItemInfoTab.isDisabled"
        v-if="configObject.ItemInfoTab != undefined ? configObject.ItemInfoTab.isVisible : false"
        label="Item Info"
        name="ItemInfoTab"
        ref="RefItemInfoTab"
      >

      <el-row>
        <el-col :lg="24" :md="24">
          <el-row>
            <el-col :lg="24" :md="24">
              <fieldset>            
                  <el-row>
                  <el-col :lg="8" :md="8">
                    <ItemInfo_HsCodeTextBox 
                      @HsCodeNumericDecimal4Point4-onBlur="(val) => { $emit('ItemInfo_HsCodeTextBox-onBlur', val); }"
                      @HsCodeNumericDecimal4Point4-onChange="(val) => { $emit('ItemInfo_HsCodeTextBox-onChange', val); }" 
                      @HsCodeNumericDecimal4Point4-onFocus="(val) => { $emit('ItemInfo_HsCodeTextBox-onFocus', val); }" 
                      @HsCodeNumericDecimal4Point4-onKeyPress="(val) => { $emit('ItemInfo_HsCodeTextBox-onKeyPress', val); }"
                      @HsCodeNumericDecimal4Point4-onKeyUp="(val) => { $emit('ItemInfo_HsCodeTextBox-onKeyUp', val); } "
                      v-bind="{ ...ItemInfo_HsCodeTextBox, ...configObject.ItemInfo_HsCodeTextBox }"
                      :values="configObject.ItemInfo_HsCodeTextBox.ItemInfo_HsCodeTextBoxValue" 
                      name="ItemInfo_HsCodeTextBox" ref="RefItemInfo_HsCodeTextBox" 
                      v-if="configObject.ItemInfo_HsCodeTextBox != undefined ? configObject.ItemInfo_HsCodeTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="4" :md="4">
                    <HSCodeListBtn 
                      @GenericButton-onClick="$emit('HSCodeListBtn-onClick')"
                      v-bind="{ ...HSCodeListBtn, ...configObject.HSCodeListBtn }" 
                      name="HSCodeListBtn" ref="RefHSCodeListBtn"
                      v-if="configObject.HSCodeListBtn != undefined ? configObject.HSCodeListBtn.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                  <el-col :lg="8" :md="8">
                    <legend class="sumItemfontSize" v-if="configObject.ItemSumAmtSection != undefined ? configObject.ItemSumAmtSection.isVisible : false">  
                      Sum of Item Amount: &nbsp;&nbsp; {{ configObject.ItemSumAmtValue.value }}
                    </legend>
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="22" :md="22">
                    <ItemInfo_CommDescTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('ItemInfo_CommDescTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('ItemInfo_CommDescTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('ItemInfo_CommDescTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('ItemInfo_CommDescTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('ItemInfo_CommDescTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('ItemInfo_CommDescTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('ItemInfo_CommDescTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('ItemInfo_CommDescTextBox-onPaste', event); }"
                      v-bind="{ ...ItemInfo_CommDescTextBox, ...configObject.ItemInfo_CommDescTextBox }"
                      :values="configObject.ItemInfo_CommDescTextBox.ItemInfo_CommDescTextBoxValue" 
                      name="ItemInfo_CommDescTextBox" 
                      ref="RefItemInfo_CommDescTextBox" 
                      v-if="configObject.ItemInfo_CommDescTextBox != undefined ? configObject.ItemInfo_CommDescTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                </el-row>
                <el-row>
                  <el-col  :lg="11" :md="11">
                    <ItemInfo_COODropDown
                      @GenericDropDown-onChange="(val) => { $emit('ItemInfo_COODropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('ItemInfo_COODropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('ItemInfo_COODropDown-onBlur', val); }"
                      v-bind="{ ...ItemInfo_COODropDown, ...configObject.ItemInfo_COODropDown }"
                      :values="configObject.ItemInfo_COODropDown.ItemInfo_COODropDownList"
                      name="ItemInfo_COODropDown"
                      ref="RefItemInfo_COODropDown"
                      v-if="configObject.ItemInfo_COODropDown != undefined ? configObject.ItemInfo_COODropDown.isVisible : false"
                    />
                  </el-col>
                  <el-col  :lg="3" :md="3"></el-col>
                  <el-col  :lg="8" :md="8">
                    <ItemInfo_UnitsDropDown
                      @GenericDropDown-onChange="(val) => { $emit('ItemInfo_UnitsDropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('ItemInfo_UnitsDropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('ItemInfo_UnitsDropDown-onBlur', val); }"
                      v-bind="{ ...ItemInfo_UnitsDropDown, ...configObject.ItemInfo_UnitsDropDown }"
                      :values="configObject.ItemInfo_UnitsDropDown.ItemInfo_UnitsDropDownList"
                      name="ItemInfo_UnitsDropDown"
                      ref="RefItemInfo_UnitsDropDown"
                      v-if="configObject.ItemInfo_UnitsDropDown != undefined ? configObject.ItemInfo_UnitsDropDown.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                </el-row>
                <el-row>
                  <el-col  :lg="11" :md="11">
                    <ItemInfo_CurrencyDropDown
                      @GenericDropDown-onChange="(val) => { $emit('ItemInfo_CurrencyDropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('ItemInfo_CurrencyDropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('ItemInfo_CurrencyDropDown-onBlur', val); }"
                      v-bind="{ ...ItemInfo_CurrencyDropDown, ...configObject.ItemInfo_CurrencyDropDown }"
                      :values="configObject.ItemInfo_CurrencyDropDown.ItemInfo_CurrencyDropDownList"
                      name="ItemInfo_CurrencyDropDown"
                      ref="RefItemInfo_CurrencyDropDown"
                      v-if="configObject.ItemInfo_CurrencyDropDown != undefined ? configObject.ItemInfo_CurrencyDropDown.isVisible : false"
                    />
                  </el-col>
                  <el-col  :lg="3" :md="3"></el-col>
                  <el-col  :lg="8" :md="8">
                    <ItemInfo_AmtFCYTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('ItemInfo_AmtFCYTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('ItemInfo_AmtFCYTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('ItemInfo_AmtFCYTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('ItemInfo_AmtFCYTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('ItemInfo_AmtFCYTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...ItemInfo_AmtFCYTextBox, ...configObject.ItemInfo_AmtFCYTextBox }"
                      :values="configObject.ItemInfo_AmtFCYTextBox.ItemInfo_AmtFCYTextBoxValue"
                      name="ItemInfo_AmtFCYTextBox"
                      ref="RefItemInfo_AmtFCYTextBox"
                      v-if="configObject.ItemInfo_AmtFCYTextBox != undefined ? configObject.ItemInfo_AmtFCYTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                </el-row>
                <el-row>
                  <el-col  :lg="8" :md="8">
                    <ItemInfo_QuantityTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('ItemInfo_QuantityTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('ItemInfo_QuantityTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('ItemInfo_QuantityTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('ItemInfo_QuantityTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('ItemInfo_QuantityTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...ItemInfo_QuantityTextBox, ...configObject.ItemInfo_QuantityTextBox }"
                      :values="configObject.ItemInfo_QuantityTextBox.ItemInfo_QuantityTextBoxValue" 
                      name="ItemInfo_QuantityTextBox" 
                      ref="RefItemInfo_QuantityTextBox" 
                      v-if="configObject.ItemInfo_QuantityTextBox != undefined ? configObject.ItemInfo_QuantityTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="18" :md="18"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="8" :md="8">
                    <ItemInfo_UnitPriceTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('ItemInfo_UnitPriceTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('ItemInfo_UnitPriceTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('ItemInfo_UnitPriceTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('ItemInfo_UnitPriceTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('ItemInfo_UnitPriceTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...ItemInfo_UnitPriceTextBox, ...configObject.ItemInfo_UnitPriceTextBox }"
                      :values="configObject.ItemInfo_UnitPriceTextBox.ItemInfo_UnitPriceTextBoxValue" 
                      name="ItemInfo_UnitPriceTextBox" 
                      ref="RefItemInfo_UnitPriceTextBox" 
                      v-if="configObject.ItemInfo_UnitPriceTextBox != undefined ? configObject.ItemInfo_UnitPriceTextBox.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="3" :md="3">
                    <ItemInfo_AddItemBtn 
                      @GenericButton-onClick="$emit('ItemInfo_AddItemBtn-onClick')"
                      v-bind="{ ...ItemInfo_AddItemBtn, ...configObject.ItemInfo_AddItemBtn }" 
                      name="ItemInfo_AddItemBtn" ref="RefItemInfo_AddItemBtn"
                      v-if="configObject.ItemInfo_AddItemBtn != undefined ? configObject.ItemInfo_AddItemBtn.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                  <el-col :lg="3" :md="3">
                    <ItemInfo_ChngItemBtn 
                      @GenericButton-onClick="$emit('ItemInfo_ChngItemBtn-onClick')"
                      v-bind="{ ...ItemInfo_ChngItemBtn, ...configObject.ItemInfo_ChngItemBtn }" 
                      name="ItemInfo_ChngItemBtn" ref="RefItemInfo_ChngItemBtn"
                      v-if="configObject.ItemInfo_ChngItemBtn != undefined ? configObject.ItemInfo_ChngItemBtn.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                  <el-col :lg="3" :md="3">
                    <ItemInfo_RemoveItemBtn 
                      @GenericButton-onClick=" $emit('ItemInfo_RemoveItemBtn-onClick')"
                      v-bind="{ ...ItemInfo_RemoveItemBtn, ...configObject.ItemInfo_RemoveItemBtn }" 
                      name="ItemInfo_RemoveItemBtn" ref="RefItemInfo_RemoveItemBtn"
                      v-if="configObject.ItemInfo_RemoveItemBtn != undefined ? configObject.ItemInfo_RemoveItemBtn.isVisible : false"
                    />
                  </el-col>
                  <el-col :lg="2" :md="2"></el-col>
                </el-row>
                
              </fieldset>
                <br>                
                  <el-row>
                  <el-col :lg="24" :md="24">
                    <ItemInfoTable
                    @GenericSortableTableView-onCurrentRow="(val, event) => { $emit('ItemInfoTable-onCurrentRow', val, event); }"
                    @GenericSortableTableView-onDoubleClickRow="(val, event) => { $emit('ItemInfoTable-onDoubleClickRow', val, event); }"
                    ref="RefItemInfoTable" name="ItemInfoTable"
                    v-bind="{ ...ItemInfoTable, ...configObject.ItemInfoTable }"
                    v-if="configObject.ItemInfoTable != undefined ? configObject.ItemInfoTable.isVisible : false"
                    />
                  </el-col>
                </el-row>
            </el-col>
          </el-row>
          
        </el-col>
      </el-row>
      </el-tab-pane>

      <!-- SEVENTH TAB----ACCUITY INFO-->
      <el-tab-pane
        :disabled="configObject.AccuityInfoTab.isDisabled"
        v-if="configObject.AccuityInfoTab != undefined ? configObject.AccuityInfoTab.isVisible : false"
        label="Accuity Info"
        name="AccuityInfoTab"
        ref="RefAccuityInfoTab"
      >
      
      <el-row>
        <el-col :lg="24" :md="24">
          <el-row>
            <el-col :lg="24" :md="24">
              <fieldset>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <AI_Bank_BICCodeTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('AI_Bank_BICCodeTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('AI_Bank_BICCodeTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('AI_Bank_BICCodeTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('AI_Bank_BICCodeTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('AI_Bank_BICCodeTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('AI_Bank_BICCodeTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('AI_Bank_BICCodeTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('AI_Bank_BICCodeTextBox-onPaste', event); }"
                      v-bind="{ ...AI_Bank_BICCodeTextBox, ...configObject.AI_Bank_BICCodeTextBox }"
                      :values="configObject.AI_Bank_BICCodeTextBox.AI_Bank_BICCodeTextBoxValue" 
                      name="AI_Bank_BICCodeTextBox" ref="RefAI_Bank_BICCodeTextBox" 
                      v-if="configObject.AI_Bank_BICCodeTextBox != undefined ? configObject.AI_Bank_BICCodeTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <AI_Port_AirportDropDown 
                      @GenericDropDown-onChange="(val) => { $emit('AI_Port_AirportDropDown-onChange', val); }"
                      @GenericDropDown-onFocus="(val) => { $emit('AI_Port_AirportDropDown-onFocus', val); }"
                      @GenericDropDown-onBlur="(val) => { $emit('AI_Port_AirportDropDown-onBlur', val); }"
                      v-bind="{ ...AI_Port_AirportDropDown, ...configObject.AI_Port_AirportDropDown }"
                      :values="configObject.AI_Port_AirportDropDown.AI_Port_AirportDropDownList"
                      name="AI_Port_AirportDropDown"
                      ref="RefAI_Port_AirportDropDown"
                      v-if="configObject.AI_Port_AirportDropDown != undefined ? configObject.AI_Port_AirportDropDown.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <AI_AgentNameTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('AI_AgentNameTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('AI_AgentNameTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('AI_AgentNameTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('AI_AgentNameTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('AI_AgentNameTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('AI_AgentNameTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('AI_AgentNameTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('AI_AgentNameTextBox-onPaste', event); }"
                      v-bind="{ ...AI_AgentNameTextBox, ...configObject.AI_AgentNameTextBox }"
                      :values="configObject.AI_AgentNameTextBox.AI_AgentNameTextBoxValue" 
                      name="AI_AgentNameTextBox" 
                      ref="RefAI_AgentNameTextBox" 
                      v-if="configObject.AI_AgentNameTextBox != undefined ? configObject.AI_AgentNameTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <AI_OtherPartyTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('AI_OtherPartyTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('AI_OtherPartyTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('AI_OtherPartyTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('AI_OtherPartyTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('AI_OtherPartyTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('AI_OtherPartyTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('AI_OtherPartyTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('AI_OtherPartyTextBox-onPaste', event); }"
                      v-bind="{ ...AI_OtherPartyTextBox, ...configObject.AI_OtherPartyTextBox }"
                      :values="configObject.AI_OtherPartyTextBox.AI_OtherPartyTextBoxValue" 
                      name="AI_OtherPartyTextBox" 
                      ref="RefAI_OtherPartyTextBox" 
                      v-if="configObject.AI_OtherPartyTextBox != undefined ? configObject.AI_OtherPartyTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <AI_OtherPartyAddrTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('AI_OtherPartyAddrTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('AI_OtherPartyAddrTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('AI_OtherPartyAddrTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('AI_OtherPartyAddrTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('AI_OtherPartyAddrTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('AI_OtherPartyAddrTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('AI_OtherPartyAddrTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('AI_OtherPartyAddrTextBox-onPaste', event); }"
                      v-bind="{ ...AI_OtherPartyAddrTextBox, ...configObject.AI_OtherPartyAddrTextBox }"
                      :values="configObject.AI_OtherPartyAddrTextBox.AI_OtherPartyAddrTextBoxValue" 
                      name="AI_OtherPartyAddrTextBox" 
                      ref="RefAI_OtherPartyAddrTextBox" 
                      v-if="configObject.AI_OtherPartyAddrTextBox != undefined ? configObject.AI_OtherPartyAddrTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <AI_Comment_DescTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('AI_Comment_DescTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('AI_Comment_DescTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('AI_Comment_DescTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('AI_Comment_DescTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('AI_Comment_DescTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('AI_Comment_DescTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('AI_Comment_DescTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('AI_Comment_DescTextBox-onPaste', event); }"
                      v-bind="{ ...AI_Comment_DescTextBox, ...configObject.AI_Comment_DescTextBox }"
                      :values="configObject.AI_Comment_DescTextBox.AI_Comment_DescTextBoxValue" 
                      name="AI_Comment_DescTextBox" 
                      ref="RefAI_Comment_DescTextBox" 
                      v-if="configObject.AI_Comment_DescTextBox != undefined ? configObject.AI_Comment_DescTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
              </fieldset>
            </el-col>
          </el-row>
          
        </el-col>
      </el-row>
      </el-tab-pane>

      <!-- EIGHTH TAB----PSW INFORMATION-->
      <el-tab-pane
        :disabled="configObject.PSWInformationTab.isDisabled"
        v-if="configObject.PSWInformationTab != undefined ? configObject.PSWInformationTab.isVisible : false"
        label="PSW Information"
        name="PSWInformationTab"
        ref="RefPSWInformationTab"
      >

      <el-row>
        <el-col :lg="24" :md="24">
          <el-row>
            <el-col :lg="24" :md="24">
              <fieldset>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <PSW_FinInstNoTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('PSW_FinInstNoTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('PSW_FinInstNoTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('PSW_FinInstNoTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('PSW_FinInstNoTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('PSW_FinInstNoTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('PSW_FinInstNoTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('PSW_FinInstNoTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('PSW_FinInstNoTextBox-onPaste', event); }"
                      v-bind="{ ...PSW_FinInstNoTextBox, ...configObject.PSW_FinInstNoTextBox }"
                      :values="configObject.PSW_FinInstNoTextBox.PSW_FinInstNoTextBoxValue" 
                      name="PSW_FinInstNoTextBox" ref="RefPSW_FinInstNoTextBox" 
                      v-if="configObject.PSW_FinInstNoTextBox != undefined ? configObject.PSW_FinInstNoTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <PSW_FinInstDate 
                      @DateDdMmYyyy-onBlur="(val) => { $emit('PSW_FinInstDate-onBlur', val); }"
                      @DateDdMmYyyy-onChange="(val) => { $emit('PSW_FinInstDate-onChange', val); }"
                      @DateDdMmYyyy-onFocus="(val) => { $emit('PSW_FinInstDate-onFocus', val); }"
                      @DateDdMmYyyy-onKeyPress="(val, event) => { $emit('PSW_FinInstDate-onKeyPress', val, event); }"
                      @DateDdMmYyyy-onKeyUp="(val, event) => { $emit('PSW_FinInstDate-onKeyUp', val, event); }"
                      v-bind="{ ...PSW_FinInstDate, ...configObject.PSW_FinInstDate }"
                      :values="configObject.PSW_FinInstDate.PSW_FinInstDateValue" 
                      name="PSW_FinInstDate" 
                      ref="RefPSW_FinInstDate" 
                      v-if="configObject.PSW_FinInstDate != undefined ? configObject.PSW_FinInstDate.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <PSW_ModePayTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('PSW_ModePayTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('PSW_ModePayTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('PSW_ModePayTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('PSW_ModePayTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('PSW_ModePayTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('PSW_ModePayTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('PSW_ModePayTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('PSW_ModePayTextBox-onPaste', event); }"
                      v-bind="{ ...PSW_ModePayTextBox, ...configObject.PSW_ModePayTextBox }"
                      :values="configObject.PSW_ModePayTextBox.PSW_ModePayTextBoxValue" 
                      name="PSW_ModePayTextBox" 
                      ref="RefPSW_ModePayTextBox" 
                      v-if="configObject.PSW_ModePayTextBox != undefined ? configObject.PSW_ModePayTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <PSW_FinInstExpDate 
                      @DateDdMmYyyy-onBlur="(val) => { $emit('PSW_FinInstExpDate-onBlur', val); }"
                      @DateDdMmYyyy-onChange="(val) => { $emit('PSW_FinInstExpDate-onChange', val); }"
                      @DateDdMmYyyy-onFocus="(val) => { $emit('PSW_FinInstExpDate-onFocus', val); }"
                      @DateDdMmYyyy-onKeyPress="(val, event) => { $emit('PSW_FinInstExpDate-onKeyPress', val, event); }"
                      @DateDdMmYyyy-onKeyUp="(val, event) => { $emit('PSW_FinInstExpDate-onKeyUp', val, event); }"
                      v-bind="{ ...PSW_FinInstExpDate, ...configObject.PSW_FinInstExpDate }"
                      :values="configObject.PSW_FinInstExpDate.PSW_FinInstExpDateValue" 
                      name="PSW_FinInstExpDate" 
                      ref="RefPSW_FinInstExpDate" 
                      v-if="configObject.PSW_FinInstExpDate != undefined ? configObject.PSW_FinInstExpDate.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <PSW_ConsigneeIBANTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('PSW_ConsigneeIBANTextBox-onBlur', val); }"
                      @GenericTextBox-onChange="(val) => { $emit('PSW_ConsigneeIBANTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('PSW_ConsigneeIBANTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('PSW_ConsigneeIBANTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('PSW_ConsigneeIBANTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('PSW_ConsigneeIBANTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('PSW_ConsigneeIBANTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('PSW_ConsigneeIBANTextBox-onPaste', event); }"
                      v-bind="{ ...PSW_ConsigneeIBANTextBox, ...configObject.PSW_ConsigneeIBANTextBox }"
                      :values="configObject.PSW_ConsigneeIBANTextBox.PSW_ConsigneeIBANTextBoxValue" 
                      name="PSW_ConsigneeIBANTextBox" 
                      ref="RefPSW_ConsigneeIBANTextBox" 
                      v-if="configObject.PSW_ConsigneeIBANTextBox != undefined ? configObject.PSW_ConsigneeIBANTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
              </fieldset>
            </el-col>
          </el-row>
          
        </el-col>
      </el-row>

      </el-tab-pane>

      <!-- NINTH TAB----M-FORM-->
      <el-tab-pane
        :disabled="configObject.MFormTab.isDisabled"
        v-if="configObject.MFormTab != undefined ? configObject.MFormTab.isVisible : false"
        label="M-Form"
        name="MFormTab"
        ref="RefMFormTab"
      >

      <fieldset>
        <el-row>
          <el-col :lg="12" :md="12">
            <MForm_NoTextBox 
              @GenericTextBox-onBlur="(val) => { $emit('MForm_NoTextBox-onBlur', val); }"
              @GenericTextBox-onChange="(val) => { $emit('MForm_NoTextBox-onChange', val); }"
              @GenericTextBox-onFocus="(val) => { $emit('MForm_NoTextBox-onFocus', val); }"
              @GenericTextBox-onKeyPress="(val, event) => { $emit('MForm_NoTextBox-onKeyPress', val, event); }"
              @GenericTextBox-onKeyUp="(val, event) => { $emit('MForm_NoTextBox-onKeyUp', val, event); }"
              @GenericTextBox-onKeyDown="(val, event) => { $emit('MForm_NoTextBox-onKeyDown', val, event); }"
              @GenericTextBox-onInput="(val, event) => { $emit('MForm_NoTextBox-onInput', val, event); }"
              @GenericTextBox-onPaste="(event) => { $emit('MForm_NoTextBox-onPaste', event); }"
              v-bind="{ ...MForm_NoTextBox, ...configObject.MForm_NoTextBox }"
              :values="configObject.MForm_NoTextBox.MForm_NoTextBoxValue" 
              name="MForm_NoTextBox" ref="RefMForm_NoTextBox" 
              v-if="configObject.MForm_NoTextBox != undefined ? configObject.MForm_NoTextBox.isVisible : false"
            />
          </el-col>
          <el-col :lg="12" :md="12">
            <MForm_PurposeCdDropDown
              @GenericDropDown-onChange="(val) => { $emit('MForm_PurposeCdDropDown-onChange', val); }"
              @GenericDropDown-onFocus="(val) => { $emit('MForm_PurposeCdDropDown-onFocus', val); }"
              @GenericDropDown-onBlur="(val) => { $emit('MForm_PurposeCdDropDown-onBlur', val); }"
              v-bind="{ ...MForm_PurposeCdDropDown, ...configObject.MForm_PurposeCdDropDown }"
              :values="configObject.MForm_PurposeCdDropDown.MForm_PurposeCdDropDownList" 
              name="MForm_PurposeCdDropDown"
              ref="RefMForm_PurposeCdDropDown"
              v-if="configObject.MForm_PurposeCdDropDown != undefined ? configObject.MForm_PurposeCdDropDown.isVisible : false"
            />
          </el-col>
        </el-row>
        <el-row>
          <el-col :lg="24" :md="24">
            <MForm_DeptCdDropDown
              @GenericDropDown-onChange="(val) => { $emit('MForm_DeptCdDropDown-onChange', val); }"
              @GenericDropDown-onFocus="(val) => { $emit('MForm_DeptCdDropDown-onFocus', val); }"
              @GenericDropDown-onBlur="(val) => { $emit('MForm_DeptCdDropDown-onBlur', val); }"
              v-bind="{ ...MForm_DeptCdDropDown, ...configObject.MForm_DeptCdDropDown }"
              :values="configObject.MForm_DeptCdDropDown.MForm_DeptCdDropDownList" 
              name="MForm_DeptCdDropDown"
              ref="RefMForm_DeptCdDropDown"
              v-if="configObject.MForm_DeptCdDropDown != undefined ? configObject.MForm_DeptCdDropDown.isVisible : false"
            />
          </el-col>
        </el-row>
        <el-row>
          <el-col :lg="12" :md="12"></el-col>
          <el-col :lg="12" :md="12">
            <MForm_ShortAmtTextBox
              @AmountNumericDecimal-onBlur="(val) => { $emit('MForm_ShortAmtTextBox-onBlur', val); }"
              @AmountNumericDecimal-onChange="(val) => { $emit('MForm_ShortAmtTextBox-onChange', val); }"
              @AmountNumericDecimal-onFocus="(val) => { $emit('MForm_ShortAmtTextBox-onFocus', val); }"
              @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('MForm_ShortAmtTextBox-onKeyPress', val, event); }"
              @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('MForm_ShortAmtTextBox-onKeyUp', val, event); }"
              v-bind="{ ...MForm_ShortAmtTextBox, ...configObject.MForm_ShortAmtTextBox }"
              :values="configObject.MForm_ShortAmtTextBox.MForm_ShortAmtTextBoxValue"
              name="MForm_ShortAmtTextBox"
              ref="RefMForm_ShortAmtTextBox"
              v-if="configObject.MForm_ShortAmtTextBox != undefined ? configObject.MForm_ShortAmtTextBox.isVisible : false"
            />
          </el-col>
        </el-row>
      </fieldset>
      <br>
        <el-row>
          <el-col :lg="24" :md="24">
            <MFormTable
              @GenericSortableTableView-onCurrentRow="(val, event) => { $emit('MFormTable-onCurrentRow', val, event); }"
              @GenericSortableTableView-onDoubleClickRow="(val, event) => { $emit('MFormTable-onDoubleClickRow', val, event); }"
              ref="RefMFormTable" name="MFormTable"
              v-bind="{ ...MFormTable, ...configObject.MFormTable }"
              v-if="configObject.MFormTable != undefined ? configObject.MFormTable.isVisible : false"
            />
          </el-col>
        </el-row>
      <fieldset>
        <el-row>
          <el-col :lg="10" :md="10"></el-col>
          <el-col :lg="4" :md="4">
            <MForm_AddItemBtn 
              @GenericButton-onClick="$emit('MForm_AddItemBtn-onClick')"
              v-bind="{ ...MForm_AddItemBtn, ...configObject.MForm_AddItemBtn }" 
              name="MForm_AddItemBtn" ref="RefMForm_AddItemBtn"
              v-if="configObject.MForm_AddItemBtn != undefined ? configObject.MForm_AddItemBtn.isVisible : false"
            />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
            <el-col :lg="4" :md="4">
              <MForm_ChngItemBtn 
                @GenericButton-onClick="$emit('MForm_ChngItemBtn-onClick')"
                v-bind="{ ...MForm_ChngItemBtn, ...configObject.MForm_ChngItemBtn }" 
                name="MForm_ChngItemBtn" ref="RefMForm_ChngItemBtn"
                v-if="configObject.MForm_ChngItemBtn != undefined ? configObject.MForm_ChngItemBtn.isVisible : false"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
            <el-col :lg="4" :md="4">
              <MForm_RemoveItemBtn 
                @GenericButton-onClick="$emit('MForm_RemoveItemBtn-onClick')"
                v-bind="{ ...MForm_RemoveItemBtn, ...configObject.MForm_RemoveItemBtn }" 
                name="MForm_RemoveItemBtn" ref="RefMForm_RemoveItemBtn"
                v-if="configObject.MForm_RemoveItemBtn != undefined ? configObject.MForm_RemoveItemBtn.isVisible : false"
              />
            </el-col>
        </el-row>
      </fieldset>
      </el-tab-pane>
   
      <!-- TENTH TAB----RETURN-->
      <el-tab-pane
        :disabled="configObject.ReturnTab.isDisabled"
        v-if="configObject.ReturnTab != undefined ? configObject.ReturnTab.isVisible : false"
        label="Return"
        name="ReturnTab"
        ref="RefReturnTab"
      >
      <el-row>
        <el-col :lg="24" :md="24">
          <el-row>
            <el-col :lg="24" :md="24">
              <fieldset>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <Return_AdvBalTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Return_AdvBalTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Return_AdvBalTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Return_AdvBalTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Return_AdvBalTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Return_AdvBalTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Return_AdvBalTextBox, ...configObject.Return_AdvBalTextBox }"
                      :values="configObject.Return_AdvBalTextBox.Return_AdvBalTextBoxValue" 
                      name="Return_AdvBalTextBox" ref="RefReturn_AdvBalTextBox" 
                      v-if="configObject.Return_AdvBalTextBox != undefined ? configObject.Return_AdvBalTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <Return_AmtTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Return_AmtTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Return_AmtTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Return_AmtTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Return_AmtTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Return_AmtTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Return_AmtTextBox, ...configObject.Return_AmtTextBox }"
                      :values="configObject.Return_AmtTextBox.Return_AmtTextBoxValue" 
                      name="Return_AmtTextBox" ref="RefReturn_AmtTextBox" 
                      v-if="configObject.Return_AmtTextBox != undefined ? configObject.Return_AmtTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <Return_ExchRateTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Return_ExchRateTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Return_ExchRateTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Return_ExchRateTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Return_ExchRateTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Return_ExchRateTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Return_ExchRateTextBox, ...configObject.Return_ExchRateTextBox }"
                      :values="configObject.Return_ExchRateTextBox.Return_ExchRateTextBoxValue" 
                      name="Return_ExchRateTextBox" ref="RefReturn_ExchRateTextBox" 
                      v-if="configObject.Return_ExchRateTextBox != undefined ? configObject.Return_ExchRateTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <Return_PKRTextBox 
                      @AmountNumericDecimal-onBlur="(val) => { $emit('Return_PKRTextBox-onBlur', val); }"
                      @AmountNumericDecimal-onChange="(val) => { $emit('Return_PKRTextBox-onChange', val); }"
                      @AmountNumericDecimal-onFocus="(val) => { $emit('Return_PKRTextBox-onFocus', val); }"
                      @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Return_PKRTextBox-onKeyPress', val, event); }"
                      @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Return_PKRTextBox-onKeyUp', val, event); }"
                      v-bind="{ ...Return_PKRTextBox, ...configObject.Return_PKRTextBox }"
                      :values="configObject.Return_PKRTextBox.Return_PKRTextBoxValue" 
                      name="Return_PKRTextBox" ref="RefReturn_PKRTextBox" 
                      v-if="configObject.Return_PKRTextBox != undefined ? configObject.Return_PKRTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                
                <br><br><br><br><br>

                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <Return_SBPNoTextBox 
                      @GenericTextBox-onBlur="(val) => { $emit('Return_SBPNoTextBox-onBlur', val); }"  
                      @GenericTextBox-onChange="(val) => { $emit('Return_SBPNoTextBox-onChange', val); }"
                      @GenericTextBox-onFocus="(val) => { $emit('Return_SBPNoTextBox-onFocus', val); }"
                      @GenericTextBox-onKeyPress="(val, event) => { $emit('Return_SBPNoTextBox-onKeyPress', val, event); }"
                      @GenericTextBox-onKeyUp="(val, event) => { $emit('Return_SBPNoTextBox-onKeyUp', val, event); }"
                      @GenericTextBox-onKeyDown="(val, event) => { $emit('Return_SBPNoTextBox-onKeyDown', val, event); }"
                      @GenericTextBox-onInput="(val, event) => { $emit('Return_SBPNoTextBox-onInput', val, event); }"
                      @GenericTextBox-onPaste="(event) => { $emit('Return_SBPNoTextBox-onPaste', event); }"
                      v-bind="{ ...Return_SBPNoTextBox, ...configObject.Return_SBPNoTextBox }"
                      :values="configObject.Return_SBPNoTextBox.Return_SBPNoTextBoxValue"
                      name="Return_SBPNoTextBox"
                      ref="RefReturn_SBPNoTextBox"
                      v-if="configObject.Return_SBPNoTextBox != undefined ? configObject.Return_SBPNoTextBox.isVisible : false"
                    />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="23" :md="23">
                    <Return_SBPDate 
                      @DateDdMmYyyy-onBlur="val => $emit('Return_SBPDate-onBlur', val)"
                      @DateDdMmYyyy-onChange="val => $emit('Return_SBPDate-onChange', val)"
                      @DateDdMmYyyy-onFocus="val => $emit('Return_SBPDate-onFocus', val)"
                      @DateDdMmYyyy-onKeyPress="(val, event) => $emit('Return_SBPDate-onKeyPress', val, event)"
                      @DateDdMmYyyy-onKeyUp="(val, event) => $emit('Return_SBPDate-onKeyUp', val, event)"
                      v-bind="{ ...Return_SBPDate, ...configObject.Return_SBPDate }"
                      :values="configObject.Return_SBPDate.Return_SBPDateValue" 
                      name="Return_SBPDate" ref="RefReturn_SBPDate" 
                      v-if="configObject.Return_SBPDate != undefined ? configObject.Return_SBPDate.isVisible : false"
                    />
                  </el-col>
                </el-row>
              </fieldset>
            </el-col>
          </el-row>
          
        </el-col>
      </el-row>
      </el-tab-pane>
      
      <!-- ELEVENTH TAB----TRANSFER-->
      <el-tab-pane
        :disabled="configObject.TransferTab.isDisabled"
        v-if="configObject.TransferTab != undefined ? configObject.TransferTab.isVisible : false"
        label="Transfer"
        name="TransferTab"
        ref="RefTransferTab"
      >

      <fieldset>
        <fieldset v-if="configObject.section8 != undefined ? configObject.section8.isVisible : false">
          <el-row>
            <el-col :lg="24" :md="24">
              <Trf_FCPercentTextBox 
                @AmountNumericDecimal-onBlur="(val) => { $emit('Trf_FCPercentTextBox-onBlur', val); }"
                @AmountNumericDecimal-onChange="(val) => { $emit('Trf_FCPercentTextBox-onChange', val); }"
                @AmountNumericDecimal-onFocus="(val) => { $emit('Trf_FCPercentTextBox-onFocus', val); }"
                @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Trf_FCPercentTextBox-onKeyPress', val, event); }"
                @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Trf_FCPercentTextBox-onKeyUp', val, event); }"
                v-bind="{ ...Trf_FCPercentTextBox, ...configObject.Trf_FCPercentTextBox }"
                :values="configObject.Trf_FCPercentTextBox.Trf_FCPercentTextBoxValue" 
                name="Trf_FCPercentTextBox" ref="RefTrf_FCPercentTextBox" 
                v-if="configObject.Trf_FCPercentTextBox != undefined ? configObject.Trf_FCPercentTextBox.isVisible : false"
              />
            </el-col>
          </el-row>
          <el-row>
            <el-col :lg="24" :md="24">
              <Trf_AmtTextBox 
                @AmountNumericDecimal-onBlur="(val) => { $emit('Trf_AmtTextBox-onBlur', val); }"
                @AmountNumericDecimal-onChange="(val) => { $emit('Trf_AmtTextBox-onChange', val); }"
                @AmountNumericDecimal-onFocus="(val) => { $emit('Trf_AmtTextBox-onFocus', val); }"
                @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Trf_AmtTextBox-onKeyPress', val, event); }"
                @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Trf_AmtTextBox-onKeyUp', val, event); }"
                v-bind="{ ...Trf_AmtTextBox, ...configObject.Trf_AmtTextBox }"
                :values="configObject.Trf_AmtTextBox.Trf_AmtTextBoxValue" 
                name="Trf_AmtTextBox" ref="RefTrf_AmtTextBox" 
                v-if="configObject.Trf_AmtTextBox != undefined ? configObject.Trf_AmtTextBox.isVisible : false"
              />
            </el-col>
          </el-row>
          <el-row>
            <el-col :lg="24" :md="24">
              <Trf_Date 
                @DateDdMmYyyy-onBlur="val => $emit('Trf_Date-onBlur', val)"
                @DateDdMmYyyy-onChange="val => $emit('Trf_Date-onChange', val)"
                @DateDdMmYyyy-onFocus="val => $emit('Trf_Date-onFocus', val)"
                @DateDdMmYyyy-onKeyPress="(val, event) => $emit('Trf_Date-onKeyPress', val, event)"
                @DateDdMmYyyy-onKeyUp="(val, event) => $emit('Trf_Date-onKeyUp', val, event)"
                v-bind="{ ...Trf_Date, ...configObject.Trf_Date }"
                :values="configObject.Trf_Date.Trf_DateValue" 
                name="Trf_Date" ref="RefTrf_Date" 
                v-if="configObject.Trf_Date != undefined ? configObject.Trf_Date.isVisible : false"
              />
            </el-col>
          </el-row>
          <el-row>
            <el-col :lg="12" :md="12">
              <Trf_CustNoTextBox 
                @CustomerNumberNumeric6-onBlur="(val) => { $emit('Trf_CustNoTextBox-onBlur', val); }"
                @CustomerNumberNumeric6-onKeyPress="(val, event) => { $emit('Trf_CustNoTextBox-onKeyPress', val, event);} "
                @CustomerNumberNumeric6-onFocus="(val) => { $emit('Trf_CustNoTextBox-onFocus', val); }"
                v-bind="{ ...Trf_CustNoTextBox, ...configObject.Trf_CustNoTextBox }"
                :values="configObject.Trf_CustNoTextBox.Trf_CustNoTextBoxValue"
                name="Trf_CustNoTextBox"
                ref="RefTrf_CustNoTextBox"
                v-if="configObject.Trf_CustNoTextBox != undefined ? configObject.Trf_CustNoTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="4" :md="4"></el-col>
            <el-col :lg="7" :md="7">
              <Trf_FCAccountDropDown
                @GenericDropDown-onChange="val => $emit('Trf_FCAccountDropDown-onChange', val)"
                @GenericDropDown-onFocus="val => $emit('Trf_FCAccountDropDown-onFocus', val)"
                @GenericDropDown-onBlur="val => $emit('Trf_FCAccountDropDown-onBlur', val)"
                v-bind="{ ...Trf_FCAccountDropDown, ...configObject.Trf_FCAccountDropDown }"
                :values="configObject.Trf_FCAccountDropDown.Trf_FCAccountDropDownList" 
                name="Trf_FCAccountDropDown" ref="RefTrf_FCAccountDropDown"
                v-if="configObject.Trf_FCAccountDropDown != undefined ? configObject.Trf_FCAccountDropDown.isVisible : false"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
          <el-row>
            <el-col :lg="12" :md="12">
              <Trf_ExchRateTextBox
                @AmountNumericDecimal-onBlur="(val) => { $emit('Trf_ExchRateTextBox-onBlur', val); }"
                @AmountNumericDecimal-onChange="(val) => { $emit('Trf_ExchRateTextBox-onChange', val); }"
                @AmountNumericDecimal-onFocus="(val) => { $emit('Trf_ExchRateTextBox-onFocus', val); }"
                @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Trf_ExchRateTextBox-onKeyPress', val, event); }"
                @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Trf_ExchRateTextBox-onKeyUp', val, event); }"
                v-bind="{ ...Trf_ExchRateTextBox, ...configObject.Trf_ExchRateTextBox }"
                :values="configObject.Trf_ExchRateTextBox.Trf_ExchRateTextBoxValue" 
                name="Trf_ExchRateTextBox" ref="RefTrf_ExchRateTextBox" 
                v-if="configObject.Trf_ExchRateTextBox != undefined ? configObject.Trf_ExchRateTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="4" :md="4"></el-col>
            <el-col :lg="7" :md="7">
              <Trf_LocalEqvTextBox
                @AmountNumericDecimal-onBlur="(val) => { $emit('Trf_LocalEqvTextBox-onBlur', val); }"
                @AmountNumericDecimal-onChange="(val) => { $emit('Trf_LocalEqvTextBox-onChange', val); }"
                @AmountNumericDecimal-onFocus="(val) => { $emit('Trf_LocalEqvTextBox-onFocus', val); }"
                @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Trf_LocalEqvTextBox-onKeyPress', val, event); }"
                @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Trf_LocalEqvTextBox-onKeyUp', val, event); }"
                v-bind="{ ...Trf_LocalEqvTextBox, ...configObject.Trf_LocalEqvTextBox }"
                :values="configObject.Trf_LocalEqvTextBox.Trf_LocalEqvTextBoxValue" 
                name="Trf_LocalEqvTextBox" ref="RefTrf_LocalEqvTextBox" 
                v-if="configObject.Trf_LocalEqvTextBox != undefined ? configObject.Trf_LocalEqvTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
        </fieldset>
        <br>
        <fieldset v-if="configObject.section9 != undefined ? configObject.section9.isVisible : false">
          <el-row>
            <el-col :lg="24" :md="24">
              <Trf_PRCBalTextBox
                @AmountNumericDecimal-onBlur="(val) => { $emit('Trf_PRCBalTextBox-onBlur', val); }"
                @AmountNumericDecimal-onChange="(val) => { $emit('Trf_PRCBalTextBox-onChange', val); }"
                @AmountNumericDecimal-onFocus="(val) => { $emit('Trf_PRCBalTextBox-onFocus', val); }"
                @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Trf_PRCBalTextBox-onKeyPress', val, event); }"
                @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Trf_PRCBalTextBox-onKeyUp', val, event); }"
                v-bind="{ ...Trf_PRCBalTextBox, ...configObject.Trf_PRCBalTextBox }"
                :values="configObject.Trf_PRCBalTextBox.Trf_PRCBalTextBoxValue" 
                name="Trf_PRCBalTextBox" ref="RefTrf_PRCBalTextBox" 
                v-if="configObject.Trf_PRCBalTextBox != undefined ? configObject.Trf_PRCBalTextBox.isVisible : false"
              />
            </el-col>
          </el-row>
          <el-row>
            <el-col :lg="24" :md="24">
              <Trf_LowerAmtTextBox
                @AmountNumericDecimal-onBlur="(val) => { $emit('Trf_LowerAmtTextBox-onBlur', val); }"
                @AmountNumericDecimal-onChange="(val) => { $emit('Trf_LowerAmtTextBox-onChange', val); }"
                @AmountNumericDecimal-onFocus="(val) => { $emit('Trf_LowerAmtTextBox-onFocus', val); }"
                @AmountNumericDecimal-onKeyPress="(val, event) => { $emit('Trf_LowerAmtTextBox-onKeyPress', val, event); }"
                @AmountNumericDecimal-onKeyUp="(val, event) => { $emit('Trf_LowerAmtTextBox-onKeyUp', val, event); }"
                v-bind="{ ...Trf_LowerAmtTextBox, ...configObject.Trf_LowerAmtTextBox }"
                :values="configObject.Trf_LowerAmtTextBox.Trf_LowerAmtTextBoxValue" 
                name="Trf_LowerAmtTextBox" ref="RefTrf_LowerAmtTextBox" 
                v-if="configObject.Trf_LowerAmtTextBox != undefined ? configObject.Trf_LowerAmtTextBox.isVisible : false"
              />
            </el-col>
          </el-row>
          <el-row>
            <el-col :lg="24" :md="24">
              <Trf_BankNameTextBox
                @GenericTextBox-onBlur="val => $emit('Trf_BankNameTextBox-onBlur', val)"
                @GenericTextBox-onChange="val => $emit('Trf_BankNameTextBox-onChange', val)"
                @GenericTextBox-onFocus="val => $emit('Trf_BankNameTextBox-onFocus', val)"
                @GenericTextBox-onKeyPress="(val, event) => $emit('Trf_BankNameTextBox-onKeyPress', val, event)"
                @GenericTextBox-onKeyUp="(val, event) => $emit('Trf_BankNameTextBox-onKeyUp', val, event)"
                @GenericTextBox-onKeyDown="(val, event) => $emit('Trf_BankNameTextBox-onKeyDown', val, event)"
                @GenericTextBox-onInput="(val, event) => { $emit('Trf_BankNameTextBox-onInput', val, event); }"
                @GenericTextBox-onPaste="(event) => { $emit('Trf_BankNameTextBox-onPaste', event); }"
                v-bind="{ ...Trf_BankNameTextBox, ...configObject.Trf_BankNameTextBox }"
                :values="configObject.Trf_BankNameTextBox.Trf_BankNameTextBoxValue" 
                name="Trf_BankNameTextBox" ref="RefTrf_BankNameTextBox" 
                v-if="configObject.Trf_BankNameTextBox != undefined ? configObject.Trf_BankNameTextBox.isVisible : false"
              />
            </el-col>
          </el-row>
          <br><br><br>
        </fieldset>
      </fieldset>
      </el-tab-pane>
      </el-tabs>
      </el-col>
    <el-col :lg="1" :md="1"></el-col>
</el-row>

<!-- Buttons section -->
<el-row>
  <el-col :lg="23" :md="23">
    <fieldset>
      <el-row>
        <el-col :lg="2" :md="2">
          <Ok_button 
            @GenericButton-onClick=" $emit('Ok_button-onClick')"
            v-bind="{ ...Ok_button, ...configObject.Ok_button }" 
            name="Ok_button" ref="RefOk_button"
            v-if="configObject.Ok_button != undefined ? configObject.Ok_button.isVisible : false"
          />
          <Change_button 
            @GenericButton-onClick=" $emit('Change_button-onClick')"
            v-bind="{ ...Change_button, ...configObject.Change_button }" 
            name="Change_button" ref="RefChange_button"
            v-if="configObject.Change_button != undefined ? configObject.Change_button.isVisible : false"
          />
          <Cancel_button 
            @GenericButton-onClick="$emit('Cancel_button-onClick')"
            v-bind="{ ...Cancel_button, ...configObject.Cancel_button }" 
            name="Cancel_button" ref="RefCancel_button"
            v-if="configObject.Cancel_button != undefined ? configObject.Cancel_button.isVisible : false"
          />
          <ReInitiate_button 
            @GenericButton-onClick="$emit('ReInitiate_button-onClick')"
            v-bind="{ ...ReInitiate_button, ...configObject.ReInitiate_button }" 
            name="ReInitiate_button" ref="RefReInitiate_button"
            v-if="configObject.ReInitiate_button != undefined ? configObject.ReInitiate_button.isVisible : false"
          />
          <Reject_button 
            @GenericButton-onClick="$emit('Reject_button-onClick')"
            v-bind="{ ...Reject_button, ...configObject.Reject_button }" 
            name="Reject_button" ref="RefReject_button"
            v-if="configObject.Reject_button != undefined ? configObject.Reject_button.isVisible : false"
          />
          <Return_button 
            @GenericButton-onClick="$emit('Return_button-onClick')"
            v-bind="{ ...Return_button, ...configObject.Return_button }" 
            name="Return_button" ref="RefReturn_button"
            v-if="configObject.Return_button != undefined ? configObject.Return_button.isVisible : false"
          />
          <Modify_button 
            @GenericButton-onClick=" $emit('Modify_button-onClick')"
            v-bind="{ ...Modify_button, ...configObject.Modify_button }" 
            name="Modify_button" ref="RefModify_button"
            v-if="configObject.Modify_button != undefined ? configObject.Modify_button.isVisible : false"
          />
        </el-col>
        <el-col :lg="1" :md="1">
        </el-col>
        <el-col :lg="3" :md="3">
          <Exception_button 
            @GenericButton-onClick="$emit('Exception_button-onClick')"
            v-bind="{ ...Exception_button, ...configObject.Exception_button }" 
            name="Exception_button" ref="RefException_button"
            v-if="configObject.Exception_button != undefined ? configObject.Exception_button.isVisible : false"
          />
        </el-col>
        <el-col :lg="1" :md="1"></el-col>
        <el-col :lg="2" :md="2">
          <FXDetail_button 
            @GenericButton-onClick="$emit('FXDetail_button-onClick')"
            v-bind="{ ...FXDetail_button, ...configObject.FXDetail_button }" 
            name="FXDetail_button" ref="RefFXDetail_button"
            v-if="configObject.FXDetail_button != undefined ? configObject.FXDetail_button.isVisible : false"
          />
        </el-col>
        <el-col :lg="1" :md="1"></el-col>
        <el-col :lg="3" :md="3">
          <ViewDocs_button 
            @GenericButton-onClick="$emit('ViewDocs_button-onClick')"
            v-bind="{ ...ViewDocs_button, ...configObject.ViewDocs_button }" 
            name="ViewDocs_button" ref="RefViewDocs_button"
            v-if="configObject.ViewDocs_button != undefined ? configObject.ViewDocs_button.isVisible : false"
          />
        </el-col>
        <el-col :lg="1" :md="1"></el-col>
        <el-col :lg="3" :md="3">
          <ViewVouch_button 
            @GenericButton-onClick="$emit('ViewVouch_button-onClick')"
            v-bind="{ ...ViewVouch_button, ...configObject.ViewVouch_button }" 
            name="ViewVouch_button" ref="RefViewVouch_button"
            v-if="configObject.ViewVouch_button != undefined ? configObject.ViewVouch_button.isVisible : false"
          />
        </el-col>
        <el-col :lg="2" :md="2"></el-col>
        <el-col :lg="2" :md="2">
          <Back_button 
            @GenericButton-onClick="$emit('Back_button-onClick')"
            v-bind="{ ...Back_button, ...configObject.Back_button }" 
            name="Back_button" ref="RefBack_button"
            v-if="configObject.Back_button != undefined ? configObject.Back_button.isVisible : false"
          />
        </el-col>
        <el-col :lg="1" :md="1"></el-col>
        <el-col :lg="2" :md="2">
          <Exit_button 
            @GenericButton-onClick="$emit('Exit_button-onClick')"
            v-bind="{ ...Exit_button, ...configObject.Exit_button }" 
            name="Exit_button" ref="RefExit_button"
            v-if="configObject.Exit_button != undefined ? configObject.Exit_button.isVisible : false"
          />
        </el-col>
      </el-row>
    </fieldset>
  </el-col>
  <el-col :lg="1" :md="1"></el-col> 
</el-row>


</Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import { reactive } from 'vue';
import {
    AccountNumberNumericDashes21 as AccountNumber,
    NtnNumericDashes9 as NTNNumber,
    GenericTextBox as AccTitleTextBox,
    GenericTextBox as CCINoTextBox,
    GenericRadioButton as BankRadioBtn,
    GenericRadioButton as PSWWebocRadioBtn,
    GenericRadioButton as RedForFERadioBtn,
    GenericTextBox as FwdRefNoTextBox,
    GenericDropDown as SettlementMethodDropDown,

    GenericDropDown as Advance_CurrencyDropDown,
    AmountNumericDecimal as Advance_TotalAmtTextBox,
    AmountNumericDecimal as Advance_NostroAmtTextBox,
    AmountNumericDecimal as Advance_ExchangeRateTextBox,
    AmountNumericDecimal as Advance_AmtLCYTextBox,
    AmountNumericDecimal as Advance_TreasuryRateTextBox,
    AmountNumericDecimal as Advance_FOBValTextBox,
    GenericTextBox as Advance_NostroBankTextBox,
    GenericButton as NostroListButton,
    AmountNumericDecimal as Advance_AdviceNoTextBox,
    GenericTextBox as Advance_CommFCYTextBox,
    GenericDropDown as Advance_IdentifyTypeDropDown,
    GenericTextBox as Advance_IdentifyNoTextBox,
    GenericTextBox as Advance_RemmitInstTextBox,
    GenericTextBox as Advance_IBAN_ACNoTextBox,
    GenericTextBox as Advance_SBPApprovalNoTextBox,
    DateDdMmYyyy as Advance_SBPApprovalDateTextBox,
    GenericTextBox as Advance_BuyerTextBox,
    GenericButton as BuyerListButton,
    GenericTextBox as Advance_CountryReceiptTextBox,
    GenericButton as CountryReceiptListButton,
    GenericTextBox as Advance_CountryTextBox,
    GenericButton as CountryListButton,
    GenericDropDown as Advance_CityDropDown,
    GenericTextBox as Advance_ReimbBankTextBox,
    GenericButton as ReimbBankListButton,
    GenericDropDown as Advance_DestinationDropDown,
    GenericDropDown as Advance_IncoTermsDropDown,
    GenericTextBox as Advance_SwftRefNoTextBox,
    GenericSortableTableView as ChargesTable,
    GenericButton as GetChargesButton,
    GenericButton as ChangeChargesButton,
    AmountNumericDecimal as ShortPay_ShortAmtTextBox,
    AmountNumericDecimal as ShortPay_ExchgRateTextBox,
    AmountNumericDecimal as ShortPay_AmtLCYTextBox,
    AmountNumericDecimal as ShortPay_TreasuryRateTextBox,
    AmountNumericDecimal as ShortPay_TotTranAmtTextBox,
    GenericTextArea as RemarksTextArea,
    GenericTextBox as Eform_AdvpNoTextBox,
    DateDdMmYyyy as Eform_DateTextBox,
    GenericTextBox as Eform_CurrencyTextBox,
    AmountNumericDecimal as Eform_PRCAmtTextBox,
    AmountNumericDecimal as Eform_BalanceTextBox,
    GenericSortableTableView as EFormTable,
    HsCodeNumericDecimal4Point4 as ItemInfo_HsCodeTextBox,
    GenericButton as HSCodeListBtn,
    GenericTextBox as ItemInfo_CommDescTextBox,
    GenericDropDown as ItemInfo_COODropDown,
    GenericDropDown as ItemInfo_UnitsDropDown,
    GenericDropDown as ItemInfo_CurrencyDropDown,
    AmountNumericDecimal as ItemInfo_AmtFCYTextBox,
    AmountNumericDecimal as ItemInfo_QuantityTextBox,
    AmountNumericDecimal as ItemInfo_UnitPriceTextBox,
    GenericButton as ItemInfo_AddItemBtn,
    GenericButton as ItemInfo_ChngItemBtn,
    GenericButton as ItemInfo_RemoveItemBtn,
    GenericSortableTableView as ItemInfoTable,
    GenericTextBox as AI_Bank_BICCodeTextBox,
    GenericDropDown as AI_Port_AirportDropDown,
    GenericTextBox as AI_AgentNameTextBox,
    GenericTextBox as AI_OtherPartyTextBox,
    GenericTextBox as AI_OtherPartyAddrTextBox,
    GenericTextBox as AI_Comment_DescTextBox,
    GenericTextBox as PSW_FinInstNoTextBox,
    DateDdMmYyyy as PSW_FinInstDate,
    GenericTextBox as PSW_ModePayTextBox,
    DateDdMmYyyy as PSW_FinInstExpDate,
    GenericTextBox as PSW_ConsigneeIBANTextBox,
    GenericTextBox as MForm_NoTextBox,
    GenericDropDown as MForm_DeptCdDropDown,
    GenericDropDown as MForm_PurposeCdDropDown,
    AmountNumericDecimal as MForm_ShortAmtTextBox,
    GenericSortableTableView as MFormTable,
    GenericButton as MForm_AddItemBtn,
    GenericButton as MForm_ChngItemBtn,
    GenericButton as MForm_RemoveItemBtn,
    AmountNumericDecimal as Return_AdvBalTextBox,
    AmountNumericDecimal as Return_AmtTextBox,
    AmountNumericDecimal as Return_ExchRateTextBox,
    AmountNumericDecimal as Return_PKRTextBox,
    GenericTextBox as Return_SBPNoTextBox,
    DateDdMmYyyy as Return_SBPDate,
    AmountNumericDecimal as Trf_FCPercentTextBox,
    AmountNumericDecimal as Trf_AmtTextBox,
    DateDdMmYyyy as Trf_Date,
    CustomerNumberNumeric6 as Trf_CustNoTextBox,
    AmountNumericDecimal as Trf_ExchRateTextBox,
    GenericDropDown as Trf_FCAccountDropDown,
    AmountNumericDecimal as Trf_LocalEqvTextBox,
    AmountNumericDecimal as Trf_PRCBalTextBox,
    AmountNumericDecimal as Trf_LowerAmtTextBox,
    GenericTextBox as Trf_BankNameTextBox,
    GenericButton as Ok_button,
    GenericButton as Change_button,
    GenericButton as Cancel_button,
    GenericButton as ReInitiate_button,
    GenericButton as Reject_button,
    GenericButton as Return_button,
    GenericButton as Modify_button,
    GenericButton as Exception_button,
    GenericButton as FXDetail_button,
    GenericButton as ViewDocs_button,
    GenericButton as ViewVouch_button,
    GenericButton as Back_button,
    GenericButton as Exit_button

  } from "@teresol-v2/ui-components";
export default {
  name: 'MegaSet1147',

  components: {
    Form,
    AccountNumber,
      NTNNumber,
      AccTitleTextBox,
      CCINoTextBox,
      BankRadioBtn,
      PSWWebocRadioBtn,
      RedForFERadioBtn,
      FwdRefNoTextBox,
      SettlementMethodDropDown,
      Advance_CurrencyDropDown,
      Advance_TotalAmtTextBox,
      Advance_NostroAmtTextBox,
      Advance_ExchangeRateTextBox,
      Advance_AmtLCYTextBox,
      Advance_TreasuryRateTextBox,
      Advance_FOBValTextBox,
      Advance_NostroBankTextBox,
      NostroListButton,
      Advance_AdviceNoTextBox,
      Advance_CommFCYTextBox,
      Advance_IdentifyTypeDropDown,
      Advance_IdentifyNoTextBox,
      Advance_RemmitInstTextBox,
      Advance_IBAN_ACNoTextBox,
      Advance_SBPApprovalNoTextBox,
      Advance_SBPApprovalDateTextBox,
      Advance_BuyerTextBox,
      BuyerListButton,
      Advance_CountryReceiptTextBox,
      CountryReceiptListButton,
      Advance_CountryTextBox,
      CountryListButton,
      Advance_CityDropDown,
      Advance_ReimbBankTextBox,
      ReimbBankListButton,
      Advance_DestinationDropDown,
      Advance_IncoTermsDropDown,
      Advance_SwftRefNoTextBox,
      ChargesTable,
      GetChargesButton,
      ChangeChargesButton,
      ShortPay_ShortAmtTextBox,
      ShortPay_ExchgRateTextBox,
      ShortPay_AmtLCYTextBox,
      ShortPay_TreasuryRateTextBox,
      ShortPay_TotTranAmtTextBox,
      RemarksTextArea,
      Eform_AdvpNoTextBox,
      Eform_DateTextBox,
      Eform_CurrencyTextBox,
      Eform_PRCAmtTextBox,
      Eform_BalanceTextBox,
      EFormTable,

      ItemInfo_HsCodeTextBox,
      ItemInfo_CommDescTextBox,
      ItemInfo_COODropDown,
      ItemInfo_UnitsDropDown,
      ItemInfo_CurrencyDropDown,
      ItemInfo_AmtFCYTextBox,
      ItemInfo_QuantityTextBox,
      ItemInfo_UnitPriceTextBox,
      HSCodeListBtn,
      ItemInfo_AddItemBtn,
      ItemInfo_ChngItemBtn,
      ItemInfo_RemoveItemBtn,
      ItemInfoTable,

      AI_Bank_BICCodeTextBox,
      AI_Port_AirportDropDown,
      AI_AgentNameTextBox,
      AI_OtherPartyTextBox,
      AI_OtherPartyAddrTextBox,
      AI_Comment_DescTextBox,

      PSW_FinInstNoTextBox,
      PSW_FinInstDate,
      PSW_ModePayTextBox,
      PSW_FinInstExpDate,
      PSW_ConsigneeIBANTextBox,

      MForm_NoTextBox,
      MForm_DeptCdDropDown,
      MForm_PurposeCdDropDown,
      MForm_ShortAmtTextBox,
      MFormTable,
      MForm_AddItemBtn,
      MForm_ChngItemBtn,
      MForm_RemoveItemBtn,

      Return_AdvBalTextBox,
      Return_AmtTextBox,
      Return_ExchRateTextBox,
      Return_PKRTextBox,
      Return_SBPNoTextBox,
      Return_SBPDate,

      Trf_FCPercentTextBox,
      Trf_AmtTextBox,
      Trf_Date,
      Trf_CustNoTextBox,
      Trf_ExchRateTextBox,
      Trf_FCAccountDropDown,
      Trf_LocalEqvTextBox,
      Trf_PRCBalTextBox,
      Trf_LowerAmtTextBox,
      Trf_BankNameTextBox,

      Ok_button,
      Change_button,
      Cancel_button,
      ReInitiate_button,
      Reject_button,
      Return_button,
      Modify_button,
      Exception_button,
      FXDetail_button,
      ViewDocs_button,
      ViewVouch_button,
      Back_button,
      Exit_button
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive(props.configObj.componentProps);

    return {
      onSubmit,
        configObject,
        AccountNumber: { spanLabels: 5, spanInputs: 19 },
        NTNNumber: { spanLabels: 5, spanInputs: 19 },
        AccTitleTextBox : { spanLabels: 5, spanInputs: 19 },
        CCINoTextBox : { spanLabels: 5, spanInputs: 19 },
        BankRadioBtn: { spanLabels: 0, spanInputs: 24 },
        PSWWebocRadioBtn: { spanLabels: 0, spanInputs: 24 },
        RedForFERadioBtn: { spanLabels: 0, spanInputs: 24 },
        FwdRefNoTextBox: { spanLabels: 7, spanInputs: 10 },   
        SettlementMethodDropDown: { spanLabels: 8, spanInputs: 10 },
        Advance_CurrencyDropDown: { spanLabels: 6, spanInputs: 18 },
        Advance_TotalAmtTextBox: { spanLabels: 9, spanInputs: 15 },
        Advance_NostroAmtTextBox: { spanLabels: 6, spanInputs: 10 },
        Advance_ExchangeRateTextBox: { spanLabels: 6, spanInputs: 10 },
        Advance_AmtLCYTextBox: { spanLabels: 6, spanInputs: 10 },
        Advance_TreasuryRateTextBox: { spanLabels: 6, spanInputs: 10 },
        Advance_FOBValTextBox: { spanLabels: 6, spanInputs: 15 },
        Advance_NostroBankTextBox: { spanLabels: 8, spanInputs: 16 },
        NostroListButton: { spanInputs: 24, nativeType: 'button' },
        Advance_AdviceNoTextBox: { spanLabels: 8, spanInputs: 16 },
        Advance_CommFCYTextBox: { spanLabels: 8, spanInputs: 15 },
        Advance_IdentifyTypeDropDown: { spanLabels: 8, spanInputs: 15 },
        Advance_IdentifyNoTextBox: { spanLabels: 8, spanInputs: 15 },
        Advance_RemmitInstTextBox: { spanLabels: 8, spanInputs: 15 },
        Advance_IBAN_ACNoTextBox: { spanLabels: 8, spanInputs: 15 },
        Advance_SBPApprovalNoTextBox: { spanLabels: 8, spanInputs: 15 },
        Advance_SBPApprovalDateTextBox: { spanLabels: 8, spanInputs: 8 },
        Advance_BuyerTextBox: { spanLabels: 7, spanInputs: 17 },
        BuyerListButton: { spanInputs: 24, nativeType: 'button' },
        Advance_CountryReceiptTextBox: { spanLabels: 10, spanInputs: 14 },
        CountryReceiptListButton: { spanInputs: 24, nativeType: 'button' },
        Advance_CountryTextBox: { spanLabels: 7, spanInputs: 17 },
        CountryListButton: { spanInputs: 24, nativeType: 'button' },
        Advance_CityDropDown: { spanLabels: 5, spanInputs: 18 },
        Advance_ReimbBankTextBox: { spanLabels: 7, spanInputs: 17},
        ReimbBankListButton: { spanInputs: 24, nativeType: 'button' },
        Advance_DestinationDropDown: { spanLabels: 5, spanInputs: 18 },
        Advance_IncoTermsDropDown: { spanLabels: 7, spanInputs: 16 },
        Advance_SwftRefNoTextBox: { spanLabels: 7, spanInputs: 16 },
        ChargesTable: { spanLabels: 0, spanInputs:  24},
        GetChargesButton: { spanInputs: 24, nativeType: 'button' },
        ChangeChargesButton: { spanInputs: 24, nativeType: 'button' },
        ShortPay_ShortAmtTextBox: { spanLabels: 3, spanInputs: 6 },
        ShortPay_ExchgRateTextBox: { spanLabels: 3, spanInputs: 6 },
        ShortPay_AmtLCYTextBox: { spanLabels: 3, spanInputs: 6 },
        ShortPay_TreasuryRateTextBox: { spanLabels: 3, spanInputs: 6 },
        ShortPay_TotTranAmtTextBox: { spanLabels: 3, spanInputs: 6 },
        RemarksTextArea: { spanLabels: 0, spanInputs: 24 },
        Eform_AdvpNoTextBox: { spanLabels: 7, spanInputs: 13 },
        Eform_DateTextBox: { spanLabels: 5, spanInputs: 15 },
        Eform_CurrencyTextBox: { spanLabels: 7, spanInputs: 17 },
        Eform_PRCAmtTextBox: { spanLabels: 7, spanInputs: 17 },
        Eform_BalanceTextBox: { spanLabels: 7, spanInputs: 13 },
        EFormTable: { spanLabels: 0, spanInputs:  24},
        ItemInfo_HsCodeTextBox: { spanLabels: 11, spanInputs: 13 },
        HSCodeListBtn: { spanInputs: 15, nativeType: 'button' },
        ItemInfo_CommDescTextBox: { spanLabels: 4, spanInputs: 20 },
        ItemInfo_COODropDown: { spanLabels: 8, spanInputs: 12 },
        ItemInfo_UnitsDropDown: { spanLabels: 7, spanInputs: 17 },
        ItemInfo_CurrencyDropDown: { spanLabels: 8, spanInputs: 12 },
        ItemInfo_AmtFCYTextBox: { spanLabels: 7, spanInputs: 17 },
        ItemInfo_QuantityTextBox: { spanLabels: 11, spanInputs: 13 },
        ItemInfo_UnitPriceTextBox: { spanLabels: 11, spanInputs: 13 },
        ItemInfo_AddItemBtn: { spanInputs: 24, nativeType: 'button' },
        ItemInfo_ChngItemBtn: { spanInputs: 24, nativeType: 'button' },
        ItemInfo_RemoveItemBtn: { spanInputs: 24, nativeType: 'button' },
        ItemInfoTable: { spanLabels: 0, spanInputs:  24},
        AI_Bank_BICCodeTextBox: { spanLabels: 8, spanInputs: 12 },
        AI_Port_AirportDropDown: { spanLabels: 8, spanInputs: 12 },
        AI_AgentNameTextBox: { spanLabels: 8, spanInputs: 12 },
        AI_OtherPartyTextBox: { spanLabels: 8, spanInputs: 12 },
        AI_OtherPartyAddrTextBox: { spanLabels: 8, spanInputs: 12 },
        AI_Comment_DescTextBox: { spanLabels: 8, spanInputs: 12 },
        PSW_FinInstNoTextBox: { spanLabels: 6, spanInputs: 10 },
        PSW_FinInstDate: { spanLabels: 6, spanInputs: 5 },
        PSW_ModePayTextBox: { spanLabels: 6, spanInputs: 5 },
        PSW_FinInstExpDate: { spanLabels: 6, spanInputs: 5 },
        PSW_ConsigneeIBANTextBox: { spanLabels: 6, spanInputs: 10 },
        MForm_NoTextBox: { spanLabels: 4, spanInputs: 8 },
        MForm_PurposeCdDropDown: { spanLabels: 7, spanInputs: 12 },
        MForm_DeptCdDropDown: { spanLabels: 2, spanInputs: 6 },
        MForm_ShortAmtTextBox: { spanLabels: 7, spanInputs: 8 },
        MFormTable: { spanLabels: 0, spanInputs: 24 },
        MForm_AddItemBtn: { spanInputs: 24, nativeType: 'button' },
        MForm_ChngItemBtn: { spanInputs: 24, nativeType: 'button' },
        MForm_RemoveItemBtn: { spanInputs: 24, nativeType: 'button' },
        Return_AdvBalTextBox: { spanLabels: 5, spanInputs: 10 },
        Return_AmtTextBox: { spanLabels: 5, spanInputs: 10 },
        Return_ExchRateTextBox: { spanLabels: 5, spanInputs: 10 },
        Return_PKRTextBox: { spanLabels: 5, spanInputs: 10 },
        Return_SBPNoTextBox: { spanLabels: 5, spanInputs: 10 },
        Return_SBPDate: { spanLabels: 5, spanInputs: 4 },
        Trf_FCPercentTextBox: { spanLabels: 3, spanInputs: 4 },
        Trf_AmtTextBox: { spanLabels: 3, spanInputs: 7 },
        Trf_Date: { spanLabels: 3, spanInputs: 4 },
        Trf_CustNoTextBox: { spanLabels: 6, spanInputs: 8 },
        Trf_ExchRateTextBox: { spanLabels: 6, spanInputs: 8 },
        Trf_FCAccountDropDown: { spanLabels: 9, spanInputs: 15 },
        Trf_LocalEqvTextBox: { spanLabels: 9, spanInputs: 15 },
        Trf_PRCBalTextBox: { spanLabels: 4, spanInputs: 10 },
        Trf_LowerAmtTextBox: { spanLabels: 4, spanInputs: 10 },
        Trf_BankNameTextBox: { spanLabels: 4, spanInputs: 10 },
        Ok_button: { spanInputs: 24, nativeType: 'button' },   
        Change_button: { spanInputs: 24, nativeType: 'button' },
        Cancel_button: { spanInputs: 24, nativeType: 'button' },
        ReInitiate_button: { spanInputs: 24, nativeType: 'button' },
        Reject_button: { spanInputs: 24, nativeType: 'button' },  
        Return_button: { spanInputs: 24, nativeType: 'button' },    
        Modify_button: { spanInputs: 24, nativeType: 'button' },     
        Exception_button: { spanInputs: 24, nativeType: 'button' },      
        FXDetail_button: { spanInputs: 24, nativeType: 'button' },
        ViewDocs_button: { spanInputs: 24, nativeType: 'button' },
        ViewVouch_button: { spanInputs: 24, nativeType: 'button' },
        Back_button: { spanInputs: 24, nativeType: 'button' },
        Exit_button: { spanInputs: 24, nativeType: 'button' },
    };
  }
};
</script>

  <style scoped>
  :deep(.font-bold) {
    font-weight: bold;
  }

  .greenyellow {
    color: greenyellow;
  }

  .red {
    color: red;
  }

  .yellow {
    color: yellow;
  }

  .black {
    color: black;
  }

  :deep(.font-size) {
    font-size: 11px !important;
  }

  :deep(.sumItemfontSize) {
    font-size: 16px !important;
  }

  :deep(.mainHeading) {
    font-size: 20px !important;
  }

</style>
 
