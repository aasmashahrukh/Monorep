// MegaSet1146.stories.js

import MegaSet1146 from "../MegaSet/MegaSet1146.vue";
import { ref } from "vue";
import { action } from "@storybook/addon-actions";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "MegaSet1146",
  component: MegaSet1146,
};

const configurationObject = {
  componentProps: {

    PRCNoTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      PRCNoTextBoxValue: '04564/2023',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('PRC No.'),
      backgroundColor: 'White',
      maxlength: 10
    },

    PRCAmountTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      PRCAmountTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('PRC Amount'),
      backgroundColor: 'White',
      maxlength: 30
    },
    RealizedAmountTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      RealizedAmountTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('Realized Amount'),
      backgroundColor: 'White',
      maxlength: 30
    },
    PRCDateTextBox:{
      dataType:"numericSpecial",
      inputLength: 15,
      tabIndex: "1",
      textColor: "black",
      labelColor: "black",
      labelFontWeight: "none",
      mandatory: false,
      backgroundColor: "white",
      autoFocusTextBox: true,
      textAlignment: "left",
      isDisabled: false,
      isVisible: true,
      label: "PRC Dt.",
      PRCDateTextBoxValue:""
    },
    CCYLabel:{
      isVisible: true,
      label: ""
    },
    ParanthesisLabel:{
      isVisible: true,
    },
    TabPane: {
      activeName: 'FDDCharges'
    },
    FDDCharges: {
      isDisable: ref(false),
      isVisible: ref(true),
      label: 'FDD Charges',
      labelColor: 'black'
    },
    DDTTRadioButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      radioLabel: '',
      backgroundColor: 'white',
      mandatory: ref(true),
      radioDisplay: '',
      DDTTRadioButtonValues: 'WithoutAgency',
      radioGroup: [
        {
          label: 'DD',
          value: 'WithAgency',
          isDisabled: false
        },

        {
          label: 'IT',
          value: 'WithoutAgency',
          isDisabled: false
        }
      ]
    },
    WebocPswRadioButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      radioLabel: '',
      backgroundColor: 'white',
      mandatory: ref(true),
      radioDisplay: '',
      WebocPswRadioButtonValues: 'WithoutAgency',
      radioGroup: [
        {
          label: 'Weboc',
          value: 'WithAgency',
          isDisabled: false
        },

        {
          label: 'PSW',
          value: 'PSW',
          isDisabled: false
        }
      ]
    },
    CurrencyTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Currency',
      backgroundColor: 'white',
      dataType: ref(''),
      inputLength: '10',
      mandatory: ref(true),
      CurrencyTextBoxValue: ''
    },
    CurrencyListButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'List'
    },
    FDDAmountFcyTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      FDDAmountFcyTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('FDD Amount FCY'),
      backgroundColor: 'White',
      maxlength: 30
    },
      ExchangeRateTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      ExchangeRateTextBoxValue: '123.00000',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: true,
      label: ref('Exchange Rate'),
      backgroundColor: 'White',
      maxlength: 30,
      dataType: 'alphaNumericSpecial',
      inputLength: '',
      tabIndex: ''
    },
    LocalEquivalentTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      LocalEquivalentTextBoxValue: '5',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('Local Equivalent'),
      backgroundColor: 'White',
      maxlength: 30
    },
    TreasuryRateTextBox:  {
       isDisabled: ref(false),
      isVisible: ref(true),
      TreasuryRateTextBoxValue: '176.0000',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: true,
      label: ref('Treasury Rate'),
      backgroundColor: 'White',
      maxlength: 30,
      dataType: 'alphaNumericSpecial',
      inputLength: '',
      tabIndex: ''
    },
    FDDCommLcyTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      FDDCommLcyTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      labelColor:'blue',
      mandatory: ref(true),
      label: ref('FDD Comm. LCY'),
      backgroundColor: 'White',
      maxlength: 30
    },

    NostroBankTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Nostro Bank',
      backgroundColor: 'white',
      dataType: ref(''),
      inputLength: '10',
      mandatory: ref(true),
      NostroBankTextBoxValue: ''
    },
    NostroBankListButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'List'
    },
    RespondingBranchDropDown: {
        mandatory: false,
        tabIndex: "",
        isDisabled: false,
        isVisible: true,
        RespondingBranchDropDownDefaultValue: "Normal",
        RespondingBranchDropDownValue: [{ value: "Normal", option: "Normal" }],
        dropDownLabel: "Resp. Brn",
        inputFontWeight : 'normal',
        labelFontWeight :'normal',
        //fontSizeInput :'5px',
      },

      FDDFTTNoTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'FDD/FTT No.',
      backgroundColor: 'white',
      dataType: ref(''),
      labelColor:'blue',
      inputLength: '10',
      mandatory: ref(true),
      FDDFTTNoTextBoxValue: ''
    },
    FDDFTTDateTextBox: {
      dataType:"numericSpecial",
      inputLength: 15,
      tabIndex: "1",
      textColor: "black",
      labelColor: "black",
      labelFontWeight: "none",
      mandatory: false,
      backgroundColor: "white",
      autoFocusTextBox: true,
      textAlignment: "left",
      isDisabled: false,
      isVisible: true,
      label: "FDD/FTTDate",
      FDDFTTDateTextBoxValue:""
    },
    OkButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'OK'
    },
    ViewDocsButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'View Docs'
    },
    BackButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Back'
    },
    ExitButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Exit'
    },
  }
};
const configurationObject1 = {
  componentProps: {

    PRCNoTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      PRCNoTextBoxValue: '04564/2023',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('PRC No.'),
      backgroundColor: 'White',
      maxlength: 10
    },

    PRCAmountTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      PRCAmountTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('PRC Amount'),
      backgroundColor: 'White',
      maxlength: 30
    },
    RealizedAmountTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      RealizedAmountTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('Realized Amount'),
      backgroundColor: 'White',
      maxlength: 30
    },
    PRCDateTextBox:{
      dataType:"numericSpecial",
      inputLength: 15,
      tabIndex: "1",
      textColor: "black",
      labelColor: "black",
      labelFontWeight: "none",
      mandatory: false,
      backgroundColor: "white",
      autoFocusTextBox: true,
      textAlignment: "left",
      isDisabled: false,
      isVisible: true,
      label: "PRC Dt.",
      PRCDateTextBoxValue:""
    },
    CCYLabel:{
      isVisible: true,
      label: ""
    },
    ParanthesisLabel:{
      isVisible: true,
    },
    TabPane: {
      activeName: 'FDDCharges'
    },
    FDDCharges: {
      isDisable: ref(false),
      isVisible: ref(true),
      label: 'FDD Charges',
      labelColor: 'black'
    },
    DDTTRadioButton:{
      isDisabled: ref(false),
      isVisible: ref(false),
      radioLabel: '',
      backgroundColor: 'white',
      mandatory: ref(true),
      radioDisplay: '',
      DDTTRadioButtonValues: 'WithoutAgency',
      radioGroup: [
        {
          label: 'DD',
          value: 'WithAgency',
          isDisabled: false
        },

        {
          label: 'IT',
          value: 'WithoutAgency',
          isDisabled: false
        }
      ]
    },
    WebocPswRadioButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      radioLabel: '',
      backgroundColor: 'white',
      mandatory: ref(true),
      radioDisplay: '',
      WebocPswRadioButtonValues: 'WithoutAgency',
      radioGroup: [
        {
          label: 'Weboc',
          value: 'WithAgency',
          isDisabled: false
        },

        {
          label: 'PSW',
          value: 'PSW',
          isDisabled: false
        }
      ]
    },
    CurrencyTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Currency',
      backgroundColor: 'white',
      dataType: ref(''),
      inputLength: '10',
      mandatory: ref(true),
      CurrencyTextBoxValue: ''
    },
    CurrencyListButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'List'
    },
    FDDAmountFcyTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      FDDAmountFcyTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('FDD Amount FCY'),
      backgroundColor: 'White',
      maxlength: 30
    },
      ExchangeRateTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      ExchangeRateTextBoxValue: '123.00000',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: true,
      label: ref('Exchange Rate'),
      backgroundColor: 'White',
      maxlength: 30,
      dataType: 'alphaNumericSpecial',
      inputLength: '',
      tabIndex: ''
    },
    LocalEquivalentTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      LocalEquivalentTextBoxValue: '5',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('Local Equivalent'),
      backgroundColor: 'White',
      maxlength: 30
    },
    TreasuryRateTextBox:  {
       isDisabled: ref(false),
      isVisible: ref(true),
      TreasuryRateTextBoxValue: '176.0000',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: true,
      label: ref('Treasury Rate'),
      backgroundColor: 'White',
      maxlength: 30,
      dataType: 'alphaNumericSpecial',
      inputLength: '',
      tabIndex: ''
    },
    FDDCommLcyTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      FDDCommLcyTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      labelColor:'blue',
      mandatory: ref(true),
      label: ref('FDD Comm. LCY'),
      backgroundColor: 'White',
      maxlength: 30
    },

    NostroBankTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Nostro Bank',
      backgroundColor: 'white',
      dataType: ref(''),
      inputLength: '10',
      mandatory: ref(true),
      NostroBankTextBoxValue: ''
    },
    NostroBankListButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'List'
    },
    RespondingBranchDropDown: {
        mandatory: false,
        tabIndex: "",
        isDisabled: false,
        isVisible: true,
        RespondingBranchDropDownDefaultValue: "Normal",
        RespondingBranchDropDownValue: [{ value: "Normal", option: "Normal" }],
        dropDownLabel: "Resp. Brn",
        inputFontWeight : 'normal',
        labelFontWeight :'normal',
        //fontSizeInput :'5px',
      },

      FDDFTTNoTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'FDD/FTT No.',
      backgroundColor: 'white',
      dataType: ref(''),
      labelColor:'blue',
      inputLength: '10',
      mandatory: ref(true),
      FDDFTTNoTextBoxValue: ''
    },
    FDDFTTDateTextBox: {
      dataType:"numericSpecial",
      inputLength: 15,
      tabIndex: "1",
      textColor: "black",
      labelColor: "black",
      labelFontWeight: "none",
      mandatory: false,
      backgroundColor: "white",
      autoFocusTextBox: true,
      textAlignment: "left",
      isDisabled: false,
      isVisible: true,
      label: "FDD/FTTDate",
      FDDFTTDateTextBoxValue:""
    },
    OkButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'OK'
    },
    ViewDocsButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'View Docs'
    },
    BackButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Back'
    },
    ExitButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Exit'
    },
  }
};

const configurationObject2 = {
  componentProps: {

    PRCNoTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      PRCNoTextBoxValue: '04564/2023',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('PRC No.'),
      backgroundColor: 'White',
      maxlength: 10
    },

    PRCAmountTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      PRCAmountTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('PRC Amount'),
      backgroundColor: 'White',
      maxlength: 30
    },
    RealizedAmountTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      RealizedAmountTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('Realized Amount'),
      backgroundColor: 'White',
      maxlength: 30
    },
    PRCDateTextBox:{
      dataType:"numericSpecial",
      inputLength: 15,
      tabIndex: "1",
      textColor: "black",
      labelColor: "black",
      labelFontWeight: "none",
      mandatory: false,
      backgroundColor: "white",
      autoFocusTextBox: true,
      textAlignment: "left",
      isDisabled: false,
      isVisible: true,
      label: "PRC Dt.",
      PRCDateTextBoxValue:""
    },
    CCYLabel:{
      isVisible: true,
      label: ""
    },
    ParanthesisLabel:{
      isVisible: true,
    },
    TabPane: {
      activeName: 'FDDCharges'
    },
    FDDCharges: {
      isDisable: ref(false),
      isVisible: ref(true),
      label: 'FDD Charges',
      labelColor: 'black'
    },
    DDTTRadioButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      radioLabel: '',
      backgroundColor: 'white',
      mandatory: ref(true),
      radioDisplay: '',
      DDTTRadioButtonValues: 'WithoutAgency',
      radioGroup: [
        {
          label: 'DD',
          value: 'WithAgency',
          isDisabled: false
        },

        {
          label: 'IT',
          value: 'WithoutAgency',
          isDisabled: false
        }
      ]
    },
    WebocPswRadioButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      radioLabel: '',
      backgroundColor: 'white',
      mandatory: ref(true),
      radioDisplay: '',
      WebocPswRadioButtonValues: 'WithoutAgency',
      radioGroup: [
        {
          label: 'Weboc',
          value: 'WithAgency',
          isDisabled: false
        },

        {
          label: 'PSW',
          value: 'PSW',
          isDisabled: false
        }
      ]
    },
    CurrencyTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Currency',
      backgroundColor: 'white',
      dataType: ref(''),
      inputLength: '10',
      mandatory: ref(true),
      CurrencyTextBoxValue: ''
    },
    CurrencyListButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'List'
    },
    FDDAmountFcyTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      FDDAmountFcyTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('FDD Amount FCY'),
      backgroundColor: 'White',
      maxlength: 30
    },
      ExchangeRateTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      ExchangeRateTextBoxValue: '123.00000',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: true,
      label: ref('Exchange Rate'),
      backgroundColor: 'White',
      maxlength: 30,
      dataType: 'alphaNumericSpecial',
      inputLength: '',
      tabIndex: ''
    },
    LocalEquivalentTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      LocalEquivalentTextBoxValue: '5',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: ref(true),
      label: ref('Local Equivalent'),
      backgroundColor: 'White',
      maxlength: 30
    },
    TreasuryRateTextBox:  {
       isDisabled: ref(false),
      isVisible: ref(true),
      TreasuryRateTextBoxValue: '176.0000',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      mandatory: true,
      label: ref('Treasury Rate'),
      backgroundColor: 'White',
      maxlength: 30,
      dataType: 'alphaNumericSpecial',
      inputLength: '',
      tabIndex: ''
    },
    FDDCommLcyTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      dataType: ref('numericSpecial'),
      FDDCommLcyTextBoxValue: '54564562',
      textColor: 'Black',
      labelColor: 'Black',
      labelFontWeight: 12,
      labelColor:'blue',
      mandatory: ref(true),
      label: ref('FDD Comm. LCY'),
      backgroundColor: 'White',
      maxlength: 30
    },

    NostroBankTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Nostro Bank',
      backgroundColor: 'white',
      dataType: ref(''),
      inputLength: '10',
      mandatory: ref(true),
      NostroBankTextBoxValue: ''
    },
    NostroBankListButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'List'
    },
    RespondingBranchDropDown: {
        mandatory: false,
        tabIndex: "",
        isDisabled: false,
        isVisible: true,
        RespondingBranchDropDownDefaultValue: "Normal",
        RespondingBranchDropDownValue: [{ value: "Normal", option: "Normal" }],
        dropDownLabel: "Resp. Brn",
        inputFontWeight : 'normal',
        labelFontWeight :'normal',
        //fontSizeInput :'5px',
      },

      FDDFTTNoTextBox:  {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'FDD/FTT No.',
      backgroundColor: 'white',
      dataType: ref(''),
      labelColor:'blue',
      inputLength: '10',
      mandatory: ref(true),
      FDDFTTNoTextBoxValue: ''
    },
    FDDFTTDateTextBox: {
      dataType:"numericSpecial",
      inputLength: 15,
      tabIndex: "1",
      textColor: "black",
      labelColor: "black",
      labelFontWeight: "none",
      mandatory: false,
      backgroundColor: "white",
      autoFocusTextBox: true,
      textAlignment: "left",
      isDisabled: false,
      isVisible: true,
      label: "FDD/FTTDate",
      FDDFTTDateTextBoxValue:""
    },
    OkButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'OK'
    },
    ViewDocsButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'View Docs'
    },
    BackButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Back'
    },
    ExitButton:{
      isDisabled: ref(false),
      isVisible: ref(true),
      label: 'Exit'
    },
  }
};

const Template = (args) => ({
  components: { MegaSet1146 },
  setup() {
    return {  args: {
      configObj:{
          componentProps: {
        
            PRCNoTextBox: {
              isDisabled: ref(false),
              isVisible: ref(true),
              dataType: ref('numericSpecial'),
              PRCNoTextBoxValue: '04564/2023',
              textColor: 'Black',
              labelColor: 'Black',
              labelFontWeight: 12,
              mandatory: ref(true),
              label: ref('PRC No.'),
              backgroundColor: 'White',
              maxlength: 10
            },
        
            PRCAmountTextBox: {
              isDisabled: ref(false),
              isVisible: ref(true),
              dataType: ref('numericSpecial'),
              PRCAmountTextBoxValue: '54564562',
              textColor: 'Black',
              labelColor: 'Black',
              labelFontWeight: 12,
              mandatory: ref(true),
              label: ref('PRC Amount'),
              backgroundColor: 'White',
              maxlength: 30
            },
            RealizedAmountTextBox: {
              isDisabled: ref(false),
              isVisible: ref(true),
              dataType: ref('numericSpecial'),
              RealizedAmountTextBoxValue: '54564562',
              textColor: 'Black',
              labelColor: 'Black',
              labelFontWeight: 12,
              mandatory: ref(true),
              label: ref('Realized Amount'),
              backgroundColor: 'White',
              maxlength: 30
            },
            PRCDateTextBox:{
              dataType:"numericSpecial",
              inputLength: 15,
              tabIndex: "1",
              textColor: "black",
              labelColor: "black",
              labelFontWeight: "none",
              mandatory: false,
              backgroundColor: "white",
              autoFocusTextBox: true,
              textAlignment: "left",
              isDisabled: false,
              isVisible: true,
              label: "PRC Dt.",
              PRCDateTextBoxValue:""
            },
            CCYLabel:{
              isVisible: true,
              label: ""
            },
            ParanthesisLabel:{
              isVisible: true,
            },
            TabPane: {
              activeName: 'FDDCharges'
            },
            FDDCharges: {
              isDisable: ref(false),
              isVisible: ref(true),
              label: 'FDD Charges',
              labelColor: 'black'
            },
            DDTTRadioButton:{
              isDisabled: ref(false),
              isVisible: ref(true),
              radioLabel: '',
              backgroundColor: 'white',
              mandatory: ref(true),
              radioDisplay: '',
              DDTTRadioButtonValues: 'WithoutAgency',
              radioGroup: [
                {
                  label: 'DD',
                  value: 'WithAgency',
                  isDisabled: false
                },
        
                {
                  label: 'IT',
                  value: 'WithoutAgency',
                  isDisabled: false
                }
              ]
            },
            WebocPswRadioButton:{
              isDisabled: ref(false),
              isVisible: ref(true),
              radioLabel: '',
              backgroundColor: 'white',
              mandatory: ref(true),
              radioDisplay: '',
              WebocPswRadioButtonValues: 'WithoutAgency',
              radioGroup: [
                {
                  label: 'Weboc',
                  value: 'WithAgency',
                  isDisabled: false
                },
        
                {
                  label: 'PSW',
                  value: 'PSW',
                  isDisabled: false
                }
              ]
            },
            CurrencyTextBox: {
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'Currency',
              backgroundColor: 'white',
              dataType: ref(''),
              inputLength: '10',
              mandatory: ref(true),
              CurrencyTextBoxValue: ''
            },
            CurrencyListButton: {
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'List'
            },
            FDDAmountFcyTextBox: {
              isDisabled: ref(false),
              isVisible: ref(true),
              dataType: ref('numericSpecial'),
              FDDAmountFcyTextBoxValue: '54564562',
              textColor: 'Black',
              labelColor: 'Black',
              labelFontWeight: 12,
              mandatory: ref(true),
              label: ref('FDD Amount FCY'),
              backgroundColor: 'White',
              maxlength: 30
            },
              ExchangeRateTextBox: {
              isDisabled: ref(false),
              isVisible: ref(true),
              ExchangeRateTextBoxValue: '123.00000',
              textColor: 'Black',
              labelColor: 'Black',
              labelFontWeight: 12,
              mandatory: true,
              label: ref('Exchange Rate'),
              backgroundColor: 'White',
              maxlength: 30,
              dataType: 'alphaNumericSpecial',
              inputLength: '',
              tabIndex: ''
            },
            LocalEquivalentTextBox:  {
              isDisabled: ref(false),
              isVisible: ref(true),
              dataType: ref('numericSpecial'),
              LocalEquivalentTextBoxValue: '5',
              textColor: 'Black',
              labelColor: 'Black',
              labelFontWeight: 12,
              mandatory: ref(true),
              label: ref('Local Equivalent'),
              backgroundColor: 'White',
              maxlength: 30
            },
            TreasuryRateTextBox:  {
               isDisabled: ref(false),
              isVisible: ref(true),
              TreasuryRateTextBoxValue: '176.0000',
              textColor: 'Black',
              labelColor: 'Black',
              labelFontWeight: 12,
              mandatory: true,
              label: ref('Treasury Rate'),
              backgroundColor: 'White',
              maxlength: 30,
              dataType: 'alphaNumericSpecial',
              inputLength: '',
              tabIndex: ''
            },
            FDDCommLcyTextBox:  {
              isDisabled: ref(false),
              isVisible: ref(true),
              dataType: ref('numericSpecial'),
              FDDCommLcyTextBoxValue: '54564562',
              textColor: 'Black',
              labelColor: 'Black',
              labelFontWeight: 12,
              labelColor:'blue',
              mandatory: ref(true),
              label: ref('FDD Comm. LCY'),
              backgroundColor: 'White',
              maxlength: 30
            },
        
            NostroBankTextBox: {
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'Nostro Bank',
              backgroundColor: 'white',
              dataType: ref(''),
              inputLength: '10',
              mandatory: ref(true),
              NostroBankTextBoxValue: ''
            },
            NostroBankListButton: {
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'List'
            },
            RespondingBranchDropDown: {
                mandatory: false,
                tabIndex: "",
                isDisabled: false,
                isVisible: true,
                RespondingBranchDropDownDefaultValue: "Normal",
                RespondingBranchDropDownValue: [{ value: "Normal", option: "Normal" }],
                dropDownLabel: "Resp. Brn",
                inputFontWeight : 'normal',
                labelFontWeight :'normal',
                //fontSizeInput :'5px',
              },
        
              FDDFTTNoTextBox:  {
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'FDD/FTT No.',
              backgroundColor: 'white',
              dataType: ref(''),
              labelColor:'blue',
              inputLength: '10',
              mandatory: ref(true),
              FDDFTTNoTextBoxValue: ''
            },
            FDDFTTDateTextBox: {
              dataType:"numericSpecial",
              inputLength: 15,
              tabIndex: "1",
              textColor: "black",
              labelColor: "black",
              labelFontWeight: "none",
              mandatory: false,
              backgroundColor: "white",
              autoFocusTextBox: true,
              textAlignment: "left",
              isDisabled: false,
              isVisible: true,
              label: "FDD/FTTDate",
              FDDFTTDateTextBoxValue:""
            },
            OkButton: {
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'OK'
            },
            ViewDocsButton:{
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'View Docs'
            },
            BackButton:{
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'Back'
            },
            ExitButton:{
              isDisabled: ref(false),
              isVisible: ref(true),
              label: 'Exit'
            },
          }
        
      }
      }};
  },
  template: `<MegaSet1146 v-bind="args" 
    @NameTextBox-onBlur="NameTextBox-onBlur" 
    @AddressTextBox-onBlur="AddressTextBox-onBlur"
    />`,
  methods: {
    "NameTextBox-onBlur": action("NameTextBox-onBlur"),
    "AddressTextBox-onBlur": action("AddressTextBox-onBlur"),
  },

});

const Template_SS1 = (args) => ({
  components: { MegaSet1146 },
  setup() {
    return {  args };
  },
  template: `<MegaSet1146 v-bind="args" 
    @NameTextBox-onBlur="NameTextBox-onBlur" 
    @AddressTextBox-onBlur="AddressTextBox-onBlur"
    />`,
  methods: {
    "NameTextBox-onBlur": action("NameTextBox-onBlur"),
    "AddressTextBox-onBlur": action("AddressTextBox-onBlur"),
  },

});


export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };


export const SS_EXP_619_Set_1 = Template_SS1.bind({});
SS_EXP_619_Set_1.args = { configObj: configurationObject1 };

export const SS_EXP_522_Set_1 = Template_SS1.bind({});
SS_EXP_522_Set_1.args = { configObj: configurationObject2 };
