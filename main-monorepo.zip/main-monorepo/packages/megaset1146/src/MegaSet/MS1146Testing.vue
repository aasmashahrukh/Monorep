<template>
  <Megaset1146 :configObj="configurationObject" @submit="onSubmit" 
   @onSubmit="OkButton"
  />
</template>

<script>
import Megaset1146 from './MegaSet1146.vue';
import { reactive, ref } from 'vue';
// import router from "../../router/index";

export default {
  components: {
    Megaset1146
  },

  setup() {
    return reactive({
      configurationObject: {
        screenTitle: '',
        componentProps: {

          PRCNoTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            dataType: ref('numericSpecial'),
            PRCNoTextBoxValue: '04564/2023',
            textColor: 'Black',
            labelColor: 'Black',
            labelFontWeight: 12,
            mandatory: ref(true),
            label: ref('PRC No.'),
            backgroundColor: 'White',
            maxlength: 10
          },

          PRCAmountTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            dataType: ref('numericSpecial'),
            PRCAmountTextBoxValue: '54564562',
            textColor: 'Black',
            labelColor: 'Black',
            labelFontWeight: 12,
            mandatory: ref(true),
            label: ref('PRC Amount'),
            backgroundColor: 'White',
            maxlength: 30
          },
          RealizedAmountTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            dataType: ref('numericSpecial'),
            RealizedAmountTextBoxValue: '54564562',
            textColor: 'Black',
            labelColor: 'Black',
            labelFontWeight: 12,
            mandatory: ref(true),
            label: ref('Realized Amount'),
            backgroundColor: 'White',
            maxlength: 30
          },
          PRCDateTextBox:{
            dataType:"numericSpecial",
	          inputLength: 15,
            tabIndex: "1",
            textColor: "black",
            labelColor: "black",
            labelFontWeight: "none",
            mandatory: false,
            backgroundColor: "white",
            autoFocusTextBox: true,
            textAlignment: "left",
            isDisabled: false,
            isVisible: true,
            label: "PRC Dt.",
            PRCDateTextBoxValue:"12/12/2023"
          },
          CCYLabel:{
            isVisible: true,
            label: ""
          },
          ParanthesisLabel:{
            isVisible: true,
          },
          TabPane: {
            activeName: 'FDDCharges'
          },
          FDDCharges: {
            isDisable: ref(false),
            isVisible: ref(true),
            label: 'FDD Charges',
            labelColor: 'black'
          },
          DDTTRadioButton:{
            isDisabled: ref(false),
            isVisible: ref(true),
            radioLabel: '',
            backgroundColor: 'white',
            mandatory: ref(true),
            radioDisplay: '',
            DDTTRadioButtonValues: 'WithoutAgency',
            radioGroup: [
              {
                label: 'DD',
                value: 'WithAgency',
                isDisabled: false
              },

              {
                label: 'IT',
                value: 'WithoutAgency',
                isDisabled: false
              }
            ]
          },
          WebocPswRadioButton:{
            isDisabled: ref(false),
            isVisible: ref(true),
            radioLabel: '',
            backgroundColor: 'white',
            mandatory: ref(true),
            radioDisplay: '',
            WebocPswRadioButtonValues: 'WithoutAgency',
            radioGroup: [
              {
                label: 'Weboc',
                value: 'WithAgency',
                isDisabled: false
              },

              {
                label: 'PSW',
                value: 'PSW',
                isDisabled: false
              }
            ]
          },
          CurrencyTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'Currency',
            backgroundColor: 'white',
            dataType: ref(''),
            inputLength: '10',
            mandatory: ref(true),
            CurrencyTextBoxValue: ''
          },
          CurrencyListButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'List'
          },
          FDDAmountFcyTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            dataType: ref('numericSpecial'),
            FDDAmountFcyTextBoxValue: '54564562',
            textColor: 'Black',
            labelColor: 'Black',
            labelFontWeight: 12,
            mandatory: ref(true),
            label: ref('FDD Amount FCY'),
            backgroundColor: 'White',
            maxlength: 30
          },
            ExchangeRateTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            ExchangeRateTextBoxValue: '40',
            textColor: 'Black',
            labelColor: 'Black',
            labelFontWeight: 12,
            mandatory: true,
            label: ref('Exchange Rate'),
            backgroundColor: 'White',
            maxlength: 30,
            dataType: 'alphaNumericSpecial',
            inputLength: '',
            tabIndex: ''
          },
          LocalEquivalentTextBox:  {
            isDisabled: ref(false),
            isVisible: ref(true),
            dataType: ref('numericSpecial'),
            LocalEquivalentTextBoxValue: '5343411',
            textColor: 'Black',
            labelColor: 'Black',
            labelFontWeight: 12,
            mandatory: ref(true),
            label: ref('Local Equivalent'),
            backgroundColor: 'White',
            maxlength: 30
          },
          TreasuryRateTextBox:  {
             isDisabled: ref(false),
            isVisible: ref(true),
            TreasuryRateTextBoxValue: '176',
            textColor: 'Black',
            labelColor: 'Black',
            labelFontWeight: 12,
            mandatory: true,
            label: ref('Treasury Rate'),
            backgroundColor: 'White',
            maxlength: 30,
            dataType: 'alphaNumericSpecial',
            inputLength: '',
            tabIndex: ''
          },
          FDDCommLcyTextBox:  {
            isDisabled: ref(false),
            isVisible: ref(true),
            dataType: ref('numericSpecial'),
            FDDCommLcyTextBoxValue: '543',
            textColor: 'Black',
            labelColor: 'Black',
            labelFontWeight: 12,
            labelColor:'blue',
            mandatory: ref(true),
            label: ref('FDD Comm. LCY'),
            backgroundColor: 'White',
            maxlength: 30
          },
          NostroBankTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'Nostro Bank',
            backgroundColor: 'white',
            dataType: ref(''),
            inputLength: '10',
            mandatory: ref(true),
            NostroBankTextBoxValue: 'nostro'
          },
          NostroBankListButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'List'
          },
          RespondingBranchDropDown: {
              mandatory: false,
              tabIndex: "",
              isDisabled: false,
              isVisible: true,
              RespondingBranchDropDownDefaultValue: "Normal",
              RespondingBranchDropDownValue: [{ value: "Normal", option: "Normal" }],
              dropDownLabel: "Resp. Brn",
              inputFontWeight : 'normal',
              labelFontWeight :'normal',
              //fontSizeInput :'5px',
            },

            FDDFTTNoTextBox:  {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'FDD/FTT No.',
            backgroundColor: 'white',
            dataType: ref(''),
            labelColor:'blue',
            inputLength: '10',
            mandatory: ref(true),
            FDDFTTNoTextBoxValue: '4323'
          },
          FDDFTTDateTextBox: {
            dataType:"numericSpecial",
	          inputLength: 15,
            tabIndex: "1",
            textColor: "black",
            labelColor: "black",
            labelFontWeight: "none",
            mandatory: false,
            backgroundColor: "white",
            autoFocusTextBox: true,
            textAlignment: "left",
            isDisabled: false,
            isVisible: true,
            label: "FDD/FTTDate",
            FDDFTTDateTextBoxValue:"12/12/2022"
          },
          OkButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'OK'
          },
          ViewDocsButton:{
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'View Docs'
          },
          BackButton:{
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'Back'
          },
          ExitButton:{
            isDisabled: ref(false),
            isVisible: ref(true),
            label: 'Exit'
          },
        }
      }
    });
  }
};
</script>