<template>
  <Form as="el-form" @submit="onSubmit" @invalid-submit="onInvalidSubmit">
    <fieldset>
      <el-row>
        <el-col :lg="6" :md="6" :sm="6">
          <LcNumberWithNumericDashes10
            @LcNumberWithNumericDashes10-onBlur="
              (val) => {
                $emit('PRCNoTextBox-onBlur', val);
              }
            "
            @LcNumberWithNumericDashes10-onChange="
              (val) => {
                $emit('PRCNoTextBox-onChange', val);
              }
            "
            @LcNumberWithNumericDashes10-onKeyup="
              (val) => {
                $emit('PRCNoTextBox-onKeyup', val);
              }
            "
            @LcNumberWithNumericDashes10-onKeypress="
              (val) => {
                $emit('PRCNoTextBox-onKeypress', val);
              }
            "
            @LcNumberWithNumericDashes10-onFocus="
              (val) => {
                $emit('PRCNoTextBox-onFocus', val);
              }
            "
            v-bind="{ ...PRCNoTextBox, ...configObject.PRCNoTextBox }"
            :values="configObject.PRCNoTextBox.PRCNoTextBoxValue"
            name="PRCNoTextBox"
            ref="RefPRCNoTextBox"
            v-if="configObject.PRCNoTextBox != undefined ? configObject.PRCNoTextBox.isVisible : false"
          />
        </el-col>
        <el-col :lg="9" :md="9" :sm="9">
          <AmountNumericDecimal17Point2
            @AmountNumericDecimal17Point2-onBlur="
              (val) => {
                $emit('PRCAmountTextBox-onBlur', val);
              }
            "
            @AmountNumericDecimal17Point2-onChange="
              (val) => {
                $emit('PRCAmountTextBox-onChange', val);
              }
            "
            @AmountNumericDecimal17Point2-onKeyup="
              (val) => {
                $emit('PRCAmountTextBox-onKeyup', val);
              }
            "
            @AmountNumericDecimal17Point2-onKeypress="
              (val) => {
                $emit('PRCAmountTextBox-onKeypress', val);
              }
            "
            @AmountNumericDecimal17Point2-onFocus="
              (val) => {
                $emit('PRCAmountTextBox-onFocus', val);
              }
            "
            v-bind="{ ...PRCAmountTextBox, ...configObject.PRCAmountTextBox }"
            :values="configObject.PRCAmountTextBox.PRCAmountTextBoxValue"
            name="PRCAmountTextBox"
            ref="RefPRCAmountTextBox"
            v-if="configObject.PRCAmountTextBox != undefined ? configObject.PRCAmountTextBox.isVisible : false"
          />
        </el-col>
        <el-col :lg="9" :md="9" :sm="9">
          <AmountNumericDecimal17Point2
            @AmountNumericDecimal17Point2-onBlur="
              (val) => {
                $emit('RealizedAmountTextBox-onBlur', val);
              }
            "
            @AmountNumericDecimal17Point2-onChange="
              (val) => {
                $emit('RealizedAmountTextBox-onChange', val);
              }
            "
            @AmountNumericDecimal17Point2-onKeyup="
              (val) => {
                $emit('RealizedAmountTextBox-onKeyup', val);
              }
            "
            @AmountNumericDecimal17Point2-onKeypress="
              (val) => {
                $emit('RealizedAmountTextBox-onKeypress', val);
              }
            "
            @AmountNumericDecimal17Point2-onFocus="
              (val) => {
                $emit('RealizedAmountTextBox-onFocus', val);
              }
            "
            v-bind="{ ...RealizedAmountTextBox, ...configObject.RealizedAmountTextBox }"
            :values="configObject.RealizedAmountTextBox.RealizedAmountTextBoxValue"
            name="RealizedAmountTextBox"
            ref="RefRealizedAmountTextBox"
            v-if="configObject.RealizedAmountTextBox != undefined ? configObject.RealizedAmountTextBox.isVisible : false"
          />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="6" :md="6" :sm="6">
          <DateDdMmYyyy
            @DateDdMmYyyy-onBlur="
              (val) => {
                $emit('PRCDateTextBox-onBlur', val);
              }
            "
            v-bind="{
              ...PRCDateTextBox,
              ...configObject.PRCDateTextBox
            }"
            :values="configObject.PRCDateTextBox.PRCDateTextBoxValue"
            name="PRCDateTextBox"
            ref="RefPRCDateTextBox"
            v-if="configObject.PRCDateTextBox != undefined ? configObject.PRCDateTextBox.isVisible : false"
          />
        </el-col>

        <el-col :lg="8" :md="8" :sm="8">
          <el-row>
            <el-col :lg="7" :md="7" :sm="7"> </el-col>

            <el-col :lg="2" :md="2" :sm="2">
              <el-form-item v-if="configObject.ParanthesisLabel != undefined ? configObject.ParanthesisLabel.isVisible : false"> ( </el-form-item>
            </el-col>

            <el-col :lg="3" :md="3" :sm="3">
              <el-form-item v-if="configObject.CCYLabel != undefined ? configObject.CCYLabel.isVisible : false">
                {{ configObject.CCYLabel.label }}
              </el-form-item>
            </el-col>

            <el-col :lg="1" :md="1" :sm="1">
              <el-form-item v-if="configObject.ParanthesisLabel != undefined ? configObject.ParanthesisLabel.isVisible : false"> ) </el-form-item>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
    </fieldset>
    <el-tabs
      v-model="configObject.TabPane.activeName"
      class="demo-tabs"
      type="card"
      @update:model-value="($event) => $emit('handleTabClick', $event)"
    >
      <el-tab-pane
        name="FDDCharges"
        :disabled="configObject.FDDCharges.isDisable"
        :label="configObject.FDDCharges.label"
        v-if="configObject.FDDCharges != undefined ? configObject.FDDCharges.isVisible : false"
        :inputColor="configObject.FDDCharges.inputColor"
      >
        <el-row>
          <el-col :lg="4" :md="4" :sm="4">
            <GenericRadioButton
              name="DDTTRadioButton"
              @GenericRadioButton-onChange="
                (val) => {
                  $emit('DDTTRadioButton-onChange', val);
                }
              "
              ref="RefDDTTRadioButton"
              v-bind="{
                ...DDTTRadioButton,
                ...configObject.DDTTRadioButton
              }"
              :values="configObject.DDTTRadioButton.DDTTRadioButtonValues"
              v-if="configObject.DDTTRadioButton != undefined ? configObject.DDTTRadioButton.isVisible : false"
            />
          </el-col>

          <el-col :lg="12" :md="12" :sm="12"></el-col>
          <el-col :lg="4" :md="5" :sm="5">
            <GenericRadioButton
              name="WebocPswRadioButton"
              @GenericRadioButton-onChange="
                (val) => {
                  $emit('WebocPswRadioButton-onChange', val);
                }
              "
              ref="RefWebocPswRadioButton"
              v-bind="{
                ...WebocPswRadioButton,
                ...configObject.WebocPswRadioButton
              }"
              :values="configObject.WebocPswRadioButton.WebocPswRadioButtonValues"
              v-if="configObject.WebocPswRadioButton != undefined ? configObject.WebocPswRadioButton.isVisible : false"
            />
          </el-col>
        </el-row>

        <fieldset>
          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <GenericTextBox
                name="FDDFTTNoTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('FDDFTTNoTextBox-onBlur', val);
                  }
                "
                @GenericTextBox-onKeyPress="
                  (val, event) => {
                    $emit('FDDFTTNoTextBox-onKeyPress', { val, event });
                  }
                "
                @GenericTextBox-onKeyUp="
                  (val) => {
                    $emit('FDDFTTNoTextBox-onKeyUp', val);
                  }
                "
                ref="RefFDDFTTNoTextBox"
                v-bind="{
                  ...FDDFTTNoTextBox,
                  ...configObject.FDDFTTNoTextBox
                }"
                :values="configObject.FDDFTTNoTextBox.FDDFTTNoTextBoxValue"
                v-if="configObject.FDDFTTNoTextBox != undefined ? configObject.FDDFTTNoTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="14" :md="14" :sm="14"> </el-col>
          </el-row>
          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <DateDdMmYyyy
                @DateDdMmYyyy-onBlur="
                  (val) => {
                    $emit('FDDFTTDateTextBox-onBlur', val);
                  }
                "
                v-bind="{
                  ...FDDFTTDateTextBox,
                  ...configObject.FDDFTTDateTextBox
                }"
                :values="configObject.FDDFTTDateTextBox.FDDFTTDateTextBoxValue"
                name="FDDFTTDateTextBox"
                ref="RefFDDFTTDateTextBox"
                v-if="configObject.FDDFTTDateTextBox != undefined ? configObject.FDDFTTDateTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="14" :md="14" :sm="14"> </el-col>
          </el-row>
          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <CurrencyAlphaNumericSpecial25
                name="CurrencyTextBox"
                @CurrencyAlphaNumericSpecial25-onBlur="
                  (val) => {
                    $emit('CurrencyTextBox-onBlur', val);
                  }
                "
                @CurrencyAlphaNumericSpecial25-onKeyPress="
                  (val, event) => {
                    $emit('CurrencyTextBox-onKeyPress', { val, event });
                  }
                "
                @CurrencyAlphaNumericSpecial25-onKeyUp="
                  (val) => {
                    $emit('CurrencyTextBox-onKeyUp', val);
                  }
                "
                @CurrencyAlphaNumericSpecial25-onChange="
                  (val) => {
                    $emit('CurrencyTextBox-onChange', val);
                  }
                "
                @CurrencyAlphaNumericSpecial25-onFocus="
                  (val) => {
                    $emit('CurrencyTextBox-onFocus', val);
                  }
                "
                ref="RefCurrencyTextBox"
                v-bind="{
                  ...CurrencyTextBox,
                  ...configObject.CurrencyTextBox
                }"
                :values="configObject.CurrencyTextBox.CurrencyTextBoxValue"
                v-if="configObject.CurrencyTextBox != undefined ? configObject.CurrencyTextBox.isVisible : false"
              />
            </el-col>

            <el-col :lg="2" :md="2" :sm="2">
              <GenericButton
                name="CurrencyListButton"
                @GenericButton-onClick="$emit('CurrencyListButton-onClick')"
                ref="RefCurrencyListButton"
                v-bind="{ ...CurrencyListButton, ...configObject.CurrencyListButton }"
                v-if="configObject.CurrencyListButton != undefined ? configObject.CurrencyListButton.isVisible : false"
              />
            </el-col>

            <el-col :lg="12" :md="12" :sm="12"> </el-col>
          </el-row>

          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <AmountNumericDecimal17Point2
                @AmountNumericDecimal17Point2-onBlur="
                  (val) => {
                    $emit('FDDAmountFcyTextBox-onBlur', val);
                  }
                "
                @AmountNumericDecimal17Point2-onChange="
                  (val) => {
                    $emit('FDDAmountFcyTextBox-onChange', val);
                  }
                "
                @AmountNumericDecimal17Point2-onKeyup="
                  (val) => {
                    $emit('FDDAmountFcyTextBox-onKeyup', val);
                  }
                "
                @AmountNumericDecimal17Point2-onKeypress="
                  (val) => {
                    $emit('FDDAmountFcyTextBox-onKeypress', val);
                  }
                "
                @AmountNumericDecimal17Point2-onFocus="
                  (val) => {
                    $emit('FDDAmountFcyTextBox-onFocus', val);
                  }
                "
                v-bind="{ ...FDDAmountFcyTextBox, ...configObject.FDDAmountFcyTextBox }"
                :values="configObject.FDDAmountFcyTextBox.FDDAmountFcyTextBoxValue"
                name="FDDAmountFcyTextBox"
                ref="RefFDDAmountFcyTextBox"
                v-if="configObject.FDDAmountFcyTextBox != undefined ? configObject.FDDAmountFcyTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="14" :md="14" :sm="14"> </el-col>
          </el-row>
          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <ExchangeRateNumericDecimal4Point5
                @ExchangeRateNumericDecimal4Point5-onChange="
                  (val) => {
                    $emit('ExchangeRateTextBox-onChange', val);
                  }
                "
                @ExchangeRateNumericDecimal4Point5-onKeypress="
                  (val) => {
                    $emit('ExchangeRateTextBox-onKeypress', val);
                  }
                "
                @ExchangeRateNumericDecimal4Point5-onBlur="
                  (val) => {
                    $emit('ExchangeRateTextBox-onBlur', val);
                  }
                "
                @ExchangeRateNumericDecimal4Point5-onKeyup="
                  (val) => {
                    $emit('ExchangeRateTextBox-onKeyup', val);
                  }
                "
                @ExchangeRateNumericDecimal4Point5-onFocus="
                  (val) => {
                    $emit('ExchangeRateTextBox-onFocus', val);
                  }
                "
                v-bind="{
                  ...ExchangeRateTextBox,
                  ...configObject.ExchangeRateTextBox
                }"
                :values="configObject.ExchangeRateTextBox.ExchangeRateTextBoxValue"
                name="ExchangeRateTextBox"
                ref="RefExchangeRateTextBox"
                v-if="configObject.ExchangeRateTextBox != undefined ? configObject.ExchangeRateTextBox.isVisible : false"
              >
              </ExchangeRateNumericDecimal4Point5>
            </el-col>
            <el-col :lg="14" :md="14" :sm="14"> </el-col>
          </el-row>
          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <AmountNumericDecimal17Point2
                @AmountNumericDecimal17Point2-onBlur="
                  (val) => {
                    $emit('LocalEquivalentTextBox-onBlur', val);
                  }
                "
                @AmountNumericDecimal17Point2-onChange="
                  (val) => {
                    $emit('LocalEquivalentTextBox-onChange', val);
                  }
                "
                @AmountNumericDecimal17Point2-onKeyup="
                  (val) => {
                    $emit('LocalEquivalentTextBox-onKeyup', val);
                  }
                "
                @AmountNumericDecimal17Point2-onKeypress="
                  (val) => {
                    $emit('LocalEquivalentTextBox-onKeypress', val);
                  }
                "
                @AmountNumericDecimal17Point2-onFocus="
                  (val) => {
                    $emit('LocalEquivalentTextBox-onFocus', val);
                  }
                "
                v-bind="{ ...LocalEquivalentTextBox, ...configObject.LocalEquivalentTextBox }"
                :values="configObject.LocalEquivalentTextBox.LocalEquivalentTextBoxValue"
                name="LocalEquivalentTextBox"
                ref="RefLocalEquivalentTextBox"
                v-if="configObject.LocalEquivalentTextBox != undefined ? configObject.LocalEquivalentTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="14" :md="14" :sm="14"> </el-col>
          </el-row>
          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <ExchangeRateNumericDecimal4Point5
                @ExchangeRateNumericDecimal4Point5-onChange="
                  (val) => {
                    $emit('TreasuryRateTextBox-onChange', val);
                  }
                "
                @ExchangeRateNumericDecimal4Point5-onKeypress="
                  (val) => {
                    $emit('TreasuryRateTextBox-onKeypress', val);
                  }
                "
                @ExchangeRateNumericDecimal4Point5-onBlur="
                  (val) => {
                    $emit('TreasuryRateTextBox-onBlur', val);
                  }
                "
                @ExchangeRateNumericDecimal4Point5-onKeyup="
                  (val) => {
                    $emit('TreasuryRateTextBox-onKeyup', val);
                  }
                "
                @ExchangeRateNumericDecimal4Point5-onFocus="
                  (val) => {
                    $emit('TreasuryRateTextBox-onFocus', val);
                  }
                "
                v-bind="{
                  ...TreasuryRateTextBox,
                  ...configObject.TreasuryRateTextBox
                }"
                :values="configObject.TreasuryRateTextBox.TreasuryRateTextBoxValue"
                name="TreasuryRateTextBox"
                ref="RefTreasuryRateTextBox"
                v-if="configObject.TreasuryRateTextBox != undefined ? configObject.TreasuryRateTextBox.isVisible : false"
              >
              </ExchangeRateNumericDecimal4Point5>
            </el-col>
            <el-col :lg="5" :md="5" :sm="5"> </el-col>
            <el-col :lg="9" :md="9" :sm="9">
              <AmountNumericDecimal17Point2
                @AmountNumericDecimal17Point2-onBlur="
                  (val) => {
                    $emit('FDDCommLcyTextBox-onBlur', val);
                  }
                "
                @AmountNumericDecimal17Point2-onChange="
                  (val) => {
                    $emit('FDDCommLcyTextBox-onChange', val);
                  }
                "
                @AmountNumericDecimal17Point2-onKeyup="
                  (val) => {
                    $emit('FDDCommLcyTextBox-onKeyup', val);
                  }
                "
                @AmountNumericDecimal17Point2-onKeypress="
                  (val) => {
                    $emit('FDDCommLcyTextBox-onKeypress', val);
                  }
                "
                @AmountNumericDecimal17Point2-onFocus="
                  (val) => {
                    $emit('FDDCommLcyTextBox-onFocus', val);
                  }
                "
                v-bind="{ ...FDDCommLcyTextBox, ...configObject.FDDCommLcyTextBox }"
                :values="configObject.FDDCommLcyTextBox.FDDCommLcyTextBoxValue"
                name="FDDCommLcyTextBox"
                ref="RefFDDCommLcyTextBox"
                v-if="configObject.FDDCommLcyTextBox != undefined ? configObject.FDDCommLcyTextBox.isVisible : false"
              />
            </el-col>
          </el-row>

          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <GenericTextBox
                name="NostroBankTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('NostroBankTextBox-onBlur', val);
                  }
                "
                @GenericTextBox-onKeyPress="
                  (val, event) => {
                    $emit('NostroBankTextBox-onKeyPress', { val, event });
                  }
                "
                @GenericTextBox-onKeyUp="
                  (val) => {
                    $emit('NostroBankTextBox-onKeyUp', val);
                  }
                "
                ref="RefNostroBankTextBox"
                v-bind="{
                  ...NostroBankTextBox,
                  ...configObject.NostroBankTextBox
                }"
                :values="configObject.NostroBankTextBox.NostroBankTextBoxValue"
                v-if="configObject.NostroBankTextBox != undefined ? configObject.NostroBankTextBox.isVisible : false"
              />
            </el-col>

            <el-col :lg="2" :md="2" :sm="2">
              <GenericButton
                name="NostroBankListButton"
                @GenericButton-onClick="$emit('NostroBankListButton-onClick')"
                ref="RefNostroBankListButton"
                v-bind="{ ...NostroBankListButton, ...configObject.NostroBankListButton }"
                v-if="configObject.NostroBankListButton != undefined ? configObject.NostroBankListButton.isVisible : false"
              />
            </el-col>

            <el-col :lg="12" :md="12" :sm="12"> </el-col>
          </el-row>

          <el-row>
            <el-col :lg="10" :md="10" :sm="10">
              <GenericDropDown
                @GenericDropDown-onChange="
                  (val) => {
                    $emit('RespondingBranchDropDown-onChange', val);
                  }
                "
                ref="RefRespondingBranchDropDown"
                v-bind="{
                  ...RespondingBranchDropDown,
                  ...configObject.RespondingBranchDropDown
                }"
                name="RespondingBranchDropDown"
                :defaultValue="configObject.RespondingBranchDropDown.RespondingBranchDropDownDefaultValue"
                :values="configObject.RespondingBranchDropDown.RespondingBranchDropDownValue"
                v-if="configObject.RespondingBranchDropDown != undefined ? configObject.RespondingBranchDropDown.isVisible : false"
              />
            </el-col>

            <el-col :lg="16" :md="16" :sm="16"> </el-col>
          </el-row>
        </fieldset>
      </el-tab-pane>
    </el-tabs>

    <fieldset>
      <el-row>
        <el-col :lg="3" :md="3" :sm="3">
          <GenericButton
            name="OkButton"
            @GenericButton-onClick="$emit('OkButton-onClick')"
            ref="RefOkButton"
            v-bind="{ ...OkButton, ...configObject.OkButton }"
            v-if="configObject.OkButton != undefined ? configObject.OkButton.isVisible : false"
          />
        </el-col>
        <el-col :lg="6" :md="6" :sm="6"></el-col>
        <el-col :lg="3" :md="3" :sm="3">
          <GenericButton
            name="ViewDocsButton"
            @GenericButton-onClick="$emit('ViewDocsButton-onClick')"
            ref="RefViewDocsButton"
            v-bind="{ ...ViewDocsButton, ...configObject.ViewDocsButton }"
            v-if="configObject.ViewDocsButton != undefined ? configObject.ViewDocsButton.isVisible : false"
          />
        </el-col>
        <el-col :lg="6" :md="6" :sm="6"></el-col>

        <el-col :lg="3" :md="3" :sm="3">
          <GenericButton
            name="BackButton"
            @GenericButton-onClick="$emit('BackButton-onClick')"
            ref="RefBackButton"
            v-bind="{ ...BackButton, ...configObject.BackButton }"
            v-if="configObject.BackButton != undefined ? configObject.BackButton.isVisible : false"
          />
        </el-col>
        <el-col :lg="3" :md="3" :sm="3">
          <GenericButton
            name="ExitButton"
            @GenericButton-onClick="$emit('ExitButton-onClick')"
            ref="RefExitButton"
            v-bind="{ ...ExitButton, ...configObject.ExitButton }"
            v-if="configObject.ExitButton != undefined ? configObject.ExitButton.isVisible : false"
        /></el-col>
      </el-row>
    </fieldset>
  </Form>
</template>

<script>
import { reactive, ref } from 'vue';
import { ElMessageBox } from 'element-plus';
import { Form, useForm } from 'vee-validate';
import {
  LcNumberWithNumericDashes10,
  AmountNumericDecimal17Point2,
  ExchangeRateNumericDecimal4Point5,
  GenericTextBox,
  GenericButton,
  CurrencyAlphaNumericSpecial25,
  GenericDropDown,
  DateDdMmYyyy,
  GenericRadioButton
} from '@teresol-v2/ui-components';
export default {
  name: 'Megaset1146',
  components: {
    Form,
    LcNumberWithNumericDashes10,
    AmountNumericDecimal17Point2,
    ExchangeRateNumericDecimal4Point5,
    GenericTextBox,
    GenericButton,
    CurrencyAlphaNumericSpecial25,
    GenericDropDown,
    DateDdMmYyyy,
    GenericRadioButton
  },
  props: {
    //Add configuration object details
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();

    function onSubmit(values) {
      emit('onSubmit', values);
    }

    function onInvalidSubmit({ values, errors, results }) {
      let keyValueString = '';
      for (const key in errors) {
        let label = configObject[key].label
        if(label==undefined){
          label = configObject[key].dropDownLabel
        }
        if(label==undefined){
          label = configObject[key].datePickerLabel
        }
        if(label==undefined){
          label = configObject[key].checkBoxLabel
        }
        if(label==undefined){
          label = configObject[key].radioLabel
        }
        keyValueString += `<b>${label}</b>: "${errors[key]}"<br>`;
      }

      keyValueString = keyValueString.slice(0, -2);
      ElMessageBox.alert(keyValueString, 'Message', {
        draggable: true,
        showClose: false,
        autofocus: true,
        closeOnClickModal: false,
        closeOnPressEscape: false,
        dangerouslyUseHTMLString: true,
        customClass: "errorClass",
      })
    }


    const configObject = reactive(props.configObj.componentProps);

    return {
      onSubmit,
      onInvalidSubmit,
      configObject,

      PRCNoTextBox: {
        spanInputs: 13, // this property to be set on screen level
        spanLabels: 7 // this property to be set on screen level
      },

      PRCAmountTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level
      },

      RealizedAmountTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },

      PRCDateTextBox: {
        spanInputs: 13, // this property to be set on screen level
        spanLabels: 7 // this property to be set on screen levelbackgroundColor: "white",
      },

      DDTTRadioButton: {
        spanInputs: 20, // this property to be set on screen level
        spanLabels: 4 // this property to be set on screen level
      },

      WebocPswRadioButton: {
        spanInputs: 20, // this property to be set on screen level
        spanLabels: 4 // this property to be set on screen level
      },

      FDDFTTNoTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },

      FDDFTTDateTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen levelbackgroundColor: "white",
      },
      CurrencyTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },
      CurrencyListButton: {
        spanInputs: 24
      },

      FDDAmountFcyTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },
      ExchangeRateTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },
      LocalEquivalentTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },
      TreasuryRateTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },
      FDDCommLcyTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },
      NostroBankTextBox: {
        spanInputs: 15, // this property to be set on screen level
        spanLabels: 8 // this property to be set on screen level
      },
      NostroBankListButton: {
        spanInputs: 24
      },
      RespondingBranchDropDown: {
        spanInputs: 15,
        spanLabels: 8
      },
      OkButton: {
        spanInputs: 23
      },
      ViewDocsButton: {
        spanInputs: 23
      },
      BackButton: {
        spanInputs: 23
      },
      ExitButton: {
        spanInputs: 23
      }
    };
  }
};
</script>
<style>
.errorClass :deep(.el-message-box__title){
  text-align: center !important;
}
:deep(.errorClass.el-message-box){
  max-width: 30% !important;
  text-align: left !important;
}
</style>