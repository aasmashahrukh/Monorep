// Megaset1123.stories.js

import Megaset1123 from "../MegaSet/MegaSet1123.vue";
import { ref } from "vue";
import { action } from "@storybook/addon-actions";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "Megaset1123",
  component: Megaset1123,
  
};

const configurationObject = {
  componentProps: {
    searchTypeRadioButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      radioLabel: '',
      backgroundColor: 'white',
      mandatory: ref(true),
      radioDisplay: '',
      searchTypeRadioButtonValues: 'WithoutAgency',
      radioGroup: [
        {
          label: 'Search By Customer',
          value: 'Search By Customer',
          isDisabled: false
        },

        {
          label: 'Search By Invoice',
          value: 'Search By Invoice',
          isDisabled: false
        }
      ]
    },
    Branch: {
      BranchList: [{
        value: "KARACHI MAIN-1001",
        option: ""
      }],
      isDisabled: ref(false),
      isVisible: ref(true),
      tabIndex: "",
      defaultValue: "",
      colorinput: "",
      colorLabel: "",
      dropDownLabel: "Branch",
      mandatory: ""

    },
    CustomerNumberTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      CustomerNumberTextBoxValue: "",
      textColor: "Black",
      labelColor: "Black",
      labelFontWeight: 12,
      mandatory: true,
      label: ref("Customer No."),
      backgroundColor: "White",
      maxlength: 30,
      dataType: "alphaNumericSpecial",
      inputLength: "",
      tabIndex: ""
    },
    SearchButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: "Search",
      nativeType: "button",
      tabIndex: ""
    },
    InvoiceNumberTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      InvoiceNumberTextBoxValue: "",
      textColor: "Black",
      labelColor: "Black",
      labelFontWeight: 12,
      mandatory: true,
      label: ref("Invoice No."),
      backgroundColor: "White",
      maxlength: 30,
      dataType: "alphaNumericSpecial",
      inputLength: "",
      tabIndex: ""
    },
    CustomerInformationTable: {
      tableWidth: "100",//ref(200),
      tableHeight: '350px',
      tableData: [],
      tableColumns: [
        {
          prop: 'BillNo',
          label: 'Bill No.',
          align: 'left',
          columnsWidth: '20'
        },
        {
          prop: 'InvoiceNo',
          label: 'Invoice No.',
          align: 'left',
          columnsWidth: '20'
        },
        {
          prop: 'AccountNo',
          label: 'Account No.',
          align: 'left',
          columnsWidth: '20'
        },
        {
          prop: 'BillDate',
          label: 'Bill Date',
          align: 'left',
          columnsWidth: '20'
        },
        {
          prop: 'BillAmount',
          label: 'Bill Amount',
          align: 'left',
          columnsWidth: '20'
        },
      ],
      isDisabled: ref(true),
      isVisible: ref(true)
    },
    OkButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: "Ok",
      nativeType: "button",
      tabIndex: ""
    },

    ExitButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: "Exit",
      nativeType: "button",
      tabIndex: ""
    },
    Section1: {
      isDisabled: false,
      isVisible: true,
    },

    Section2: {
      isDisabled: false,
      isVisible: true,
    },
    Section3: {
      isDisabled: false,
      isVisible: true,
    },
  }
};

const configurationObject1 = {
  componentProps:  {
    searchTypeRadioButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      radioLabel: '',
      backgroundColor: 'white',
      mandatory: ref(true),
      radioDisplay: '',
      searchTypeRadioButtonValues: 'WithoutAgency',
      radioGroup: [
        {
          label: 'Search By Customer',
          value: 'Search By Customer',
          isDisabled: false
        },

        {
          label: 'Search By Invoice',
          value: 'Search By Invoice',
          isDisabled: false
        }
      ]
    },
    Branch: {
      BranchList: [{
        value: "KARACHI MAIN-1001",
        option: ""
      }],
      isDisabled: ref(false),
      isVisible: ref(true),
      tabIndex: "",
      defaultValue: "",
      colorinput: "",
      colorLabel: "",
      dropDownLabel: "Branch",
      mandatory: ""

    },
    CustomerNumberTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      CustomerNumberTextBoxValue: "",
      textColor: "Black",
      labelColor: "Black",
      labelFontWeight: 12,
      mandatory: true,
      label: ref("Customer No."),
      backgroundColor: "White",
      maxlength: 30,
      dataType: "alphaNumericSpecial",
      inputLength: "",
      tabIndex: ""
    },
    SearchButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: "Search",
      nativeType: "button",
      tabIndex: ""
    },
    InvoiceNumberTextBox: {
      isDisabled: ref(false),
      isVisible: ref(true),
      InvoiceNumberTextBoxValue: "",
      textColor: "Black",
      labelColor: "Black",
      labelFontWeight: 12,
      mandatory: true,
      label: ref("Invoice No."),
      backgroundColor: "White",
      maxlength: 30,
      dataType: "alphaNumericSpecial",
      inputLength: "",
      tabIndex: ""
    },
    CustomerInformationTable: {
      tableWidth: "100",//ref(200),
      tableHeight: '350px',
      tableData: [],
      tableColumns: [
        {
          prop: 'BillNo',
          label: 'Bill No.',
          align: 'left',
          columnsWidth: '20'
        },
        {
          prop: 'InvoiceNo',
          label: 'Invoice No.',
          align: 'left',
          columnsWidth: '20'
        },
        {
          prop: 'AccountNo',
          label: 'Account No.',
          align: 'left',
          columnsWidth: '20'
        },
        {
          prop: 'BillDate',
          label: 'Bill Date',
          align: 'left',
          columnsWidth: '20'
        },
        {
          prop: 'BillAmount',
          label: 'Bill Amount',
          align: 'left',
          columnsWidth: '20'
        },
      ],
      isDisabled: ref(true),
      isVisible: ref(true)
    },
    OkButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: "Ok",
      nativeType: "button",
      tabIndex: ""
    },

    ExitButton: {
      isDisabled: ref(false),
      isVisible: ref(true),
      label: "Exit",
      nativeType: "button",
      tabIndex: ""
    },
    Section1: {
      isDisabled: false,
      isVisible: true,
    },

    Section2: {
      isDisabled: false,
      isVisible: true,
    },
    Section3: {
      isDisabled: false,
      isVisible: true,
    },
  }
};

const Template = (args) => ({
  components: { Megaset1123 },
  setup() {
    return { args : {
      configObj : {
        screenTitle: "",
                componentProps: {
          searchTypeRadioButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            radioLabel: '',
            backgroundColor: 'white',
            mandatory: ref(true),
            radioDisplay: '',
            searchTypeRadioButtonValues: 'WithoutAgency',
            radioGroup: [
              {
                label: 'Search By Customer',
                value: 'Search By Customer',
                isDisabled: false
              },

              {
                label: 'Search By Invoice',
                value: 'Search By Invoice',
                isDisabled: false
              }
            ]
          },
          Branch: {
            BranchList: [{
              value: "KARACHI MAIN-1001",
              option: ""
            }],
            isDisabled: ref(false),
            isVisible: ref(true),
            tabIndex: "",
            defaultValue: "",
            colorinput: "",
            colorLabel: "",
            dropDownLabel: "Branch",
            mandatory: ""

          },
          CustomerNumberTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            CustomerNumberTextBoxValue: "",
            textColor: "Black",
            labelColor: "Black",
            labelFontWeight: 12,
            mandatory: true,
            label: ref("Customer No."),
            backgroundColor: "White",
            maxlength: 30,
            dataType: "alphaNumericSpecial",
            inputLength: "",
            tabIndex: ""
          },
          SearchButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: "Search",
            nativeType: "button",
            tabIndex: ""
          },
          InvoiceNumberTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            InvoiceNumberTextBoxValue: "",
            textColor: "Black",
            labelColor: "Black",
            labelFontWeight: 12,
            mandatory: true,
            label: ref("Invoice No."),
            backgroundColor: "White",
            maxlength: 30,
            dataType: "alphaNumericSpecial",
            inputLength: "",
            tabIndex: ""
          },
          CustomerInformationTable: {
            tableWidth: "100",//ref(200),
            tableHeight: '350px',
            tableData: [],
            tableColumns: [
              {
                prop: 'BillNo',
                label: 'Bill No.',
                align: 'left',
                columnsWidth: '20'
              },
              {
                prop: 'InvoiceNo',
                label: 'Invoice No.',
                align: 'left',
                columnsWidth: '20'
              },
              {
                prop: 'AccountNo',
                label: 'Account No.',
                align: 'left',
                columnsWidth: '20'
              },
              {
                prop: 'BillDate',
                label: 'Bill Date',
                align: 'left',
                columnsWidth: '20'
              },
              {
                prop: 'BillAmount',
                label: 'Bill Amount',
                align: 'left',
                columnsWidth: '20'
              },
            ],
            isDisabled: ref(true),
            isVisible: ref(true)
          },
          OkButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: "Ok",
            nativeType: "button",
            tabIndex: ""
          },

          ExitButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: "Exit",
            nativeType: "button",
            tabIndex: ""
          },
          Section1: {
            isDisabled: false,
            isVisible: true,
          },

          Section2: {
            isDisabled: false,
            isVisible: true,
          },
          Section3: {
            isDisabled: false,
            isVisible: true,
          },
        }
      }
    }};
  },
  template: `<Megaset1123 v-bind="args" 
    @NameTextBox-onBlur="NameTextBox-onBlur" 
    @AddressTextBox-onBlur="AddressTextBox-onBlur"
    />`,
  methods: {
    "NameTextBox-onBlur": action("NameTextBox-onBlur"),
    "AddressTextBox-onBlur": action("AddressTextBox-onBlur"),
  },
});

export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };

export const SS_1123_Set_1 = Template.bind({});
SS_1123_Set_1.args = { configObj: configurationObject1 };