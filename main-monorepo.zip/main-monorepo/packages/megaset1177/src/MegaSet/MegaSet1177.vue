 <!--Rahool Ownership Megaset1177 -->
 <template>
  <Form as="el-form" @submit="onSubmit">
    <fieldset 
  v-if="configObject.Section2 != undefined ? configObject.Section2.isVisible : false">
  <el-row>
    <el-col :lg="8" :md="8">
      <el-form-item class="boldedLabel">{{ configObject.HeadingLabel.HeadingLabel }} </el-form-item>
    </el-col>
    <!-- <el-col :lg="3" :md="3"></el-col> -->
    <el-col :lg="8" :md="8">
      <el-form-item v-if="configObject.HeadingLabel1 != undefined ? configObject.HeadingLabel1.isVisible : false" class="boldedLabel">{{ configObject.HeadingLabel1.HeadingLabel1 }} </el-form-item>
    </el-col>
    <el-col :lg="8" :md="8">
    </el-col>
  </el-row>
  <el-row>
    <el-col :lg="7" :md="7"></el-col>
    <el-col :lg="8" :md="8">
      <el-form-item class="boldedLabel" v-if="configObject.HeadingLabel2!=undefined?configObject.HeadingLabel2.isVisible:false">{{ configObject.HeadingLabel2.HeadingLabel2 }} </el-form-item>
    </el-col>
    <el-col :lg="4" :md="4"></el-col>
   
  </el-row>

  <el-row>
    <el-col :lg="8" :md="8">
      <GenericTextBox
        @GenericTextBox-onBlur="
          (val) => {
            $emit('FDBPNoTextBox-onBlur', val);
          }
        "
        @GenericTextBox-onChange="
          (val) => {
            $emit('FDBPNoTextBox-onChange', val);
          }
        "
        @GenericTextBox-onKeyPress="
          (val) => {
            $emit('FDBPNoTextBox-onKeyPress', val);
          }
        "
        @GenericTextBox-onKeyUp="
          (val) => {
            $emit('FDBPNoTextBox-onKeyUp', val);
          }
        "
        @GenericTextBox-onFocus="
          (val) => {
            $emit('FDBPNoTextBox-onFocus', val);
          }
        "
        v-bind="{ ...FDBPNoTextBox, ...configObject.FDBPNoTextBox }"
        name="FDBPNoTextBox"
        ref="RefFDBPNoTextBox"
        :values="configObject.FDBPNoTextBox.FDBPNoTextBoxValue"
        v-if="configObject.FDBPNoTextBox != undefined ? configObject.FDBPNoTextBox.isVisible : false"
      />

      <GenericDatePicker
        @GenericDatePicker-onBlur="
          (val) => {
            $emit('FDBPDateTextBox-onBlur', val);
          }
        "
        @GenericDatePicker-onChange="
          (val) => {
            $emit('FDBPDateTextBox-onChange', val);
          }
        "
        @GenericDatePicker-onKeyPress="
          (val) => {
            $emit('FDBPDateTextBox-onKeyPress', val);
          }
        "
        @GenericDatePicker-onKeyUp="
          (val) => {
            $emit('FDBPDateTextBox-onKeyUp', val);
          }
        "
        @GenericDatePicker-onFocus="
          (val) => {
            $emit('FDBPDateTextBox-onFocus', val);
          }
        "
        v-bind="{ ...FDBPDateTextBox, ...configObject.FDBPDateTextBox }"
        name="FDBPDateTextBox"
        ref="RefFDBPDateTextBox"
        :values="configObject.FDBPDateTextBox.FDBPDateTextBoxValue"
        v-if="configObject.FDBPDateTextBox != undefined ? configObject.FDBPDateTextBox.isVisible : false"
      />

      <GenericTextBox
        @GenericTextBox-onBlur="
          (val) => {
            $emit('FDBCNoTextBox-onBlur', val);
          }
        "
        @GenericTextBox-onChange="
          (val) => {
            $emit('FDBCNoTextBox-onChange', val);
          }
        "
        @GenericTextBox-onKeyPress="
          (val) => {
            $emit('FDBCNoTextBox-onKeyPress', val);
          }
        "
        @GenericTextBox-onKeyUp="
          (val) => {
            $emit('FDBCNoTextBox-onKeyUp', val);
          }
        "
        @GenericTextBox-onFocus="
          (val) => {
            $emit('FDBCNoTextBox-onFocus', val);
          }
        "
        v-bind="{ ...FDBCNoTextBox, ...configObject.FDBCNoTextBox }"
        name="FDBCNoTextBox"
        ref="RefFDBCNoTextBox"
        :values="configObject.FDBCNoTextBox.FDBCNoTextBoxValue"
        v-if="configObject.FDBCNoTextBox != undefined ? configObject.FDBCNoTextBox.isVisible : false"
      />

      <GenericDatePicker
        @GenericDatePicker-onBlur="
          (val) => {
            $emit('FDBCDateTextBox-onBlur', val);
          }
        "
        @GenericDatePicker-onChange="
          (val) => {
            $emit('FDBCDateTextBox-onChange', val);
          }
        "
        @GenericDatePicker-onKeyPress="
          (val) => {
            $emit('FDBCDateTextBox-onKeyPress', val);
          }
        "
        @GenericDatePicker-onKeyUp="
          (val) => {
            $emit('FDBCDateTextBox-onKeyUp', val);
          }
        "
        @GenericDatePicker-onFocus="
          (val) => {
            $emit('FDBCDateTextBox-onFocus', val);
          }
        "
        v-bind="{ ...FDBCDateTextBox, ...configObject.FDBCDateTextBox }"
        name="FDBCDateTextBox"
        ref="RefFDBCDateTextBox"
        :values="configObject.FDBCDateTextBox.FDBCDateTextBoxValue"
        v-if="configObject.FDBCDateTextBox != undefined ? configObject.FDBCDateTextBox.isVisible : false"
      />
    </el-col>
    <el-col :lg="8" :md="8">
      <AmountNumericDecimal15Point2
        @AmountNumericDecimal15Point2-onBlur="
          (val) => {
            $emit('FDBPAmtTextBox-onBlur', val);
          }
        "
        @AmountNumericDecimal15Point2-onChange="
          (val) => {
            $emit('FDBPAmtTextBox-onChange', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyPress="
          (val) => {
            $emit('FDBPAmtTextBox-onKeyPress', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyUp="
          (val) => {
            $emit('FDBPAmtTextBox-onKeyUp', val);
          }
        "
        @AmountNumericDecimal15Point2-onFocus="
          (val) => {
            $emit('FDBPAmtTextBox-onFocus', val);
          }
        "
        v-bind="{ ...FDBPAmtTextBox, ...configObject.FDBPAmtTextBox }"
        name="FDBPAmtTextBox"
        ref="RefFDBPAmtTextBox"
        :values="configObject.FDBPAmtTextBox.FDBPAmtTextBoxValue"
        v-if="configObject.FDBPAmtTextBox != undefined ? configObject.FDBPAmtTextBox.isVisible : false"
      />

      <AmountNumericDecimal15Point2
        @AmountNumericDecimal15Point2-onBlur="
          (val) => {
            $emit('FDBCAmtTextBox-onBlur', val);
          }
        "
        @AmountNumericDecimal15Point2-onChange="
          (val) => {
            $emit('FDBCAmtTextBox-onChange', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyPress="
          (val) => {
            $emit('FDBCAmtTextBox-onKeyPress', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyUp="
          (val) => {
            $emit('FDBCAmtTextBox-onKeyUp', val);
          }
        "
        @AmountNumericDecimal15Point2-onFocus="
          (val) => {
            $emit('FDBCAmtTextBox-onFocus', val);
          }
        "
        v-bind="{ ...FDBCAmtTextBox, ...configObject.FDBCAmtTextBox }"
        name="FDBCAmtTextBox"
        ref="RefFDBCAmtTextBox"
        :values="configObject.FDBCAmtTextBox.FDBCAmtTextBoxValue"
        v-if="configObject.FDBCAmtTextBox != undefined ? configObject.FDBCAmtTextBox.isVisible : false"
      />
     <el-row>
       <el-col :lg="8" :md="8">
      <el-form-item class="boldedLabel">{{ configObject.usLabel.usLabel }} </el-form-item>
      </el-col>
  
      <el-col :lg="12" :md="12">
      <GenericCheckBox
        @GenericCheckBox-onChange="(val) => { $emit('RevWholeCheckBox-onChange', val); }"
        name="RevWholeCheckBox"
        ref="RefRevWholeCheckBox"
        :values="configObject.RevWholeCheckBox.RevWholeCheckBoxValue"
        v-if="configObject.RevWholeCheckBox != undefined ? configObject.RevWholeCheckBox.isVisible : false"
        v-bind="{...RevWholeCheckBox,...configObject.RevWholeCheckBox }"
      />        
      </el-col>
     </el-row>

    </el-col>
    
    <el-col :lg="8" :md="8">
      <AmountNumericDecimal15Point2
        @AmountNumericDecimal15Point2-onBlur="
          (val) => {
            $emit('ConvAmtTextBox-onBlur', val);
          }
        "
        @AmountNumericDecimal15Point2-onChange="
          (val) => {
            $emit('ConvAmtTextBox-onChange', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyPress="
          (val) => {
            $emit('ConvAmtTextBox-onKeyPress', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyUp="
          (val) => {
            $emit('ConvAmtTextBox-onKeyUp', val);
          }
        "
        @AmountNumericDecimal15Point2-onFocus="
          (val) => {
            $emit('ConvAmtTextBox-onFocus', val);
          }
        "
        v-bind="{ ...ConvAmtTextBox, ...configObject.ConvAmtTextBox }"
        name="ConvAmtTextBox"
        ref="RefConvAmtTextBox"
        :values="configObject.ConvAmtTextBox.ConvAmtTextBoxValue"
        v-if="configObject.ConvAmtTextBox != undefined ? configObject.ConvAmtTextBox.isVisible : false"
      />

      <AmountNumericDecimal15Point2
        @AmountNumericDecimal15Point2-onBlur="
          (val) => {
            $emit('RealAmtTextBox-onBlur', val);
          }
        "
        @AmountNumericDecimal15Point2-onChange="
          (val) => {
            $emit('RealAmtTextBox-onChange', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyPress="
          (val) => {
            $emit('RealAmtTextBox-onKeyPress', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyUp="
          (val) => {
            $emit('RealAmtTextBox-onKeyUp', val);
          }
        "
        @AmountNumericDecimal15Point2-onFocus="
          (val) => {
            $emit('RealAmtTextBox-onFocus', val);
          }
        "
        v-bind="{ ...RealAmtTextBox, ...configObject.RealAmtTextBox }"
        name="RealAmtTextBox"
        ref="RefRealAmtTextBox"
        :values="configObject.RealAmtTextBox.RealAmtTextBoxValue"
        v-if="configObject.RealAmtTextBox != undefined ? configObject.RealAmtTextBox.isVisible : false"
      />

      <AmountNumericDecimal15Point2
        @AmountNumericDecimal15Point2-onBlur="
          (val) => {
            $emit('OSAmountTextBox-onBlur', val);
          }
        "
        @AmountNumericDecimal15Point2-onChange="
          (val) => {
            $emit('OSAmountTextBox-onChange', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyPress="
          (val) => {
            $emit('OSAmountTextBox-onKeyPress', val);
          }
        "
        @AmountNumericDecimal15Point2-onKeyUp="
          (val) => {
            $emit('OSAmountTextBox-onKeyUp', val);
          }
        "
        @AmountNumericDecimal15Point2-onFocus="
          (val) => {
            $emit('OSAmountTextBox-onFocus', val);
          }
        "
        v-bind="{ ...OSAmountTextBox, ...configObject.OSAmountTextBox }"
        name="OSAmountTextBox"
        ref="RefOSAmountTextBox"
        :values="configObject.OSAmountTextBox.OSAmountTextBoxValue"
        v-if="configObject.OSAmountTextBox != undefined ? configObject.OSAmountTextBox.isVisible : false"
      />
      
      
    </el-col>
  </el-row>
 
</fieldset>

    <el-tabs v-model="configObject.TabPane.activeName" class="demo-tabs fontArial" type="card" @tab-click="handleClick">
      <!-- Contract Information-->
      <el-tab-pane :label="configObject.EformNo.label" isVisible name="EformNo" ref="RefEformNo" :disabled="configObject.EformNo.isDisabled">
        <el-row>
  <el-col :lg="22" :md="22">
    <fieldset v-if="configObject.SectionEformNo != undefined ? configObject.SectionEformNo.isVisible : false">
      <el-row>
        <el-col :lg="8" :md="8">
          <el-form-item class="boldedLabel">{{ configObject.CustomerInformationHeading.CustomerInformationHeading }} </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :lg="11" :md="11">
          <AccountNumberNumericDashes21
            @AccountNumberNumericDashes21-onChange="
              (val) => {
                $emit('AccountNumbertxtBox-onChange', val);
              }
            "
            @AccountNumberNumericDashes21-onFocus="
              (val) => {
                $emit('AccountNumbertxtBox-onFocus', val);
              }
            "
            @AccountNumberNumericDashes21-onKeyUp="
              (val) => {
                $emit('AccountNumbertxtBox-onKeyUp', val);
              }
            "
            @AccountNumberNumericDashes21-onKeyPress="
              (val) => {
                $emit('AccountNumbertxtBox-onKeyPress', val);
              }
            "
            @AccountNumberNumericDashes21-onBlur="
              (val) => {
                $emit('AccountNumbertxtBox-onBlur', val);
              }
            "
            :values="configObject.AccountNumbertxtBox.AccountNumbertxtBoxValue"
            name="AccountNumbertxtBox"
            ref="RefAccountNumbertxtBox"
            v-bind="{ ...AccountNumbertxtBox, ...configObject.AccountNumbertxtBox }"
            v-if="configObject.AccountNumbertxtBox != undefined ? configObject.AccountNumbertxtBox.isVisible : false"
          />
          <AccountTitleString45
            @AccountTitleString45-onBlur="
              (val) => {
                $emit('AccountTitleTextBox-onBlur', val);
              }
            "
            @AccountTitleString45-onChange="
              (val) => {
                $emit('AccountTitleTextBox-onChange', val);
              }
            "
            @AccountTitleString45-onKeyPress="
              (val) => {
                $emit('AccountTitleTextBox-onKeyPress', val);
              }
            "
            @AccountTitleString45-onKeyUp="
              (val) => {
                $emit('AccountTitleTextBox-onKeyUp', val);
              }
            "
            @AccountTitleString45-onFocus="
              (val) => {
                $emit('AccountTitleTextBox-onFocus', val);
              }
            "
            :values="configObject.AccountTitleTextBox.AccountTitleTextBoxValue"
            name="AccountTitleTextBox"
            ref="RefAccountTitleTextBox"
            v-bind="{ ...AccountTitleTextBox, ...configObject.AccountTitleTextBox }"
            v-if="configObject.AccountTitleTextBox != undefined ? configObject.AccountTitleTextBox.isVisible : false"
          />
        </el-col>
        <el-col :lg="2" :md="2"></el-col>
        <el-col :lg="11" :md="11">
          <NtnNumericDashes9
            name="NTNNoTextBox"
            ref="RefNTNNoTextBox"
            @NtnNumericDashes9-onBlur="
              (val) => {
                $emit('NTNNoTextBox-onBlur', val);
              }
            "
            @NtnNumericDashes9-onChange="
              (val) => {
                $emit('NTNNoTextBox-onChange', val);
              }
            "
            @NtnNumericDashes9-onKeyPress="
              (val) => {
                $emit('NTNNoTextBox-onKeyPress', val);
              }
            "
            @NtnNumericDashes9-onKeyUp="
              (val) => {
                $emit('NTNNoTextBox-onKeyUp', val);
              }
            "
            @NtnNumericDashes9-onFocus="
              (val) => {
                $emit('NTNNoTextBox-onFocus', val);
              }
            "
            :values="configObject.NTNNoTextBox.NTNNoTextBoxValue"
            v-bind="{ ...NTNNoTextBox, ...configObject.NTNNoTextBox }"
            v-if="configObject.NTNNoTextBox != undefined ? configObject.NTNNoTextBox.isVisible : false"
          />
          <GenericTextBox
            name="importerRegNoTextBox"
            ref="RefimporterRegNoTextBox"
            @GenericTextBox-onFocus="
              (val) => {
                $emit('importerRegNoTextBox-onFocus', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('importerRegNoTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onBlur="
              (val) => {
                $emit('importerRegNoTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('importerRegNoTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('importerRegNoTextBox-onKeyPress', val);
              }
            "
            :values="configObject.importerRegNoTextBox.importerRegNoTextBoxValue"
            v-bind="{ ...importerRegNoTextBox, ...configObject.importerRegNoTextBox }"
            v-if="configObject.importerRegNoTextBox != undefined ? configObject.importerRegNoTextBox.isVisible : false"
          ></GenericTextBox>
        </el-col>
      </el-row>
    </fieldset>
  </el-col>
</el-row>

        <el-row>
          <el-col :lg="24" :md="24">
            <GenericSortableTableView
              @GenericSortableTableView-onClickRow="
                (val) => {
                  $emit('eformTable-onClickRow', val);
                }
              "
              @GenericSortableTableView-onCurrentRow="
                (val) => {
                  $emit('eformTable-onCurrentRow', val);
                }
              "
              @GenericSortableTableView-onDoubleClickRow="
                (val) => {
                  $emit('eformTable-onDoubleClickRow', val);
                }
              "
              name="eformTable"
              ref="RefeformTable"
              v-if="configObject.eformTable != undefined ? configObject.eformTable.isVisible : false"
              v-bind="{ ...eformTable, ...configObject.eformTable }"
            />
          </el-col>
        </el-row>

        <el-row>
          <el-col :md="4" :lg="4">
          <GenericButton
            @GenericButton-onClick="$emit('EFormConvertBtn-onClick')"
            @GenericButton-onFocus="$emit('EFormConvertBtn-onFocus')"
            name="EFormConvertBtn"
            ref="RefEFormConvertBtn"
            v-bind="{ ...EFormConvertBtn, ...configObject.EFormConvertBtn }"
            v-if="configObject.EFormConvertBtn.isVisible"
          />
        </el-col>
        </el-row>
        <el-row>
          
          <el-col :lg="24" :md="24">
            <GenericSortableTableView
              @GenericSortableTableView-onClickRow="
                (val) => {
                  $emit('eformTable2-onClickRow', val);
                }
              "
              @GenericSortableTableView-onCurrentRow="
                (val) => {
                  $emit('eformTable2-onCurrentRow', val);
                }
              "
              @GenericSortableTableView-onDoubleClickRow="
                (val) => {
                  $emit('eformTable2-onDoubleClickRow', val);
                }
              "
              name="eformTable2"
              ref="RefeformTable2"
              v-if="configObject.eformTable2 != undefined ? configObject.eformTable2.isVisible : false"
              v-bind="{ ...eformTable2, ...configObject.eformTable2 }"
            />
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane
  :label="configObject.FDBPLodgment.label"
  name="FDBPLodgment"
  ref="RefFDBPLodgment"
  :disabled="configObject.FDBPLodgment.isDisabled"
  v-if="configObject.FDBPLodgment != undefined ? configObject.FDBPLodgment.isVisible : false"
>
  <fieldset v-if="configObject.Section3FDBP != undefined ? configObject.Section3FDBP.isVisible : false">
    <el-row>
      <el-col :lg="12" :md="12">
        <AccountNumberNumericDashes21
          @AccountNumberNumericDashes21-onBlur="
            (val) => {
              $emit('FDBPAccountTextBox-onBlur', val);
            }
          "
          @AccountNumberNumericDashes21-onChange="
            (val) => {
              $emit('FDBPAccountTextBox-onChange', val);
            }
          "
          @AccountNumberNumericDashes21-onKeyPress="
            (val) => {
              $emit('FDBPAccountTextBox-onKeyPress', val);
            }
          "
          @AccountNumberNumericDashes21-onKeyUp="
            (val) => {
              $emit('FDBPAccountTextBox-onKeyUp', val);
            }
          "
          @AccountNumberNumericDashes21-onFocus="
            (val) => {
              $emit('FDBPAccountTextBox-onFocus', val);
            }
          "
          name="FDBPAccountTextBox"
          ref="RefFDBPAccountTextBox"
          v-bind="{
            ...FDBPAccountTextBox,
            ...configObject.FDBPAccountTextBox
          }"
          :values="configObject.FDBPAccountTextBox.FDBPAccountTextBoxValue"
          v-if="configObject.FDBPAccountTextBox != undefined ? configObject.FDBPAccountTextBox.isVisible : false"
        />

        <AccountNumberNumericDashes21
          @AccountNumberNumericDashes21-onBlur="
            (val) => {
              $emit('FDBCAccountTextBox-onBlur', val);
            }
          "
          @AccountNumberNumericDashes21-onChange="
            (val) => {
              $emit('FDBCAccountTextBox-onChange', val);
            }
          "
          @AccountNumberNumericDashes21-onKeyPress="
            (val) => {
              $emit('FDBCAccountTextBox-onKeyPress', val);
            }
          "
          @AccountNumberNumericDashes21-onKeyUp="
            (val) => {
              $emit('FDBCAccountTextBox-onKeyUp', val);
            }
          "
          @AccountNumberNumericDashes21-onFocus="
            (val) => {
              $emit('FDBCAccountTextBox-onFocus', val);
            }
          "
          name="FDBCAccountTextBox"
          ref="RefFDBCAccountTextBox"
          v-bind="{
            ...FDBCAccountTextBox,
            ...configObject.FDBCAccountTextBox
          }"
          :values="configObject.FDBCAccountTextBox.FDBCAccountTextBoxValue"
          v-if="configObject.FDBCAccountTextBox != undefined ? configObject.FDBCAccountTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('OriginTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('OriginTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('OriginTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('OriginTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('OriginTextBox-onFocus', val);
            }
          "
          name="OriginTextBox"
          ref="RefOriginTextBox"
          v-bind="{
            ...OriginTextBox,
            ...configObject.OriginTextBox
          }"
          :values="configObject.OriginTextBox.OriginTextBoxValue"
          v-if="configObject.OriginTextBox != undefined ? configObject.OriginTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('DocBankTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('DocBankTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('DocBankTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('DocBankTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('DocBankTextBox-onFocus', val);
            }
          "
          name="DocBankTextBox"
          ref="RefDocBankTextBox"
          v-bind="{
            ...DocBankTextBox,
            ...configObject.DocBankTextBox
          }"
          :values="configObject.DocBankTextBox.DocBankTextBoxValue"
          v-if="configObject.DocBankTextBox != undefined ? configObject.DocBankTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('DocBrnTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('DocBrnTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('DocBrnTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('DocBrnTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('DocBrnTextBox-onFocus', val);
            }
          "
          name="DocBrnTextBox"
          ref="RefDocBrnTextBox"
          v-bind="{
            ...DocBrnTextBox,
            ...configObject.DocBrnTextBox
          }"
          :values="configObject.DocBrnTextBox.DocBrnTextBoxValue"
          v-if="configObject.DocBrnTextBox != undefined ? configObject.DocBrnTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('DocBranchTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('DocBranchTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('DocBranchTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('DocBranchTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('DocBranchTextBox-onFocus', val);
            }
          "
          name="DocBranchTextBox"
          ref="RefDocBranchTextBox"
          v-bind="{
            ...DocBranchTextBox,
            ...configObject.DocBranchTextBox
          }"
          :values="configObject.DocBranchTextBox.DocBranchTextBoxValue"
          v-if="configObject.DocBranchTextBox != undefined ? configObject.DocBranchTextBox.isVisible : false"
        />

      <el-row>
      <el-col :lg="9" :md="9">
        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('DaysofDiscountTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('DaysofDiscountTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('DaysofDiscountTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('DaysofDiscountTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('DaysofDiscountTextBox-onFocus', val);
            }
          "
          name="DaysofDiscountTextBox"
          ref="RefDaysofDiscountTextBox"
          v-bind="{
            ...DaysofDiscountTextBox,
            ...configObject.DaysofDiscountTextBox
          }"
          :values="configObject.DaysofDiscountTextBox.DaysofDiscountTextBoxValue"
          v-if="configObject.DaysofDiscountTextBox != undefined ? configObject.DaysofDiscountTextBox.isVisible : false"
        />
      </el-col>
      <el-col :lg="10" :md="10">
        <RateNumericDecimal9Point5
          @RateNumericDecimal9Point5-onBlur="
            (val) => {
              $emit('MkupRateTextBox-onBlur', val);
            }
          "
          @RateNumericDecimal9Point5-onChange="
            (val) => {
              $emit('MkupRateTextBox-onChange', val);
            }
          "
          @RateNumericDecimal9Point5-onKeyPress="
            (val) => {
              $emit('MkupRateTextBox-onKeyPress', val);
            }
          "
          @RateNumericDecimal9Point5-onKeyUp="
            (val) => {
              $emit('MkupRateTextBox-onKeyUp', val);
            }
          "
          @RateNumericDecimal9Point5-onFocus="
            (val) => {
              $emit('MkupRateTextBox-onFocus', val);
            }
          "
          name="MkupRateTextBox"
          ref="RefMkupRateTextBox"
          v-bind="{
            ...MkupRateTextBox,
            ...configObject.MkupRateTextBox
          }"
          :values="configObject.MkupRateTextBox.MkupRateTextBoxValue"
          v-if="configObject.MkupRateTextBox != undefined ? configObject.MkupRateTextBox.isVisible : false"
        />
      </el-col>
      <el-col :lg="5" :md="5"></el-col>
       </el-row>

    

      <AmountNumericDecimal10Point2
          @AmountNumericDecimal10Point2-onBlur="
            (val) => {
              $emit('lodgAmountTextBox-onBlur', val);
            }
          "
          @AmountNumericDecimal10Point2-onChange="
            (val) => {
              $emit('lodgAmountTextBox-onChange', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyPress="
            (val) => {
              $emit('lodgAmountTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyUp="
            (val) => {
              $emit('lodgAmountTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal10Point2-onFocus="
            (val) => {
              $emit('lodgAmountTextBox-onFocus', val);
            }
          "
          name="lodgAmountTextBox"
          ref="ReflodgAmountTextBox"
          v-bind="{
            ...lodgAmountTextBox,
            ...configObject.lodgAmountTextBox
          }"
          :values="configObject.lodgAmountTextBox.lodgAmountTextBoxValue"
          v-if="configObject.lodgAmountTextBox != undefined ? configObject.lodgAmountTextBox.isVisible : false"
        />

      <el-row>
        <el-col :lg="9" :md="9">
        <Percentage4Point5
          @Percentage4Point5-onBlur="
            (val) => {
              $emit('DiscPercentTextBox-onBlur', val);
            }
          "
          @Percentage4Point5-onChange="
            (val) => {
              $emit('DiscPercentTextBox-onChange', val);
            }
          "
          @Percentage4Point5-onKeyPress="
            (val) => {
              $emit('DiscPercentTextBox-onKeyPress', val);
            }
          "
          @Percentage4Point5-onKeyUp="
            (val) => {
              $emit('DiscPercentTextBox-onKeyUp', val);
            }
          "
          @Percentage4Point5-onFocus="
            (val) => {
              $emit('DiscPercentTextBox-onFocus', val);
            }
          "
          name="DiscPercentTextBox"
          ref="RefDiscPercentTextBox"
          v-bind="{
            ...DiscPercentTextBox,
            ...configObject.DiscPercentTextBox
          }"
          :values="configObject.DiscPercentTextBox.DiscPercentTextBoxValue"
          v-if="configObject.DiscPercentTextBox != undefined ? configObject.DiscPercentTextBox.isVisible : false"
        />
      </el-col>
      <el-col :lg="10" :md="10">
        <RateNumericDecimal9Point5
          @RateNumericDecimal9Point5-onBlur="
            (val) => {
              $emit('SpotRtTextBox-onBlur', val);
            }
          "
          @RateNumericDecimal9Point5-onChange="
            (val) => {
              $emit('SpotRtTextBox-onChange', val);
            }
          "
          @RateNumericDecimal9Point5-onKeyPress="
            (val) => {
              $emit('SpotRtTextBox-onKeyPress', val);
            }
          "
          @RateNumericDecimal9Point5-onKeyUp="
            (val) => {
              $emit('SpotRtTextBox-onKeyUp', val);
            }
          "
          @RateNumericDecimal9Point5-onFocus="
            (val) => {
              $emit('SpotRtTextBox-onFocus', val);
            }
          "
          name="SpotRtTextBox"
          ref="RefSpotRtTextBox"
          v-bind="{
            ...SpotRtTextBox,
            ...configObject.SpotRtTextBox
          }"
          :values="configObject.SpotRtTextBox.SpotRtTextBoxValue"
          v-if="configObject.SpotRtTextBox != undefined ? configObject.SpotRtTextBox.isVisible : false"
        />
      </el-col>
      <el-col :lg="5" :md="5"></el-col>

      </el-row>

      <RateNumericDecimal3Point2
          @RateNumericDecimal3Point2-onBlur="
            (val) => {
              $emit('SpotRtEqvTextBox-onBlur', val);
            }
          "
          @RateNumericDecimal3Point2-onChange="
            (val) => {
              $emit('SpotRtEqvTextBox-onChange', val);
            }
          "
          @RateNumericDecimal3Point2-onKeyPress="
            (val) => {
              $emit('SpotRtEqvTextBox-onKeyPress', val);
            }
          "
          @RateNumericDecimal3Point2-onKeyUp="
            (val) => {
              $emit('SpotRtEqvTextBox-onKeyUp', val);
            }
          "
          @RateNumericDecimal3Point2-onFocus="
            (val) => {
              $emit('SpotRtEqvTextBox-onFocus', val);
            }
          "
          name="SpotRtEqvTextBox"
          ref="RefSpotRtEqvTextBox"
          v-bind="{
            ...SpotRtEqvTextBox,
            ...configObject.SpotRtEqvTextBox
          }"
          :values="configObject.SpotRtEqvTextBox.SpotRtEqvTextBoxValue"
          v-if="configObject.SpotRtEqvTextBox != undefined ? configObject.SpotRtEqvTextBox.isVisible : false"
        />
      
      <ExchangeRateNumericDecimal10Point5
          @ExchangeRateNumericDecimal10Point5-onBlur="
            (val) => {
              $emit('ExcRtTextBox-onBlur', val);
            }
          "
          @ExchangeRateNumericDecimal10Point5-onChange="
            (val) => {
              $emit('ExcRtTextBox-onChange', val);
            }
          "
          @ExchangeRateNumericDecimal10Point5-onKeyPress="
            (val) => {
              $emit('ExcRtTextBox-onKeyPress', val);
            }
          "
          @ExchangeRateNumericDecimal10Point5-onKeyUp="
            (val) => {
              $emit('ExcRtTextBox-onKeyUp', val);
            }
          "
          @ExchangeRateNumericDecimal10Point5-onFocus="
            (val) => {
              $emit('ExcRtTextBox-onFocus', val);
            }
          "
          name="ExcRtTextBox"
          ref="RefExcRtTextBox"
          v-bind="{
            ...ExcRtTextBox,
            ...configObject.ExcRtTextBox
          }"
          :values="configObject.ExcRtTextBox.ExcRtTextBoxValue"
          v-if="configObject.ExcRtTextBox != undefined ? configObject.ExcRtTextBox.isVisible : false"
        />

        <AmountNumericDecimal10Point2
          @AmountNumericDecimal10Point2-onBlur="
            (val) => {
              $emit('localEqvTextBox-onBlur', val);
            }
          "
          @AmountNumericDecimal10Point2-onChange="
            (val) => {
              $emit('localEqvTextBox-onChange', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyPress="
            (val) => {
              $emit('localEqvTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyUp="
            (val) => {
              $emit('localEqvTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal10Point2-onFocus="
            (val) => {
              $emit('localEqvTextBox-onFocus', val);
            }
          "
          name="localEqvTextBox"
          ref="ReflocalEqvTextBox"
          v-bind="{
            ...localEqvTextBox,
            ...configObject.localEqvTextBox
          }"
          :values="configObject.localEqvTextBox.localEqvTextBoxValue"
          v-if="configObject.localEqvTextBox != undefined ? configObject.localEqvTextBox.isVisible : false"
        />

        <RateNumericDecimal3Point2
          @RateNumericDecimal3Point2-onBlur="
            (val) => {
              $emit('TreasRtTextBox-onBlur', val);
            }
          "
          @RateNumericDecimal3Point2-onChange="
            (val) => {
              $emit('TreasRtTextBox-onChange', val);
            }
          "
          @RateNumericDecimal3Point2-onKeyPress="
            (val) => {
              $emit('TreasRtTextBox-onKeyPress', val);
            }
          "
          @RateNumericDecimal3Point2-onKeyUp="
            (val) => {
              $emit('TreasRtTextBox-onKeyUp', val);
            }
          "
          @RateNumericDecimal3Point2-onFocus="
            (val) => {
              $emit('TreasRtTextBox-onFocus', val);
            }
          "
          name="TreasRtTextBox"
          ref="RefTreasRtTextBox"
          v-bind="{
            ...TreasRtTextBox,
            ...configObject.TreasRtTextBox
          }"
          :values="configObject.TreasRtTextBox.TreasRtTextBoxValue"
          v-if="configObject.TreasRtTextBox != undefined ? configObject.TreasRtTextBox.isVisible : false"
        />

        <RateNumericDecimal3Point2
          @RateNumericDecimal3Point2-onBlur="
            (val) => {
              $emit('TrRtEquiTextBox-onBlur', val);
            }
          "
          @RateNumericDecimal3Point2-onChange="
            (val) => {
              $emit('TrRtEquiTextBox-onChange', val);
            }
          "
          @RateNumericDecimal3Point2-onKeyPress="
            (val) => {
              $emit('TrRtEquiTextBox-onKeyPress', val);
            }
          "
          @RateNumericDecimal3Point2-onKeyUp="
            (val) => {
              $emit('TrRtEquiTextBox-onKeyUp', val);
            }
          "
          @RateNumericDecimal3Point2-onFocus="
            (val) => {
              $emit('TrRtEquiTextBox-onFocus', val);
            }
          "
          name="TrRtEquiTextBox"
          ref="RefTrRtEquiTextBox"
          v-bind="{
            ...TrRtEquiTextBox,
            ...configObject.TrRtEquiTextBox
          }"
          :values="configObject.TrRtEquiTextBox.TrRtEquiTextBoxValue"
          v-if="configObject.TrRtEquiTextBox != undefined ? configObject.TrRtEquiTextBox.isVisible : false"
        />

        <GenericDatePicker
          @GenericDatePicker-onBlur="
            (val) => {
              $emit('ShipmentDateTextBox-onBlur', val);
            }
          "
          @GenericDatePicker-onChange="
            (val) => {
              $emit('ShipmentDateTextBox-onChange', val);
            }
          "
          @GenericDatePicker-onKeyPress="
            (val) => {
              $emit('ShipmentDateTextBox-onKeyPress', val);
            }
          "
          @GenericDatePicker-onKeyUp="
            (val) => {
              $emit('ShipmentDateTextBox-onKeyUp', val);
            }
          "
          @GenericDatePicker-onFocus="
            (val) => {
              $emit('ShipmentDateTextBox-onFocus', val);
            }
          "
          name="ShipmentDateTextBox"
          ref="RefShipmentDateTextBox"
          v-bind="{
            ...ShipmentDateTextBox,
            ...configObject.ShipmentDateTextBox
          }"
          :values="configObject.ShipmentDateTextBox.ShipmentDateTextBoxValue"
          v-if="configObject.ShipmentDateTextBox != undefined ? configObject.ShipmentDateTextBox.isVisible : false"
        />

        <GenericDatePicker
          @GenericDatePicker-onBlur="
            (val) => {
              $emit('DueDateTextBox-onBlur', val);
            }
          "
          @GenericDatePicker-onChange="
            (val) => {
              $emit('DueDateTextBox-onChange', val);
            }
          "
          @GenericDatePicker-onKeyPress="
            (val) => {
              $emit('DueDateTextBox-onKeyPress', val);
            }
          "
          @GenericDatePicker-onKeyUp="
            (val) => {
              $emit('DueDateTextBox-onKeyUp', val);
            }
          "
          @GenericDatePicker-onFocus="
            (val) => {
              $emit('DueDateTextBox-onFocus', val);
            }
          "
          name="DueDateTextBox"
          ref="RefDueDateTextBox"
          v-bind="{
            ...DueDateTextBox,
            ...configObject.DueDateTextBox
          }"
          :values="configObject.DueDateTextBox.DueDateTextBoxValue"
          v-if="configObject.DueDateTextBox != undefined ? configObject.DueDateTextBox.isVisible : false"
        />
      
        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('TenorTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('TenorTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('TenorTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('TenorTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('TenorTextBox-onFocus', val);
            }
          "
          name="TenorTextBox"
          ref="RefTenorTextBox"
          v-bind="{
            ...TenorTextBox,
            ...configObject.TenorTextBox
          }"
          :values="configObject.TenorTextBox.TenorTextBoxValue"
          v-if="configObject.TenorTextBox != undefined ? configObject.TenorTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('RemitBankTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('RemitBankTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('RemitBankTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('RemitBankTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('RemitBankTextBox-onFocus', val);
            }
          "
          name="RemitBankTextBox"
          ref="RefRemitBankTextBox"
          v-bind="{
            ...RemitBankTextBox,
            ...configObject.RemitBankTextBox
          }"
          :values="configObject.RemitBankTextBox.RemitBankTextBoxValue"
          v-if="configObject.RemitBankTextBox != undefined ? configObject.RemitBankTextBox.isVisible : false"
        />

        <el-row>
      <el-col :lg="8" :md="8">
        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('MarginTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('MarginTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('MarginTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('MarginTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('MarginTextBox-onFocus', val);
            }
          "
          name="MarginTextBox"
          ref="RefMarginTextBox"
          v-bind="{
            ...MarginTextBox,
            ...configObject.MarginTextBox
          }"
          :values="configObject.MarginTextBox.MarginTextBoxValue"
          v-if="configObject.MarginTextBox != undefined ? configObject.MarginTextBox.isVisible : false"
        />
      </el-col>
      <el-col :lg="16" :md="16">
        <Percentage4Point5
          @Percentage4Point5-onBlur="
            (val) => {
              $emit('PercentTextBox-onBlur', val);
            }
          "
          @Percentage4Point5-onChange="
            (val) => {
              $emit('PercentTextBox-onChange', val);
            }
          "
          @Percentage4Point5-onKeyPress="
            (val) => {
              $emit('PercentTextBox-onKeyPress', val);
            }
          "
          @Percentage4Point5-onKeyUp="
            (val) => {
              $emit('PercentTextBox-onKeyUp', val);
            }
          "
          @Percentage4Point5-onFocus="
            (val) => {
              $emit('PercentTextBox-onFocus', val);
            }
          "
          name="PercentTextBox"
          ref="RefPercentTextBox"
          v-bind="{
            ...PercentTextBox,
            ...configObject.PercentTextBox
          }"
          :values="configObject.PercentTextBox.PercentTextBoxValue"
          v-if="configObject.PercentTextBox != undefined ? configObject.PercentTextBox.isVisible : false"
        />
      </el-col>
        </el-row>

      </el-col>

      <el-col :lg="12" :md="12">
        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('BuyerTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('BuyerTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('BuyerTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('BuyerTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('BuyerTextBox-onFocus', val);
            }
          "
          name="BuyerTextBox"
          ref="RefBuyerTextBox"
          v-bind="{
            ...BuyerTextBox,
            ...configObject.BuyerTextBox
          }"
          :values="configObject.BuyerTextBox.BuyerTextBoxValue"
          v-if="configObject.BuyerTextBox != undefined ? configObject.BuyerTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('CountryTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('CountryTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('CountryTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('CountryTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('CountryTextBox-onFocus', val);
            }
          "
          name="CountryTextBox"
          ref="RefCountryTextBox"
          v-bind="{
            ...CountryTextBox,
            ...configObject.CountryTextBox
          }"
          :values="configObject.CountryTextBox.CountryTextBoxValue"
          v-if="configObject.CountryTextBox != undefined ? configObject.CountryTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('CityTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('CityTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('CityTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('CityTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('CityTextBox-onFocus', val);
            }
          "
          name="CityTextBox"
          ref="RefCityTextBox"
          v-bind="{
            ...CityTextBox,
            ...configObject.CityTextBox
          }"
          :values="configObject.CityTextBox.CityTextBoxValue"
          v-if="configObject.CityTextBox != undefined ? configObject.CityTextBox.isVisible : false"
        />

        <fieldset v-if="configObject.SectionRadioButton != undefined ? configObject.SectionRadioButton.isVisible : false">
          <GenericRadioButton
            @GenericRadioButton-onChange="
              (val) => {
                $emit('TypeRadioButton-onChange', val);
              }
            "
            @GenericRadioButton-onClick="
              (val) => {
                $emit('TypeRadioButton-onClick', val);
              }
            "
            name="TypeRadioButton"
            ref="RefTypeRadioButton"
            v-bind="{
              ...TypeRadioButton,
              ...configObject.TypeRadioButton,
            }"
            :values="configObject.TypeRadioButton.selectedValue"
            v-if="configObject.TypeRadioButton != undefined ? configObject.TypeRadioButton.isVisible : false"
          />
        </fieldset>

        <AmountNumericDecimal10Point2
          @AmountNumericDecimal10Point2-onBlur="
            (val) => {
              $emit('InvoiceAmountTextBox-onBlur', val);
            }
          "
          @AmountNumericDecimal10Point2-onChange="
            (val) => {
              $emit('InvoiceAmountTextBox-onChange', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyPress="
            (val) => {
              $emit('InvoiceAmountTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyUp="
            (val) => {
              $emit('InvoiceAmountTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal10Point2-onFocus="
            (val) => {
              $emit('InvoiceAmountTextBox-onFocus', val);
            }
          "
          name="InvoiceAmountTextBox"
          ref="RefInvoiceAmountTextBox"
          v-bind="{
            ...InvoiceAmountTextBox,
            ...configObject.InvoiceAmountTextBox
          }"
          :values="configObject.InvoiceAmountTextBox.InvoiceAmountTextBoxValue"
          v-if="configObject.InvoiceAmountTextBox != undefined ? configObject.InvoiceAmountTextBox.isVisible : false"
      />

        <AmountNumericDecimal10Point2
          @AmountNumericDecimal10Point2-onBlur="
            (val) => {
              $emit('InvAmtLCYTextBox-onBlur', val);
            }
          "
          @AmountNumericDecimal10Point2-onChange="
            (val) => {
              $emit('InvAmtLCYTextBox-onChange', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyPress="
            (val) => {
              $emit('InvAmtLCYTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyUp="
            (val) => {
              $emit('InvAmtLCYTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal10Point2-onFocus="
            (val) => {
              $emit('InvAmtLCYTextBox-onFocus', val);
            }
          "
          name="InvAmtLCYTextBox"
          ref="RefInvAmtLCYTextBox"
          v-bind="{
            ...InvAmtLCYTextBox,
            ...configObject.InvAmtLCYTextBox
          }"
          :values="configObject.InvAmtLCYTextBox.InvAmtLCYTextBoxValue"
          v-if="configObject.InvAmtLCYTextBox != undefined ? configObject.InvAmtLCYTextBox.isVisible : false"
        />


        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('VessNameAlphaNum-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('VessNameAlphaNum-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('VessNameAlphaNum-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('VessNameAlphaNum-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('VessNameAlphaNum-onFocus', val);
            }
          "
          name="VessNameAlphaNum"
          ref="RefVessNameAlphaNum"
          v-bind="{
            ...VessNameAlphaNum,
            ...configObject.VessNameAlphaNum
          }"
          :values="configObject.VessNameAlphaNum.VessNameAlphaNumValue"
          v-if="configObject.VessNameAlphaNum != undefined ? configObject.VessNameAlphaNum.isVisible : false"
      />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('CourierRefTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('CourierRefTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('CourierRefTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('CourierRefTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('CourierRefTextBox-onFocus', val);
            }
          "
          name="CourierRefTextBox"
          ref="RefCourierRefTextBox"
          v-bind="{
            ...CourierRefTextBox,
            ...configObject.CourierRefTextBox
          }"
          :values="configObject.CourierRefTextBox.CourierRefTextBoxValue"
          v-if="configObject.CourierRefTextBox != undefined ? configObject.CourierRefTextBox.isVisible : false"
        />

      

        <GenericDatePicker
          @GenericDatePicker-onBlur="
            (val) => {
              $emit('CourierDateTextBox-onBlur', val);
            }
          "
          @GenericDatePicker-onChange="
            (val) => {
              $emit('CourierDateTextBox-onChange', val);
            }
          "
          @GenericDatePicker-onKeyPress="
            (val) => {
              $emit('CourierDateTextBox-onKeyPress', val);
            }
          "
          @GenericDatePicker-onKeyUp="
            (val) => {
              $emit('CourierDateTextBox-onKeyUp', val);
            }
          "
          @GenericDatePicker-onFocus="
            (val) => {
              $emit('CourierDateTextBox-onFocus', val);
            }
          "
          name="CourierDateTextBox"
          ref="RefCourierDateTextBox"
          v-bind="{
            ...CourierDateTextBox,
            ...configObject.CourierDateTextBox
          }"
          :values="configObject.CourierDateTextBox.CourierDateTextBoxValue"
          v-if="configObject.CourierDateTextBox != undefined ? configObject.CourierDateTextBox.isVisible : false"
        />

        <AmountNumericDecimal10Point2
          @AmountNumericDecimal10Point2-onBlur="
            (val) => {
              $emit('CourierAmtTextBox-onBlur', val);
            }
          "
          @AmountNumericDecimal10Point2-onChange="
            (val) => {
              $emit('CourierAmtTextBox-onChange', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyPress="
            (val) => {
              $emit('CourierAmtTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyUp="
            (val) => {
              $emit('CourierAmtTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal10Point2-onFocus="
            (val) => {
              $emit('CourierAmtTextBox-onFocus', val);
            }
          "
          name="CourierAmtTextBox"
          ref="RefCourierAmtTextBox"
          v-bind="{
            ...CourierAmtTextBox,
            ...configObject.CourierAmtTextBox
          }"
          :values="configObject.CourierAmtTextBox.CourierAmtTextBoxValue"
          v-if="configObject.CourierAmtTextBox != undefined ? configObject.CourierAmtTextBox.isVisible : false"
        />
        
        <GenericDatePicker
          @GenericDatePicker-onBlur="
            (val) => {
              $emit('SchDateTextBox-onBlur', val);
            }
          "
          @GenericDatePicker-onChange="
            (val) => {
              $emit('SchDateTextBox-onChange', val);
            }
          "
          @GenericDatePicker-onKeyPress="
            (val) => {
              $emit('SchDateTextBox-onKeyPress', val);
            }
          "
          @GenericDatePicker-onKeyUp="
            (val) => {
              $emit('SchDateTextBox-onKeyUp', val);
            }
          "
          @GenericDatePicker-onFocus="
            (val) => {
              $emit('SchDateTextBox-onFocus', val);
            }
          "
          name="SchDateTextBox"
          ref="RefSchDateTextBox"
          v-bind="{
            ...SchDateTextBox,
            ...configObject.SchDateTextBox
          }"
          :values="configObject.SchDateTextBox.SchDateTextBoxValue"
          v-if="configObject.SchDateTextBox != undefined ? configObject.SchDateTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('ReimbBankTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('ReimbBankTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('ReimbBankTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('ReimbBankTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('ReimbBankTextBox-onFocus', val);
            }
          "
          name="ReimbBankTextBox"
          ref="RefReimbBankTextBox"
          v-bind="{
            ...ReimbBankTextBox,
            ...configObject.ReimbBankTextBox
          }"
          :values="configObject.ReimbBankTextBox.ReimbBankTextBoxValue"
          v-if="configObject.ReimbBankTextBox != undefined ? configObject.ReimbBankTextBox.isVisible : false"
        />

        <GenericTextBox
          @GenericTextBox-onBlur="
            (val) => {
              $emit('ReimbBranchTextBox-onBlur', val);
            }
          "
          @GenericTextBox-onChange="
            (val) => {
              $emit('ReimbBranchTextBox-onChange', val);
            }
          "
          @GenericTextBox-onKeyPress="
            (val) => {
              $emit('ReimbBranchTextBox-onKeyPress', val);
            }
          "
          @GenericTextBox-onKeyUp="
            (val) => {
              $emit('ReimbBranchTextBox-onKeyUp', val);
            }
          "
          @GenericTextBox-onFocus="
            (val) => {
              $emit('ReimbBranchTextBox-onFocus', val);
            }
          "
          name="ReimbBranchTextBox"
          ref="RefReimbBranchTextBox"
          v-bind="{
            ...ReimbBranchTextBox,
            ...configObject.ReimbBranchTextBox
          }"
          :values="configObject.ReimbBranchTextBox.ReimbBranchTextBoxValue"
          v-if="configObject.ReimbBranchTextBox != undefined ? configObject.ReimbBranchTextBox.isVisible : false"
        />

        <AmountNumericDecimal10Point2
          @AmountNumericDecimal10Point2-onBlur="
            (val) => {
              $emit('MarkupAmtTextBox-onBlur', val);
            }
          "
          @AmountNumericDecimal10Point2-onChange="
            (val) => {
              $emit('MarkupAmtTextBox-onChange', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyPress="
            (val) => {
              $emit('MarkupAmtTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyUp="
            (val) => {
              $emit('MarkupAmtTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal10Point2-onFocus="
            (val) => {
              $emit('MarkupAmtTextBox-onFocus', val);
            }
          "
          name="MarkupAmtTextBox"
          ref="RefMarkupAmtTextBox"
          v-bind="{
            ...MarkupAmtTextBox,
            ...configObject.MarkupAmtTextBox
          }"
          :values="configObject.MarkupAmtTextBox.MarkupAmtTextBoxValue"
          v-if="configObject.MarkupAmtTextBox != undefined ? configObject.MarkupAmtTextBox.isVisible : false"
        />
        
        <AmountNumericDecimal10Point2
          @AmountNumericDecimal10Point2-onBlur="
            (val) => {
              $emit('CharityAmtTextBox-onBlur', val);
            }
          "
          @AmountNumericDecimal10Point2-onChange="
            (val) => {
              $emit('CharityAmtTextBox-onChange', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyPress="
            (val) => {
              $emit('CharityAmtTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal10Point2-onKeyUp="
            (val) => {
              $emit('CharityAmtTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal10Point2-onFocus="
            (val) => {
              $emit('CharityAmtTextBox-onFocus', val);
            }
          "
          name="CharityAmtTextBox"
          ref="RefCharityAmtTextBox"
          v-bind="{
            ...CharityAmtTextBox,
            ...configObject.CharityAmtTextBox
          }"
          :values="configObject.CharityAmtTextBox.CharityAmtTextBoxValue"
          v-if="configObject.CharityAmtTextBox != undefined ? configObject.CharityAmtTextBox.isVisible : false"
        />

      </el-col>
    </el-row>

  

   

    
  </fieldset>
</el-tab-pane>

<el-tab-pane
  v-if="configObject.Instructions != undefined ? configObject.Instructions.isVisible : false"
  :label="configObject.Instructions.label"
  name="Instructions"
  ref="RefInstructions"
  :disabled="configObject.Instructions.isDisable"
>
  <fieldset>
    <el-row>
      <el-col :lg="14" :md="14">
        <el-form-item class="boldedLabel">Instructions</el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :lg="24" :md="24">
        <GenericTextArea
          @GenericTextArea-onBlur="
            (val) => {
              $emit('InstructionTextArea-onBlur', val);
            }
          "
          @GenericTextArea-onChange="
            (val) => {
              $emit('InstructionTextArea-onChange', val);
            }
          "
          @GenericTextArea-onKeyPress="
            (val) => {
              $emit('InstructionTextArea-onKeyPress', val);
            }
          "
          @GenericTextArea-onKeyUp="
            (val) => {
              $emit('InstructionTextArea-onKeyUp', val);
            }
          "
          @GenericTextArea-onFocus="
            (val) => {
              $emit('InstructionTextArea-onFocus', val);
            }
          "
          v-bind="{ ...InstructionTextArea, ...configObject.InstructionTextArea }"
          name="InstructionTextArea"
          ref="RefInstructionTextArea"
          :values="configObject.InstructionTextArea.InstructionTextAreaValue"
          v-if="configObject.InstructionTextArea != undefined ? configObject.InstructionTextArea.isVisible : false"
        />
      </el-col>
    </el-row>

    <br />

    <el-row>
      <el-col :lg="14" :md="14">
        <el-form-item class="boldedLabel">Remarks</el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :lg="24" :md="24">
        <GenericTextArea
          @GenericTextArea-onBlur="
            (val) => {
              $emit('RemarksTextArea-onBlur', val);
            }
          "
          @GenericTextArea-onChange="
            (val) => {
              $emit('RemarksTextArea-onChange', val);
            }
          "
          @GenericTextArea-onKeyPress="
            (val) => {
              $emit('RemarksTextArea-onKeyPress', val);
            }
          "
          @GenericTextArea-onKeyUp="
            (val) => {
              $emit('RemarksTextArea-onKeyUp', val);
            }
          "
          @GenericTextArea-onFocus="
            (val) => {
              $emit('RemarksTextArea-onFocus', val);
            }
          "
          v-bind="{ ...RemarksTextArea, ...configObject.RemarksTextArea }"
          name="RemarksTextArea"
          ref="RefRemarksTextArea"
          :values="configObject.RemarksTextArea.RemarksTextAreaValue"
          v-if="configObject.RemarksTextArea != undefined ? configObject.RemarksTextArea.isVisible : false"
        />
      </el-col>
    </el-row>
  </fieldset>
</el-tab-pane>

     

<el-tab-pane
  v-if="configObject.LC_Contracts != undefined ? configObject.LC_Contracts.isVisible : false"
  :label="configObject.LC_Contracts.label"
  name="LC_Contracts"
  ref="RefLC_Contracts"
  :disabled="configObject.LC_Contracts.isDisabled"
>
<el-row>
       <el-col :lg="2" :md="2">
       </el-col>
       <el-col :lg="7" :md="7">
         <el-form-item>{{ configObject.LC_ContractNo.label }}</el-form-item>
       </el-col>
       <el-col :lg="7" :md="7">
        <el-form-item>{{ configObject.LC_ContractDate.label }}</el-form-item>
       </el-col>
       <el-col :lg="8" :md="8">
        <el-form-item>{{ configObject.LC_ContractAmount.label }}</el-form-item>
       </el-col>


      </el-row>

      <el-row>

      <el-col :lg="1" :md="1">
       <el-form-item>1</el-form-item>
      </el-col>
      <el-col :lg="1" :md="1"></el-col>
      <el-col :lg="7" :md="7">
       <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('TextBox1-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('TextBox1-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('TextBox1-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('TextBox1-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('TextBox1-onFocus', val);
              }
            "
            name="TextBox1"
            ref="RefTextBox1"
            v-bind="{
              ...TextBox1,
              ...configObject.TextBox1
            }"
            :values="configObject.TextBox1.TextBox1Value"
            v-if="configObject.TextBox1 != undefined ? configObject.TextBox1.isVisible : false"
          />
     </el-col>
     <el-col :lg="7" :md="7">
       <GenericDatePicker
            @GenericDatePicker-onBlur="
              (val) => {
                $emit('DateBox-onBlur', val);
              }
            "
            @GenericDatePicker-onChange="
              (val) => {
                $emit('DateBox-onChange', val);
              }
            "
            @GenericDatePicker-onKeyPress="
              (val) => {
                $emit('DateBox-onKeyPress', val);
              }
            "
            @GenericDatePicker-onKeyUp="
              (val) => {
                $emit('DateBox-onKeyUp', val);
              }
            "
            @GenericDatePicker-onFocus="
              (val) => {
                $emit('DateBox-onFocus', val);
              }
            "
            name="DateBox"
            ref="RefDateBox"
            v-bind="{
              ...DateBox,
              ...configObject.DateBox
            }"
            :values="configObject.DateBox.DateBoxValue"
            v-if="configObject.DateBox != undefined ? configObject.DateBox.isVisible : false"
          />
      </el-col>
      <el-col :lg="7" :md="7">
        <AmountNumericDecimal11Point3
            @AmountNumericDecimal11Point3-onBlur="
              (val) => {
                $emit('Amount1-onBlur', val);
              }
            "
            @AmountNumericDecimal11Point3-onChange="
              (val) => {
                $emit('Amount1-onChange', val);
              }
            "
            @AmountNumericDecimal11Point3-onKeyPress="
              (val) => {
                $emit('Amount1-onKeyPress', val);
              }
            "
            @AmountNumericDecimal11Point3-onKeyUp="
              (val) => {
                $emit('Amount1-onKeyUp', val);
              }
            "
            @AmountNumericDecimal11Point3-onFocus="
              (val) => {
                $emit('Amount1-onFocus', val);
              }
            "
            name="Amount1"
            ref="RefAmount1"
            v-bind="{
              ...Amount1,
              ...configObject.Amount1
            }"
            :values="configObject.Amount1.Amount1Value"
            v-if="configObject.Amount1 != undefined ? configObject.Amount1.isVisible : false"
          />
       </el-col>
       <el-col :lg="1" :md="1">
       </el-col>

      </el-row>

      <el-row>

<el-col :lg="1" :md="1">
 <el-form-item>2</el-form-item>
</el-col>
<el-col :lg="1" :md="1"></el-col>
<el-col :lg="7" :md="7">
 <GenericTextBox
      @GenericTextBox-onBlur="
        (val) => {
          $emit('TextBox2-onBlur', val);
        }
      "
      @GenericTextBox-onChange="
        (val) => {
          $emit('TextBox2-onChange', val);
        }
      "
      @GenericTextBox-onKeyPress="
        (val) => {
          $emit('TextBox2-onKeyPress', val);
        }
      "
      @GenericTextBox-onKeyUp="
        (val) => {
          $emit('TextBox2-onKeyUp', val);
        }
      "
      @GenericTextBox-onFocus="
        (val) => {
          $emit('TextBox2-onFocus', val);
        }
      "
      name="TextBox2"
      ref="RefTextBox2"
      v-bind="{
        ...TextBox2,
        ...configObject.TextBox2
      }"
      :values="configObject.TextBox2.TextBox2Value"
      v-if="configObject.TextBox2 != undefined ? configObject.TextBox2.isVisible : false"
    />
</el-col>
<el-col :lg="7" :md="7">
 <GenericDatePicker
      @GenericDatePicker-onBlur="
        (val) => {
          $emit('DateBox2-onBlur', val);
        }
      "
      @GenericDatePicker-onChange="
        (val) => {
          $emit('DateBox2-onChange', val);
        }
      "
      @GenericDatePicker-onKeyPress="
        (val) => {
          $emit('DateBox2-onKeyPress', val);
        }
      "
      @GenericDatePicker-onKeyUp="
        (val) => {
          $emit('DateBox2-onKeyUp', val);
        }
      "
      @GenericDatePicker-onFocus="
        (val) => {
          $emit('DateBox2-onFocus', val);
        }
      "
      name="DateBox2"
      ref="RefDateBox2"
      v-bind="{
        ...DateBox2,
        ...configObject.DateBox2
      }"
      :values="configObject.DateBox2.DateBox2Value"
      v-if="configObject.DateBox2 != undefined ? configObject.DateBox2.isVisible : false"
    />
</el-col>
<el-col :lg="7" :md="7">
  <AmountNumericDecimal11Point3
      @AmountNumericDecimal11Point3-onBlur="
        (val) => {
          $emit('Amount2-onBlur', val);
        }
      "
      @AmountNumericDecimal11Point3-onChange="
        (val) => {
          $emit('Amount2-onChange', val);
        }
      "
      @AmountNumericDecimal11Point3-onKeyPress="
        (val) => {
          $emit('Amount2-onKeyPress', val);
        }
      "
      @AmountNumericDecimal11Point3-onKeyUp="
        (val) => {
          $emit('Amount2-onKeyUp', val);
        }
      "
      @AmountNumericDecimal11Point3-onFocus="
        (val) => {
          $emit('Amount2-onFocus', val);
        }
      "
      name="Amount2"
      ref="RefAmount2"
      v-bind="{
        ...Amount2,
        ...configObject.Amount2
      }"
      :values="configObject.Amount2.Amount2Value"
      v-if="configObject.Amount2 != undefined ? configObject.Amount2.isVisible : false"
    />
 </el-col>
 <el-col :lg="1" :md="1">
 </el-col>

      </el-row>

      <el-row>

<el-col :lg="1" :md="1">
 <el-form-item>3</el-form-item>
</el-col>
<el-col :lg="1" :md="1"></el-col>
<el-col :lg="7" :md="7">
 <GenericTextBox
      @GenericTextBox-onBlur="
        (val) => {
          $emit('TextBox3-onBlur', val);
        }
      "
      @GenericTextBox-onChange="
        (val) => {
          $emit('TextBox3-onChange', val);
        }
      "
      @GenericTextBox-onKeyPress="
        (val) => {
          $emit('TextBox3-onKeyPress', val);
        }
      "
      @GenericTextBox-onKeyUp="
        (val) => {
          $emit('TextBox3-onKeyUp', val);
        }
      "
      @GenericTextBox-onFocus="
        (val) => {
          $emit('TextBox3-onFocus', val);
        }
      "
      name="TextBox3"
      ref="RefTextBox3"
      v-bind="{
        ...TextBox3,
        ...configObject.TextBox3
      }"
      :values="configObject.TextBox3.TextBox3Value"
      v-if="configObject.TextBox3 != undefined ? configObject.TextBox3.isVisible : false"
    />
</el-col>
<el-col :lg="7" :md="7">
 <GenericDatePicker
      @GenericDatePicker-onBlur="
        (val) => {
          $emit('DateBox3-onBlur', val);
        }
      "
      @GenericDatePicker-onhange="
        (val) => {
          $emit('DateBox3-onChange', val);
        }
      "
      @GenericDatePicker-oneyPress="
        (val) => {
          $emit('DateBox3-onKeyPress', val);
        }
      "
      @GenericDatePicker-oneyUp="
        (val) => {
          $emit('DateBox3-onKeyUp', val);
        }
      "
      @GenericDatePicker-onocus="
        (val) => {
          $emit('DateBox3-onFocus', val);
        }
    "
      name="DateBox3"
      ref="RefDateBox3"
      v-bind="{
      ...DateBox3,
        ...configObject.DateBox3
    }"
    :values="configObject.DateBox3.DateBox3Value"
      v-if="configObject.DateBox3 != undefined ? configObject.DateBox3.isVisible : false"
    />
</el-col>
<el-col :lg="7" :md="7">
  <AmountNumericDecimal11Point3
      @AmountNumericDecimal11Point3-onBlur="
        (val) => {
          $emit('Amount3-onBlur', val);
        }
      "
      @AmountNumericDecimal11Point3-onChange="
        (val) => {
          $emit('Amount3-onChange', val);
        }
      "
      @AmountNumericDecimal11Point3-onKeyPress="
        (val) => {
          $emit('Amount3-onKeyPress', val);
        }
      "
      @AmountNumericDecimal11Point3-onKeyUp="
        (val) => {
          $emit('Amount3-onKeyUp', val);
        }
      "
      @AmountNumericDecimal11Point3-onFocus="
        (val) => {
          $emit('Amount3-onFocus', val);
        }
      "
      name="Amount3"
      ref="RefAmount3"
      v-bind="{
        ...Amount3,
        ...configObject.Amount3
      }"
      :values="configObject.Amount3.Amount3Value"
      v-if="configObject.Amount3 != undefined ? configObject.Amount3.isVisible : false"
    />
 </el-col>
 <el-col :lg="1" :md="1">
 </el-col>

      </el-row>

      <el-row>

<el-col :lg="1" :md="1">
 <el-form-item>4</el-form-item>
</el-col>
<el-col :lg="1" :md="1"></el-col>
<el-col :lg="7" :md="7">
 <GenericTextBox
      @GenericTextBox-onBlur="
        (val) => {
          $emit('TextBox4-onBlur', val);
        }
      "
      @GenericTextBox-onChange="
        (val) => {
          $emit('TextBox4-onChange', val);
        }
      "
      @GenericTextBox-onKeyPress="
        (val) => {
          $emit('TextBox4-onKeyPress', val);
        }
      "
      @GenericTextBox-onKeyUp="
        (val) => {
          $emit('TextBox4-onKeyUp', val);
        }
      "
      @GenericTextBox-onFocus="
        (val) => {
          $emit('TextBox4-onFocus', val);
        }
      "
      name="TextBox4"
      ref="RefTextBox4"
      v-bind="{
        ...TextBox4,
        ...configObject.TextBox4
      }"
      :values="configObject.TextBox4.TextBox4Value"
      v-if="configObject.TextBox4 != undefined ? configObject.TextBox4.isVisible : false"
    />
</el-col>
<el-col :lg="7" :md="7">
 <GenericDatePicker
      @GenericDatePicker-onBlur="
        (val) => {
          $emit('DateBox4-onBlur', val);
        }
      "
      @GenericDatePicker-onhange="
        (val) => {
          $emit('DateBox4-onChange', val);
        }
      "
      @GenericDatePicker-oneyPress="
        (val) => {
          $emit('DateBox4-onKeyPress', val);
        }
      "
      @GenericDatePicker-oneyUp="
        (val) => {
          $emit('DateBox4-onKeyUp', val);
        }
      "
      @GenericDatePicker-onocus="
        (val) => {
          $emit('DateBox4-onFocus', val);
        }
    "
      name="DateBox4"
      ref="RefDateBox4"
      v-bind="{
      ...DateBox4,
        ...configObject.DateBox4
    }"
    :values="configObject.DateBox4.DateBox4Value"
      v-if="configObject.DateBox4 != undefined ? configObject.DateBox4.isVisible : false"
    />
</el-col>
<el-col :lg="7" :md="7">
  <AmountNumericDecimal11Point3
      @AmountNumericDecimal11Point3-onBlur="
        (val) => {
          $emit('Amount4-onBlur', val);
        }
      "
      @AmountNumericDecimal11Point3-onChange="
        (val) => {
          $emit('Amount4-onChange', val);
        }
      "
      @AmountNumericDecimal11Point3-onKeyPress="
        (val) => {
          $emit('Amount4-onKeyPress', val);
        }
      "
      @AmountNumericDecimal11Point3-onKeyUp="
        (val) => {
          $emit('Amount4-onKeyUp', val);
        }
      "
      @AmountNumericDecimal11Point3-onFocus="
        (val) => {
          $emit('Amount4-onFocus', val);
        }
      "
      name="Amount4"
      ref="RefAmount4"
      v-bind="{
        ...Amount4,
        ...configObject.Amount4
      }"
      :values="configObject.Amount4.Amount4Value"
      v-if="configObject.Amount4 != undefined ? configObject.Amount4.isVisible : false"
    />
 </el-col>
 <el-col :lg="1" :md="1">
 </el-col>

      </el-row>

      <el-row>

<el-col :lg="1" :md="1">
 <el-form-item>5</el-form-item>
</el-col>
<el-col :lg="1" :md="1"></el-col>
<el-col :lg="7" :md="7">
 <GenericTextBox
      @GenericTextBox-onBlur="
        (val) => {
          $emit('TextBox5-onBlur', val);
        }
      "
      @GenericTextBox-onChange="
        (val) => {
          $emit('TextBox5-onChange', val);
        }
      "
      @GenericTextBox-onKeyPress="
        (val) => {
          $emit('TextBox5-onKeyPress', val);
        }
      "
      @GenericTextBox-onKeyUp="
        (val) => {
          $emit('TextBox5-onKeyUp', val);
        }
      "
      @GenericTextBox-onFocus="
        (val) => {
          $emit('TextBox5-onFocus', val);
        }
      "
      name="TextBox5"
      ref="RefTextBox5"
      v-bind="{
        ...TextBox5,
        ...configObject.TextBox5
      }"
      :values="configObject.TextBox5.TextBox5Value"
      v-if="configObject.TextBox5 != undefined ? configObject.TextBox5.isVisible : false"
    />
</el-col>
<el-col :lg="7" :md="7">
 <GenericDatePicker
      @GenericDatePicker-onBlur="
        (val) => {
          $emit('DateBox5-onBlur', val);
        }
      "
      @GenericDatePicker-onhange="
        (val) => {
          $emit('DateBox5-onChange', val);
        }
      "
      @GenericDatePicker-oneyPress="
        (val) => {
          $emit('DateBox5-onKeyPress', val);
        }
      "
      @GenericDatePicker-oneyUp="
        (val) => {
          $emit('DateBox5-onKeyUp', val);
        }
      "
      @GenericDatePicker-onocus="
        (val) => {
          $emit('DateBox5-onFocus', val);
        }
    "
      name="DateBox5"
      ref="RefDateBox5"
      v-bind="{
      ...DateBox5,
        ...configObject.DateBox5
    }"
    :values="configObject.DateBox5.DateBox5Value"
      v-if="configObject.DateBox5 != undefined ? configObject.DateBox5.isVisible : false"
    />
</el-col>
<el-col :lg="7" :md="7">
  <AmountNumericDecimal11Point3
      @AmountNumericDecimal11Point3-onBlur="
        (val) => {
          $emit('Amount5-onBlur', val);
        }
      "
      @AmountNumericDecimal11Point3-onChange="
        (val) => {
          $emit('Amount5-onChange', val);
        }
      "
      @AmountNumericDecimal11Point3-onKeyPress="
        (val) => {
          $emit('Amount5-onKeyPress', val);
        }
      "
      @AmountNumericDecimal11Point3-onKeyUp="
        (val) => {
          $emit('Amount5-onKeyUp', val);
        }
      "
      @AmountNumericDecimal11Point3-onFocus="
        (val) => {
          $emit('Amount5-onFocus', val);
        }
      "
      name="Amount5"
      ref="RefAmount5"
      v-bind="{
        ...Amount5,
        ...configObject.Amount5
      }"
      :values="configObject.Amount5.Amount5Value"
      v-if="configObject.Amount5 != undefined ? configObject.Amount5.isVisible : false"
    />
 </el-col>
 <el-col :lg="1" :md="1">
 </el-col>

      </el-row>

      <fieldset v-if="configObject.Section1 != undefined ? configObject.Section1.isVisible : false">
      <el-row>
        <el-col :lg="12" :md="12">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('InvNoTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('InvNoTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('InvNoTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('InvNoTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('InvNoTextBox-onFocus', val);
              }
            "
            name="InvNoTextBox"
            ref="RefInvNoTextBox"
            v-bind="{
              ...InvNoTextBox,
              ...configObject.InvNoTextBox
            }"
            :values="configObject.InvNoTextBox.InvNoTextBoxValue"
            v-if="configObject.InvNoTextBox != undefined ? configObject.InvNoTextBox.isVisible : false"
          />
        </el-col>
        <el-col :lg="12" :md="12">
          <GenericDatePicker
            @GenericDatePicker-onBlur="
              (val) => {
                $emit('InvDtTextBox-onBlur', val);
              }
            "
            @GenericDatePicker-onChange="
              (val) => {
                $emit('InvDtTextBox-onChange', val);
              }
            "
            @GenericDatePicker-onKeyPress="
              (val) => {
                $emit('InvDtTextBox-onKeyPress', val);
              }
            "
            @GenericDatePicker-onKeyUp="
              (val) => {
                $emit('InvDtTextBox-onKeyUp', val);
              }
            "
            @GenericDatePicker-onFocus="
              (val) => {
                $emit('InvDtTextBox-onFocus', val);
              }
            "
            name="InvDtTextBox"
            ref="RefInvDtTextBox"
            v-bind="{
              ...InvDtTextBox,
              ...configObject.InvDtTextBox
            }"
            :values="configObject.InvDtTextBox.InvDtTextBoxValue"
            v-if="configObject.InvDtTextBox != undefined ? configObject.InvDtTextBox.isVisible : false"
          />
        </el-col>
      </el-row>

      <el-row>
        <el-col :lg="12" :md="12">
          <AmountNumericDecimal10Point2
            @AmountNumericDecimal10Point2-onBlur="
              (val) => {
                $emit('FOBValueTextBox-onBlur', val);
              }
            "
            @AmountNumericDecimal10Point2-onChange="
              (val) => {
                $emit('FOBValueTextBox-onChange', val);
              }
            "
            @AmountNumericDecimal10Point2-onKeyPress="
              (val) => {
                $emit('FOBValueTextBox-onKeyPress', val);
              }
            "
            @AmountNumericDecimal10Point2-onKeyUp="
              (val) => {
                $emit('FOBValueTextBox-onKeyUp', val);
              }
            "
            @AmountNumericDecimal10Point2-onFocus="
              (val) => {
                $emit('FOBValueTextBox-onFocus', val);
              }
            "
            name="FOBValueTextBox"
            ref="RefFOBValueTextBox"
            v-bind="{
              ...FOBValueTextBox,
              ...configObject.FOBValueTextBox
            }"
            :values="configObject.FOBValueTextBox.FOBValueTextBoxValue"
            v-if="configObject.FOBValueTextBox != undefined ? configObject.FOBValueTextBox.isVisible : false"
          />
        </el-col>

        <el-col :lg="12" :md="12">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('BLNoTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('BLNoTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('BLNoTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('BLNoTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('BLNoTextBox-onFocus', val);
              }
            "
            name="BLNoTextBox"
            ref="RefBLNoTextBox"
            v-bind="{
              ...BLNoTextBox,
              ...configObject.BLNoTextBox
            }"
            :values="configObject.BLNoTextBox.BLNoTextBoxValue"
            v-if="configObject.BLNoTextBox != undefined ? configObject.BLNoTextBox.isVisible : false"
          />
        </el-col>
      </el-row>
      </fieldset>

      <el-row>
        <el-col :lg="15" :md="15">
          <GenericTextBox
            @GenericTextBox-onBlur="
              (val) => {
                $emit('DocRemTextBox-onBlur', val);
              }
            "
            @GenericTextBox-onChange="
              (val) => {
                $emit('DocRemTextBox-onChange', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('DocRemTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('DocRemTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onFocus="
              (val) => {
                $emit('DocRemTextBox-onFocus', val);
              }
            "
            name="DocRemTextBox"
            ref="RefDocRemTextBox"
            v-bind="{
              ...DocRemTextBox,
              ...configObject.DocRemTextBox
            }"
            :values="configObject.DocRemTextBox.DocRemTextBoxValue"
            v-if="configObject.DocRemTextBox != undefined ? configObject.DocRemTextBox.isVisible : false"
          />
        </el-col>
        <el-col :lg="4" :md="4">
        <el-form-item v-if="configObject.EDSRefNo != undefined ? configObject.EDSRefNo.isVisible : false">{{ configObject.EDSRefNo.label }}</el-form-item>
        </el-col>
        <el-col :lg="2" :md="2">
        <el-form-item v-if="configObject.EDSRefNoValue != undefined ? configObject.EDSRefNoValue.isVisible : false">{{ configObject.EDSRefNoValue.label }}</el-form-item>
        </el-col>
      </el-row>

      <fieldset v-if="configObject.Section1GD != undefined ? configObject.Section1GD.isVisible : false">
      <el-row>
        <el-col :lg="12" :md="12">
          <GenericDropDown
            @GenericDropDown-onChange="
              (val) => {
                $emit('GDNumberDropDown-onChange', val);
              }
            "
            name="GDNumberDropDown"
            ref="RefGDNumberDropDown"
            v-bind="{
              ...GDNumberDropDown,
              ...configObject.GDNumberDropDown
            }"
            :values="configObject.GDNumberDropDown.branchList"
            v-if="configObject.GDNumberDropDown  !=undefined ? configObject.GDNumberDropDown.isVisible :false"
          />

        </el-col>
        <el-col :lg="12" :md="12">
          <AmountNumericDecimal11Point3
            @AmountNumericDecimal11Point3-onBlur="
              (val) => {
                $emit('InvAmount-onBlur', val);
              }
            "
            @AmountNumericDecimal11Point3-onChange="
              (val) => {
                $emit('InvAmount-onChange', val);
              }
            "
            @AmountNumericDecimal11Point3-onKeyPress="
              (val) => {
                $emit('InvAmount-onKeyPress', val);
              }
            "
            @AmountNumericDecimal11Point3-onKeyUp="
              (val) => {
                $emit('InvAmount-onKeyUp', val);
              }
            "
            @AmountNumericDecimal11Point3-onFocus="
              (val) => {
                $emit('InvAmount-onFocus', val);
              }
            "
            name="InvAmount"
            ref="RefInvAmount"
            v-bind="{
              ...InvAmount,
              ...configObject.InvAmount
            }"
            :values="configObject.InvAmount.AInvAmountValue"
            v-if="configObject.InvAmount != undefined ? configObject.InvAmount.isVisible : false"
          />
        </el-col>

      </el-row>
      
    </fieldset>

    <el-row>
      <el-col :lg="24" :md="24">
        <GenericSortableTableView @BranchInfoTable2-onClickRow="(val) => {
            $emit('InfoTable1-onClickRow', val);
          }
          " v-bind="{ ...InfoTable1, ...configObject.InfoTable1 }" name="InfoTable1"
          ref="RefInfoTable1" v-if="configObject.InfoTable1.isVisible" />
      </el-col>
    </el-row>

    <el-row>
      <el-col :lg="12" :md="12">
          <AmountNumericDecimal11Point3
            @AmountNumericDecimal11Point3-onBlur="
              (val) => {
                $emit('TotalFOBValue-onBlur', val);
              }
            "
            @AmountNumericDecimal11Point3-onChange="
              (val) => {
                $emit('TotalFOBValue-onChange', val);
              }
            "
            @AmountNumericDecimal11Point3-onKeyPress="
              (val) => {
                $emit('TotalFOBValue-onKeyPress', val);
              }
            "
            @AmountNumericDecimal11Point3-onKeyUp="
              (val) => {
                $emit('TotalFOBValue-onKeyUp', val);
              }
            "
            @AmountNumericDecimal11Point3-onFocus="
              (val) => {
                $emit('TotalFOBValue-onFocus', val);
              }
            "
            name="TotalFOBValue"
            ref="RefTotalFOBValue"
            v-bind="{
              ...TotalFOBValue,
              ...configObject.TotalFOBValue
            }"
            :values="configObject.TotalFOBValue.TotalFOBValueValue"
            v-if="configObject.TotalFOBValue != undefined ? configObject.TotalFOBValue.isVisible : false"
          />
        </el-col>
        <el-col :md="2" :lg="2"></el-col>
        <el-col :md="3" :lg="3">
         
      <GenericButton
        @GenericButton-onClick="$emit('AddGdButton-onClick')"
        @GenericButton-onFocus="$emit('AddGdButton-onFocus')"
        name="AddGdButton"
        ref="RefAddGdButton"
        v-bind="{ ...AddGdButton, ...configObject.AddGdButton }"
        v-if="configObject.AddGdButton != undefined ? configObject.AddGdButton.isVisible : false"
      />
    </el-col>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('RemoveGdButton-onClick')"
        @GenericButton-onFocus="$emit('RemoveGdButton-onFocus')"
        name="RemoveGdButton"
        ref="RefRemoveGdButton"
        v-bind="{ ...RemoveGdButton, ...configObject.RemoveGdButton }"
        v-if="configObject.RemoveGdButton != undefined ? configObject.RemoveGdButton.isVisible : false"
      />
    </el-col>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('ChangeGdButton-onClick')"
        @GenericButton-onFocus="$emit('ChangeGdButton-onFocus')"
        name="ChangeGdButton"
        ref="RefChangeGdButton"
        v-bind="{ ...ChangeGdButton, ...configObject.ChangeGdButton }"
        v-if="configObject.ChangeGdButton != undefined ? configObject.ChangeGdButton.isVisible : false"
      />
    </el-col>
    </el-row>
    <el-row>
      <el-col :lg="12" :md="12">
          <AmountNumericDecimal11Point3
            @AmountNumericDecimal11Point3-onBlur="
              (val) => {
                $emit('TotalInvAmount-onBlur', val);
              }
            "
            @AmountNumericDecimal11Point3-onChange="
              (val) => {
                $emit('TotalInvAmount-onChange', val);
              }
            "
            @AmountNumericDecimal11Point3-onKeyPress="
              (val) => {
                $emit('TotalInvAmount-onKeyPress', val);
              }
            "
            @AmountNumericDecimal11Point3-onKeyUp="
              (val) => {
                $emit('TotalInvAmount-onKeyUp', val);
              }
            "
            @AmountNumericDecimal11Point3-onFocus="
              (val) => {
                $emit('TotalInvAmount-onFocus', val);
              }
            "
            name="TotalInvAmount"
            ref="RefTotalInvAmount"
            v-bind="{
              ...TotalInvAmount,
              ...configObject.TotalInvAmount
            }"
            :values="configObject.TotalInvAmount.TotalInvAmountValue"
            v-if="configObject.TotalInvAmount != undefined ? configObject.TotalInvAmount.isVisible : false"
          />
        </el-col>
    </el-row>
</el-tab-pane>

<el-tab-pane
  v-if="configObject.DocBank != undefined ? configObject.DocBank.isVisible : false"
  :label="configObject.DocBank.label"
  name="DocBank"
  ref="RefDocBank"
  :disabled="configObject.DocBank.isDisabled"
>
  <fieldset>
    <el-row>
      <el-col :lg="24" :md="24">
        <GenericTextArea
          @GenericTextArea-onBlur="
            (val) => {
              $emit('AddressTextArea-onBlur', val);
            }
          "
          @GenericTextArea-onChange="
            (val) => {
              $emit('AddressTextArea-onChange', val);
            }
          "
          @GenericTextArea-onKeyPress="
            (val) => {
              $emit('AddressTextArea-onKeyPress', val);
            }
          "
          @GenericTextArea-onKeyUp="
            (val) => {
              $emit('AddressTextArea-onKeyUp', val);
            }
          "
          @GenericTextArea-onFocus="
            (val) => {
              $emit('AddressTextArea-onFocus', val);
            }
          "
          v-bind="{ ...AddressTextArea, ...configObject.AddressTextArea }"
          name="AddressTextArea"
          ref="RefAddressTextArea"
          :values="configObject.AddressTextArea.AddressTextAreaValue"
          v-if="configObject.AddressTextArea != undefined ? configObject.AddressTextArea.isVisible : false"
        />
      </el-col>
    </el-row>
  </fieldset>
</el-tab-pane>
    
<el-tab-pane
  v-if="configObject.FDBPChargesTab != undefined ? configObject.FDBPChargesTab.isVisible : false"
  :label="configObject.FDBPChargesTab.label"
  name="FDBPChargesTab"
  ref="RefFDBPChargesTab"
  :disabled="configObject.FDBPChargesTab.isDisabled"
>
  <el-row>
    <el-col :lg="24" :md="24">
      <GenericSortableTableView
        @GenericSortableTableView-onClickRow="
          (val) => {
            $emit('FdbpChargesTable-onClickRow', val);
          }
        "
        @GenericSortableTableView-onCurrentRow="
          (val) => {
            $emit('FdbpChargesTable-onCurrentRow', val);
          }
        "
        @GenericSortableTableView-onDoubleClickRow="
          (val) => {
            $emit('FdbpChargesTable-onDoubleClickRow', val);
          }
        "
        name="FdbpChargesTable"
        ref="RefFdbpChargesTable"
        v-if="configObject.FdbpChargesTable != undefined ? configObject.FdbpChargesTable.isVisible : false"
        v-bind="{ ...FdbpChargesTable, ...configObject.FdbpChargesTable }"
      />
    </el-col>
  </el-row>
</el-tab-pane>
    </el-tabs>

    <fieldset>
  <el-row>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('OkButton-onClick')"
        name="OkButton"
        ref="RefOkButton"
        v-bind="{ ...OkButton, ...configObject.OkButton }"
        v-if="configObject.OkButton != undefined ? configObject.OkButton.isVisible : false"
      />
    </el-col>
    <el-col :md="2" :lg="2"></el-col>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('viewVoucherButton-onClick')"
        @GenericButton-onFocus="$emit('viewVoucherButton-onFocus')"
        name="viewVoucherButton"
        ref="RefviewVoucherButton"
        v-bind="{ ...viewVoucherButton, ...configObject.viewVoucherButton }"
        v-if="configObject.viewVoucherButton != undefined ? configObject.viewVoucherButton.isVisible : false"
      />

      <GenericButton
        @GenericButton-onClick="$emit('ExceptionButton-onClick')"
        @GenericButton-onFocus="$emit('ExceptionButton-onFocus')"
        name="ExceptionButton"
        ref="RefExceptionButton"
        v-bind="{ ...ExceptionButton, ...configObject.ExceptionButton }"
        v-if="configObject.ExceptionButton != undefined ? configObject.ExceptionButton.isVisible : false"
      />
    </el-col>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('fxDetailBtn-onClick')"
        @GenericButton-onFocus="$emit('fxDetailBtn-onFocus')"
        name="fxDetailBtn"
        ref="ReffxDetailBtn"
        v-bind="{ ...fxDetailBtn, ...configObject.fxDetailBtn }"
        v-if="configObject.fxDetailBtn != undefined ? configObject.fxDetailBtn.isVisible : false"
      />
    </el-col>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('viewFdbpDocsBtn-onClick')"
        @GenericButton-onFocus="$emit('viewFdbpDocsBtn-onFocus')"
        name="viewFdbpDocsBtn"
        ref="RefviewFdbpDocsBtn"
        v-bind="{ ...viewFdbpDocsBtn, ...configObject.viewFdbpDocsBtn }"
        v-if="configObject.viewFdbpDocsBtn != undefined ? configObject.viewFdbpDocsBtn.isVisible : false"
      />

      <GenericButton
        @GenericButton-onClick="$emit('viewFdbcDocsBtn-onClick')"
        @GenericButton-onFocus="$emit('viewFdbcDocsBtn-onFocus')"
        name="viewFdbcDocsBtn"
        ref="RefviewFdbcDocsBtn"
        v-bind="{ ...viewFdbcDocsBtn, ...configObject.viewFdbcDocsBtn }"
        v-if="configObject.viewFdbcDocsBtn != undefined ? configObject.viewFdbcDocsBtn.isVisible : false"
      />
    </el-col>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('viewDocsBtn-onClick')"
        @GenericButton-onFocus="$emit('viewDocsBtn-onFocus')"
        name="viewDocsBtn"
        ref="RefviewDocsBtn"
        v-bind="{ ...viewDocsBtn, ...configObject.viewDocsBtn }"
        v-if="configObject.viewDocsBtn != undefined ? configObject.viewDocsBtn.isVisible : false"
      />
    </el-col>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('BackBtn-onClick')"
        @GenericButton-onFocus="$emit('BackBtn-onFocus')"
        name="BackBtn"
        ref="RefBackBtn"
        v-bind="{ ...BackBtn, ...configObject.BackBtn }"
        v-if="configObject.BackBtn != undefined ? configObject.BackBtn.isVisible : false"
      />
    </el-col>
    <el-col :md="3" :lg="3">
      <GenericButton
        @GenericButton-onClick="$emit('ExitBtn-onClick')"
        @GenericButton-onFocus="$emit('ExitBtn-onFocus')"
        name="ExitBtn"
        ref="RefExitBtn"
        v-bind="{ ...ExitBtn, ...configObject.ExitBtn }"
        v-if="configObject.ExitBtn != undefined ? configObject.ExitBtn.isVisible : false"
      />
    </el-col>
  </el-row>
  <el-row>
    <el-col :md="3" :lg="3"></el-col>
    <el-col :md="2" :lg="2"></el-col>
   
    <el-col :md="3" :lg="3"></el-col>
    <el-col :md="3" :lg="3">
      
    </el-col>
  </el-row>
</fieldset>
  </Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import { reactive } from 'vue';
import {
  GenericTextBox, GenericButton, GenericDropDown, RateNumericDecimal9Point5, RateNumericDecimal3Point2, AmountNumericDecimal10Point2, AccountNumberNumericDashes21, GenericRadioButton, Percentage4Point5, ExchangeRateNumericDecimal10Point5, GenericDatePicker,
  DateDdMmYyyy,
  GenericCheckBox,
  CnicNumberNumericDashes15,
  PassportPakistanAlphaNumeric10,
  AccountTitleString45,
  CurrencyAlphaNumericSpecial25,
  AmountNumericDecimal15Point2,
  GenericSortableTableView,
  IbanAlphaNumeric24,
  GenericTextArea,
  LcNumberWithNumericDashes10,
  NtnNumericDashes9,
  GenericPaginationComponent,
  AmountNumericDecimal11Point3
} from '@teresol-v2/ui-components';

export default {
  name: 'MegaSet1177',
  components: {
    Form,
    GenericTextBox,
    GenericButton,
    AmountNumericDecimal11Point3,
    RateNumericDecimal9Point5,
    RateNumericDecimal3Point2,
    Percentage4Point5,
    DateDdMmYyyy,
    GenericDropDown,
    GenericCheckBox,
    CnicNumberNumericDashes15,
    AmountNumericDecimal10Point2,
    PassportPakistanAlphaNumeric10,
    AccountNumberNumericDashes21,
    AccountTitleString45,
    GenericRadioButton,
    GenericDatePicker,
    CurrencyAlphaNumericSpecial25,
    AmountNumericDecimal15Point2,
    GenericSortableTableView,
    IbanAlphaNumeric24,
    GenericTextArea,
    LcNumberWithNumericDashes10,
    NtnNumericDashes9,
    GenericPaginationComponent,
    ExchangeRateNumericDecimal10Point5
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive({
      ...props.configObj.componentProps
    });

    return {
      onSubmit,
      configObject,

      FDBPNoTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
     
      FDBCAmtTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      FDBPAmtTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      ConvAmtTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      RealAmtTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      FDBPDateTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      FDBCDateTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      FDBCNoTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      RevWholeCheckBox: {
        spanInputs: 10,
        spanLabels: 3,
      },
      OSAmountTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      AccountNumbertxtBox: {
        spanInputs: 15,
        spanLabels: 4
      },
      AccountTitleTextBox: {
        spanInputs: 15,
        spanLabels: 4
      },
      NTNNoTextBox: {
        spanInputs: 15,
        spanLabels: 4
      },
      importerRegNoTextBox: {
        spanInputs: 15,
        spanLabels: 4
      },
      eformTable: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 4
      },
      eformTable1: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 4
      },
      //fdbc tab
      FDBPAccountTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },

      FDBCAccountTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },

      BuyerTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      CountryTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      VessNameAlphaNum: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      OriginTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      CityTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      ReimbBankTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      RemitBankTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      ExcRtTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      CourierRefTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      localEqvTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      CourierAmtTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      DocBankTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      TenorTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      MarginTextBox: {
        spanInputs: 5, // this property to be set on screen level
        spanLabels: 18 // this property to be set on screen level,2
      },
      TypeRadioButton: {
        spanInputs: 24,
        spanLabels: 0,
      },
      DocBrnTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      DocBranchTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
    
      DaysofDiscountTextBox: {
        spanInputs: 5, // this property to be set on screen level
        spanLabels: 16 // this property to be set on screen level,2
      },
      
      DiscPercentTextBox: {
        spanInputs: 5, // this property to be set on screen level
        spanLabels: 16 // this property to be set on screen level,2
      },
      //
      PercentTextBox: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 1// this property to be set on screen level,2
      },
      MkupRateTextBox: {
        spanInputs: 7, // this property to be set on screen level
        spanLabels: 9 // this property to be set on screen level,2
      },
      SpotRtTextBox: {
        spanInputs: 7, // this property to be set on screen level
        spanLabels: 9 // this property to be set on screen level,2
      },
      InvoiceAmountTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      CharityAmtTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels:  6// this property to be set on screen level,2
      },
      TreasRtTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      TrRtEquiTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      lodgAmountTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      InvAmtLCYTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      SpotRtEqvTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      MarkupAmtTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      CourierDateTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      SchDateTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      ShipmentDateTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      
      DueDateTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      ReimbBranchTextBox: {
        spanInputs: 12, // this property to be set on screen level
        spanLabels: 6 // this property to be set on screen level,2
      },
      //InstructionsTAb
      InstructionTextArea: {
        spanInputs: 13,
        spanLabels: 0
      },
      RemarksTextArea: {
        spanInputs: 13,
        spanLabels: 0
      },

            //DocBankTab
      AddressTextArea: {
        spanInputs: 14,
        spanLabels: 2,
      },
      //LCContracts details
      TextBox1: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      TextBox2: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      TextBox3: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      TextBox4: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      TextBox5: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      DateBox: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      DateBox2: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      DateBox3: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      DateBox4: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      DateBox5: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      Amount1: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      Amount2: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      Amount3: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      Amount4: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      Amount5: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 0 // this property to be set on screen level,2
      },
      InvNoTextBox: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 5 // this property to be set on screen level,2
      },
      InvDtTextBox: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 5 // this property to be set on screen level,2
      },
      FOBValueTextBox: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 5 // this property to be set on screen level,2
      },
      BLNoTextBox: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 5 // this property to be set on screen level,2
      },
      DocRemTextBox: {
        spanInputs: 19, // this property to be set on screen level
        spanLabels: 4 // this property to be set on screen level,2
      },
      GDNumberDropDown: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 5 // this property to be set on screen level,2
      },
      InvAmount: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 5 // this property to be set on screen level,2
      },
      InfoTable1: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 0,
        tableHeight: '200px',
        tableWidth: '100',
        tableLabel: '',
      },
      TotalFOBValue: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 5 // this property to be set on screen level,2
      },
      TotalInvAmount: {
        spanInputs: 14, // this property to be set on screen level
        spanLabels: 5 // this property to be set on screen level,2
      },
      
    
      //FDBPCharges Tab
     
      FdbpChargesTable:{
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 0
      },
     
   
      //buttons
      OkButton: {
        label: 'OK',
        spanInputs: 23
      },
      
      
      fxDetailBtn: {
        label: 'FX Detail',
        spanInputs: 23
      },
      RemoveGdButton: {
        label: 'Remove GD',
        spanInputs: 22
      },
      EFormConvertBtn: {
        label: 'E-Form Convert',
        spanInputs: 19
      },
      AddGdButton: {
        label: 'Add GD',
        spanInputs: 22
      },
      viewVoucherButton: {
        label: 'View Voucher',
        spanInputs: 23
      },
      ExceptionButton: {
        label: 'Exception',
        spanInputs: 20
      },
      viewDocsBtn: {
        label: 'View Docs',
        spanInputs: 23
      },
      viewFdbpDocsBtn: {
        label: 'View FDBP Docs.',
        spanInputs: 24
      },
      ChangeGdButton: {
        label: 'Change GD',
        spanInputs: 22
      },
      viewFdbcDocsBtn: {
        label: 'View FDBC Docs.',
        spanInputs: 24
      },
      BackBtn: {
        label: 'Back',
        spanInputs: 23
      },
      ExitBtn: {
        label: 'Exit',
        spanInputs: 23
      }
    };
  }
};
</script>
 <style>

.boldedLabel {
  font-weight: bold;
}
</style>
