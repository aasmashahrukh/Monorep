<template>
  <MegaSet1177 :configObj="MS1177_configurationObject" @onSubmit="onSubmit" />
</template>
<script>
import MegaSet1177 from '../MegaSet/MegaSet1177.vue';
import { reactive ,ref } from 'vue';
export default {
  components: {
    MegaSet1177
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    }
  },
  setup() {
    return reactive({
      MS1177_configurationObject: {
        componentProps: {
    FDBPNoTextBox: {
      values: '',
      isVisible: true,
      label: 'FDBP No.',
      dataType: 'alphaNumericSpecial',
      inputLength: 10,
      tabIndex: {},
      isDisabled: false,
      textColor: {},
      labelColor: {},
      labelFontWeight: {},
      inputFontWeight: {},
      mandatory: true,
      autoFocusTextBox: {},
      textAlignment: 'left'
    },
    FDBPAmtTextBox: {
      values: '',
      backgroundColor: 'white',
      isVisible: true,
      label: 'FDBP Amount',
      tabIndex: {},
      isDisabled: false,
      textColor: {},
      labelColor: {},
      labelFontWeight: {},
      inputFontWeight: {},
      mandatory: true,
      autoFocusTextBox: {}
    },
    FDBCAmtTextBox: {
      values: '',
      backgroundColor: 'white',
      isVisible: true,
      label: 'FDBC Amount',
      tabIndex: {},
      isDisabled: false,
      textColor: {},
      labelColor: {},
      labelFontWeight: {},
      inputFontWeight: {},
      mandatory: true,
      autoFocusTextBox: {}
    },
    ConvAmtTextBox: {
      values: '',
      isVisible: true,
      label: 'CONV AMT',
      tabIndex: {},
      isDisabled: false,
      backgroundColor: 'white',
      labelFontWeight: {},
      inputFontWeight: {},
      mandatory: true,
      autoFocusTextBox: {}
    },
    RealAmtTextBox: {
      values: '',
      isVisible: true,
      label: 'Real Amt',
      tabIndex: {},
      isDisabled: false,
      backgroundColor: 'white',
      labelFontWeight: {},
      inputFontWeight: {},
      mandatory: true,
      autoFocusTextBox: {}
    },
    OSAmountTextBox: {
      values: '',
      isVisible: true,
      label: 'O/S Amt',
      tabIndex: {},
      isDisabled: false,
      backgroundColor: 'white',
      labelFontWeight: {},
      inputFontWeight: {},
      mandatory: true,
      autoFocusTextBox: {}
    },
    FDBCNoTextBox: {
      values: '',
      isVisible: true,
      label: 'FDBC No.',
      dataType: 'alphaNumericSpecial',
      inputLength: 10,
      tabIndex: {},
      isDisabled: false,
      textColor: {},
      labelColor: {},
      labelFontWeight: {},
      inputFontWeight: {},
      mandatory: true,
      autoFocusTextBox: {},
      textAlignment: 'left'
    },
    usdLabel: {
      usdLabel: '{USD } Label',
      usdLabel1: 'USD',
      usdLabel2: 'USD'
    },
    usLabel: {
      usLabel: '{USD  }',
    },
    HeadingLabel: {
      HeadingLabel: 'Converted From',
    },
    HeadingLabel1: {
      isVisible: true,
      HeadingLabel1: 'ISLAMIC BANKING S FAISAL BR-5001',
    },
    HeadingLabel2: {
      isVisible: true,
      HeadingLabel2: 'FDBC CONVERT TYPE: MUSAWAMA',
    },

    RevWholeCheckBox: {
        isDisabled: true,
        isVisible: true,
        checkBoxLabel: "Rev Whole",
        RevWholeCheckBoxValue:true,
      },



    FDBPDateTextBox: {
      isDisabled: false,
      values: {},
      datePickerLabel: 'FDBP Dt.',
      textColor: {},
      labelColor: {},
      mandatory: {},
      isVisible: true
    },
    FDBCDateTextBox: {
      isDisabled: false,
      values: {},
      datePickerLabel: 'FDBC Dt.',
      textColor: {},
      labelColor: {},
      mandatory: {},
      isVisible: true
    },

    Section1: {
      isVisible: true
    },
    SectionRadio1: {
      isVisible: true
    },
    Section2: {
      isVisible: true
    },
    Section3FDBP: {
      isVisible: true
    },

    TabPane: {
      activeName: 'EformNo'
    },
    EformNo: {
      isDisable: false,
      label: 'E-Form'
    },
    SectionEformNo: {
      isVisible: true
    },
    FDBPLodgment: {
      isDisable: false,
      isVisible: true,
      label: 'FDBP Lodgement'
    },
    Instructions: {
      isDisable: false,
      label: 'Instructions',
      isVisible: true
    },
    DocBank: {
      isDisable: false,
      isVisible: true,
      label: 'Doc Bank'
    },
    PSWInfoTab: {
      isDisable: false,
      isVisible: true,
      label: 'L/C Information'
    },
    LC_Contracts: {
      isDisable: false,
      isVisible: true,
      label: 'LC-Contracts'
    },
    changeCustomer: {
      isDisable: false,
      isVisible: true,
      label: 'Change Customer'
    },
    FDBPChargesTab: {
      isDisable: false,
      isVisible: true,
      label: 'FDBP Lodg Charges'
    },
    CustomerInformationHeading:{
      CustomerInformationHeading: 'Customer Information',
    },
    AccountNumbertxtBox: {
      isDisabled: true,
      values: '0039-0081-000254-04-1',
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white',
      label: 'A/C No.'
    },
    AccountTitleTextBox: {
      isDisabled: true,
      label: 'A/C title',
      values: 'LABORATORIES (PVT) LTD',
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },

    NTNNoTextBox: {
      isDisabled: true,
      values: '0786715-8',
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white',
      label: 'NTN No.'
    },
    importerRegNoTextBox: {
      isDisabled: true,
      values: '111111',
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white',
      label: 'CCI No.'
    },
    eformTable: {
      isDisabled: false,
      isVisible: true,
      tableLabel: 'E-Forms',
      tableHeight: '220px',
      tableWidth: 85,
      currentRow: 1,
      tableColumns: [
       {
          prop: 'EFormNo',
          label: 'EForm No',
          align: 'center'
        },
        {
          prop: 'CertDate',
          label: 'Cert. Date',
          align: 'center'
        },
        {
          prop: 'Tenor',
          label: 'Tenor',
          align: 'center'
        },
        {
          prop: 'TermsofCont',
          label: 'Terms of Cont.',
          align: 'center'
        },
        {
          prop: 'Amount',
          label: 'Amount',
          align: 'center'
        },
        {
          prop: 'CCY',
          label: 'CCY',
          align: 'center'
        },
        {
          prop: 'UtilAmt',
          label: 'Util. Amt',
          align: 'center'
        },
        {
          prop: 'BalanceAmt',
          label: 'Balance Amt',
          align: 'center'
        },
        {
          prop: 'ExchangeRate',
          label: 'Exchg Rate',
          align: 'center'
        },
        {
          prop: 'Converted',
          label: 'Converted',
          align: 'center'
        },
        {
          prop: 'lodgUtil',
          label: 'lodg Util.',
          align: 'center'
        },
        {
          prop: 'BalanceQty',
          label: 'Balance QTY',
          align: 'center'
        },
        {
          prop: 'ConvertQty',
          label: 'Convert QTY',
          align: 'center'
        },
        {
          prop: 'FiNo',
          label: 'FI No.',
          align: 'center'
        },
        {
          prop: 'GDNo',
          label: 'GD No.',
          align: 'center'
        },

      ],
      tableData: [
        {
          EFormNo: 'AHB-IMP-06',
          CertDate: '11/12/24',
          Tenor: '0000',
          TermsofCont:'D/P CAD-02',
          Amount: '10000.000',
          CCY: 'USD',
          UtilAmt: '10000.00',
          BalanceAmt: '10000.00',
          ExchangeRate: '100000',
          Converted: 'A',
          lodgUtil: 'SSF',
          BalanceQty: '555',
          ConvertQty: '6',
          FiNo: '1234',
          GDNo: '1234'
        }
      ]
    },
    eformTable2: {
      isDisabled: false,
      isVisible: true,
      tableLabel: '',
      tableHeight: '220px',
      tableWidth: 85,
      currentRow: 1,
      tableColumns: [
       {
          prop: 'HSCode',
          label: 'HS Code',
          align: 'center'
        },
        {
          prop: 'Description',
          label: 'Description',
          align: 'center'
        },
        {
          prop: 'Qty',
          label: 'Qty',
          align: 'center'
        },
        {
          prop: 'UnitPrice',
          label: 'Unit Price',
          align: 'center'
        },
        {
          prop: 'Amount',
          label: 'Amount',
          align: 'center'
        },
        {
          prop: 'ShipQty',
          label: 'Ship Qty',
          align: 'center'
        },
        {
          prop: 'lodgUtilAmt',
          label: 'lodg Util Amt',
          align: 'center'
        },
        {
          prop: 'BalanceAmt',
          label: 'Balance Amt.',
          align: 'center'
        },
        {
          prop: 'BalanceShipQty',
          label: 'Balance Ship Qty',
          align: 'center'
        },
        {
          prop: 'RealizedShipQty',
          label: 'Realized ship qty',
          align: 'center'
        },
        {
          prop: 'ShortAmt',
          label: 'Short Amt',
          align: 'center'
        },
        {
          prop: 'RealizedAmt',
          label: 'Realized Amt',
          align: 'center'
        },
        {
          prop: 'ItemNo',
          label: 'Item No',
          align: 'center'
        },
        {
          prop: 'GDNo',
          label: 'GD No',
          align: 'center'
        },

      ],
      tableData: [
        {
          HSCode: 'AHB-IMP-06',
          Description: '11/12/24',
          Qty: '0000',
          UnitPrice: 'USD',
          Amount: '10000.000',
          ShipQty: 'SSF',
          lodgUtilAmt: 'SSF',
          BalanceAmt: '10000.00',
          BalanceShipQty: '10000.00',
          RealizedShipQty: '555',
          ShortAmt:'10000.00',
          RealizedAmt:'10000.00',
          ItemNo: '1234',
          GDNo: '1234'
        }
      ]
    },
    //fdbp tab


    FDBPAccountTextBox: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      label: "FDBP A/C",
      backgroundColor: "white"
    },
    FDBCAccountTextBox: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      label: "FDBC A/C",
      backgroundColor: "white"
    },
    ShipmentQuantityTextBox: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      label: "Ship Qty",
    },
    Section3FDBP: {
      isVisible: true,
    },
    SectionRadioButton: {
      isVisible: true,
    },
    AddressTextBox2: {
      isVisible: true,
      isDisabled: false,
    },

    BuyerTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Buyer",
      inputLength:30,
      colorInput: "",
      colorLabel: "",

    },

    CountryTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Country",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      dataType: "alpha"
    },
    OriginTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Origin",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    VessNameAlphaNum: {
      isVisible: true,
      isDisabled: false,
      label: "Vessel Name",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    CityTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "City",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    
    ExcRtTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Exchange Rate",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor: "white",
    },
    
    ReimbBankTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Reimb. Bank",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    
    RemitBankTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Remit. Bank",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    ReimbBranchTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Reimb. Branch",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    DueDateTextBox: {
      isVisible: true,
      isDisabled: false,
      datePickerLabel: "Due Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    ShipmentDateTextBox: {
      isVisible: true,
      isDisabled: false,
      datePickerLabel: "Shipment Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    CourierDateTextBox: {
      isVisible: true,
      isDisabled: false,
      datePickerLabel: "Courier Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    SchDateTextBox: {
      isVisible: true,
      isDisabled: false,
      datePickerLabel: "Schedule Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    CourierRefTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Courier Ref",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    localEqvTextBox:{
      isVisible: true,
      isDisabled: false,
      label: "Local Equivalent",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor:"white",
    },
    
    CourierAmtTextBox:{
      isVisible: true,
      isDisabled: false,
      label: "Courier Amt",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor:"white",
    },
    DocBankTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Doc. Bank",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    
    TenorTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Tenor",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      dataType: "numeric",
    },
    MarginTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Margin",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      dataType: "numeric",
    },
    DocBankTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Doc. Bank",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    TypeRadioButton: {
      isVisible: true,
      isDisabled: false,
      mandatory: false,
      selectedValue: "Ready",
      radioGroup: [
        {
          value: "Ready",
          label: "Ready",
          isDisabled: false,
        },
        {
          value: "Forward",
          label: "Forward",
          isDisabled: false,
        },
        {
          value: "FE-25 LoanNo Exposure",
          label: "FE-25 LoanNo Exposure",
          isDisabled: false,
        },
      ],
      radioDisplay: "row",

      radioLabel: "",
    },
    DocBrnTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Doc. Brn",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    DocBranchTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Doc Branch",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    //
    DaysofDiscountTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Days of Discount",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    DiscPercentTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Disc %",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor: "white",
    },
    PercentTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "%",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor: "white",
      
    },
    MkupRateTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Pft/MkupRate",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    }, 
    //
    SpotRtTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Spot Rt",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    InvoiceAmountTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Invoice Amount",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    
    CharityAmtTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Charity Amount",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    lodgAmountTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Lodgment Amount",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    TreasRtTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Treasury Rate",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    
    TrRtEquiTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Tr Rate Equi",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    InvAmtLCYTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Inv Amt LCY",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    SpotRtEqvTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Spot Rt Eqv",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    MarkupAmtTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Markup Amt",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    //InstructionTab
    InstructionTextArea: {
      label: 'Instructions',
      InstructionTextAreaValue: 'InstructionTextAreaValue',
      dataType: 'alphaNumericSpecial',

      isDisabled: false,
      minRows: 3,
      maxRows: 5,
      mandatory: true,
      backgroundColor: 'white',
      isVisible: true
    },
    RemarksTextArea: {
      label: 'Remarks',
      RemarksTextAreaValue: 'RemarksTextAreaValue',
      dataType: 'alphaNumericSpecial',
      minRows: 3,
      maxRows: 5,
      isDisabled: false,
      textColor: 'black',
      labelColor: 'black',
      mandatory: true,
      backgroundColor: 'white',
      isVisible: true
    },
    //DocBank Tab
    AddressTextArea: {
      label: 'Address',
      AddressTextAreaValue: 'InstructionTextAreaValue',
      dataType: 'alphaNumericSpecial',
      isDisabled: false,
      minRows: 10,
      maxRows: 10,
      mandatory: true,
      backgroundColor: 'white',
      isVisible: true
    },

    //fdbpDetails
    LC_ContractNo: {
      isVisible: true,
      label:"L/C Contract No",
    },
    LC_ContractDate: {
      isVisible: true,
      label:"L/C Contract Date",
    },
    LC_ContractAmount: {
      isVisible: true,
      label:"L/C Amount",
    },
    
    TextBox1: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    TextBox2: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    TextBox3: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    TextBox4: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    TextBox5: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    DateBox: {
      isVisible: true,
      isDisabled: false,
      //datePickerLabel: "Courier Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    DateBox2: {
      isVisible: true,
      isDisabled: false,
      //datePickerLabel: "Courier Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    DateBox3: {
      isVisible: true,
      isDisabled: false,
      //datePickerLabel: "Courier Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    DateBox4: {
      isVisible: true,
      isDisabled: false,
      //datePickerLabel: "Courier Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    DateBox5: {
      isVisible: true,
      isDisabled: false,
      //datePickerLabel: "Courier Date",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    Amount1: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor: "white",
    },
    Amount2: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor: "white",
    },
    Amount3: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor: "white",
    },
    Amount4: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor: "white",
    },
    Amount5: {
      isVisible: true,
      isDisabled: false,
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      backgroundColor: "white",
    },
    InvNoTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Inv No",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      dataType: "numeric",
    },
    InvDtTextBox: {
      isVisible: true,
      isDisabled: false,
      datePickerLabel: "Inv Dt",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    FOBValueTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "FOB Value",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",

    },
    BLNoTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "B/L No",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
      dataType: "numeric",
    },
    DocRemTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "Doc rem",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    EDSRefNo: {
      isVisible: true,
      label:"EDS Unique Ref No:",
    },
    EDSRefNoValue:{
      isVisible: true,
      label:"1035FBP240000042"
    },
    GDNumberTextBox: {
      isVisible: true,
      isDisabled: false,
      label: "GD Number",
      inputLength:30,
      colorInput: "",
      colorLabel: "",
    },
    InvAmount: {
      isVisible: true,
      isDisabled: false,
      label: "Inv. Amount",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",
    },
    InfoTable1: {
      isVisible: true,
      tableData: [
        {
          GD_Number: "SAAZ-AB-00012",
          BLNo: "10000",
          BLDate: "2024-03-12",
          InvNo: "545556",
          InvDate:"2024-03-12",
          FOBValueFCY: "10000.000",
          InvAmount: "10000.000",
        },
      ],
      tableColumns: [
        {
          prop: "GD_Number",
          label: "GD Number",
          align: "left",
          columnsWidth: "10",
        },
        {
          prop: "BLNo",
          label: "B/L No",
          align: "left",
          columnsWidth: "8",
        },
        {
          prop: "BLDate",
          label: "B/L Date",
          align: "left",
          columnsWidth: "10",
        },
        {
          prop: "InvNo",
          label: "Invoice No",
          align: "left",
          columnsWidth: "10",
        },
        {
          prop: "InvDate",
          label: "Invoice Date",
          align: "left",
          columnsWidth: "8",
        },
        {
          prop: "FOBValueFCY",
          label: "FOB Value FCY",
          align: "center",
          columnsWidth: "6",
        },
        {
          prop: "InvAmount",
          label: "Inv Amount",
          align: "center",
          columnsWidth: "6",
        },
      ],
      currentRow: {},
    },
    TotalFOBValue: {
      isVisible: true,
      isDisabled: false,
      label: "Total FOB Value",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",
    },
    TotalInvAmount: {
      isVisible: true,
      isDisabled: false,
      label: "Total Inv Amount",
      inputLength:30,
      colorInput: "",
      backgroundColor:"White",
      colorLabel: "",
    },
    GDNumberDropDown: {
      isDisabled: false,
      isVisible: true, // set true for Visible Component and set false for invisible Component
      dropDownLabel: 'GD Number',
      branchList: ref([{option:"karachi Main" ,value:"11"}]),
      spanInput: ref(2)
    },



    Section1GD:{
      isVisible:true
    },

    //mform tab
   
    FdbpChargesTable: {
      isDisabled: false,
      isVisible: true,
      tableLabel: '',
      tableHeight: '220px',
      tableWidth: 85,
      currentRow: 1,
      tableColumns: [
        {
          prop: 'Trancd',
          label: 'Trancd',
          align: 'center'
        },
        {
          prop: 'Tran_Description',
          label: 'Tran Description',
          align: 'center'
        },
        {
          prop: 'GL_Account',
          label: 'Gl Account',
          align: 'center'
        },
        {
          prop: 'Perc',
          label: 'Perc',
          align: 'center'
        },
        {
          prop: 'Amount',
          label: 'Amount',
          align: 'center'
        },
      
      ],
      tableData: [
        {
          Trancd: '1001',
          Tran_Description: 'AHB-IMP-06',
          GL_Account: ' ADV',
          Perc: '1234',
          Amount: '2019',
        }
      ]
    },
  
    //buttons
    OkButton: {
      isDisabled: true,
      nativeType: 'button',
      isVisible: true
    },
    AuthorizeButton: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    cancelbtn: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    fxDetailBtn: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    RemoveGdButton: {
      isDisabled: true,
      nativeType: 'button',
      isVisible: true
    },
    EFormConvertBtn: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    viewVoucherButton: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    AddGdButton: {
      isDisabled: true,
      nativeType: 'button',
      isVisible: true
    },
    ExceptionButton: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    viewDocsBtn: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    viewFdbpDocsBtn: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    ChangeGdButton: {
      isDisabled: true,
      nativeType: 'button',
      isVisible: true
    },
    viewFdbcDocsBtn: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },

    BackBtn: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    },
    ExitBtn: {
      isDisabled: false,
      nativeType: 'button',
      isVisible: true
    }
  }
      }
    });
  }
};
</script>