#!/bin/bash
## declare an array variable
declare -a arr=("386" "387"   )

## now loop through the above array
for i in "${arr[@]}"
#for i in {284..284}
do
   echo "$i"
   # or do whatever with individual element of the array
   git submodule add -f http://10.10.1.210:8040/r2-bcbs-projects/front-end-development/teresol-megasets/megaset$i.git 
   #git submodule add -f http://10.10.1.210:8040/r2-bcbs-projects/portals/home-remit-coc/megaset$i.git
   #git submodule add -f http://10.10.1.210:8040/r2-bcbs-projects/portals/rtps-reports/megaset$i.git
   git submodule update -f --init megaset$i 
   cd megaset$i
   #git pull
   git checkout packaged
   npm run buildpatch
   npm publish --registry http://10.10.1.210:8022/repository/pkg-release/
   git push
   cd ..
   #break
done

# You can access them using echo "${arr[0]}", "${arr[1]}" also
 