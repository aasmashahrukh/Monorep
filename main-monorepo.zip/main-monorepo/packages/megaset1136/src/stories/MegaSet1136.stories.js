// MegaSet1136.stories.js

import MegaSet1136 from "../MegaSet/MegaSet1136.vue";
import { ref } from "vue";
import { action } from "@storybook/addon-actions";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "MegaSet1136",
  component: MegaSet1136,
};

const configurationObject = {
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: true,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
};

const configurationObject_SS_113_Set1 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}

const configurationObject_SS_113_Set2  ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: true
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}

const configurationObject_SS_113_Set3  ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set4 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set5 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set6 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: true,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set7 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set8 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set9 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set10 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: true,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set11 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: false,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: true
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}
const configurationObject_SS_113_Set12 ={
  componentProps: {
    Section1: {
      isVisible: true
    },
    LDBCNoTextBox: {
      LDBCNoTextBoxValue: '',
      isVisible: false,
      label: 'LDBC No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBPNoTextBox: {
      LDBPNoTextBoxValue: '',
      isVisible: true,
      label: 'LDBP No.',
      dataType: 'alphaNumeric',
      inputLength: 15,
      backgroundColor: 'White',
      isDisabled: false
    },
    LDBCYearTextBox: {
      isDisabled: false,
      isVisible: false,
      backgroundColor: 'white',
      label: '/',
      LDBCYearTextBoxValue: ''
    },
    LDBPYearTextBox: {
      isDisabled: false,
      isVisible: true,
      backgroundColor: 'white',
      label: '/',
      LDBPYearTextBoxValue: ''
    },
    SearchButton: {
      isVisible: true,
      label: 'Search',
      isDisabled: false
    },
    InstrumentNoDropDown: {
      InstrumentNoDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Instrument No.',
      isDisabled: false
    },
    VoucherNoYearDropDown: {
      VoucherNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Voucher No./Year',
      isDisabled: false
    },
    ConvertedBillNoYearDropDown: {
      ConvertedBillNoYearDropDownValue: [
        {
          value: '12345 (001)',
          option: '12345 (001)'
        },
        {
          value: '54321 (002)',
          option: '54321 (002)'
        }
      ],
      defaultValue: '12345 (001)',
      isVisible: false,
      dropDownLabel: 'Converted Bill No./Year',
      isDisabled: false
    },
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: true
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    Section2: {
      isVisible: true
    }
  }
}


const Template = (args) => ({
  components: { MegaSet1136 },
  template: `<MegaSet1136 v-bind="args"/>`,
  setup() {
    return { 
      args:{
        configObj:{
          componentProps: {
            Section1: {
              isVisible: true
            },
            LDBCNoTextBox: {
              LDBCNoTextBoxValue: '',
              isVisible: true,
              label: 'LDBC No.',
              dataType: 'alphaNumeric',
              inputLength: 15,
              backgroundColor: 'White',
              isDisabled: false
            },
            LDBPNoTextBox: {
              LDBPNoTextBoxValue: '',
              isVisible: true,
              label: 'LDBP No.',
              dataType: 'alphaNumeric',
              inputLength: 15,
              backgroundColor: 'White',
              isDisabled: false
            },
            LDBCYearTextBox: {
              isDisabled: false,
              isVisible: true,
              backgroundColor: 'white',
              label: '/',
              LDBCYearTextBoxValue: ''
            },
            LDBPYearTextBox: {
              isDisabled: false,
              isVisible: true,
              backgroundColor: 'white',
              label: '/',
              LDBPYearTextBoxValue: ''
            },
            SearchButton: {
              isVisible: true,
              label: 'Search',
              isDisabled: false
            },
            InstrumentNoDropDown: {
              InstrumentNoDropDownValue: [
                {
                  value: '12345 (001)',
                  option: '12345 (001)'
                },
                {
                  value: '54321 (002)',
                  option: '54321 (002)'
                }
              ],
              defaultValue: '12345 (001)',
              isVisible: true,
              dropDownLabel: 'Instrument No.',
              isDisabled: false
            },
            VoucherNoYearDropDown: {
              VoucherNoYearDropDownValue: [
                {
                  value: '12345 (001)',
                  option: '12345 (001)'
                },
                {
                  value: '54321 (002)',
                  option: '54321 (002)'
                }
              ],
              defaultValue: '12345 (001)',
              isVisible: true,
              dropDownLabel: 'Voucher No./Year',
              isDisabled: false
            },
            ConvertedBillNoYearDropDown: {
              ConvertedBillNoYearDropDownValue: [
                {
                  value: '12345 (001)',
                  option: '12345 (001)'
                },
                {
                  value: '54321 (002)',
                  option: '54321 (002)'
                }
              ],
              defaultValue: '12345 (001)',
              isVisible: true,
              dropDownLabel: 'Converted Bill No./Year',
              isDisabled: false
            },
            OKButton: {
              isVisible: true,
              label: 'OK',
              isDisabled: false
            },
            ExitButton: {
              isVisible: true,
              label: 'Exit',
              isDisabled: false
            },
            Section2: {
              isVisible: true
            }
          }
        }
      }
    };
  },
});
const Template_SS = (args) => ({
  components: { MegaSet1136 },
  template: `<MegaSet1136 v-bind="args"/>`,
  setup() {
    return { args }
    }
});

export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };

export const SS_113_Set1 = Template_SS.bind({})
SS_113_Set1.args = {configObj: configurationObject_SS_113_Set1}

export const SS_113_Set2 = Template_SS.bind({})
SS_113_Set2.args = {configObj: configurationObject_SS_113_Set2}

export const SS_113_Set3 = Template_SS.bind({})
SS_113_Set3.args = {configObj: configurationObject_SS_113_Set3}

export const SS_113_Set4 = Template_SS.bind({})
SS_113_Set4.args = {configObj: configurationObject_SS_113_Set4}

export const SS_113_Set5 = Template_SS.bind({})
SS_113_Set5.args = {configObj: configurationObject_SS_113_Set5}

export const SS_113_Set6 = Template_SS.bind({})
SS_113_Set6.args = {configObj: configurationObject_SS_113_Set6}

export const SS_113_Set7 = Template_SS.bind({})
SS_113_Set7.args = {configObj: configurationObject_SS_113_Set7}

export const SS_113_Set8 = Template_SS.bind({})
SS_113_Set8.args = {configObj: configurationObject_SS_113_Set8}

export const SS_113_Set9 = Template_SS.bind({})
SS_113_Set9.args = {configObj: configurationObject_SS_113_Set9}

export const SS_113_Set10 = Template_SS.bind({})
SS_113_Set10.args = {configObj: configurationObject_SS_113_Set10}

export const SS_113_Set11 = Template_SS.bind({})
SS_113_Set11.args = {configObj: configurationObject_SS_113_Set11}

export const SS_113_Set12 = Template_SS.bind({})
SS_113_Set12.args = {configObj: configurationObject_SS_113_Set12}
