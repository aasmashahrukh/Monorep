<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row>
      <el-col :sm="15" :md="15" :lg="15">
        <fieldset v-if="configObject.Section1 != undefined ? configObject.Section1.isVisible : false">
          <el-row>
            <el-col :md="4" :lg="4"></el-col>
            <el-col :md="11" :lg="11">
              <GenericTextBox
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('LDBCNoTextBox-onBlur', val);
                  }
                "
                @GenericTextBox-onChange="
                  (val) => {
                    $emit('LDBCNoTextBox-onChange', val);
                  }
                "
                @GenericTextBox-onKeyUp="
                  (val) => {
                    $emit('LDBCNoTextBox-onKeyUp', val);
                  }
                "
                @GenericTextBox-onKeyPress="
                  (val,event) => {
                    $emit('LDBCNoTextBox-onKeyPress', val,event);
                  }
                "
                @GenericTextBox-onFocus="
                  (val) => {
                    $emit('LDBCNoTextBox-onFocus', val);
                  }
                "
                name="LDBCNoTextBox"
                ref="RefLDBCNoTextBox"
                v-if="configObject.LDBCNoTextBox != undefined ? configObject.LDBCNoTextBox.isVisible : false"
                :values="configObject.LDBCNoTextBox.LDBCNoTextBoxValue"
                v-bind="{ ...LDBCNoTextBox, ...configObject.LDBCNoTextBox }"
              />
              <GenericTextBox
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('LDBPNoTextBox-onBlur', val);
                  }
                "
                @GenericTextBox-onChange="
                  (val) => {
                    $emit('LDBPNoTextBox-onChange', val);
                  }
                "
                @GenericTextBox-onKeyUp="
                  (val) => {
                    $emit('LDBPNoTextBox-onKeyUp', val);
                  }
                "
                @GenericTextBox-onKeyPress="
                  (val,event) => {
                    $emit('LDBPNoTextBox-onKeyPress', val,event);
                  }
                "
                @GenericTextBox-onFocus="
                  (val) => {
                    $emit('LDBPNoTextBox-onFocus', val);
                  }
                "
                name="LDBPNoTextBox"
                ref="RefLDBPNoTextBox"
                v-if="configObject.LDBPNoTextBox != undefined ? configObject.LDBPNoTextBox.isVisible : false"
                :values="configObject.LDBPNoTextBox.LDBPNoTextBoxValue"
                v-bind="{ ...LDBPNoTextBox, ...configObject.LDBPNoTextBox }"
              />
            </el-col>
            <el-col :md="1" :lg="1" ></el-col>
            <el-col  :md="8" :lg="8">
              <YearNumeric4
                @YearNumeric4-onChange="
                  (val) => {
                    $emit('LDBCYearTextBox-onChange', val);
                  }
                "
                @YearNumeric4-onBlur="
                  (val) => {
                    $emit('LDBCYearTextBox-onBlur', val);
                  }
                "
                @YearNumeric4-onKeyPress="
                  (val, event) => {
                    $emit('LDBCYearTextBox-onKeyPress', val);
                  }
                "
                @YearNumeric4-onKeyUp="
                  (val, event) => {
                    $emit('LDBCYearTextBox-onKeyUp', val);
                  }
                "
                @YearNumeric4-onFocus="
                  (val) => {
                    $emit('LDBCYearTextBox-onFocus', val);
                  }
                "
                name="LDBCYearTextBox"
                ref="RefLDBCYearTextBox"
                :values="configObject.LDBCYearTextBox.LDBCYearTextBoxValue"
                v-bind="{ ...LDBCYearTextBox, ...configObject.LDBCYearTextBox }"
                v-if="configObject.LDBCYearTextBox != undefined ? configObject.LDBCYearTextBox.isVisible : false"
              />
              <YearNumeric4
                @YearNumeric4-onChange="
                  (val) => {
                    $emit('LDBPYearTextBox-onChange', val);
                  }
                "
                @YearNumeric4-onBlur="
                  (val) => {
                    $emit('LDBPYearTextBox-onBlur', val);
                  }
                "
                @YearNumeric4-onKeyPress="
                  (val, event) => {
                    $emit('LDBPYearTextBox-onKeyPress', val);
                  }
                "
                @YearNumeric4-onKeyUp="
                  (val, event) => {
                    $emit('LDBPYearTextBox-onKeyUp', val);
                  }
                "
                @YearNumeric4-onFocus="
                  (val) => {
                    $emit('LDBPYearTextBox-onFocus', val);
                  }
                "
                name="LDBPYearTextBox"
                ref="RefLDBPYearTextBox"
                :values="configObject.LDBPYearTextBox.LDBPYearTextBoxValue"
                v-bind="{ ...LDBPYearTextBox, ...configObject.LDBPYearTextBox }"
                v-if="configObject.LDBPYearTextBox != undefined ? configObject.LDBPYearTextBox.isVisible : false"
              />
             
            </el-col>
          </el-row>
          <el-row>
            <el-col :md="15" :lg="15" ></el-col>
            <el-col  :md="8" :lg="8">
              <GenericButton
                @GenericButton-onClick="$emit('SearchButton-onClick')"
                @GenericButton-onFocus="$emit('SearchButton-onFocus')"
                name="SearchButton"
                ref="RefSearchButton"
                v-if="configObject.SearchButton != undefined ? configObject.SearchButton.isVisible : false"
                v-bind="{ ...SearchButton, ...configObject.SearchButton }"
              />
            </el-col>
          </el-row>
          <el-row>
            <el-col :md="4" :lg="4"></el-col>
            <el-col :md="16" :lg="16">
              <GenericDropDown
                @GenericDropDown-onChange="
                  (val) => {
                    $emit('InstrumentNoDropDown-onChange', val);
                  }
                "
                @GenericDropDown-onClick="
                  (val) => {
                    $emit('InstrumentNoDropDown-onClick', val);
                  }
                "
                @GenericDropDown-onFocus="
                  (val) => {
                    $emit('InstrumentNoDropDown-onFocus', val);
                  }
                "
                name="InstrumentNoDropDown"
                ref="RefInstrumentNoDropDown"
                v-if="configObject.InstrumentNoDropDown != undefined ? configObject.InstrumentNoDropDown.isVisible : false"
                :values="configObject.InstrumentNoDropDown.InstrumentNoDropDownValue"
                v-bind="{ ...InstrumentNoDropDown, ...configObject.InstrumentNoDropDown }"
              />
              <GenericDropDown
                @GenericDropDown-onChange="
                  (val) => {
                    $emit('VoucherNoYearDropDown-onChange', val);
                  }
                "
                @GenericDropDown-onClick="
                  (val) => {
                    $emit('VoucherNoYearDropDown-onClick', val);
                  }
                "
                @GenericDropDown-onFocus="
                  (val) => {
                    $emit('VoucherNoYearDropDown-onFocus', val);
                  }
                "
                name="VoucherNoYearDropDown"
                ref="RefVoucherNoYearDropDown"
                v-if="configObject.VoucherNoYearDropDown != undefined ? configObject.VoucherNoYearDropDown.isVisible : false"
                :values="configObject.VoucherNoYearDropDown.VoucherNoYearDropDownValue"
                v-bind="{ ...VoucherNoYearDropDown, ...configObject.VoucherNoYearDropDown }"
              />
              <GenericDropDown
                @GenericDropDown-onChange="
                  (val) => {
                    $emit('ConvertedBillNoYearDropDown-onChange', val);
                  }
                "
                @GenericDropDown-onClick="
                  (val) => {
                    $emit('ConvertedBillNoYearDropDown-onClick', val);
                  }
                "
                @GenericDropDown-onFocus="
                  (val) => {
                    $emit('ConvertedBillNoYearDropDown-onFocus', val);
                  }
                "
                name="ConvertedBillNoYearDropDown"
                ref="RefConvertedBillNoYearDropDown"
                v-if="configObject.ConvertedBillNoYearDropDown != undefined ? configObject.ConvertedBillNoYearDropDown.isVisible : false"
                :values="configObject.ConvertedBillNoYearDropDown.ConvertedBillNoYearDropDownValue"
                v-bind="{ ...ConvertedBillNoYearDropDown, ...configObject.ConvertedBillNoYearDropDown }"
              />
            </el-col>
            <el-col :md="6" :lg="6"> </el-col>
          </el-row>
        </fieldset>
      </el-col>
    </el-row>

    <el-row>
      <el-col :md="15" :lg="15">
        <fieldset v-if="configObject.Section2 != undefined ? configObject.Section2.isVisible : false">
          <el-row>
            <el-col :md="4" :lg="4">
              <GenericButton
                @GenericButton-onClick="$emit('OKButton-onClick')"
                @GenericButton-onFocus="$emit('OKButton-onFocus')"
                name="OKButton"
                ref="RefOKButton"
                v-if="configObject.OKButton != undefined ? configObject.OKButton.isVisible : false"
                v-bind="{ ...OKButton, ...configObject.OKButton }"
              />
            </el-col>
            <el-col :md="16" :lg="16"></el-col>
            <el-col  :md="4" :lg="4">
              <GenericButton
                @GenericButton-onClick="$emit('ExitButton-onClick')"
                @GenericButton-onFocus="$emit('ExitButton-onFocus')"
                name="ExitButton"
                ref="RefExitButton"
                v-if="configObject.ExitButton != undefined ? configObject.ExitButton.isVisible : false"
                v-bind="{ ...ExitButton, ...configObject.ExitButton }"
              />
            </el-col>
          </el-row>
        </fieldset>
      </el-col>
    </el-row>
  </Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import { reactive } from 'vue';
import { GenericTextBox, YearNumeric4, GenericButton, GenericDropDown } from '@teresol-v2/ui-components';
export default {
  name: 'MegaSet1136',

  components: {
    Form,
    GenericTextBox,
    YearNumeric4,
    GenericButton,
    GenericDropDown
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive(props.configObj.componentProps);

    return {
      onSubmit,
      configObject,
      LDBCNoTextBox: {
        spanInputs: 11,
        spanLabels: 13
      },
      LDBPNoTextBox: {
        spanInputs: 11,
        spanLabels: 13
      },
      LDBCYearTextBox: {
        spanInputs: 8,
        spanLabels: 2
      },
      LDBPYearTextBox: {
        spanInputs: 8,
        spanLabels: 2
      },
      SearchButton: {
        spanInputs: 13,
      },
      InstrumentNoDropDown: {
        spanInputs: 14,
        spanLabels: 9
      },
      VoucherNoYearDropDown: {
        spanInputs: 14,
        spanLabels: 9
      },
      ConvertedBillNoYearDropDown: {
        spanInputs: 14,
        spanLabels: 9
      },
      OKButton: {
        spanInputs: 23
      },
      ExitButton:{
        spanInputs: 23
      },
    };
  }
};
</script>
