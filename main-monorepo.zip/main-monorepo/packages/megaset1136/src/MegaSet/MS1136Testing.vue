<template>
  <MegaSet1136 :configObj="configurationObject" @onSubmit="onSubmit" />
</template>
<script>
import MegaSet1136 from '../MegaSet/MegaSet1136.vue';
import { reactive } from 'vue';
export default {
  components: {
    MegaSet1136
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    }
  },
  setup() {
    return reactive({
      configurationObject: {
        componentProps: {
          Section1: {
            isVisible: true
          },
          LDBCNoTextBox: {
            LDBCNoTextBoxValue: '',
            isVisible: true,
            label: 'LDBC No.',
            dataType: 'alphaNumeric',
            inputLength: 15,
            backgroundColor: 'White',
            isDisabled: false
          },
          LDBPNoTextBox: {
            LDBPNoTextBoxValue: '',
            isVisible: true,
            label: 'LDBP No.',
            dataType: 'alphaNumeric',
            inputLength: 15,
            backgroundColor: 'White',
            isDisabled: false
          },
          LDBCYearTextBox: {
            isDisabled: false,
            isVisible: true,
            backgroundColor: 'white',
            label: '/',
            LDBCYearTextBoxValue: ''
          },
          LDBPYearTextBox: {
            isDisabled: false,
            isVisible: true,
            backgroundColor: 'white',
            label: '/',
            LDBPYearTextBoxValue: ''
          },
          SearchButton: {
            isVisible: true,
            label: 'Search',
            isDisabled: false
          },
          InstrumentNoDropDown: {
            InstrumentNoDropDownValue: [
              {
                value: '12345 (001)',
                option: '12345 (001)'
              },
              {
                value: '54321 (002)',
                option: '54321 (002)'
              }
            ],
            defaultValue: '12345 (001)',
            isVisible: true,
            dropDownLabel: 'Instrument No.',
            isDisabled: false
          },
          VoucherNoYearDropDown: {
            VoucherNoYearDropDownValue: [
              {
                value: '12345 (001)',
                option: '12345 (001)'
              },
              {
                value: '54321 (002)',
                option: '54321 (002)'
              }
            ],
            defaultValue: '12345 (001)',
            isVisible: true,
            dropDownLabel: 'Voucher No./Year',
            isDisabled: false
          },
          ConvertedBillNoYearDropDown: {
            ConvertedBillNoYearDropDownValue: [
              {
                value: '12345 (001)',
                option: '12345 (001)'
              },
              {
                value: '54321 (002)',
                option: '54321 (002)'
              }
            ],
            defaultValue: '12345 (001)',
            isVisible: true,
            dropDownLabel: 'Converted Bill No./Year',
            isDisabled: false
          },
          OKButton: {
            isVisible: true,
            label: 'OK',
            isDisabled: false
          },
          ExitButton: {
            isVisible: true,
            label: 'Exit',
            isDisabled: false
          },
          Section2: {
            isVisible: true
          }
        }
      }
    });
  }
};
</script>