import MegaSet1139 from './MegaSet/MegaSet1139.vue'

function install(Vue) {
	if (install.installed) return;
	install.installed = true;

	Vue.component("MegaSet1139",MegaSet1139);
}

const plugin = {
	install,
};

let GlobalVue = null;
if (typeof window !== "undefined") {
	GlobalVue = window.Vue;
} else if (typeof global !== "undefined") {
	GlobalVue = global.vue;
}
if (GlobalVue) {
	GlobalVue.use(plugin);
}

MegaSet1139.install = install;

export default MegaSet1139;