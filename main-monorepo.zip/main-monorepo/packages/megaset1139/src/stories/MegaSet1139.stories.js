// MegaSet1139.stories.js

import MegaSet1139 from "../MegaSet/MegaSet1139.vue";
import { ref } from "vue";
import { action } from "@storybook/addon-actions";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "MegaSet1139",
  component: MegaSet1139,
};

const configurationObject = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: true
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        },
        {
          value: 'LC',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
        {
          value: 'Sales',
          label: 'Sales',
          isDisabled: false
        }
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipDate',
          label: 'From Ship. Date',
          isDisabled: false
        },
        {
          value: 'AfterShipDate',
          label: 'After Ship. Date',
          isDisabled: false
        },
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByBeneficiary',
          label: 'By Beneficiary',
          isDisabled: false
        },
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
        {
          value: 'ByRail',
          label: 'By Rail',
          isDisabled: false
        }
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: true,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: true,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: true,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: true,
      label: 'Cancel',
      isDisabled: false
    }
  }
};

const configurationObject_SS_EXP_115_Set1 = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'FromShipDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set2 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'AfterShipDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipDate',
          label: 'After Shipment. Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set3 = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Sales',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Sales',
          label: 'Sales',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'NegotiationDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set4 = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'LC',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'FromShipDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipDate',
          label: 'From Shipment Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}
const configurationObject_SS_EXP_115_Set5 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'LC',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'LC',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'AfterShipDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}


const configurationObject_SS_EXP_115_Set6 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'AfterShipDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipDate',
          label: 'After Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set7 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Sales',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Sales',
          label: 'Sales',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'NegotiationDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set8 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: false
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Shipment Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: 'Buyer',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: 'ByRoad',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        }
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set9 = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: false,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'LC',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'AfterShipDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipDate',
          label: 'After Shipment Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set10 = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'AfterShipmentDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipmentDate',
          label: 'After Shipment Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: 'Buyer',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: true,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set11 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'LC',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'LC',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'AfterShipmentDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipmentDate',
          label: 'After Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: true,
      label: 'Cancel',
      isDisabled: false
    }
  }
}
const configurationObject_SS_EXP_115_Set12 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'LC',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'FromShipmentDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: true,
      label: 'Cancel',
      isDisabled: false
    }
  }
}
const configurationObject_SS_EXP_115_Set13_14 = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'FromShipmentDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: 'Buyer',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '', 
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: true,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set15 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Sales',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Sales',
          label: 'Sales',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'NegotiationDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: 'Beneficiary',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '', 
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set16 = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'After Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipmentDate',
          label: 'After Shipment Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: 'Buyer',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '', 
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set17 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Sales',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Sales',
          label: 'Sales',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'NegotiationDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set18 = {
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'AfterShipmentDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipmentDate',
          label: 'After Shipment Date',
          isDisabled: false
        }
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: 'Buyer',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '', 
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}
const configurationObject_SS_EXP_115_Set19 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: false,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Sales',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Sales',
          label: 'Sales',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'NegotiationDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set20 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: false,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'After Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipmentDate',
          label: 'After Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set21 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Sales',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Sales',
          label: 'Sales',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'NegotiationDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: true,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set22 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'After Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipmentDate',
          label: 'After Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: true,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set23 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Sales',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Sales',
          label: 'Sales',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'NegotiationDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: true,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set24 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: false
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'After Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipmentDate',
          label: 'After Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: true,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set25_27_28 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set26 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set29 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: false,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set30 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: false,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set31 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: true,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}


const configurationObject_SS_EXP_115_Set32 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: true,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set33_34 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: true,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set35 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: true
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: false,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: true,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set36 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: true,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set37 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'L/C',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'L/C',
          label: 'L/C',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'NegotiationDate',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'NegotiationDate',
          label: 'Negotiation Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: true,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set38_39 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set40 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: false,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: false
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'After Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'AfterShipmentDate',
          label: 'After Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Beneficiary',
          label: 'Beneficiary',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: true,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: false,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set41 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: true,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: false,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: true,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set42 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: true,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: false,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const configurationObject_SS_EXP_115_Set43 ={
  componentProps: {
    AccountNumberTextBox: {
      label: 'A/C No.',
      isDisabled: false,
      isVisible: true,
      AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    AccountTitleTextBox: {
      label: 'A/C Title.',
      isDisabled: false,
      isVisible: true,
      AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
      backgroundColor: 'white',
      mandatory: false
    },

    NtnNumberTextBox: {
      label: 'NTN No.',
      isDisabled: false,
      isVisible: true,
      NtnNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CCINumberTextBox: {
      label: 'CCI No',
      isDisabled: false,
      isVisible: true,
      CCINumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },

    TabPane: {
      activeName: 'BillInfoTab'
    },
    BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    InstrumentInfoTab: {
      isDisabled: false,
      isVisible: true,
      label: 'Instrument Info'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section1: {
      isDisabled: false,
      isVisible: true
    },
    Section2: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '011002/2024',
      isVisible: true
    },
    LDBCAccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBCAccountNumberTextBoxValue: '0338149840011',
      backgroundColor: 'white',
      mandatory: false
    },
    //Instrument Info tab
    Section3: {
      isDisabled: false,
      isVisible: false
    },
    BillAmountTextBox1: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    BalanceAmountTextBox1: {
      label: 'Balance Amount',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox1Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentBalAmountTextBox: {
      label: 'Instrument Bal',
      isDisabled: false,
      isVisible: true,
      InstrumentBalAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstrumentInformationSection: {
      isVisible: true
    },
    SBPChequeDDPORadioButton: {
      isDisabled: false,
      values: '',
      isVisible: false,
      SBPChequeDDPORadioButtonValue: 'Discrepancy',
      list1: [
        {
          value: 'SBP Cheque',
          label: 'SBP Cheque',
          isDisabled: false
        }
      ],
      list2: [
        {
          value: 'DD',
          label: 'DD',
          isDisabled: false
        }
      ],
      list3: [
        {
          value: 'PO',
          label: 'PO',
          isDisabled: false
        }
      ]
    },
    InstTypeTextBox: {
      label: 'Inst. Type',
      isDisabled: false,
      isVisible: true,
      InstTypeTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric',
      mandatory: false
    },
    InstNoTextBox: {
      label: 'Inst. No',
      isDisabled: false,
      isVisible: true,
      InstNoTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    InstAmountTextBox: {
      label: 'Inst. Amount',
      isDisabled: false,
      isVisible: true,
      InstAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    InstDateTextBox: {
      InstDateTextBoxValue: '',
      isVisible: true,
      label: 'Inst. Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    //bills info tab
     BillInfoTab: {
      isDisabled: false,
      label: 'Bill Info'
    },
    SalesTaxTab: {
      isDisabled: false,
      label: 'Sales Tax'
    },

    CustomerInformationSection: {
      isVisible: true
    },
    Section4: {
      isDisabled: false,
      isVisible: true
    },
    Section5: {
      isDisabled: false,
      isVisible: true
    },
    Section6: {
      isDisabled: false,
      isVisible: true
    },
    Section7: {
      isDisabled: false,
      isVisible: true
    },
    Section8: {
      isDisabled: false,
      isVisible: true
    },

    Section9: {
      isDisabled: false,
      isVisible: true
    },
    Section10: {
      isDisabled: false,
      isVisible: true
    },
    Section11: {
      isDisabled: false,
      isVisible: true
    },
    Section12: {
      isDisabled: false,
      isVisible: true
    },
    Section13: {
      isDisabled: false,
      isVisible: true
    },
    Section14: {
      isDisabled: false,
      isVisible: true
    },
    Section15: {
      isDisabled: false,
      isVisible: true
    },
    ///Bills Info
    LDBC_No: {
      LDBCText: '101001/2024',
      isVisible: true
    },

    LDBP_No: {
      LDBPText: '101001/2024',
      isVisible: true
    },

    LDBC_AccountNumberTextBox: {
      label: 'LDBC A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBC_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },

    LDBP_AccountNumberTextBox: {
      label: 'LDBP A/C No.',
      isDisabled: false,
      isVisible: true,
      LDBP_AccountNumberTextBoxValue: '60010124000192019',
      backgroundColor: 'white',
      mandatory: false
    },
    DateTextBox: {
      label: 'Date',
      isDisabled: false,
      isVisible: true,
      DateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    ContractLCRadioButton: {
      isDisabled: false,
      ContractLCRadioButtonValue: 'Contract',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Contract',
          label: 'Contract',
          isDisabled: false
        }
      ]
    },

    ExportSalesRadioButton: {
      isDisabled: false,
      ExportSalesRadioButtonValue: 'Export',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Export',
          label: 'Export',
          isDisabled: false
        },
      ]
    },

    TermTextBox: {
      label: 'Term',
      isDisabled: false,
      isVisible: true,
      TermTextBoxValue: 'SIGHT -1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    SightLabel: {
      SightText: '',
      isVisible: false
    },
    UsanceLabel: {
      UsanceText: '',
      isVisible: true,
    },

    TenorDaysTextBox: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      TenorDaysTextBoxValue: '1 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DateRadioButton: {
      isDisabled: false,
      DateRadioButtonValue: 'From Shipment Date',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'FromShipmentDate',
          label: 'From Shipment Date',
          isDisabled: false
        },
      ]
    },

    ShipDateTextBox: {
      label: 'Ship Date',
      isDisabled: false,
      isVisible: true,
      ShipDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    DueDateTextBox: {
      label: 'Due Date',
      isDisabled: false,
      isVisible: true,
      DueDateTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BankTextBox: {
      label: 'Bank',
      isDisabled: false,
      isVisible: true,
      BankTextBoxValue: 'ISLAMIC BANK',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BranchTextBox: {
      label: 'Branch',
      isDisabled: false,
      isVisible: true,
      BranchTextBoxValue: 'Karachi-0006 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BeneficiaryBuyerRadioButton: {
      isDisabled: false,
      BeneficiaryBuyerRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'Buyer',
          label: 'Buyer',
          isDisabled: false
        }
      ]
    },

    RoadRailRadioButton: {
      isDisabled: false,
      RoadRailRadioButtonValue: '',
      radioLabel: '',
      mandatory: false,
      isVisible: true,

      radioGroup: [
        {
          value: 'ByRoad',
          label: 'By Road',
          isDisabled: false
        },
      ]
    },

    DiscountInfoDays: {
      label: 'Days',
      isDisabled: false,
      isVisible: true,
      DiscountInfoDaysValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    RateTextBox: {
      label: 'Rate',
      isDisabled: false,
      isVisible: true,
      RateTextBoxValue: '52.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    BuyerTextBox: {
      label: 'Buyer',
      isDisabled: false,
      isVisible: true,
      BuyerTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BillAmountTextBox2: {
      label: 'Bill Amount ',
      isDisabled: false,
      isVisible: true,
      BillAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    BalanceAmountTextBox2: {
      label: 'Balance Amount ',
      isDisabled: false,
      isVisible: true,
      BalanceAmountTextBox2Value: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CommodityTextBox: {
      label: 'Commodity',
      isDisabled: false,
      isVisible: true,
      CommodityTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



      OriginTextBox: {
      label: 'Origin',
      isDisabled: false,
      isVisible: true,
      OriginTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    DestinationTextBox: {
      label: 'Destination',
      isDisabled: false,
      isVisible: true,
      DestinationTextBoxValue: '6 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },


    InvoiveNumberTextBox: {
      label: 'Invoice No',
      isDisabled: false,
      isVisible: true,
      InvoiveNumberTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     InvoiceAmountTextBox: {
      label: 'Invoice Amount ',
      isDisabled: false,
      isVisible: true,
      InvoiceAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    InvoiceDateTextBox:{
     label: 'Invoice Date ',
      isDisabled: false,
      isVisible: true,
      InvoiceDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },



    CourierRefTextBox: {
      label: 'Courier Ref',
      isDisabled: false,
      isVisible: true,
      CourierRefTextBoxValue: '',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
     CourierAmountTextBox: {
      label: 'Courier Amount ',
      isDisabled: false,
      isVisible: true,
      CourierAmountTextBoxValue: '200.00 ',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },

    CourierDateTextBox:{
     label: 'Courier Date ',
      isDisabled: false,
      isVisible: true,
      CourierDateTextBoxValue: '04/11/2024',
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'numeric',
      mandatory: false
    },
    MaturityTextBox: {
      MaturityTextBoxValue: '',
      isVisible: false,
      label: 'Maturity Date',
      backgroundColor: 'White',
      isDisabled: false
    },
    BillAmountTextBox3: {
      label: 'Bill Amount',
      isDisabled: false,
      isVisible: false,
      BillAmountTextBox3Value: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ReversedAmountTextBox:{
      label: 'Reversed Amount',
      isDisabled: false,
      isVisible: false,
      ReversedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    ConvertedAmountTextBox:{
      label: 'Convert Amount',
      isDisabled: false,
      isVisible: false,
      ConvertedAmountTextBoxValue: '',
      backgroundColor: 'white',
      mandatory: false
    },
    //bttons field
    OKButton: {
      isVisible: false,
      label: 'OK',
      isDisabled: false
    },
    BackButton: {
      isVisible: true,
      label: 'Back',
      isDisabled: false
    },
    ViewLodgeVoucherButton: {
      isVisible: true,
      label: 'View Lodge Voucher',
      isDisabled: false
    },
    ExitButton: {
      isVisible: true,
      label: 'Exit',
      isDisabled: false
    },
    ReturnButton: {
      isVisible: false,
      label: 'Return',
      isDisabled: false
    },
    CancelButton: {
      isVisible: true,
      label: 'Cancel',
      isDisabled: false
    }
  }
}

const Template = (args) => ({
  components: { MegaSet1139 },
  template: `<MegaSet1139 v-bind="args"/>`,
  setup() {
    return {
      args: {
        configObj: {
          componentProps: {
            AccountNumberTextBox: {
              label: 'A/C No.',
              isDisabled: false,
              isVisible: true,
              AccountNumberTextBoxValue: '60010124000192019',
              backgroundColor: 'white',
              mandatory: false
            },
            AccountTitleTextBox: {
              label: 'A/C Title.',
              isDisabled: false,
              isVisible: true,
              AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
              backgroundColor: 'white',
              mandatory: false
            },
  
            NtnNumberTextBox: {
              label: 'NTN No.',
              isDisabled: false,
              isVisible: true,
              NtnNumberTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            CCINumberTextBox: {
              label: 'CCI No',
              isDisabled: false,
              isVisible: true,
              CCINumberTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'alphaNumeric',
              mandatory: false
            },
  
            TabPane: {
              activeName: 'BillInfoTab'
            },
            BillInfoTab: {
              isDisabled: false,
              label: 'Bill Info'
            },
            InstrumentInfoTab: {
              isDisabled: false,
              isVisible: true,
              label: 'Instrument Info'
            },
  
            CustomerInformationSection: {
              isVisible: true
            },
            Section1: {
              isDisabled: false,
              isVisible: true
            },
            Section2: {
              isDisabled: false,
              isVisible: true
            },
            ///Bills Info
            LDBC_No: {
              LDBCText: '011002/2024',
              isVisible: true
            },
            LDBCAccountNumberTextBox: {
              label: 'LDBC A/C No.',
              isDisabled: false,
              isVisible: true,
              LDBCAccountNumberTextBoxValue: '0338149840011',
              backgroundColor: 'white',
              mandatory: false
            },
            //Instrument Info tab
            Section3: {
              isDisabled: false,
              isVisible: true
            },
            BillAmountTextBox1: {
              label: 'Bill Amount',
              isDisabled: false,
              isVisible: true,
              BillAmountTextBox1Value: '',
              backgroundColor: 'white',
              mandatory: false
            },
            BalanceAmountTextBox1: {
              label: 'Balance Amount',
              isDisabled: false,
              isVisible: true,
              BalanceAmountTextBox1Value: '',
              backgroundColor: 'white',
              mandatory: false
            },
            InstrumentBalAmountTextBox: {
              label: 'Instrument Bal',
              isDisabled: false,
              isVisible: true,
              InstrumentBalAmountTextBoxValue: '',
              backgroundColor: 'white',
              mandatory: false
            },
            InstrumentInformationSection: {
              isVisible: true
            },
            SBPChequeDDPORadioButton: {
              isDisabled: false,
              values: '',
              isVisible: true,
              SBPChequeDDPORadioButtonValue: 'Discrepancy',
              list1: [
                {
                  value: 'SBP Cheque',
                  label: 'SBP Cheque',
                  isDisabled: false
                }
              ],
              list2: [
                {
                  value: 'DD',
                  label: 'DD',
                  isDisabled: false
                }
              ],
              list3: [
                {
                  value: 'PO',
                  label: 'PO',
                  isDisabled: false
                }
              ]
            },
            InstTypeTextBox: {
              label: 'Inst. Type',
              isDisabled: false,
              isVisible: true,
              InstTypeTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'alphaNumeric',
              mandatory: false
            },
            InstNoTextBox: {
              label: 'Inst. No',
              isDisabled: false,
              isVisible: true,
              InstNoTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
            InstAmountTextBox: {
              label: 'Inst. Amount',
              isDisabled: false,
              isVisible: true,
              InstAmountTextBoxValue: '',
              backgroundColor: 'white',
              mandatory: false
            },
            InstDateTextBox: {
              InstDateTextBoxValue: '',
              isVisible: true,
              label: 'Inst. Date',
              backgroundColor: 'White',
              isDisabled: false
            },
            //bills info tab
             BillInfoTab: {
              isDisabled: false,
              label: 'Bill Info'
            },
            SalesTaxTab: {
              isDisabled: false,
              label: 'Sales Tax'
            },
  
            CustomerInformationSection: {
              isVisible: true
            },
            Section4: {
              isDisabled: false,
              isVisible: true
            },
            Section5: {
              isDisabled: false,
              isVisible: true
            },
            Section6: {
              isDisabled: false,
              isVisible: true
            },
            Section7: {
              isDisabled: false,
              isVisible: true
            },
            Section8: {
              isDisabled: false,
              isVisible: true
            },
  
            Section9: {
              isDisabled: false,
              isVisible: true
            },
            Section10: {
              isDisabled: false,
              isVisible: true
            },
            Section11: {
              isDisabled: false,
              isVisible: true
            },
            Section12: {
              isDisabled: false,
              isVisible: true
            },
            Section13: {
              isDisabled: false,
              isVisible: true
            },
            Section14: {
              isDisabled: false,
              isVisible: true
            },
            Section15: {
              isDisabled: false,
              isVisible: true
            },
            ///Bills Info
            LDBC_No: {
              LDBCText: '101001/2024',
              isVisible: true
            },
  
            LDBP_No: {
              LDBPText: '101001/2024',
              isVisible: true
            },
  
            LDBC_AccountNumberTextBox: {
              label: 'LDBC A/C No.',
              isDisabled: false,
              isVisible: true,
              LDBC_AccountNumberTextBoxValue: '60010124000192019',
              backgroundColor: 'white',
              mandatory: false
            },
  
            LDBP_AccountNumberTextBox: {
              label: 'LDBP A/C No.',
              isDisabled: false,
              isVisible: true,
              LDBP_AccountNumberTextBoxValue: '60010124000192019',
              backgroundColor: 'white',
              mandatory: false
            },
            DateTextBox: {
              label: 'Date',
              isDisabled: false,
              isVisible: true,
              DateTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            ContractLCRadioButton: {
              isDisabled: false,
              ContractLCRadioButtonValue: '',
              radioLabel: '',
              mandatory: false,
              isVisible: true,
  
              radioGroup: [
                {
                  value: 'Contract',
                  label: 'Contract',
                  isDisabled: false
                },
                {
                  value: 'LC',
                  label: 'L/C',
                  isDisabled: false
                }
              ]
            },
  
            ExportSalesRadioButton: {
              isDisabled: false,
              ExportSalesRadioButtonValue: '',
              radioLabel: '',
              mandatory: false,
              isVisible: true,
  
              radioGroup: [
                {
                  value: 'Export',
                  label: 'Export',
                  isDisabled: false
                },
                {
                  value: 'Sales',
                  label: 'Sales',
                  isDisabled: false
                }
              ]
            },
  
            TermTextBox: {
              label: 'Term',
              isDisabled: false,
              isVisible: true,
              TermTextBoxValue: 'SIGHT -1 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            SightLabel: {
              SightText: '',
              isVisible: true
            },
            UsanceLabel: {
              UsanceText: '',
              isVisible: true,
            },
  
            TenorDaysTextBox: {
              label: 'Days',
              isDisabled: false,
              isVisible: true,
              TenorDaysTextBoxValue: '1 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
            DateRadioButton: {
              isDisabled: false,
              DateRadioButtonValue: '',
              radioLabel: '',
              mandatory: false,
              isVisible: true,
  
              radioGroup: [
                {
                  value: 'FromShipDate',
                  label: 'From Ship. Date',
                  isDisabled: false
                },
                {
                  value: 'AfterShipDate',
                  label: 'After Ship. Date',
                  isDisabled: false
                },
                {
                  value: 'NegotiationDate',
                  label: 'Negotiation Date',
                  isDisabled: false
                }
              ]
            },
  
            ShipDateTextBox: {
              label: 'Ship Date',
              isDisabled: false,
              isVisible: true,
              ShipDateTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
            DueDateTextBox: {
              label: 'Due Date',
              isDisabled: false,
              isVisible: true,
              DueDateTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            BankTextBox: {
              label: 'Bank',
              isDisabled: false,
              isVisible: true,
              BankTextBoxValue: 'ISLAMIC BANK',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
            BranchTextBox: {
              label: 'Branch',
              isDisabled: false,
              isVisible: true,
              BranchTextBoxValue: 'Karachi-0006 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            BeneficiaryBuyerRadioButton: {
              isDisabled: false,
              BeneficiaryBuyerRadioButtonValue: '',
              radioLabel: '',
              mandatory: false,
              isVisible: true,
  
              radioGroup: [
                {
                  value: 'ByBeneficiary',
                  label: 'By Beneficiary',
                  isDisabled: false
                },
                {
                  value: 'Buyer',
                  label: 'Buyer',
                  isDisabled: false
                }
              ]
            },
  
            RoadRailRadioButton: {
              isDisabled: false,
              RoadRailRadioButtonValue: '',
              radioLabel: '',
              mandatory: false,
              isVisible: true,
  
              radioGroup: [
                {
                  value: 'ByRoad',
                  label: 'By Road',
                  isDisabled: false
                },
                {
                  value: 'ByRail',
                  label: 'By Rail',
                  isDisabled: false
                }
              ]
            },
  
            DiscountInfoDays: {
              label: 'Days',
              isDisabled: false,
              isVisible: true,
              DiscountInfoDaysValue: '6 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
            RateTextBox: {
              label: 'Rate',
              isDisabled: false,
              isVisible: true,
              RateTextBoxValue: '52.00 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
            BuyerTextBox: {
              label: 'Buyer',
              isDisabled: false,
              isVisible: true,
              BuyerTextBoxValue: '6 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            BillAmountTextBox2: {
              label: 'Bill Amount ',
              isDisabled: false,
              isVisible: true,
              BillAmountTextBox2Value: '200.00 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            BalanceAmountTextBox2: {
              label: 'Balance Amount ',
              isDisabled: false,
              isVisible: true,
              BalanceAmountTextBox2Value: '200.00 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            CommodityTextBox: {
              label: 'Commodity',
              isDisabled: false,
              isVisible: true,
              CommodityTextBoxValue: '6 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
  
  
              OriginTextBox: {
              label: 'Origin',
              isDisabled: false,
              isVisible: true,
              OriginTextBoxValue: '6 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            DestinationTextBox: {
              label: 'Destination',
              isDisabled: false,
              isVisible: true,
              DestinationTextBoxValue: '6 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
  
            InvoiveNumberTextBox: {
              label: 'Invoice No',
              isDisabled: false,
              isVisible: true,
              InvoiveNumberTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
             InvoiceAmountTextBox: {
              label: 'Invoice Amount ',
              isDisabled: false,
              isVisible: true,
              InvoiceAmountTextBoxValue: '200.00 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            InvoiceDateTextBox:{
             label: 'Invoice Date ',
              isDisabled: false,
              isVisible: true,
              InvoiceDateTextBoxValue: '04/11/2024',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
  
  
            CourierRefTextBox: {
              label: 'Courier Ref',
              isDisabled: false,
              isVisible: true,
              CourierRefTextBoxValue: '',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
             CourierAmountTextBox: {
              label: 'Courier Amount ',
              isDisabled: false,
              isVisible: true,
              CourierAmountTextBoxValue: '200.00 ',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
  
            CourierDateTextBox:{
             label: 'Courier Date ',
              isDisabled: false,
              isVisible: true,
              CourierDateTextBoxValue: '04/11/2024',
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'numeric',
              mandatory: false
            },
            MaturityTextBox: {
              MaturityTextBoxValue: '',
              isVisible: true,
              label: 'Maturity Date',
              backgroundColor: 'White',
              isDisabled: false
            },
            BillAmountTextBox3: {
              label: 'Bill Amount',
              isDisabled: false,
              isVisible: true,
              BillAmountTextBox3Value: '',
              backgroundColor: 'white',
              mandatory: false
            },
            ReversedAmountTextBox:{
              label: 'Reversed Amount',
              isDisabled: false,
              isVisible: true,
              ReversedAmountTextBoxValue: '',
              backgroundColor: 'white',
              mandatory: false
            },
            ConvertedAmountTextBox:{
              label: 'Convert Amount',
              isDisabled: false,
              isVisible: true,
              ConvertedAmountTextBoxValue: '',
              backgroundColor: 'white',
              mandatory: false
            },
            //bttons field
            OKButton: {
              isVisible: true,
              label: 'OK',
              isDisabled: false
            },
            BackButton: {
              isVisible: true,
              label: 'Back',
              isDisabled: false
            },
            ViewLodgeVoucherButton: {
              isVisible: true,
              label: 'View Lodge Voucher',
              isDisabled: false
            },
            ExitButton: {
              isVisible: true,
              label: 'Exit',
              isDisabled: false
            },
            ReturnButton: {
              isVisible: true,
              label: 'Return',
              isDisabled: false
            },
            CancelButton: {
              isVisible: true,
              label: 'Cancel',
              isDisabled: false
            }
          }
        }
      }
    };
  },
});
const Template_SS = (args) => ({
  components: { MegaSet1139 },
  template:  `<MegaSet1139 v-bind="args"/>`,
  setup() {
    return { args };
  },
});

export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };

export const SS_EXP_115_Set1 = Template_SS.bind({})
SS_EXP_115_Set1.args = {configObj: configurationObject_SS_EXP_115_Set1}

export const SS_EXP_115_Set2 = Template_SS.bind({})
SS_EXP_115_Set2.args = {configObj: configurationObject_SS_EXP_115_Set2}

export const SS_EXP_115_Set3 = Template_SS.bind({})
SS_EXP_115_Set3.args = {configObj: configurationObject_SS_EXP_115_Set3}

export const SS_EXP_115_Set4 = Template_SS.bind({})
SS_EXP_115_Set4.args = {configObj: configurationObject_SS_EXP_115_Set4}

export const SS_EXP_115_Set5 = Template_SS.bind({})
SS_EXP_115_Set5.args = {configObj: configurationObject_SS_EXP_115_Set5}

export const SS_EXP_115_Set6 = Template_SS.bind({})
SS_EXP_115_Set6.args = {configObj: configurationObject_SS_EXP_115_Set6}

export const SS_EXP_115_Set7 = Template_SS.bind({})
SS_EXP_115_Set7.args = {configObj: configurationObject_SS_EXP_115_Set7}

export const SS_EXP_115_Set8 = Template_SS.bind({})
SS_EXP_115_Set8.args = {configObj: configurationObject_SS_EXP_115_Set8}

export const SS_EXP_115_Set9 = Template_SS.bind({})
SS_EXP_115_Set9.args = {configObj: configurationObject_SS_EXP_115_Set9}

export const SS_EXP_115_Set10 = Template_SS.bind({})
SS_EXP_115_Set10.args = {configObj: configurationObject_SS_EXP_115_Set10}

export const SS_EXP_115_Set11 = Template_SS.bind({})
SS_EXP_115_Set11.args = {configObj: configurationObject_SS_EXP_115_Set11}

export const SS_EXP_115_Set12 = Template_SS.bind({})
SS_EXP_115_Set12.args = {configObj: configurationObject_SS_EXP_115_Set12}

export const SS_EXP_115_Set13_14 = Template_SS.bind({})
SS_EXP_115_Set13_14.args = {configObj: configurationObject_SS_EXP_115_Set13_14}

export const SS_EXP_115_Set15 = Template_SS.bind({})
SS_EXP_115_Set15.args = {configObj: configurationObject_SS_EXP_115_Set15}

export const SS_EXP_115_Set16 = Template_SS.bind({})
SS_EXP_115_Set16.args = {configObj: configurationObject_SS_EXP_115_Set16}

export const SS_EXP_115_Set17 = Template_SS.bind({})
SS_EXP_115_Set17.args = {configObj: configurationObject_SS_EXP_115_Set17}

export const SS_EXP_115_Set18 = Template_SS.bind({})
SS_EXP_115_Set18.args = {configObj: configurationObject_SS_EXP_115_Set18}

export const SS_EXP_115_Set19 = Template_SS.bind({})
SS_EXP_115_Set19.args = {configObj: configurationObject_SS_EXP_115_Set19}

export const SS_EXP_115_Set20 = Template_SS.bind({})
SS_EXP_115_Set20.args = {configObj: configurationObject_SS_EXP_115_Set20}

export const SS_EXP_115_Set21 = Template_SS.bind({})
SS_EXP_115_Set21.args = {configObj: configurationObject_SS_EXP_115_Set21}

export const SS_EXP_115_Set22 = Template_SS.bind({})
SS_EXP_115_Set22.args = {configObj: configurationObject_SS_EXP_115_Set22}

export const SS_EXP_115_Set23 = Template_SS.bind({})
SS_EXP_115_Set23.args = {configObj: configurationObject_SS_EXP_115_Set23}

export const SS_EXP_115_Set24 = Template_SS.bind({})
SS_EXP_115_Set24.args = {configObj: configurationObject_SS_EXP_115_Set24}

export const SS_EXP_115_Set25_27_28 = Template_SS.bind({})
SS_EXP_115_Set25_27_28.args = {configObj: configurationObject_SS_EXP_115_Set25_27_28}

export const SS_EXP_115_Set26 = Template_SS.bind({})
SS_EXP_115_Set26.args = {configObj: configurationObject_SS_EXP_115_Set26}

export const SS_EXP_115_Set29 = Template_SS.bind({})
SS_EXP_115_Set29.args = {configObj: configurationObject_SS_EXP_115_Set29}

export const SS_EXP_115_Set30 = Template_SS.bind({})
SS_EXP_115_Set30.args = {configObj: configurationObject_SS_EXP_115_Set30}

export const SS_EXP_115_Set31 = Template_SS.bind({})
SS_EXP_115_Set31.args = {configObj: configurationObject_SS_EXP_115_Set31}

export const SS_EXP_115_Set32 = Template_SS.bind({})
SS_EXP_115_Set32.args = {configObj: configurationObject_SS_EXP_115_Set32}

export const SS_EXP_115_Set33_34 = Template_SS.bind({})
SS_EXP_115_Set33_34.args = {configObj: configurationObject_SS_EXP_115_Set33_34}

export const SS_EXP_115_Set35 = Template_SS.bind({})
SS_EXP_115_Set35.args = {configObj: configurationObject_SS_EXP_115_Set35}

export const SS_EXP_115_Set36 = Template_SS.bind({})
SS_EXP_115_Set36.args = {configObj: configurationObject_SS_EXP_115_Set36}

export const SS_EXP_115_Set37 = Template_SS.bind({})
SS_EXP_115_Set37.args = {configObj: configurationObject_SS_EXP_115_Set37}

export const SS_EXP_115_Set38_39 = Template_SS.bind({})
SS_EXP_115_Set38_39.args = {configObj: configurationObject_SS_EXP_115_Set38_39}

export const SS_EXP_115_Set40 = Template_SS.bind({})
SS_EXP_115_Set40.args = {configObj: configurationObject_SS_EXP_115_Set40}

export const SS_EXP_115_Set41 = Template_SS.bind({})
SS_EXP_115_Set41.args = {configObj: configurationObject_SS_EXP_115_Set41}

export const SS_EXP_115_Set42 = Template_SS.bind({})
SS_EXP_115_Set42.args = {configObj: configurationObject_SS_EXP_115_Set42}

export const SS_EXP_115_Set43 = Template_SS.bind({})
SS_EXP_115_Set43.args = {configObj: configurationObject_SS_EXP_115_Set43}