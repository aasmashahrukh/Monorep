<template>
  <MegaSet1139 :configObj="configurationObject" 
  @onSubmit="OKButton" 
  @handleTabClick="TabClicked"
  @AccountNumberTextBox-onBlur="AccountNumberTextBoxOnBlur"
  @NtnNumberTextBox-onBlur="NtnNumberTextBoxOnBlur"
  @AccountTitleTextBox-onBlur="AccountTitleTextBoxOnBlur"
  @CCINumberTextBox-onBlur="CCINumberTextBoxOnBlur"
  @BillAmountTextBox1-onBlur="BillAmountTextBox1OnBlur"
  @ContractLCRadioButton-onChange="ContractLCRadioButtonOnChange"
  @DateTextBox-onBlur="DateTextBoxOnBlur"
  @OKButton-onClick="OKButtonOnClick"
  @RateTextBox-onBlur="RateTextBoxOnBlur"
  />
</template>
<script>
import MegaSet1139 from '../MegaSet/MegaSet1139.vue';
import { reactive } from 'vue';
export default {
  components: {
    MegaSet1139
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    },
    TabClicked(val){
      console.log('TabClicked',val)
    },
    AccountNumberTextBoxOnBlur(val){
      console.log('AccountNumberTextBoxOnBlur',val)
    },
    NtnNumberTextBoxOnBlur(val){
      console.log("NtnNumberTextBoxOnBlur",val)
    },
    AccountTitleTextBoxOnBlur(val){
      console.log('AccountTitleTextBoxOnBlur',val)
    },
    CCINumberTextBoxOnBlur(val){
      console.log('CCINumberTextBoxOnBlur',val)
    },
    BillAmountTextBox1OnBlur(val){
      console.log("BillAmountTextBox1OnBlur",val)
    },
    ContractLCRadioButtonOnChange(val){
      console.log('ContractLCRadioButtonOnChange',val)
    },
    DateTextBoxOnBlur(val){
      console.log('DateTextBoxOnBlur',val)
    },
    OKButtonOnClick(){
      console.log("OKButtonOnClick")
    },
    RateTextBoxOnBlur(val){
      console.log('RateTextBoxOnBlur',val)
    }
  },
  setup() {
    return reactive({
      configurationObject: {
        componentProps: {
          AccountNumberTextBox: {
            label: 'A/C No.',
            isDisabled: false,
            isVisible: true,
            AccountNumberTextBoxValue: '60010124000192019',
            backgroundColor: 'white',
            mandatory: false
          },
          AccountTitleTextBox: {
            label: 'A/C Title.',
            isDisabled: false,
            isVisible: true,
            AccountTitleTextBoxValue: '6001-0124-000192-01-9-AC TITLE',
            backgroundColor: 'white',
            mandatory: false
          },

          NtnNumberTextBox: {
            label: 'NTN No.',
            isDisabled: false,
            isVisible: true,
            NtnNumberTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          CCINumberTextBox: {
            label: 'CCI No',
            isDisabled: false,
            isVisible: true,
            CCINumberTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'alphaNumeric',
            mandatory: false
          },

          TabPane: {
            activeName: 'BillInfoTab'
          },
          BillInfoTab: {
            isDisabled: false,
            label: 'Bill Info'
          },
          InstrumentInfoTab: {
            isDisabled: false,
            isVisible: true,
            label: 'Instrument Info'
          },

          CustomerInformationSection: {
            isVisible: true
          },
          Section1: {
            isDisabled: false,
            isVisible: true
          },
          Section2: {
            isDisabled: false,
            isVisible: true
          },
          ///Bills Info
          LDBCNo: {
            LDBCText:"LDBC 101001/2024",
            isVisible: true
          },
          LDBCAccountNumberTextBox: {
            label: 'LDBC A/C No.',
            isDisabled: false,
            isVisible: true,
            LDBCAccountNumberTextBoxValue: '0338149840011',
            backgroundColor: 'white',
            mandatory: false
          },
          //Instrument Info tab
          Section3: {
            isDisabled: false,
            isVisible: true
          },
          BillAmountTextBox1: {
            label: 'Bill Amount',
            isDisabled: false,
            isVisible: true,
            BillAmountTextBox1Value: '',
            backgroundColor: 'white',
            mandatory: false
          },
          BalanceAmountTextBox1: {
            label: 'Balance Amount',
            isDisabled: false,
            isVisible: true,
            BalanceAmountTextBox1Value: '',
            backgroundColor: 'white',
            mandatory: false
          },
          InstrumentBalAmountTextBox: {
            label: 'Instrument Bal',
            isDisabled: false,
            isVisible: true,
            InstrumentBalAmountTextBoxValue: '',
            backgroundColor: 'white',
            mandatory: false
          },
          InstrumentInformationSection: {
            isVisible: true
          },
          SBPChequeDDPORadioButton: {
            isDisabled: false,
            values: '',
            isVisible: true,
            SBPChequeDDPORadioButtonValue: 'Discrepancy',
            list1: [
              {
                value: 'SBP Cheque',
                label: 'SBP Cheque',
                isDisabled: false
              }
            ],
            list2: [
              {
                value: 'DD',
                label: 'DD',
                isDisabled: false
              }
            ],
            list3: [
              {
                value: 'PO',
                label: 'PO',
                isDisabled: false
              }
            ]
          },
          InstTypeTextBox: {
            label: 'Inst. Type',
            isDisabled: false,
            isVisible: true,
            InstTypeTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'alphaNumeric',
            mandatory: false
          },
          InstNoTextBox: {
            label: 'Inst. No',
            isDisabled: false,
            isVisible: true,
            InstNoTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          InstAmountTextBox: {
            label: 'Inst. Amount',
            isDisabled: false,
            isVisible: true,
            InstAmountTextBoxValue: '',
            backgroundColor: 'white',
            mandatory: false
          },
          InstDateTextBox: {
            InstDateTextBoxValue: '',
            isVisible: true,
            label: 'Inst. Date',
            backgroundColor: 'White',
            isDisabled: false
          },
          //bills info tab
           BillInfoTab: {
            isDisabled: false,
            label: 'Bill Info'
          },
          SalesTaxTab: {
            isDisabled: false,
            label: 'Sales Tax'
          },

          CustomerInformationSection: {
            isVisible: true
          },
          Section4: {
            isDisabled: false,
            isVisible: true
          },
          Section5: {
            isDisabled: false,
            isVisible: true
          },
          Section6: {
            isDisabled: false,
            isVisible: true
          },
          Section7: {
            isDisabled: false,
            isVisible: true
          },
          Section8: {
            isDisabled: false,
            isVisible: true
          },

          Section9: {
            isDisabled: false,
            isVisible: true
          },
          Section10: {
            isDisabled: false,
            isVisible: true
          },
          Section11: {
            isDisabled: false,
            isVisible: true
          },
          Section12: {
            isDisabled: false,
            isVisible: true
          },
          Section13: {
            isDisabled: false,
            isVisible: true
          },
          Section14: {
            isDisabled: false,
            isVisible: true
          },
          Section15: {
            isDisabled: false,
            isVisible: true
          },
          ///Bills Info
          LDBC_No: {
            LDBCText: "LDBP No. / LDBC No. Year: 101001/2024",
            isVisible: true
          },

          LDBP_No: {
            LDBPText: '101001/2024',
            isVisible: true
          },

          LDBC_AccountNumberTextBox: {
            label: 'LDBC A/C No.',
            isDisabled: false,
            isVisible: true,
            LDBC_AccountNumberTextBoxValue: '60010124000192019',
            backgroundColor: 'white',
            mandatory: false
          },

          LDBP_AccountNumberTextBox: {
            label: 'LDBP A/C No.',
            isDisabled: false,
            isVisible: true,
            LDBP_AccountNumberTextBoxValue: '60010124000192019',
            backgroundColor: 'white',
            mandatory: false
          },
          DateTextBox: {
            label: 'Date',
            isDisabled: false,
            isVisible: true,
            DateTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          ContractLCRadioButton: {
            isDisabled: false,
            ContractLCRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'Contract',
                label: 'Contract',
                isDisabled: false
              },
              {
                value: 'LC',
                label: 'L/C',
                isDisabled: false
              }
            ]
          },

          ExportSalesRadioButton: {
            isDisabled: false,
            ExportSalesRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'Export',
                label: 'Export',
                isDisabled: false
              },
              {
                value: 'Sales',
                label: 'Sales',
                isDisabled: false
              }
            ]
          },

          TermTextBox: {
            label: 'Term',
            isDisabled: false,
            isVisible: true,
            TermTextBoxValue: 'SIGHT -1 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          SightLabel: {
            SightText: '',
            isVisible: true
          },
          UsanceLabel: {
            UsanceText: '',
            isVisible: true,
          },

          TenorDaysTextBox: {
            label: 'Days',
            isDisabled: false,
            isVisible: true,
            TenorDaysTextBoxValue: '1 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          DateRadioButton: {
            isDisabled: false,
            DateRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'FromShipDate',
                label: 'From Ship. Date',
                isDisabled: false
              },
              {
                value: 'AfterShipDate',
                label: 'After Ship. Date',
                isDisabled: false
              },
              {
                value: 'NegotiationDate',
                label: 'Negotiation Date',
                isDisabled: false
              }
            ]
          },

          ShipDateTextBox: {
            label: 'Ship Date',
            isDisabled: false,
            isVisible: true,
            ShipDateTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          DueDateTextBox: {
            label: 'Due Date',
            isDisabled: false,
            isVisible: true,
            DueDateTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          BankTextBox: {
            label: 'Bank',
            isDisabled: false,
            isVisible: true,
            BankTextBoxValue: 'ISLAMIC BANK',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          BranchTextBox: {
            label: 'Branch',
            isDisabled: false,
            isVisible: true,
            BranchTextBoxValue: 'Karachi-0006 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          BeneficiaryBuyerRadioButton: {
            isDisabled: false,
            BeneficiaryBuyerRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'ByBeneficiary',
                label: 'By Beneficiary',
                isDisabled: false
              },
              {
                value: 'Buyer',
                label: 'Buyer',
                isDisabled: false
              }
            ]
          },

          RoadRailRadioButton: {
            isDisabled: false,
            RoadRailRadioButtonValue: '',
            radioLabel: '',
            mandatory: false,
            isVisible: true,

            radioGroup: [
              {
                value: 'ByRoad',
                label: 'By Road',
                isDisabled: false
              },
              {
                value: 'ByRail',
                label: 'By Rail',
                isDisabled: false
              }
            ]
          },

          DiscountInfoDays: {
            label: 'Days',
            isDisabled: false,
            isVisible: true,
            DiscountInfoDaysValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          RateTextBox: {
            label: 'Rate',
            isDisabled: false,
            isVisible: true,
            RateTextBoxValue: '52.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          BuyerTextBox: {
            label: 'Buyer',
            isDisabled: false,
            isVisible: true,
            BuyerTextBoxValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          BillAmountTextBox2: {
            label: 'Bill Amount ',
            isDisabled: false,
            isVisible: true,
            BillAmountTextBox2Value: '200.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          BalanceAmountTextBox2: {
            label: 'Balance Amount ',
            isDisabled: false,
            isVisible: true,
            BalanceAmountTextBox2Value: '200.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          CommodityTextBox: {
            label: 'Commodity',
            isDisabled: false,
            isVisible: true,
            CommodityTextBoxValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },



            OriginTextBox: {
            label: 'Origin',
            isDisabled: false,
            isVisible: true,
            OriginTextBoxValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          DestinationTextBox: {
            label: 'Destination',
            isDisabled: false,
            isVisible: true,
            DestinationTextBoxValue: '6 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },


          InvoiveNumberTextBox: {
            label: 'Invoice No',
            isDisabled: false,
            isVisible: true,
            InvoiveNumberTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
           InvoiceAmountTextBox: {
            label: 'Invoice Amount ',
            isDisabled: false,
            isVisible: true,
            InvoiceAmountTextBoxValue: '200.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          InvoiceDateTextBox:{
           label: 'Invoice Date ',
            isDisabled: false,
            isVisible: true,
            InvoiceDateTextBoxValue: '04/11/2024',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },



          CourierRefTextBox: {
            label: 'Courier Ref',
            isDisabled: false,
            isVisible: true,
            CourierRefTextBoxValue: '',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
           CourierAmountTextBox: {
            label: 'Courier Amount ',
            isDisabled: false,
            isVisible: true,
            CourierAmountTextBoxValue: '200.00 ',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },

          CourierDateTextBox:{
           label: 'Courier Date ',
            isDisabled: false,
            isVisible: true,
            CourierDateTextBoxValue: '04/11/2024',
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'numeric',
            mandatory: false
          },
          MaturityTextBox: {
            MaturityTextBoxValue: '',
            isVisible: true,
            label: 'Maturity Date',
            backgroundColor: 'White',
            isDisabled: false
          },
          BillAmountTextBox3: {
            label: 'Bill Amount',
            isDisabled: false,
            isVisible: true,
            BillAmountTextBox3Value: '',
            backgroundColor: 'white',
            mandatory: false
          },
          ReversedAmountTextBox:{
            label: 'Reversed Amount',
            isDisabled: false,
            isVisible: true,
            ReversedAmountTextBoxValue: '',
            backgroundColor: 'white',
            mandatory: false
          },
          ConvertedAmountTextBox:{
            label: 'Converted Amount',
            isDisabled: false,
            isVisible: true,
            ConvertedAmountTextBoxValue: '',
            backgroundColor: 'white',
            mandatory: false
          },
          //bttons field
          OKButton: {
            isVisible: true,
            label: 'OK',
            isDisabled: false,
            nativeType:"submit"
          },
          BackButton: {
            isVisible: true,
            label: 'Back',
            isDisabled: false
          },
          ViewLodgeVoucherButton: {
            isVisible: true,
            label: 'View Lodge Voucher',
            isDisabled: false
          },
          ExitButton: {
            isVisible: true,
            label: 'Exit',
            isDisabled: false
          },
          ReturnButton: {
            isVisible: true,
            label: 'Return',
            isDisabled: false
          },
          CancelButton: {
            isVisible: true,
            label: 'Cancel',
            isDisabled: false
          }
        }
      }
    });
  }
};
</script>