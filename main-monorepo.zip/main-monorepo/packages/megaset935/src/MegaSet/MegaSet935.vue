<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row>
      <el-col :lg="1" :md="1"> </el-col>
      <el-col :lg="20" :md="20">
        <fieldset v-if="configObject.Section1.isVisible">
          <legend>CDR Information</legend>
          <el-row>
            <el-col :lg="1" :md="1"></el-col>
            <el-col :lg="20" :md="20">
              <GenericTextBox
                ref="RefDuplicateCDRNoTextBox"
                name="DuplicateCDRNoTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('DuplicateCDRNoTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...DuplicateCDRNoTextBox, ...configObject.DuplicateCDRNoTextBox }"
                :values="configObject.DuplicateCDRNoTextBox.DuplicateCDRNoTextBoxValue"
                v-if="configObject.DuplicateCDRNoTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefCDRNoTextBox"
                name="CDRNoTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('CDRNoTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...CDRNoTextBox, ...configObject.CDRNoTextBox }"
                :values="configObject.CDRNoTextBox.CDRNoTextBoxValue"
                v-if="configObject.CDRNoTextBox.isVisible"
              />
              <DateDdMmYyyy
                ref="RefIssuingDate"
                name="IssuingDate"
                @DateDdMmYyyy-onBlur="
                  (val) => {
                    $emit('IssuingDate-onBlur', val);
                  }
                "
                v-bind="{ ...IssuingDate, ...configObject.IssuingDate }"
                :values="configObject.IssuingDate.IssuingDateValue"
                v-if="configObject.IssuingDate.isVisible"
              />
              <AmountNumericDecimal11Point3
                ref="RefAmountTextBox"
                name="AmountTextBox"
                @AmountNumericDecimal11Point3-onBlur="
                  (val) => {
                    $emit('AmountTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...AmountTextBox, ...configObject.AmountTextBox }"
                :values="configObject.AmountTextBox.AmountTextBoxValue"
                v-if="configObject.AmountTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefBeneficiaryTextBox"
                name="BeneficiaryTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('BeneficiaryTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...BeneficiaryTextBox, ...configObject.BeneficiaryTextBox }"
                :values="configObject.BeneficiaryTextBox.BeneficiaryTextBoxValue"
                v-if="configObject.BeneficiaryTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefRemarksTextBox"
                name="RemarksTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('RemarksTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...RemarksTextBox, ...configObject.RemarksTextBox }"
                :values="configObject.RemarksTextBox.RemarksTextBoxValue"
                v-if="configObject.RemarksTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefNoLabelTextBox"
                name="NoLabelTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('NoLabelTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...NoLabelTextBox, ...configObject.NoLabelTextBox }"
                :values="configObject.NoLabelTextBox.NoLabelTextBoxValue"
                v-if="configObject.NoLabelTextBox.isVisible"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
        </fieldset>
        <fieldset v-if="configObject.Section2.isVisible">
          <legend>Status Information</legend>
          <el-row>
            <el-col :lg="1" :md="1"></el-col>
            <el-col :lg="20" :md="20">
              <GenericTextBox
                ref="RefStatusTextBox"
                name="StatusTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('StatusTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...StatusTextBox, ...configObject.StatusTextBox }"
                :values="configObject.StatusTextBox.StatusTextBoxValue"
                v-if="configObject.StatusTextBox.isVisible"
              />
              <GenericTextBox
                ref="RefStatusIDTextBox"
                name="StatusIDTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('StatusIDTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...StatusIDTextBox, ...configObject.StatusIDTextBox }"
                :values="configObject.StatusIDTextBox.StatusIDTextBoxValue"
                v-if="configObject.StatusIDTextBox.isVisible"
              />
              <DateDdMmYyyy
                ref="RefStatusDate"
                name="StatusDate"
                @DateDdMmYyyy-onBlur="
                  (val) => {
                    $emit('StatusDate-onBlur', val);
                  }
                "
                v-bind="{ ...StatusDate, ...configObject.StatusDate }"
                :values="configObject.StatusDate.StatusDateValue"
                v-if="configObject.StatusDate.isVisible"
              />
              <GenericTextBox
                ref="RefRenewedTextBox"
                name="RenewedTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('RenewedTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...RenewedTextBox, ...configObject.RenewedTextBox }"
                :values="configObject.RenewedTextBox.RenewedTextBoxValue"
                v-if="configObject.RenewedTextBox.isVisible"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
        </fieldset>
        <fieldset v-if="configObject.Section3.isVisible">
          <legend>Mode Of Payment</legend>
          <el-row>
            <el-col :lg="6" :md="6"></el-col>
            <el-col :lg="6" :md="6">
              <GenericRadioButton
                ref="RefMdeOfPayment"
                name="MdeOfPayment"
                @GenericRadioButton-onChange="
                   (val) => {
                    $emit('MdeOfPayment-onChange', val);
                  }
                "
                v-bind="{ ...MdeOfPayment, ...configObject.MdeOfPayment }"
                :values="configObject.MdeOfPayment.MdeOfPaymentValue"
                v-if="configObject.MdeOfPayment.isVisible"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
        </fieldset>
        <fieldset v-if="configObject.Section4.isVisible">
          <el-row>
            <el-col :lg="5" :md="5">
              <GenericButton
                ref="RefProcessOrgButton"
                name="ProcessOrgButton"
                @GenericButton-onClick="
                    $emit('ProcessOrgButton-onClick');"
                v-bind="{ ...ProcessOrgButton, ...configObject.ProcessOrgButton }"
                v-if="configObject.ProcessOrgButton.isVisible"
              />
              <GenericButton
                ref="RefProcessDupCDRButton"
                name="ProcessDupCDRButton"
                @GenericButton-onClick="
                    $emit('ProcessDupCDRButton-onClick');"
                v-bind="{ ...ProcessDupCDRButton, ...configObject.ProcessDupCDRButton }"
                v-if="configObject.ProcessDupCDRButton.isVisible"
              />
            </el-col>
            <el-col :lg="4" :md="4">
              <GenericButton
                ref="RefProcessDupButton"
                name="ProcessDupButton"
                @GenericButton-onClick="
                    $emit('ProcessDupButton-onClick');"
                v-bind="{ ...ProcessDupButton, ...configObject.ProcessDupButton }"
                v-if="configObject.ProcessDupButton.isVisible"
              />
           
            </el-col>
            <el-col :lg="8" :md="8"></el-col>
            <el-col :lg="3" :md="3">
              <GenericButton
                ref="RefBackButton"
                name="BackButton"
                @GenericButton-onClick="
                    $emit('BackButton-onClick');"
                v-bind="{ ...BackButton, ...configObject.BackButton }"
                v-if="configObject.BackButton.isVisible"
              />
             
            </el-col>
            <el-col :lg="3" :md="3">
             
              <GenericButton
                ref="RefExitButton"
                name="ExitButton"
                @GenericButton-onClick="
                    $emit('ExitButton-onClick');
                "
                v-bind="{ ...ExitButton, ...configObject.ExitButton }"
                v-if="configObject.ExitButton.isVisible"
              />
            </el-col>
          </el-row>
        </fieldset>
      </el-col>
      <el-col :lg="2" :md="2"> </el-col>
    </el-row>
  </Form>
</template>
<script>
import { GenericTextBox, DateDdMmYyyy, AmountNumericDecimal11Point3, GenericRadioButton, GenericButton } from '@teresol-v2/ui-components';
import { Form, useForm } from 'vee-validate';
import { reactive, ref } from 'vue';
export default {
  name: 'MegaSet935',

  components: {
    Form,
    GenericTextBox,
    DateDdMmYyyy,
    AmountNumericDecimal11Point3,
    GenericRadioButton,
    GenericButton
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive({
      ...props.configObj.componentProps
    });

    return {
      onSubmit,
      configObject,
      DuplicateCDRNoTextBox: { spanInputs: 12, spanLabels: 6 },
      CDRNoTextBox: { spanInputs: 12, spanLabels: 6 },
      IssuingDate: { spanInputs: 12, spanLabels: 6 },
      AmountTextBox: { spanInputs: 12, spanLabels: 6 },
      BeneficiaryTextBox: { spanInputs: 17, spanLabels: 6 },
      RemarksTextBox: { spanInputs: 17, spanLabels: 6 },
      NoLabelTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusIDTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusDate: { spanInputs: 17, spanLabels: 6 },
      RenewedTextBox: { spanInputs: 17, spanLabels: 6 },
      ModeOfPayment: { spanInputs: 17, spanLabels: 6 },
      ProcessOrgButton: { spanInputs: 21 },
      ProcessDupButton: { spanInputs: 23 },
      ProcessDupCDRButton: { spanInputs: 23 },
      BackButton: { spanInputs: 23 },
      ExitButton: { spanInputs: 23 },
    };
  }
};
</script>
