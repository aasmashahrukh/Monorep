<template>
<MegaSet935 :configObj="configurationObject"
  @onSubmit="onSubmit" />
</template>
<script>
import MegaSet935 from '../MegaSet/MegaSet935.vue';
import { reactive ,ref} from 'vue';
export default {
  components: {
    MegaSet935
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    },
  },
  setup() {
    return reactive({
        configurationObject:{
          componentProps:{
            DuplicateCDRNoTextBox:{
              label:"DupCDRNo",
              isVisible:true,
              isDisabled:false,
              dataType:"numeric",
              inputLength:"10",
              backgroundColor:'white',
              DuplicateCDRNoTextBoxValue:"98"
            },
            CDRNoTextBox:{
              label:"CDR No",
              isVisible:true,
              isDisabled:false,
              dataType:"numeric",
              inputLength:"10",
              backgroundColor:'white',
              CDRNoTextBoxValue:"98"
            },
            IssuingDate:{
              label:"Issuing Date",
              isVisible:true,
              isDisabled:false,
              backgroundColor:'white',
              IssuingDateValue:""
            },
            AmountTextBox:{
              label:"Amount",
              isVisible:true,
              isDisabled:false,
              dataType:"numeric",
              inputLength:"10",
              backgroundColor:'white',
              AmountTextBoxValue:"98"
            },
            BeneficiaryTextBox:{
              label:"Beneficiary",
              isVisible:true,
              isDisabled:false,
              dataType:"alphaneumeric",
              inputLength:"100",
              backgroundColor:'white',
              BeneficiaryTextBoxValue:"98"
            },
            RemarksTextBox:{
              label:"Remarks",
              isVisible:true,
              isDisabled:false,
              dataType:"alphaneumeric",
              inputLength:"100",
              backgroundColor:'white',
              RemarksTextBoxValue:"Remarks"
            },
            NoLabelTextBox:{
              label:"",
              isVisible:true,
              isDisabled:false,
              dataType:"alphaneumeric",
              inputLength:"100",
              backgroundColor:'white',
              NoLabelTextBoxValue:"NoLabelTextBox"
            },
            StatusTextBox:{
              label:"Status",
              isVisible:true,
              isDisabled:false,
              dataType:"alphaneumeric",
              inputLength:"100",
              backgroundColor:'white',
              StatusTextBoxValue:"Issued"
            },
            StatusIDTextBox:{
              label:"Status ID",
              isVisible:true,
              isDisabled:false,
              dataType:"alphaneumeric",
              inputLength:"100",
              backgroundColor:'white',
              StatusIDTextBoxValue:""
            },
            StatusDate:{
              label:"Status Date",
              isVisible:true,
              isDisabled:false,
              backgroundColor:'white',
              IssuingDateValue:""
            },
            RenewedTextBox:{
              label:"Renewed",
              isVisible:true,
              isDisabled:false,
              dataType:"alphaneumeric",
              inputLength:"100",
              backgroundColor:'white',
              RenewedTextBox:""
            },
            MdeOfPayment:{
              label:"Renewed",
              isVisible:true,
              isDisabled:false,
              radioGroup:[{
                value:'Credit to A/C',
                label:'Credit to A/C',
                isVisible:true,
                isDisabled:false,
              }]
            },
            ProcessOrgButton:{
              label:'Process Org',
              isVisible:true,
               isDisabled:false,
            },
            ProcessDupButton:{
              label:'Process Dup',
              isVisible:true,
               isDisabled:false,
            },
            ProcessDupCDRButton:{
              label:'Process Duplicate CDR',
              isVisible:true,
               isDisabled:false,
            },
            ExitButton:{
              label:'Exit',
              isVisible:true,
               isDisabled:false,
            },
            BackButton:{
              label:'Back',
              isVisible:true,
               isDisabled:false,
            },
            Section1:{
              isVisible:true,
            },
            Section2:{
              isVisible:true,
            },
            Section3:{
              isVisible:true,
            },
            Section4:{
              isVisible:true,
            },
          }
        }
    });
  }
};
</script>