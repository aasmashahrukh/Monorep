import MegaSet935 from './MegaSet/MegaSet935.vue'

function install(Vue) {
	if (install.installed) return;
	install.installed = true;

	Vue.component("MegaSet935",MegaSet935);
}

const plugin = {
	install,
};

let GlobalVue = null;
if (typeof window !== "undefined") {
	GlobalVue = window.Vue;
} else if (typeof global !== "undefined") {
	GlobalVue = global.vue;
}
if (GlobalVue) {
	GlobalVue.use(plugin);
}

MegaSet935.install = install;

export default MegaSet935;