import { createRouter, createWebHistory } from 'vue-router'

import MegaSet from '../MegaSet/MS1101Testing.vue'

const routes = [
  {
    path: '/',
    name: 'MegaSet',
    component: MegaSet
  },
]


const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
