// Megaset1101.stories.js

import Megaset1101 from "../MegaSet/MegaSet1101.vue";
import { ref } from "vue";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "Megaset1101",
  component: Megaset1101,
};

const configurationObject = {
  componentProps: {
    GoButton: {
      isVisible: true,
      isDisabled: true,
      label: 'Go',
      labelFontWeight: 'bold'
    },
    SwiftDataTable: {
      isDisabled: false,
      isVisible: true,
      tableHeight: ref('10vw'),
      tableWidth: ref(100),
      tableData: [
        {
          sno: 165928,
          date: '2024-02-20',
          type: 700,
          beneficiary: 'INDUS PLUS PVT LIM.',
          lc_no: 'L124J01694',
          swift_amend_no: 1,
          status: 'UNPROCESSED',
          amount: '27,000,00 - USD'
        }
      ],
      tableColumns: [
        {
          prop: 'sno',
          label: 'SNo.',
          align: 'center',
          columnsWidth: 5
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'type',
          label: 'Type',
          align: 'center',
          columnsWidth: 8
        },
        {
          prop: 'beneficiary',
          label: 'Beneficiary',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'lc_no',
          label: 'L/C No.',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'swift_amend_no',
          label: 'SWIFT AMEND NO.',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: 10
        }
      ]
    },
    ProgressBar: {
      textInside: true,
      strokeWidth: 16,
      percentage: 50,
      isVisible: true,
      color: 'rgb(0, 0,0)',
      label: ref(''),
      textAlign: 'center'
    },

    ProceedButton: {
      isVisible: true,
      isDisabled: true,
      label: 'Proceed',
      labelFontWeight: 'bold'
    },
    records: {
      isVisible: true,
      value: 1609
    },
    RemoveButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Remove',
      labelFontWeight: 'bold'
    },
    BackButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Back',
      labelFontWeight: 'bold'
    },
    Section1: {
      isVisible: true
    },
    section2: {
      isVisible: true
    },
    section3: {
      isVisible: true
    }
  }
};


const configurationObject1_SS_EXP_1_Set_1 = {
  componentProps: {
    GoButton: {
      isVisible: true,
      isDisabled: true,
      label: 'Go',
      labelFontWeight: 'bold'
    },
    SwiftDataTable: {
      isDisabled: false,
      isVisible: true,
      tableHeight: ref('20vw'),
      tableWidth: ref(100),
      tableData: [
        {
          sno: 165928,
          date: '2024-02-20',
          type: 700,
          beneficiary: 'INDUS PLUS PVT LIM.',
          lc_no: 'L124J01694',
          swift_amend_no: 1,
          status: 'UNPROCESSED',
          amount: '27,000,00 - USD'
        },
        {
          sno: 165929,
          date: '2024-02-20',
          type: 700,
          beneficiary: 'INTERNATIONAL PACIFIC',
          lc_no: 'LCU/01/062/8599',
          swift_amend_no: 1,
          status: 'UNPROCESSED',
          amount: '27,000,00 - USD'
        },
        {
          sno: 165979,
          date: '2024-02-22',
          type: 700,
          beneficiary: 'ISMAIL RESIGN (PVT) L..',
          lc_no: 'L124J01694',
          swift_amend_no: 1,
          status: 'UNPROCESSED',
          amount: '27,000,00 - USD'
        }
      ],
      tableColumns: [
        {
          prop: 'sno',
          label: 'SNo.',
          align: 'center',
          columnsWidth: 5
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'type',
          label: 'Type',
          align: 'center',
          columnsWidth: 8
        },
        {
          prop: 'beneficiary',
          label: 'Beneficiary',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'lc_no',
          label: 'L/C No.',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'swift_amend_no',
          label: 'SWIFT AMEND NO.',
          align: 'center',
          columnsWidth: 10
        },
      ]
    },
    ProgressBar: {
      textInside: true,
      strokeWidth: 16,
      percentage: 0,
      isVisible: true,
      color: 'rgb(0, 0,0)',
      label: ref(''),
      textAlign: 'center'
    },
    ProceedButton: {
      isVisible: true,
      isDisabled: true,
      label: 'Proceed',
      labelFontWeight: 'bold'
    },
    records: {
      isVisible: true,
      value: 7
    },
    BackButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Back',
      labelFontWeight: 'bold'
    },
    Section1: {
      isVisible: true
    },
    section2: {
      isVisible: true
    },
    section3: {
      isVisible: true
    }
  }
};

const configurationObject1_SS_EXP_1_Set_2 = {
  componentProps: {
    GoButton: {
      isVisible: true,
      isDisabled: true,
      label: 'Go',
      labelFontWeight: 'bold'
    },
    SwiftDataTable: {
      isDisabled: false,
      isVisible: true,
      tableHeight: ref('20vw'),
      tableWidth: ref(100),
      tableData: [
        {
          sno: 165928,
          date: '2024-02-20',
          type: 700,
          beneficiary: 'INDUS PLUS PVT LIM.',
          lc_no: 'L124J01694',
          swift_amend_no: 1,
          status: 'UNPROCESSED',
          amount: '27,000,00 - USD'
        },
        {
          sno: 165929,
          date: '2024-02-20',
          type: 700,
          beneficiary: 'INTERNATIONAL PACIFIC',
          lc_no: 'LCU/01/062/8599',
          swift_amend_no: 1,
          status: 'UNPROCESSED',
          amount: '27,000,00 - USD'
        },
        {
          sno: 165979,
          date: '2024-02-22',
          type: 700,
          beneficiary: 'ISMAIL RESIGN (PVT) L..',
          lc_no: 'L124J01694',
          swift_amend_no: 1,
          status: 'UNPROCESSED',
          amount: '27,000,00 - USD'
        }
      ],
      tableColumns: [
        {
          prop: 'sno',
          label: 'SNo.',
          align: 'center',
          columnsWidth: 5
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'type',
          label: 'Type',
          align: 'center',
          columnsWidth: 8
        },
        {
          prop: 'beneficiary',
          label: 'Beneficiary',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'lc_no',
          label: 'L/C No.',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'swift_amend_no',
          label: 'SWIFT AMEND NO.',
          align: 'left',
          columnsWidth: 10
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: 10
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: 10
        },
      ]
    },
    ProgressBar: {
      textInside: true,
      strokeWidth: 16,
      percentage: 0,
      isVisible: true,
      color: 'rgb(0, 0,0)',
      label: ref(''),
      textAlign: 'center'
    },
    ProceedButton: {
      isVisible: true,
      isDisabled: true,
      label: 'Proceed',
      labelFontWeight: 'bold'
    },
    records: {
      isVisible: true,
      value: 1609
    },
    BackButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Back',
      labelFontWeight: 'bold'
    },
    RemoveButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Remove',
      labelFontWeight: 'bold'
    },
    Section1: {
      isVisible: true
    },
    section2: {
      isVisible: true
    },
    section3: {
      isVisible: true
    }
  }
};

const Template = (args) => ({
  components: { Megaset1101 },
  setup() {
    return {
      args: {
        configObj: {
          componentProps: {
            GoButton: {
              isVisible: true,
              isDisabled: true,
              label: 'Go',
              labelFontWeight: 'bold'
            },
            SwiftDataTable: {
              isDisabled: false,
              isVisible: true,
              tableHeight: ref('10vw'),
              tableWidth: ref(100),
              tableData: [
                {
                  sno: 165928,
                  date: '2024-02-20',
                  type: 700,
                  beneficiary: 'INDUS PLUS PVT LIM.',
                  lc_no: 'L124J01694',
                  swift_amend_no: 1,
                  status: 'UNPROCESSED',
                  amount: '27,000,00 - USD'
                }
              ],
              tableColumns: [
                {
                  prop: 'sno',
                  label: 'SNo.',
                  align: 'center',
                  columnsWidth: 5
                },
                {
                  prop: 'date',
                  label: 'Date',
                  align: 'center',
                  columnsWidth: 10
                },
                {
                  prop: 'type',
                  label: 'Type',
                  align: 'center',
                  columnsWidth: 8
                },
                {
                  prop: 'beneficiary',
                  label: 'Beneficiary',
                  align: 'center',
                  columnsWidth: 10
                },
                {
                  prop: 'lc_no',
                  label: 'L/C No.',
                  align: 'center',
                  columnsWidth: 10
                },
                {
                  prop: 'swift_amend_no',
                  label: 'SWIFT AMEND NO.',
                  align: 'center',
                  columnsWidth: 10
                },
                {
                  prop: 'status',
                  label: 'Status',
                  align: 'center',
                  columnsWidth: 10
                },
                {
                  prop: 'amount',
                  label: 'Amount',
                  align: 'center',
                  columnsWidth: 10
                }
              ]
            },
            ProgressBar: {
              textInside: true,
              strokeWidth: 16,
              percentage: 50,
              isVisible: true,
              color: 'rgb(0, 0,0)',
              label: ref(''),
              textAlign: 'center'
            },

            ProceedButton: {
              isVisible: true,
              isDisabled: true,
              label: 'Proceed',
              labelFontWeight: 'bold'
            },
            records: {
              isVisible: true,
              value: 1609
            },
            RemoveButton: {
              isVisible: true,
              isDisabled: false,
              label: 'Remove',
              labelFontWeight: 'bold'
            },
            BackButton: {
              isVisible: true,
              isDisabled: false,
              label: 'Back',
              labelFontWeight: 'bold'
            },
            Section1: {
              isVisible: true
            },
            section2: {
              isVisible: true
            },
            section3: {
              isVisible: true
            }
          }
        }
      }
    };
  },
  template: `<Megaset1101 v-bind="args"
    />`,
  methods: {},
});

const Sets_Template = (args) => ({
  components: { Megaset1101 },
  setup() {
    return { args };
  },
  template: `<Megaset1101 v-bind="args"
    />`,
  methods: {},
});

export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };

export const SS_EXP_1_Set_1 = Sets_Template.bind({});
SS_EXP_1_Set_1.args = { configObj: configurationObject1_SS_EXP_1_Set_1 };

export const SS_EXP_1_Set_2 = Sets_Template.bind({});
SS_EXP_1_Set_2.args = { configObj: configurationObject1_SS_EXP_1_Set_2 };


