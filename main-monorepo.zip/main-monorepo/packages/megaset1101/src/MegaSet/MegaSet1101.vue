<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row>
      <el-col :lg="20" :md="20">
        <fieldset v-if="configObject.Section1 != undefined ? configObject.Section1.isVisible : false">
          <legend>Swift Messages (List Updation)</legend>
          <el-row>
            <el-col :lg="3" :md="3">
              <GenericButton
                @GenericButton-onClick="$emit('GoButton-onClick')"
                v-if="configObject.GoButton != undefined ? configObject.GoButton.isVisible : false"
                v-bind="{
                  ...GoButton,
                  ...configObject.GoButton
                }"
                name="GoButton"
                ref="RefGoButton"
              />
            </el-col>
            <el-col :lg="3" :md="3"></el-col>
            <el-col :lg="16" :md="16">
              <!-- <el-progress style="width: 100%" :text-inside="true"> 25% </el-progress> -->
              <el-progress
                :text-inside="configObject.ProgressBar.textInside ? configObject.ProgressBar.textInside : ProgressBar.textInside"
                :stroke-width="configObject.ProgressBar.strokeWidth ? configObject.ProgressBar.strokeWidth : ProgressBar.strokeWidth"
                :percentage="configObject.ProgressBar.percentage ? configObject.ProgressBar.percentage : ProgressBar.percentage"
                :color="configObject.ProgressBar.color ? configObject.ProgressBar.color : ProgressBar.color"
                v-if="configObject.ProgressBar != undefined ? configObject.ProgressBar.isVisible : false"
              ></el-progress>
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
          </el-row>
          <br />
        </fieldset>
      </el-col>
      <el-col :lg="4" :md="4"></el-col>
    </el-row>
    <br />
    <el-row>
      <el-col :lg="20" :md="20">
        <legend>Swift Messages Received</legend>
        <el-row>
          <el-col :lg="24" :md="24">
            <GenericSortableTableView
              @GenericSortableTableView-onCurrentRow="
                (val) => {
                  $emit('SwiftDataTable-onCurrentRow', val);
                }
              "
              @GenericSortableTableView-onClickRow="
                (val) => {
                  $emit('SwiftDataTable-onClickRow', val);
                }
              "
              @GenericSortableTableView-onDoubleClickRow="
                (val) => {
                  $emit('SwiftDataTable-onDoubleClickRow', val);
                }
              "
              ref="RefSwiftDataTable"
              v-bind="{ ...SwiftDataTable, ...configObject.SwiftDataTable }"
              name="SwiftDataTable"
              v-if="configObject.SwiftDataTable != undefined ? configObject.SwiftDataTable.isVisible : false"
            />
          </el-col>
        </el-row>
      </el-col>
      <el-col :lg="4" :md="4"></el-col>
    </el-row>
    <el-row>
      <el-col :lg="20" :md="20">
        <fieldset>
          <el-row>
            <el-col :lg="3" :md="3">
              <GenericButton
                @GenericButton-onClick="$emit('ProceedButton-onClick')"
                v-if="configObject.ProceedButton != undefined ? configObject.ProceedButton.isVisible : false"
                v-bind="{
                  ...ProceedButton,
                  ...configObject.ProceedButton
                }"
                name="ProceedButton"
                ref="RefProceedButton"
              />
            </el-col>
            <el-col :lg="1" :md="1"></el-col>
            <el-col :lg="8" :md="8">
              <legend v-if="configObject.records != undefined ? configObject.records.value : false">
                No. of Records :{{ configObject.records.value }}
              </legend>
            </el-col>
            <el-col :lg="3" :md="3">
              <GenericButton
                @GenericButton-onClick="$emit('RemoveButton-onClick')"
                v-if="configObject.RemoveButton != undefined ? configObject.RemoveButton.isVisible : false"
                v-bind="{
                  ...RemoveButton,
                  ...configObject.RemoveButton
                }"
                name="RemoveButton"
                ref="RefRemoveButton"
              />
            </el-col>
            <el-col :lg="6" :md="6"></el-col>
            <el-col :lg="3" :md="3">
              <GenericButton
                @GenericButton-onClick="$emit('BackButton-onClick')"
                v-if="configObject.BackButton != undefined ? configObject.BackButton.isVisible : false"
                v-bind="{
                  ...BackButton,
                  ...configObject.BackButton
                }"
                name="BackButton"
                ref="RefBackButton"
              />
            </el-col>
          </el-row>
        </fieldset>
      </el-col>
      <el-col :lg="4" :md="4"></el-col>
    </el-row>
  </Form>
</template>

<script>
import { reactive } from 'vue';
import { Form, useForm } from 'vee-validate';
import { GenericButton, GenericSortableTableView } from '@teresol-v2/ui-components';
export default {
  name: 'Megaset1101',
  components: {
    Form,
    GenericButton,
    GenericSortableTableView
  },
  props: {
    //Add configuration object details
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }

    const configObject = reactive(props.configObj.componentProps);

    return {
      onSubmit,
      configObject,
      GoButton: {
        spanInputs: 24, // this property to be set on screen level
        nativeType: 'button' // this property to be set on screen level
      },
      SwiftDataTable: {
        spanInputs: 24,
        spanLabels: 0
      },
      ProgressBar: {
        textInside: true,
        strokeWidth: 16,
        percentage: 0,
        color: 'rgb(0, 0, 0)',
        textAlign: 'center'
      },
      ProceedButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      RemoveButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      BackButton: {
        spanInputs: 24,
        nativeType: 'button'
      }
    };
  }
};
</script>

