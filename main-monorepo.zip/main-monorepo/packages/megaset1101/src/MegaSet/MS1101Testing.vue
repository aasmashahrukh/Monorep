<template>
  <Megaset1101 :configObj="configurationObject" />
</template>
<script>
import Megaset1101 from './MegaSet1101.vue';
import { reactive, ref } from 'vue';
export default {
  components: {
    Megaset1101
  },
  methods: {},
  setup() {
    return reactive({
      configurationObject: {
        componentProps: {
          GoButton: {
            isVisible: true,
            isDisabled: true,
            label: 'Go',
            labelFontWeight: 'bold'
          },
          SwiftDataTable: {
            isDisabled: false,
            isVisible: true,
            tableHeight: ref('10vw'),
            tableWidth: ref(100),
            tableData: [
              {
                sno: 165928,
                date: '2024-02-20',
                type: 700,
                beneficiary: 'INDUS PLUS PVT LIM.',
                lc_no: 'L124J01694',
                swift_amend_no: 1,
                status: 'UNPROCESSED',
                amount: '27,000,00 - USD'
              }
            ],
            tableColumns: [
              {
                prop: 'sno',
                label: 'SNo.',
                align: 'center',
                columnsWidth: 5
              },
              {
                prop: 'date',
                label: 'Date',
                align: 'center',
                columnsWidth: 10
              },
              {
                prop: 'type',
                label: 'Type',
                align: 'center',
                columnsWidth: 8
              },
              {
                prop: 'beneficiary',
                label: 'Beneficiary',
                align: 'center',
                columnsWidth: 10
              },
              {
                prop: 'lc_no',
                label: 'L/C No.',
                align: 'center',
                columnsWidth: 10
              },
              {
                prop: 'swift_amend_no',
                label: 'SWIFT AMEND NO.',
                align: 'center',
                columnsWidth: 10
              },
              {
                prop: 'status',
                label: 'Status',
                align: 'center',
                columnsWidth: 10
              },
              {
                prop: 'amount',
                label: 'Amount',
                align: 'center',
                columnsWidth: 10
              }
            ]
          },
          ProgressBar: {
            textInside: true,
            strokeWidth: 16,
            percentage: 50,
            isVisible: true,
            color: 'rgb(0, 0,0)',
            label: ref(''),
            textAlign: 'center'
          },

          ProceedButton: {
            isVisible: true,
            isDisabled: true,
            label: 'Proceed',
            labelFontWeight: 'bold'
          },
          records: {
            isVisible: true,
            value: 1609
          },
          RemoveButton: {
            isVisible: true,
            isDisabled: false,
            label: 'Remove',
            labelFontWeight: 'bold'
          },
          BackButton: {
            isVisible: true,
            isDisabled: false,
            label: 'Back',
            labelFontWeight: 'bold'
          },
          Section1: {
            isVisible: true
          },
          section2: {
            isVisible: true
          },
          section3: {
            isVisible: true
          }
        }
      }
    });
  }
};
</script>
