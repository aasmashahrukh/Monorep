<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row>
      <el-col :md="24" :lg="24">
        <el-tabs v-model="configObject.TabPane.activeName" type="card" @update:model-value="($event) => $emit('handleTabClick', $event)">
          <el-tab-pane :label="configObject.BillInfoTab.label" name="BillInfoTab">
            <el-row>
              <el-col :md="24" :lg="24">
                <fieldset v-if="configObject.Section4 != undefined ? configObject.Section4.isVisible : false">
                  <el-row>
                    <el-col :md="5" :lg="7">
                      <DateDdMmYyyy
                        @DateDdMmYyyy-onBlur="
                          (val) => {
                            $emit('DateTextBox-onBlur', val);
                          }
                        "
                        @DateDdMmYyyy-onChange="
                          (val) => {
                            $emit('DateTextBox-onChange', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyPress="
                          (val) => {
                            $emit('DateTextBox-onKeyPress', val);
                          }
                        "
                        @DateDdMmYyyy-onKeyUp="
                          (val) => {
                            $emit('DateTextBox-onKeyUp', val);
                          }
                        "
                        @DateDdMmYyyy-onFocus="
                          (val) => {
                            $emit('DateTextBox-onFocus', val);
                          }
                        "
                        v-bind="{ ...DateTextBox, ...configObject.DateTextBox }"
                        name="DateTextBox"
                        ref="RefDateTextBox"
                        :values="configObject.DateTextBox.DateTextBoxValue"
                        v-if="configObject.DateTextBox != undefined ? configObject.DateTextBox.isVisible : false"
                      />
                    </el-col>
                    <el-col :lg="8" :md="8">
                      <GenericDatePicker
                        @GenericDatePicker-onBlur="
                          (val) => {
                            $emit('CertificationDateTextBox-onBlur', val);
                          }
                        "
                        name="CertificationDateTextBox"
                        ref="RefCertificationDateTextBox"
                        v-bind="{
                          ...CertificationDateTextBox,
                          ...configObject.CertificationDateTextBox
                        }"
                        :values="configObject.CertificationDateTextBox.CertificationDateTextBoxValue"
                        v-if="configObject.CertificationDateTextBox != undefined ? configObject.CertificationDateTextBox.isVisible : false"
                      >
                      </GenericDatePicker>
                    </el-col>
                    
                  </el-row>
                  <el-row>
                    <el-col :md="24" :lg="24">
                      <GenericCompositeAlphaNumericSpecialWithButton 
                        @GenericCompositeAlphaNumericSpecialWithButtonLeft-onChange="
                          (val) => {
                            $emit('AlphaNumericSpecialWithButton-onBlur', val);
                          }
                        "
                        @BrowseButton-onClick="  () => {
                            $emit('BrowseButton-onClick');
                          }"
                      :isDisabledRight="true"
                      :isDisabledLeft="true"
                      :textLabel = "configObject.AlphaNumericSpecialWithButton.label"
                      name="AlphaNumericSpecialWithButton"
                      ref="RefAlphaNumericSpecialWithButton"
                      :values="configObject.AlphaNumericSpecialWithButton.AlphaNumericSpecialWithButtonValue"
                      v-if="configObject.AlphaNumericSpecialWithButton != undefined ? configObject.AlphaNumericSpecialWithButton.isVisible : false"
                       />
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>
          </el-tab-pane>

          <el-tab-pane
            :label="configObject.InstrumentInfoTab.label"
            v-if="configObject.InstrumentInfoTab != undefined ? configObject.InstrumentInfoTab.isVisible : false"
            name="InstrumentInfo"
          >
            <el-row>
              <el-col :md="24" :lg="24">
                <fieldset v-if="configObject.Section14 != undefined ? configObject.Section14.isVisible : false">
                  <el-row>
                    <el-col :md="10" :lg="10">
                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('BillAmountTextBox2-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('BillAmountTextBox2-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('BillAmountTextBox2-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...BillAmountTextBox2,
                          ...configObject.BillAmountTextBox2
                        }"
                        name="BillAmountTextBox2"
                        ref="RefBillAmountTextBox2"
                        :values="configObject.BillAmountTextBox2.BillAmountTextBox2Value"
                        v-if="configObject.BillAmountTextBox2 != undefined ? configObject.BillAmountTextBox2.isVisible : false"
                      />
                    </el-col>
                    <el-col :md="4" :lg="4"></el-col>
                    <el-col :md="10" :lg="10">
                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('BalanceAmountTextBox2-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('BalanceAmountTextBox2-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('BalanceAmountTextBox2-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...BalanceAmountTextBox2,
                          ...configObject.BalanceAmountTextBox2
                        }"
                        name="BalanceAmountTextBox2"
                        ref="RefBalanceAmountTextBox2"
                        :values="configObject.BalanceAmountTextBox2.BalanceAmountTextBox2Value"
                        v-if="configObject.BalanceAmountTextBox2 != undefined ? configObject.BalanceAmountTextBox2.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :md="10" :lg="10">
                      <AmountNumericDecimal15Point2
                        @AmountNumericDecimal15Point2-onBlur="
                          (val) => {
                            $emit('InstrumentBalAmountTextBox-onBlur', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onKeyPress="
                          (val) => {
                            $emit('InstrumentBalAmountTextBox-onKeyPress', val);
                          }
                        "
                        @AmountNumericDecimal15Point2-onFocus="
                          (val) => {
                            $emit('InstrumentBalAmountTextBox-onFocus', val);
                          }
                        "
                        v-bind="{
                          ...InstrumentBalAmountTextBox,
                          ...configObject.InstrumentBalAmountTextBox
                        }"
                        name="InstrumentBalAmountTextBox"
                        ref="RefInstrumentBalAmountTextBox"
                        :values="configObject.InstrumentBalAmountTextBox.InstrumentBalAmountTextBoxValue"
                        v-if="configObject.InstrumentBalAmountTextBox != undefined ? configObject.InstrumentBalAmountTextBox.isVisible : false"
                      />
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :md="24" :lg="24">
                      <fieldset
                        v-if="configObject.InstrumentInformationSection != undefined ? configObject.InstrumentInformationSection.isVisible : false"
                      >
                        <legend>Instrument Info</legend>
                        <el-row>
                          <el-col :md="3" :lg="3"></el-col>
                          <el-col :md="4" :lg="4">
                            <GenericRadioButton
                              @GenericRadioButton-onChange="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onChange', val);
                                }
                              "
                              @GenericRadioButton-onClick="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onClick', val);
                                }
                              "
                              @GenericRadioButton-onFocus="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onFocus', val);
                                }
                              "
                              name="SBPChequeDDPORadioButton"
                              ref="RefSBPChequeDDPORadioButton"
                              v-bind="{ ...SBPChequeDDPORadioButton, ...configObject.SBPChequeDDPORadioButton }"
                              :values="configObject.SBPChequeDDPORadioButton.SBPChequeDDPORadioButtonValue"
                              v-if="configObject.SBPChequeDDPORadioButton != undefined ? configObject.SBPChequeDDPORadioButton.isVisible : false"
                              :radioGroup="configObject.SBPChequeDDPORadioButton.list1"
                            />
                          </el-col>
                          <el-col :md="3" :lg="3"></el-col>

                          <el-col :md="4" :lg="4">
                            <GenericRadioButton
                              @GenericRadioButton-onChange="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onChange', val);
                                }
                              "
                              @GenericRadioButton-onClick="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onClick', val);
                                }
                              "
                              @GenericRadioButton-onFocus="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onFocus', val);
                                }
                              "
                              name="SBPChequeDDPORadioButton"
                              ref="RefSBPChequeDDPORadioButton"
                              v-bind="{ ...SBPChequeDDPORadioButton, ...configObject.SBPChequeDDPORadioButton }"
                              :values="configObject.SBPChequeDDPORadioButton.SBPChequeDDPORadioButtonValue"
                              v-if="configObject.SBPChequeDDPORadioButton != undefined ? configObject.SBPChequeDDPORadioButton.isVisible : false"
                              :radioGroup="configObject.SBPChequeDDPORadioButton.list2"
                            />
                          </el-col>
                          <el-col :md="3" :lg="3"></el-col>

                          <el-col :md="4" :lg="4">
                            <GenericRadioButton
                              @GenericRadioButton-onChange="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onChange', val);
                                }
                              "
                              @GenericRadioButton-onClick="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onClick', val);
                                }
                              "
                              @GenericRadioButton-onFocus="
                                (val) => {
                                  $emit('SBPChequeDDPORadioButton-onFocus', val);
                                }
                              "
                              name="SBPChequeDDPORadioButton"
                              ref="RefSBPChequeDDPORadioButton"
                              v-bind="{ ...SBPChequeDDPORadioButton, ...configObject.SBPChequeDDPORadioButton }"
                              :values="configObject.SBPChequeDDPORadioButton.SBPChequeDDPORadioButtonValue"
                              v-if="configObject.SBPChequeDDPORadioButton != undefined ? configObject.SBPChequeDDPORadioButton.isVisible : false"
                              :radioGroup="configObject.SBPChequeDDPORadioButton.list3"
                            />
                          </el-col>
                        </el-row>
                        <el-row>
                          <el-col :md="8" :lg="8"></el-col>
                          <el-col :md="9" :lg="9">
                            <GenericTextBox
                              @GenericTextBox-onBlur="
                                (val) => {
                                  $emit('InstTypeTextBox-onBlur', val);
                                }
                              "
                              @GenericTextBox-onChange="
                                (val) => {
                                  $emit('InstTypeTextBox-onChange', val);
                                }
                              "
                              @GenericTextBox-onKeyPress="
                                (val, event) => {
                                  $emit('InstTypeTextBox-onKeyPress', val, event);
                                }
                              "
                              @GenericTextBox-onKeyUp="
                                (val) => {
                                  $emit('InstTypeTextBox-onKeyUp', val);
                                }
                              "
                              @GenericTextBox-onFocus="
                                (val) => {
                                  $emit('InstTypeTextBox-onFocus', val);
                                }
                              "
                              v-bind="{
                                ...InstTypeTextBox,
                                ...configObject.InstTypeTextBox
                              }"
                              name="InstTypeTextBox"
                              ref="RefInstTypeTextBox"
                              :values="configObject.InstTypeTextBox.InstTypeTextBoxValue"
                              v-if="configObject.InstTypeTextBox != undefined ? configObject.InstTypeTextBox.isVisible : false"
                            />
                          </el-col>
                        </el-row>
                        <el-row>
                          <el-col :md="6" :lg="6">
                            <GenericTextBox
                              @GenericTextBox-onBlur="
                                (val) => {
                                  $emit('InstNoTextBox-onBlur', val);
                                }
                              "
                              @GenericTextBox-onChange="
                                (val) => {
                                  $emit('InstNoTextBox-onChange', val);
                                }
                              "
                              @GenericTextBox-onKeyPress="
                                (val, event) => {
                                  $emit('InstNoTextBox-onKeyPress', val, event);
                                }
                              "
                              @GenericTextBox-onKeyUp="
                                (val) => {
                                  $emit('InstNoTextBox-onKeyUp', val);
                                }
                              "
                              @GenericTextBox-onFocus="
                                (val) => {
                                  $emit('InstNoTextBox-onFocus', val);
                                }
                              "
                              v-bind="{
                                ...InstNoTextBox,
                                ...configObject.InstNoTextBox
                              }"
                              name="InstNoTextBox"
                              ref="RefInstNoTextBox"
                              :values="configObject.InstNoTextBox.InstNoTextBoxValue"
                              v-if="configObject.InstNoTextBox != undefined ? configObject.InstNoTextBox.isVisible : false"
                            />
                          </el-col>
                          <el-col :md="2" :lg="2"></el-col>
                          <el-col :md="9" :lg="9">
                            <AmountNumericDecimal15Point2
                              @AmountNumericDecimal15Point2-onBlur="
                                (val) => {
                                  $emit('InstAmountTextBox-onBlur', val);
                                }
                              "
                              @AmountNumericDecimal15Point2-onKeyPress="
                                (val) => {
                                  $emit('InstAmountTextBox-onKeyPress', val);
                                }
                              "
                              @AmountNumericDecimal15Point2-onFocus="
                                (val) => {
                                  $emit('InstAmountTextBox-onFocus', val);
                                }
                              "
                              v-bind="{
                                ...InstAmountTextBox,
                                ...configObject.InstAmountTextBox
                              }"
                              name="InstAmountTextBox"
                              ref="RefInstAmountTextBox"
                              :values="configObject.InstAmountTextBox.InstAmountTextBoxValue"
                              v-if="configObject.InstAmountTextBox != undefined ? configObject.InstAmountTextBox.isVisible : false"
                            />
                          </el-col>
                          <el-col :md="1" :lg="1"></el-col>
                          <el-col :md="6" :lg="6">
                            <DateDdMmYyyy
                              @DateDdMmYyyy-onBlur="
                                (val) => {
                                  $emit('InstDateTextBox-onBlur', val);
                                }
                              "
                              @DateDdMmYyyy-onChange="
                                (val) => {
                                  $emit('InstDateTextBox-onChange', val);
                                }
                              "
                              @DateDdMmYyyy-onKeyUp="
                                (val) => {
                                  $emit('InstDateTextBox-onKeyUp', val);
                                }
                              "
                              @DateDdMmYyyy-onKeyPress="
                                (val) => {
                                  $emit('InstDateTextBox-onKeyPress', val);
                                }
                              "
                              @DateDdMmYyyy-onFocus="
                                (val) => {
                                  $emit('InstDateTextBox-onFocus', val);
                                }
                              "
                              name="InstDateTextBox"
                              ref="RefInstDateTextBox"
                              v-bind="{ ...InstDateTextBox, ...configObject.InstDateTextBox }"
                              :values="configObject.InstDateTextBox.InstDateTextBoxValue"
                              v-if="configObject.InstDateTextBox != undefined ? configObject.InstDateTextBox.isVisible : false"
                            />
                          </el-col>
                        </el-row>
                      </fieldset>
                    </el-col>
                  </el-row>
                </fieldset>
              </el-col>
            </el-row>
          </el-tab-pane>
        </el-tabs>
      </el-col>
    </el-row>

    <!-- <el-row>
      <el-col :lg="24" :md="24">
        <el-tabs v-model="activeName" type="card" class="demo-tabs" @tab-click="$emit('handleTabClick')">
          <el-tab-pane v-if="configObject.PersonalInfo.isVisible" :disabled="configObject.PersonalInfo.isDisabled" label="Personal Info" name="first">
            <fieldset>
              <el-row>
                <el-col :lg="9" :md="9">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('IdDocTypeDropDown-onChange', val) }"
                    v-bind="{ ...IdDocTypeDropDown, ...configObject.IdDocTypeDropDown }"
                    v-if="configObject.IdDocTypeDropDown.isVisible"
                    :defaultValue="configObject.IdDocTypeDropDown.idDocTypeValue"
                    :values="configObject.IdDocTypeDropDown.list" name="IdDocTypeDropDown" ref="refIdDocTypeDropDown" />
                </el-col>
                <el-col :lg="1" :md="1"></el-col>
                <el-col :lg="9" :md="9">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('IdDocNoTextBox-onBlur', val) }"
                    v-bind="{ ...IdDocNoTextBox, ...configObject.IdDocNoTextBox }"
                    v-if="configObject.IdDocNoTextBox.isVisible" :values="configObject.IdDocNoTextBox.idDocNumberValue"
                    name="IdDocNoTextBox" ref="refIdDocNoTextBox" />
                </el-col>
                <el-col :lg="5" :md="5"></el-col>
              </el-row>
            </fieldset>
            <fieldset>
              <fieldset>
                <el-row>
                  <el-col :lg="9" :md="9">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('IdDocTypeDropDown1-onChange', val) }"
                      v-bind="{ ...IdDocTypeDropDown1, ...configObject.IdDocTypeDropDown1 }"
                      v-if="configObject.IdDocTypeDropDown1.isVisible"
                      :defaultValue="configObject.IdDocTypeDropDown1.idDocTypeValue1"
                      :values="configObject.IdDocTypeDropDown1.list" name="IdDocTypeDropDown1"
                      ref="refIdDocTypeDropDown1" />
                  </el-col>
                  <el-col :lg="3" :md="3"></el-col>
                  <el-col :lg="9" :md="9">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('IdDocNoTextBox1-onBlur', val) }"
                      v-bind="{ ...IdDocNoTextBox1, ...configObject.IdDocNoTextBox1 }"
                      v-if="configObject.IdDocNoTextBox1.isVisible"
                      :values="configObject.IdDocNoTextBox1.idDocNumberValue1" name="IdDocNoTextBox1"
                      ref="refIdDocNoTextBox1" />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                </el-row>
                <el-row>
                  <el-col :lg="5" :md="5">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('CustomerNameDropDown-onChange', val) }"
                      v-bind="{ ...CustomerNameDropDown, ...configObject.CustomerNameDropDown }"
                      v-if="configObject.CustomerNameDropDown.isVisible"
                      :defaultValue="configObject.CustomerNameDropDown.customerTitle"
                      :values="configObject.CustomerNameDropDown.list" name="CustomerNameDropDown"
                      ref="refCustomerNameDropDown" />
                  </el-col>
                  <el-col :lg="7" :md="7">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('CustomerNameTextBox-onBlur', val) }"
                      v-bind="{ ...CustomerNameTextBox, ...configObject.CustomerNameTextBox }"
                      v-if="configObject.CustomerNameTextBox.isVisible"
                      :values="configObject.CustomerNameTextBox.customerNameValue" name="CustomerNameTextBox"
                      ref="refCustomerNameTextBox" />
                  </el-col>
                  <el-col :lg="12" :md="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('MotherNameTextBox-onBlur', val) }"
                      v-bind="{ ...MotherNameTextBox, ...configObject.MotherNameTextBox }"
                      v-if="configObject.MotherNameTextBox.isVisible"
                      :values="configObject.MotherNameTextBox.motherNameValue" name="MotherNameTextBox"
                      ref="refMotherNameTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="5" :md="5">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('YoungSaverDropDown-onChange', val) }"
                      v-bind="{ ...YoungSaverDropDown, ...configObject.YoungSaverDropDown }"
                      v-if="configObject.YoungSaverDropDown.isVisible"
                      :defaultValue="configObject.YoungSaverDropDown.youngSaverTitle"
                      :values="configObject.YoungSaverDropDown.list" name="YoungSaverDropDown"
                      ref="refYoungSaverDropDown" />
                  </el-col>
                  <el-col :lg="7" :md="7">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('YoungSaverTextBox-onBlur', val) }"
                      v-bind="{ ...YoungSaverTextBox, ...configObject.YoungSaverTextBox }"
                      v-if="configObject.YoungSaverTextBox.isVisible"
                      :values="configObject.YoungSaverTextBox.YoungSaverNameValue" name="YoungSaverTextBox"
                      ref="refYoungSaverTextBox" />
                  </el-col>
                  <el-col :lg="12" :md="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('MartialStatusTextBox-onBlur', val) }"
                      v-bind="{ ...MartialStatusTextBox, ...configObject.MartialStatusTextBox }"
                      v-if="configObject.MartialStatusTextBox.isVisible"
                      :values="configObject.MartialStatusTextBox.martialStatusValue" name="MartialStatusTextBox"
                      ref="refMartialStatusTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="12" :md="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('FatherHusbandNameTextBox-onBlur', val) }"
                      v-bind="{ ...FatherHusbandNameTextBox, ...configObject.FatherHusbandNameTextBox }"
                      v-if="configObject.FatherHusbandNameTextBox.isVisible"
                      :values="configObject.FatherHusbandNameTextBox.fatherHusbandNameValue"
                      name="FatherHusbandNameTextBox" ref="refFatherHusbandNameTextBox" />
                  </el-col>
                  <el-col :lg="12" :md="12">
                    <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('DOBTextBox-onBlur', val) }"
                      v-bind="{ ...DOBTextBox, ...configObject.DOBTextBox }" v-if="configObject.DOBTextBox.isVisible"
                      :values="configObject.DOBTextBox.dobValue" name="DOBTextBox" ref="DOBTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="12" :md="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('QualificationDropDown-onChange', val) }"
                      v-bind="{ ...QualificationDropDown, ...configObject.QualificationDropDown }"
                      v-if="configObject.QualificationDropDown.isVisible"
                      :defaultValue="configObject.QualificationDropDown.qualificationValue"
                      :values="configObject.QualificationDropDown.list" name="QualificationDropDown"
                      ref="refQualificationDropDown" />
                  </el-col>
                </el-row>
              </fieldset>
              <fieldset>
                <el-row>
                  <el-col :lg="10" :md="10">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('NationalityDropDown-onChange', val) }"
                      v-bind="{ ...NationalityDropDown, ...configObject.NationalityDropDown }"
                      v-if="configObject.NationalityDropDown.isVisible"
                      :defaultValue="configObject.NationalityDropDown.nationalityValue"
                      :values="configObject.NationalityDropDown.list" name="NationalityDropDown"
                      ref="refNationalityDropDown" />
                  </el-col>
                  <el-col :lg="1" :md="1"></el-col>
                  <el-col :lg="4" :md="4">
                    <GenericCheckBox
                      @GenericCheckBox-onChange="(val) => { $emit('OtherNationalityCheckBox-onChange', val) }"
                      v-bind="{ ...OtherNationalityCheckBox, ...configObject.OtherNationalityCheckBox }"
                      v-if="configObject.OtherNationalityCheckBox.isVisible"
                      :values="configObject.OtherNationalityCheckBox.otherNationalityValue"
                      name="OtherNationalityCheckBox" ref="refOtherNationalityCheckBox" />
                  </el-col>
                  <el-col :lg="3" :md="3">
                    <GenericButton @GenericButton-onClick="$emit('AddViewButton-onClick')" name="AddViewButton"
                      ref="refAddViewButton" v-bind="{ ...AddViewButton, ...configObject.AddViewButton }"
                      v-if="configObject.AddViewButton.isVisible" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :lg="10" :md="10">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('OccupationDropDown-onChange', val) }"
                      v-bind="{ ...OccupationDropDown, ...configObject.OccupationDropDown }"
                      v-if="configObject.OccupationDropDown.isVisible"
                      :defaultValue="configObject.OccupationDropDown.occupationValue"
                      :values="configObject.OccupationDropDown.list" name="OccupationDropDown"
                      ref="refOccupationDropDown" />
                  </el-col>
                  <el-col :md="2" :lg="2"></el-col>
                  <el-col :md="12" :lg="12">
                    <CnicNumberNumericDashes15
                      @CnicNumberNumericDashes15-onBlur="(val) => { $emit('NatTaxNoTextBox-onBlur', val) }"
                      v-bind="{ ...NatTaxNoTextBox, ...configObject.NatTaxNoTextBox }"
                      v-if="configObject.NatTaxNoTextBox.isVisible" :values="configObject.NatTaxNoTextBox.natTaxNoValue"
                      name="NatTaxNoTextBox" ref="refNatTaxNoTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="10" :lg="10">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('BirthCertificateNoTextBox-onBlur', val) }"
                      v-bind="{ ...BirthCertificateNoTextBox, ...configObject.BirthCertificateNoTextBox }"
                      v-if="configObject.BirthCertificateNoTextBox.isVisible"
                      :values="configObject.BirthCertificateNoTextBox.birthCertNoValue" name="BirthCertificateNoTextBox"
                      ref="refBirthCertificateNoTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="10" :lg="10">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('STNNoTextBox-onBlur', val) }"
                      v-bind="{ ...STNNoTextBox, ...configObject.STNNoTextBox }"
                      v-if="configObject.STNNoTextBox.isVisible" :values="configObject.STNNoTextBox.stnNoValue"
                      name="STNNoTextBox" ref="refSTNNoTextBox" />
                  </el-col>
                </el-row>
              </fieldset>
              <label v-if="configObject.EISection.isVisible" style="color: blue; font-weight: bold;">Employer
                Information</label>
              <fieldset v-if="configObject.EISection.isVisible">
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SINameOfEmployerTextBox-onBlur', val) }"
                      v-bind="{ ...SINameOfEmployerTextBox, ...configObject.SINameOfEmployerTextBox }"
                      v-if="configObject.SINameOfEmployerTextBox.isVisible"
                      :values="configObject.SINameOfEmployerTextBox.nameOfEmployerValue" name="SINameOfEmployerTextBox"
                      ref="refSINameOfEmployerTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SIJobTitleTextBox-onBlur', val) }"
                      v-bind="{ ...SIJobTitleTextBox, ...configObject.SIJobTitleTextBox }"
                      v-if="configObject.SIJobTitleTextBox.isVisible"
                      :values="configObject.SIJobTitleTextBox.jobTitleValue" name="SIJobTitleTextBox"
                      ref="refSIJobTitleTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SIEmployerAddressTextBox-onBlur', val) }"
                      v-bind="{ ...SIEmployerAddressTextBox, ...configObject.SIEmployerAddressTextBox }"
                      v-if="configObject.SIEmployerAddressTextBox.isVisible"
                      :values="configObject.SIEmployerAddressTextBox.employerAddressValue" name="SIEmployerAddressTextBox"
                      ref="refSIEmployerAddressTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('SICountryDropDown-onChange', val) }"
                      v-bind="{ ...SICountryDropDown, ...configObject.SICountryDropDown }"
                      v-if="configObject.SICountryDropDown.isVisible"
                      :defaultValue="configObject.SICountryDropDown.countryValue"
                      :values="configObject.SICountryDropDown.list" name="SICountryDropDown" ref="refSICountryDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SISLANameTextBox-onBlur', val) }"
                      v-bind="{ ...SISLANameTextBox, ...configObject.SISLANameTextBox }"
                      v-if="configObject.SISLANameTextBox.isVisible" :values="configObject.SISLANameTextBox.slaNameValue"
                      name="SISLANameTextBox" ref="refSISLANameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('SICityDropDown-onChange', val) }"
                      v-bind="{ ...SICityDropDown, ...configObject.SICityDropDown }"
                      v-if="configObject.SICityDropDown.isVisible" :defaultValue="configObject.SICityDropDown.cityValue"
                      :values="configObject.SICityDropDown.list" name="SICityDropDown" ref="refSICityDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SIATVNameTextBox-onBlur', val) }"
                      v-bind="{ ...SIATVNameTextBox, ...configObject.SIATVNameTextBox }"
                      v-if="configObject.SIATVNameTextBox.isVisible" :values="configObject.SIATVNameTextBox.atvNameValue"
                      name="SIATVNameTextBox" ref="refSIATVNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SIProvinceTextBox-onBlur', val) }"
                      v-bind="{ ...SIProvinceTextBox, ...configObject.SIProvinceTextBox }"
                      v-if="configObject.SIProvinceTextBox.isVisible"
                      :values="configObject.SIProvinceTextBox.provinceValue" name="SIProvinceTextBox"
                      ref="refSIProvinceTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SIPostalCodeTextBox-onBlur', val) }"
                      v-bind="{ ...SIPostalCodeTextBox, ...configObject.SIPostalCodeTextBox }"
                      v-if="configObject.SIPostalCodeTextBox.isVisible"
                      :values="configObject.SIPostalCodeTextBox.postalCodeValue" name="SIPostalCodeTextBox"
                      ref="refSIPostalCodeTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('SIDistrictDropDown-onChange', val) }"
                      v-bind="{ ...SIDistrictDropDown, ...configObject.SIDistrictDropDown }"
                      v-if="configObject.SIDistrictDropDown.isVisible"
                      :defaultValue="configObject.SIDistrictDropDown.districtValue"
                      :values="configObject.SIDistrictDropDown.list" name="SIDistrictDropDown"
                      ref="refSIDistrictDropDown" />
                  </el-col>
                </el-row>
              </fieldset>
              <label v-if="configObject.BISection.isVisible" style="color: blue; font-weight: bold;">Business
                Information</label>
              <fieldset v-if="configObject.BISection.isVisible">
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('BINameOfBusinessTextBox-onBlur', val) }"
                      v-bind="{ ...BINameOfBusinessTextBox, ...configObject.BINameOfBusinessTextBox }"
                      v-if="configObject.BINameOfBusinessTextBox.isVisible"
                      :values="configObject.BINameOfBusinessTextBox.nameOfBusinessValue" name="BINameOfBusinessTextBox"
                      ref="refBINameOfBusinessTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('BIJobTitleTextBox-onBlur', val) }"
                      v-bind="{ ...BIJobTitleTextBox, ...configObject.BIJobTitleTextBox }"
                      v-if="configObject.BIJobTitleTextBox.isVisible"
                      :values="configObject.BIJobTitleTextBox.jobTitleValue" name="BIJobTitleTextBox"
                      ref="refBIJobTitleTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('BIBusinessAddressTextBox-onBlur', val) }"
                      v-bind="{ ...BIBusinessAddressTextBox, ...configObject.BIBusinessAddressTextBox }"
                      v-if="configObject.BIBusinessAddressTextBox.isVisible"
                      :values="configObject.BIBusinessAddressTextBox.businessAddressValue" name="BIBusinessAddressTextBox"
                      ref="refBIBusinessAddressTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('BICountryDropDown-onChange', val) }"
                      v-bind="{ ...BICountryDropDown, ...configObject.BICountryDropDown }"
                      v-if="configObject.BICountryDropDown.isVisible"
                      :defaultValue="configObject.BICountryDropDown.countryValue"
                      :values="configObject.BICountryDropDown.list" name="BICountryDropDown" ref="refBICountryDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('BISLANameTextBox-onBlur', val) }"
                      v-bind="{ ...BISLANameTextBox, ...configObject.BISLANameTextBox }"
                      v-if="configObject.BISLANameTextBox.isVisible" :values="configObject.BISLANameTextBox.slaNameValue"
                      name="BISLANameTextBox" ref="refBISLANameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('BICityDropDown-onChange', val) }"
                      v-bind="{ ...BICityDropDown, ...configObject.BICityDropDown }"
                      v-if="configObject.BICityDropDown.isVisible" :defaultValue="configObject.BICityDropDown.cityValue"
                      :values="configObject.BICityDropDown.list" name="BICityDropDown" ref="refBICityDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('BIATVNameTextBox-onBlur', val) }"
                      v-bind="{ ...BIATVNameTextBox, ...configObject.BIATVNameTextBox }"
                      v-if="configObject.BIATVNameTextBox.isVisible" :values="configObject.BIATVNameTextBox.atvNameValue"
                      name="BIATVNameTextBox" ref="refBIATVNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('BIProvinceTextBox-onBlur', val) }"
                      v-bind="{ ...BIProvinceTextBox, ...configObject.BIProvinceTextBox }"
                      v-if="configObject.BIProvinceTextBox.isVisible"
                      :values="configObject.BIProvinceTextBox.provinceValue" name="BIProvinceTextBox"
                      ref="refBIProvinceTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('BIPostalCodeTextBox-onBlur', val) }"
                      v-bind="{ ...BIPostalCodeTextBox, ...configObject.BIPostalCodeTextBox }"
                      v-if="configObject.BIPostalCodeTextBox.isVisible"
                      :values="configObject.BIPostalCodeTextBox.postalCodeValue" name="BIPostalCodeTextBox"
                      ref="refBIPostalCodeTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('BIDistrictDropDown-onChange', val) }"
                      v-bind="{ ...BIDistrictDropDown, ...configObject.BIDistrictDropDown }"
                      v-if="configObject.BIDistrictDropDown.isVisible"
                      :defaultValue="configObject.BIDistrictDropDown.districtValue"
                      :values="configObject.BIDistrictDropDown.list" name="BIDistrictDropDown"
                      ref="refBIDistrictDropDown" />
                  </el-col>
                </el-row>
              </fieldset>
              <label v-if="configObject.SDSection.isVisible" style="color: blue; font-weight: bold;">Student
                Details</label>
              <fieldset v-if="configObject.SDSection.isVisible">
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SDNameOfStudentTextBox-onBlur', val) }"
                      v-bind="{ ...SDNameOfStudentTextBox, ...configObject.SDNameOfStudentTextBox }"
                      v-if="configObject.SDNameOfStudentTextBox.isVisible"
                      :values="configObject.SDNameOfStudentTextBox.nameOfStudentValue" name="SDNameOfStudentTextBox"
                      ref="refSDNameOfStudentTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SDJobTitleTextBox-onBlur', val) }"
                      v-bind="{ ...SDJobTitleTextBox, ...configObject.SDJobTitleTextBox }"
                      v-if="configObject.SDJobTitleTextBox.isVisible"
                      :values="configObject.SDJobTitleTextBox.jobTitleValue" name="SDJobTitleTextBox"
                      ref="refSDJobTitleTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SDStudentAddressTextBox-onBlur', val) }"
                      v-bind="{ ...SDStudentAddressTextBox, ...configObject.SDStudentAddressTextBox }"
                      v-if="configObject.SDStudentAddressTextBox.isVisible"
                      :values="configObject.SDStudentAddressTextBox.studentAddressValue" name="SDStudentAddressTextBox"
                      ref="refSDStudentAddressTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('SDCountryDropDown-onChange', val) }"
                      v-bind="{ ...SDCountryDropDown, ...configObject.SDCountryDropDown }"
                      v-if="configObject.SDCountryDropDown.isVisible"
                      :defaultValue="configObject.SDCountryDropDown.countryValue"
                      :values="configObject.SDCountryDropDown.list" name="SDCountryDropDown" ref="refSDCountryDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SDSLANameTextBox-onBlur', val) }"
                      v-bind="{ ...SDSLANameTextBox, ...configObject.SDSLANameTextBox }"
                      v-if="configObject.SDSLANameTextBox.isVisible" :values="configObject.SDSLANameTextBox.slaNameValue"
                      name="SDSLANameTextBox" ref="refSDSLANameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('SDCityDropDown-onChange', val) }"
                      v-bind="{ ...SDCityDropDown, ...configObject.SDCityDropDown }"
                      v-if="configObject.SDCityDropDown.isVisible" :defaultValue="configObject.SDCityDropDown.cityValue"
                      :values="configObject.SDCityDropDown.list" name="SDCityDropDown" ref="refSDCityDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SDATVNameTextBox-onBlur', val) }"
                      v-bind="{ ...SDATVNameTextBox, ...configObject.SDATVNameTextBox }"
                      v-if="configObject.SDATVNameTextBox.isVisible" :values="configObject.SDATVNameTextBox.atvNameValue"
                      name="SDATVNameTextBox" ref="refSDATVNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SDProvinceTextBox-onBlur', val) }"
                      v-bind="{ ...SDProvinceTextBox, ...configObject.SDProvinceTextBox }"
                      v-if="configObject.SDProvinceTextBox.isVisible"
                      :values="configObject.SDProvinceTextBox.provinceValue" name="SDProvinceTextBox"
                      ref="refSDProvinceTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('SDPostalCodeTextBox-onBlur', val) }"
                      v-bind="{ ...SDPostalCodeTextBox, ...configObject.SDPostalCodeTextBox }"
                      v-if="configObject.SDPostalCodeTextBox.isVisible"
                      :values="configObject.SDPostalCodeTextBox.postalCodeValue" name="SDPostalCodeTextBox"
                      ref="refSDPostalCodeTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('SDDistrictDropDown-onChange', val) }"
                      v-bind="{ ...SDDistrictDropDown, ...configObject.SDDistrictDropDown }"
                      v-if="configObject.SDDistrictDropDown.isVisible"
                      :defaultValue="configObject.SDDistrictDropDown.districtValue"
                      :values="configObject.SDDistrictDropDown.list" name="SDDistrictDropDown"
                      ref="refSDDistrictDropDown" />
                  </el-col>
                </el-row>
              </fieldset>
              <label v-if="configObject.OISection.isVisible" style="color: blue; font-weight: bold;">Others
                Information</label>
              <fieldset v-if="configObject.OISection.isVisible">
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('OIOthersNameTextBox-onBlur', val) }"
                      v-bind="{ ...OIOthersNameTextBox, ...configObject.OIOthersNameTextBox }"
                      v-if="configObject.OIOthersNameTextBox.isVisible"
                      :values="configObject.OIOthersNameTextBox.othersNameValue" name="OIOthersNameTextBox"
                      ref="refOIOthersNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('OIJobTitleTextBox-onBlur', val) }"
                      v-bind="{ ...OIJobTitleTextBox, ...configObject.OIJobTitleTextBox }"
                      v-if="configObject.OIJobTitleTextBox.isVisible"
                      :values="configObject.OIJobTitleTextBox.jobTitleValue" name="OIJobTitleTextBox"
                      ref="refOIJobTitleTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('OIOthersAddressTextBox-onBlur', val) }"
                      v-bind="{ ...OIOthersAddressTextBox, ...configObject.OIOthersAddressTextBox }"
                      v-if="configObject.OIOthersAddressTextBox.isVisible"
                      :values="configObject.OIOthersAddressTextBox.othersAddressValue" name="OIOthersAddressTextBox"
                      ref="refOIOthersAddressTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('OICountryDropDown-onChange', val) }"
                      v-bind="{ ...OICountryDropDown, ...configObject.OICountryDropDown }"
                      v-if="configObject.OICountryDropDown.isVisible"
                      :defaultValue="configObject.OICountryDropDown.countryValue"
                      :values="configObject.OICountryDropDown.list" name="OICountryDropDown" ref="refOICountryDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('OISLANameTextBox-onBlur', val) }"
                      v-bind="{ ...OISLANameTextBox, ...configObject.OISLANameTextBox }"
                      v-if="configObject.OISLANameTextBox.isVisible" :values="configObject.OISLANameTextBox.slaNameValue"
                      name="OISLANameTextBox" ref="refOISLANameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('OICityDropDown-onChange', val) }"
                      v-bind="{ ...OICityDropDown, ...configObject.OICityDropDown }"
                      v-if="configObject.OICityDropDown.isVisible" :defaultValue="configObject.OICityDropDown.cityValue"
                      :values="configObject.OICityDropDown.list" name="OICityDropDown" ref="refOICityDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('OIATVNameTextBox-onBlur', val) }"
                      v-bind="{ ...OIATVNameTextBox, ...configObject.OIATVNameTextBox }"
                      v-if="configObject.OIATVNameTextBox.isVisible" :values="configObject.OIATVNameTextBox.atvNameValue"
                      name="OIATVNameTextBox" ref="refOIATVNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('OIProvinceTextBox-onBlur', val) }"
                      v-bind="{ ...OIProvinceTextBox, ...configObject.OIProvinceTextBox }"
                      v-if="configObject.OIProvinceTextBox.isVisible"
                      :values="configObject.OIProvinceTextBox.provinceValue" name="OIProvinceTextBox"
                      ref="refOIProvinceTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('OIPostalCodeTextBox-onBlur', val) }"
                      v-bind="{ ...OIPostalCodeTextBox, ...configObject.OIPostalCodeTextBox }"
                      v-if="configObject.OIPostalCodeTextBox.isVisible"
                      :values="configObject.OIPostalCodeTextBox.postalCodeValue" name="OIPostalCodeTextBox"
                      ref="refOIPostalCodeTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('OIDistrictDropDown-onChange', val) }"
                      v-bind="{ ...OIDistrictDropDown, ...configObject.OIDistrictDropDown }"
                      v-if="configObject.OIDistrictDropDown.isVisible"
                      :defaultValue="configObject.OIDistrictDropDown.districtValue"
                      :values="configObject.OIDistrictDropDown.list" name="OIDistrictDropDown"
                      ref="refOIDistrictDropDown" />
                  </el-col>
                </el-row>
              </fieldset>
              <label v-if="configObject.DPSection.isVisible" style="color: blue; font-weight: bold;">Details of
                Person</label>
              <fieldset v-if="configObject.DPSection.isVisible">
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('DPNameTextBox-onBlur', val) }"
                      v-bind="{ ...DPNameTextBox, ...configObject.DPNameTextBox }"
                      v-if="configObject.DPNameTextBox.isVisible" :values="configObject.DPNameTextBox.nameValue"
                      name="DPNameTextBox" ref="refDPNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('DPJobTitleTextBox-onBlur', val) }"
                      v-bind="{ ...DPJobTitleTextBox, ...configObject.DPJobTitleTextBox }"
                      v-if="configObject.DPJobTitleTextBox.isVisible"
                      :values="configObject.DPJobTitleTextBox.jobTitleValue" name="DPJobTitleTextBox"
                      ref="refDPJobTitleTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('DPAddressTextBox-onBlur', val) }"
                      v-bind="{ ...DPAddressTextBox, ...configObject.DPAddressTextBox }"
                      v-if="configObject.DPAddressTextBox.isVisible" :values="configObject.DPAddressTextBox.addressValue"
                      name="DPAddressTextBox" ref="refDPAddressTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('DPCountryDropDown-onChange', val) }"
                      v-bind="{ ...DPCountryDropDown, ...configObject.DPCountryDropDown }"
                      v-if="configObject.DPCountryDropDown.isVisible"
                      :defaultValue="configObject.DPCountryDropDown.countryValue"
                      :values="configObject.DPCountryDropDown.list" name="DPCountryDropDown" ref="refDPCountryDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('DPSLANameTextBox-onBlur', val) }"
                      v-bind="{ ...DPSLANameTextBox, ...configObject.DPSLANameTextBox }"
                      v-if="configObject.DPSLANameTextBox.isVisible" :values="configObject.DPSLANameTextBox.slaNameValue"
                      name="DPSLANameTextBox" ref="refDPSLANameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('DPCityDropDown-onChange', val) }"
                      v-bind="{ ...DPCityDropDown, ...configObject.DPCityDropDown }"
                      v-if="configObject.DPCityDropDown.isVisible" :defaultValue="configObject.DPCityDropDown.cityValue"
                      :values="configObject.DPCityDropDown.list" name="DPCityDropDown" ref="refDPCityDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('DPATVNameTextBox-onBlur', val) }"
                      v-bind="{ ...DPATVNameTextBox, ...configObject.DPATVNameTextBox }"
                      v-if="configObject.DPATVNameTextBox.isVisible" :values="configObject.DPATVNameTextBox.atvNameValue"
                      name="DPATVNameTextBox" ref="refDPATVNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('DPProvinceTextBox-onBlur', val) }"
                      v-bind="{ ...DPProvinceTextBox, ...configObject.DPProvinceTextBox }"
                      v-if="configObject.DPProvinceTextBox.isVisible"
                      :values="configObject.DPProvinceTextBox.provinceValue" name="DPProvinceTextBox"
                      ref="refDPProvinceTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('DPPostalCodeTextBox-onBlur', val) }"
                      v-bind="{ ...DPPostalCodeTextBox, ...configObject.DPPostalCodeTextBox }"
                      v-if="configObject.DPPostalCodeTextBox.isVisible"
                      :values="configObject.DPPostalCodeTextBox.postalCodeValue" name="DPPostalCodeTextBox"
                      ref="refDPPostalCodeTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('DPDistrictDropDown-onChange', val) }"
                      v-bind="{ ...DPDistrictDropDown, ...configObject.DPDistrictDropDown }"
                      v-if="configObject.DPDistrictDropDown.isVisible"
                      :defaultValue="configObject.DPDistrictDropDown.districtValue"
                      :values="configObject.DPDistrictDropDown.list" name="DPDistrictDropDown"
                      ref="refDPDistrictDropDown" />
                  </el-col>
                </el-row>
              </fieldset>
              <label v-if="configObject.HDSection.isVisible" style="color: blue; font-weight: bold;">HouseWife
                Details</label>
              <fieldset v-if="configObject.HDSection.isVisible">
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('HDNameTextBox-onBlur', val) }"
                      v-bind="{ ...HDNameTextBox, ...configObject.HDNameTextBox }"
                      v-if="configObject.HDNameTextBox.isVisible" :values="configObject.HDNameTextBox.nameValue"
                      name="HDNameTextBox" ref="refHDNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('HDJobTitleTextBox-onBlur', val) }"
                      v-bind="{ ...HDJobTitleTextBox, ...configObject.HDJobTitleTextBox }"
                      v-if="configObject.HDJobTitleTextBox.isVisible"
                      :values="configObject.HDJobTitleTextBox.jobTitleValue" name="HDJobTitleTextBox"
                      ref="refHDJobTitleTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('HDAddressTextBox-onBlur', val) }"
                      v-bind="{ ...HDAddressTextBox, ...configObject.HDAddressTextBox }"
                      v-if="configObject.HDAddressTextBox.isVisible" :values="configObject.HDAddressTextBox.addressValue"
                      name="HDAddressTextBox" ref="refHDAddressTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('HDCountryDropDown-onChange', val) }"
                      v-bind="{ ...HDCountryDropDown, ...configObject.HDCountryDropDown }"
                      v-if="configObject.HDCountryDropDown.isVisible"
                      :defaultValue="configObject.HDCountryDropDown.countryValue"
                      :values="configObject.HDCountryDropDown.list" name="HDCountryDropDown" ref="refHDCountryDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('HDSLANameTextBox-onBlur', val) }"
                      v-bind="{ ...HDSLANameTextBox, ...configObject.HDSLANameTextBox }"
                      v-if="configObject.HDSLANameTextBox.isVisible" :values="configObject.HDSLANameTextBox.slaNameValue"
                      name="HDSLANameTextBox" ref="refHDSLANameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('HDCityDropDown-onChange', val) }"
                      v-bind="{ ...HDCityDropDown, ...configObject.HDCityDropDown }"
                      v-if="configObject.HDCityDropDown.isVisible" :defaultValue="configObject.HDCityDropDown.cityValue"
                      :values="configObject.HDCityDropDown.list" name="HDCityDropDown" ref="refHDCityDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('HDATVNameTextBox-onBlur', val) }"
                      v-bind="{ ...HDATVNameTextBox, ...configObject.HDATVNameTextBox }"
                      v-if="configObject.HDATVNameTextBox.isVisible" :values="configObject.HDATVNameTextBox.atvNameValue"
                      name="HDATVNameTextBox" ref="refHDATVNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('HDProvinceTextBox-onBlur', val) }"
                      v-bind="{ ...HDProvinceTextBox, ...configObject.HDProvinceTextBox }"
                      v-if="configObject.HDProvinceTextBox.isVisible"
                      :values="configObject.HDProvinceTextBox.provinceValue" name="HDProvinceTextBox"
                      ref="refHDProvinceTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('HDPostalCodeTextBox-onBlur', val) }"
                      v-bind="{ ...HDPostalCodeTextBox, ...configObject.HDPostalCodeTextBox }"
                      v-if="configObject.HDPostalCodeTextBox.isVisible"
                      :values="configObject.HDPostalCodeTextBox.postalCodeValue" name="HDPostalCodeTextBox"
                      ref="refHDPostalCodeTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('HDDistrictDropDown-onChange', val) }"
                      v-bind="{ ...HDDistrictDropDown, ...configObject.HDDistrictDropDown }"
                      v-if="configObject.HDDistrictDropDown.isVisible"
                      :defaultValue="configObject.HDDistrictDropDown.districtValue"
                      :values="configObject.HDDistrictDropDown.list" name="HDDistrictDropDown"
                      ref="refHDDistrictDropDown" />
                  </el-col>
                </el-row>
              </fieldset>
              <label v-if="configObject.ODSection.isVisible" style="color: blue; font-weight: bold;">Occupation
                Details</label>
              <fieldset v-if="configObject.ODSection.isVisible">
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('ODNameofEmpBusTextBox-onBlur', val) }"
                      v-bind="{ ...ODNameofEmpBusTextBox, ...configObject.ODNameofEmpBusTextBox }"
                      v-if="configObject.ODNameofEmpBusTextBox.isVisible"
                      :values="configObject.ODNameofEmpBusTextBox.nameValue" name="ODNameofEmpBusTextBox"
                      ref="refODNameofEmpBusTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('ODJobTitleTextBox-onBlur', val) }"
                      v-bind="{ ...ODJobTitleTextBox, ...configObject.ODJobTitleTextBox }"
                      v-if="configObject.ODJobTitleTextBox.isVisible"
                      :values="configObject.ODJobTitleTextBox.jobTitleValue" name="ODJobTitleTextBox"
                      ref="refODJobTitleTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('ODHFBNameTextBox-onBlur', val) }"
                      v-bind="{ ...ODHFBNameTextBox, ...configObject.ODHFBNameTextBox }"
                      v-if="configObject.ODHFBNameTextBox.isVisible" :values="configObject.ODHFBNameTextBox.hfbNameValue"
                      name="ODHFBNameTextBox" ref="refODHFBNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('ODCountryDropDown-onChange', val) }"
                      v-bind="{ ...ODCountryDropDown, ...configObject.ODCountryDropDown }"
                      v-if="configObject.ODCountryDropDown.isVisible"
                      :defaultValue="configObject.ODCountryDropDown.countryValue"
                      :values="configObject.ODCountryDropDown.list" name="ODCountryDropDown" ref="refODCountryDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('ODSLANameTextBox-onBlur', val) }"
                      v-bind="{ ...ODSLANameTextBox, ...configObject.ODSLANameTextBox }"
                      v-if="configObject.ODSLANameTextBox.isVisible" :values="configObject.ODSLANameTextBox.slaNameValue"
                      name="ODSLANameTextBox" ref="refODSLANameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('ODCityDropDown-onChange', val) }"
                      v-bind="{ ...ODCityDropDown, ...configObject.ODCityDropDown }"
                      v-if="configObject.ODCityDropDown.isVisible" :defaultValue="configObject.ODCityDropDown.cityValue"
                      :values="configObject.ODCityDropDown.list" name="ODCityDropDown" ref="refODCityDropDown" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('ODATVNameTextBox-onBlur', val) }"
                      v-bind="{ ...ODATVNameTextBox, ...configObject.ODATVNameTextBox }"
                      v-if="configObject.ODATVNameTextBox.isVisible" :values="configObject.ODATVNameTextBox.atvNameValue"
                      name="ODATVNameTextBox" ref="refODATVNameTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('ODProvinceTextBox-onBlur', val) }"
                      v-bind="{ ...ODProvinceTextBox, ...configObject.ODProvinceTextBox }"
                      v-if="configObject.ODProvinceTextBox.isVisible"
                      :values="configObject.ODProvinceTextBox.provinceValue" name="ODProvinceTextBox"
                      ref="refODProvinceTextBox" />
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :md="14" :lg="12">
                    <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('ODPostalCodeTextBox-onBlur', val) }"
                      v-bind="{ ...ODPostalCodeTextBox, ...configObject.ODPostalCodeTextBox }"
                      v-if="configObject.ODPostalCodeTextBox.isVisible"
                      :values="configObject.ODPostalCodeTextBox.postalCodeValue" name="ODPostalCodeTextBox"
                      ref="refODPostalCodeTextBox" />
                  </el-col>
                  <el-col :md="10" :lg="12">
                    <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('ODDistrictDropDown-onChange', val) }"
                      v-bind="{ ...ODDistrictDropDown, ...configObject.ODDistrictDropDown }"
                      v-if="configObject.ODDistrictDropDown.isVisible"
                      :defaultValue="configObject.ODDistrictDropDown.districtValue"
                      :values="configObject.ODDistrictDropDown.list" name="ODDistrictDropDown"
                      ref="refODDistrictDropDown" />
                  </el-col>
                </el-row>
              </fieldset>
            </fieldset>
          </el-tab-pane>
          <el-tab-pane v-if="configObject.CNICPassportInfo.isVisible" :disabled="configObject.CNICPassportInfo.isDisabled" label="CNIC/Passport Info" name="second">
            <fieldset>
              <el-row>
                <el-col :md="1" :lg="1"></el-col>
                <el-col :md="10" :lg="10">
                  <CnicNumberNumericDashes15
                    @CnicNumberNumericDashes15-onBlur="(val) => { $emit('ComputerizedCNICTextBox-onBlur', val) }"
                    v-bind="{ ...ComputerizedCNICTextBox, ...configObject.ComputerizedCNICTextBox }"
                    v-if="configObject.ComputerizedCNICTextBox.isVisible"
                    :values="configObject.ComputerizedCNICTextBox.cnicValue" name="ComputerizedCNICTextBox"
                    ref="refComputerizedCNICTextBox" />
                </el-col>
                <el-col :md="2" :lg="2"></el-col>
                <el-col :md="10" :lg="10">
                  <PassportPakistanAlphaNumeric10
                    @PassportPakistanAlphaNumeric10-onBlur="(val) => { $emit('PassportNumberTextBox-onBlur', val) }"
                    v-bind="{ ...PassportNumberTextBox, ...configObject.PassportNumberTextBox }"
                    v-if="configObject.PassportNumberTextBox.isVisible"
                    :values="configObject.PassportNumberTextBox.passportValue" name="PassportNumberTextBox"
                    ref="refPassportNumberTextBox" />
                </el-col>
                <el-col :md="1" :lg="1"></el-col>
              </el-row>
              <el-row>
                <el-col :md="1" :lg="1"></el-col>
                <el-col :md="10" :lg="10">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('CNICExpityDateTextBox-onBlur', val) }"
                    v-bind="{ ...CNICExpityDateTextBox, ...configObject.CNICExpityDateTextBox }"
                    v-if="configObject.CNICExpityDateTextBox.isVisible"
                    :values="configObject.CNICExpityDateTextBox.cnicExpiryValue" name="CNICExpityDateTextBox"
                    ref="refCNICExpityDateTextBox" />
                </el-col>
                <el-col :md="2" :lg="2"></el-col>
                <el-col :md="10" :lg="10">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('PassportPlaceIssueTextBox-onBlur', val) }"
                    v-bind="{ ...PassportPlaceIssueTextBox, ...configObject.PassportPlaceIssueTextBox }"
                    v-if="configObject.PassportPlaceIssueTextBox.isVisible"
                    :values="configObject.PassportPlaceIssueTextBox.passPlaceValue" name="PassportPlaceIssueTextBox"
                    ref="refPassportPlaceIssueTextBox" />
                </el-col>
                <el-col :md="1" :lg="1"></el-col>
              </el-row>
              <el-row>
                <el-col :md="13" :lg="13"></el-col>
                <el-col :md="10" :lg="10">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('MotherNameTextBox1-onBlur', val) }"
                    v-bind="{ ...MotherNameTextBox1, ...configObject.MotherNameTextBox1 }"
                    v-if="configObject.MotherNameTextBox1.isVisible" :values="configObject.MotherNameTextBox1.motherValue"
                    name="MotherNameTextBox1" ref="refMotherNameTextBox1" />
                </el-col>
                <el-col :md="1" :lg="1"></el-col>
              </el-row>
              <el-row>
                <el-col :md="1" :lg="1"></el-col>
                <el-col :md="10" :lg="10">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('PassportExpiryDateTextBox-onBlur', val) }"
                    v-bind="{ ...PassportExpiryDateTextBox, ...configObject.PassportExpiryDateTextBox }"
                    v-if="configObject.PassportExpiryDateTextBox.isVisible"
                    :values="configObject.PassportExpiryDateTextBox.passportExpiryValue" name="PassportExpiryDateTextBox"
                    ref="refPassportExpiryDateTextBox" />
                </el-col>
                <el-col :md="13" :lg="13"></el-col>
              </el-row>
              <el-row>
                <el-col :md="1" :lg="1"></el-col>
                <el-col :md="10" :lg="10">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('PassportPlaceIssueTextBox1-onBlur', val) }"
                    v-bind="{ ...PassportPlaceIssueTextBox1, ...configObject.PassportPlaceIssueTextBox1 }"
                    v-if="configObject.PassportPlaceIssueTextBox1.isVisible"
                    :values="configObject.PassportPlaceIssueTextBox1.passPlaceValue" name="PassportPlaceIssueTextBox1"
                    ref="refPassportPlaceIssueTextBox1" />
                </el-col>
                <el-col :md="2" :lg="2"></el-col>
                <el-col :md="5" :lg="5">
                  <GenericCheckBox
                    @GenericCheckBox-onChange="(val) => { $emit('OtherNationalityCheckBox1-onChange', val) }"
                    v-bind="{ ...OtherNationalityCheckBox1, ...configObject.OtherNationalityCheckBox1 }"
                    v-if="configObject.OtherNationalityCheckBox1.isVisible"
                    :values="configObject.OtherNationalityCheckBox1.otherNationalityValue"
                    name="OtherNationalityCheckBox1" ref="refOtherNationalityCheckBox1" />
                </el-col>
                <el-col :md="1" :lg="1"></el-col>
                <el-col :md="4" :lg="4">
                  <GenericButton @GenericButton-onClick="$emit('AddViewButton1-onClick')" name="AddViewButton1"
                    ref="refAddViewButton1" v-bind="{ ...AddViewButton1, ...configObject.AddViewButton1 }"
                    v-if="configObject.AddViewButton1.isVisible" />
                </el-col>
                <el-col :md="1" :lg="1"></el-col>
              </el-row>
              <el-row>
                <el-col :md="1" :lg="1"></el-col>
                <el-col :md="10" :lg="10">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('DOBTextBox1-onBlur', val) }"
                    v-bind="{ ...DOBTextBox1, ...configObject.DOBTextBox1 }" v-if="configObject.DOBTextBox1.isVisible"
                    :values="configObject.DOBTextBox1.dobValue" name="DOBTextBox1" ref="refDOBTextBox1" />
                </el-col>
                <el-col :md="13" :lg="13"></el-col>
              </el-row>
              <el-row>
                <el-col :md="1" :lg="1"></el-col>
                <el-col :md="3" :lg="3">
                  <el-form-item style="font-family: Arial, Helvetica, sans-serif;">Mailing Address</el-form-item>
                </el-col>
                <el-col :md="1" :lg="1"></el-col>
                <el-col :md="5" :lg="5">
                  <GenericCheckBox @GenericCheckBox-onChange="(val) => { $emit('CurrentAddressCheckBox-onChange', val) }"
                    v-bind="{ ...CurrentAddressCheckBox, ...configObject.CurrentAddressCheckBox }"
                    v-if="configObject.CurrentAddressCheckBox.isVisible"
                    :values="configObject.CurrentAddressCheckBox.value" name="CurrentAddressCheckBox"
                    ref="refCurrentAddressCheckBox" />
                </el-col>
                <el-col :md="5" :lg="5">
                  <GenericCheckBox
                    @GenericCheckBox-onChange="(val) => { $emit('PermanentAddressCheckBox-onChange', val) }"
                    v-bind="{ ...PermanentAddressCheckBox, ...configObject.PermanentAddressCheckBox }"
                    v-if="configObject.PermanentAddressCheckBox.isVisible"
                    :values="configObject.PermanentAddressCheckBox.value" name="PermanentAddressCheckBox"
                    ref="refPermanentAddressCheckBox" />
                </el-col>
                <el-col :md="5" :lg="5">
                  <GenericCheckBox
                    @GenericCheckBox-onChange="(val) => { $emit('BusinessOfficeAddressCheckBox-onChange', val) }"
                    v-bind="{ ...BusinessOfficeAddressCheckBox, ...configObject.BusinessOfficeAddressCheckBox }"
                    v-if="configObject.BusinessOfficeAddressCheckBox.isVisible"
                    :values="configObject.BusinessOfficeAddressCheckBox.value" name="BusinessOfficeAddressCheckBox"
                    ref="refBusinessOfficeAddressCheckBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('CNICIssuanceDateTextBox-onBlur', val) }"
                    v-bind="{ ...CNICIssuanceDateTextBox, ...configObject.CNICIssuanceDateTextBox }"
                    v-if="configObject.CNICIssuanceDateTextBox.isVisible"
                    :values="configObject.CNICIssuanceDateTextBox.dateValue" name="CNICIssuanceDateTextBox"
                    ref="refCNICIssuanceDateTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('PassportExpiryDateTextBox1-onBlur', val) }"
                    v-bind="{ ...PassportExpiryDateTextBox1, ...configObject.PassportExpiryDateTextBox1 }"
                    v-if="configObject.PassportExpiryDateTextBox1.isVisible"
                    :values="configObject.PassportExpiryDateTextBox1.passportExpiryValue"
                    name="PassportExpiryDateTextBox1" ref="refPassportExpiryDateTextBox1" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('FamilyNoTextBox-onBlur', val) }"
                    v-bind="{ ...FamilyNoTextBox, ...configObject.FamilyNoTextBox }"
                    v-if="configObject.FamilyNoTextBox.isVisible" :values="configObject.FamilyNoTextBox.familyValue"
                    name="FamilyNoTextBox" ref="refFamilyNoTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('PassportIssueDateTextBox-onBlur', val) }"
                    v-bind="{ ...PassportIssueDateTextBox, ...configObject.PassportIssueDateTextBox }"
                    v-if="configObject.PassportIssueDateTextBox.isVisible"
                    :values="configObject.PassportIssueDateTextBox.passValue" name="PassportIssueDateTextBox"
                    ref="refPassportIssueDateTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('CNICIdMarkTextBox-onBlur', val) }"
                    v-bind="{ ...CNICIdMarkTextBox, ...configObject.CNICIdMarkTextBox }"
                    v-if="configObject.CNICIdMarkTextBox.isVisible" :values="configObject.CNICIdMarkTextBox.cnicValue"
                    name="CNICIdMarkTextBox" ref="refCNICIdMarkTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('IdDocTypeDropDown2-onChange', val) }"
                    v-bind="{ ...IdDocTypeDropDown2, ...configObject.IdDocTypeDropDown2 }"
                    v-if="configObject.IdDocTypeDropDown2.isVisible"
                    :defaultValue="configObject.IdDocTypeDropDown2.idDocTypeValue"
                    :values="configObject.IdDocTypeDropDown2.list" name="IdDocTypeDropDown2"
                    ref="refIdDocTypeDropDown2" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <NicNumberNumericDashes13
                    @NicNumberNumericDashes13-onBlur="(val) => { $emit('OldNICTextBox-onBlur', val) }"
                    v-bind="{ ...OldNICTextBox, ...configObject.OldNICTextBox }"
                    v-if="configObject.OldNICTextBox.isVisible" :values="configObject.OldNICTextBox.nicValue"
                    name="OldNICTextBox" ref="refOldNICTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <CnicNumberNumericDashes15
                    @CnicNumberNumericDashes15-onBlur="(val) => { $emit('IDNoTextBox-onBlur', val) }"
                    v-bind="{ ...IDNoTextBox, ...configObject.IDNoTextBox }" v-if="configObject.IDNoTextBox.isVisible"
                    :values="configObject.IDNoTextBox.idNoValue" name="IDNoTextBox" ref="refIDNoTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('CountryOfBirthDropDown-onChange', val) }"
                    v-bind="{ ...CountryOfBirthDropDown, ...configObject.CountryOfBirthDropDown }"
                    v-if="configObject.CountryOfBirthDropDown.isVisible"
                    :defaultValue="configObject.CountryOfBirthDropDown.countryBirthValue"
                    :values="configObject.CountryOfBirthDropDown.list" name="CountryOfBirthDropDown"
                    ref="refCountryOfBirthDropDown" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('IssuanceDateTextBox-onBlur', val) }"
                    v-bind="{ ...IssuanceDateTextBox, ...configObject.IssuanceDateTextBox }"
                    v-if="configObject.IssuanceDateTextBox.isVisible"
                    :values="configObject.IssuanceDateTextBox.issueValue" name="IssuanceDateTextBox"
                    ref="refIssuanceDateTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12"></el-col>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('ExpiryDateTextBox-onBlur', val) }"
                    v-bind="{ ...ExpiryDateTextBox, ...configObject.ExpiryDateTextBox }"
                    v-if="configObject.ExpiryDateTextBox.isVisible" :values="configObject.ExpiryDateTextBox.expiryValue"
                    name="ExpiryDateTextBox" ref="refExpiryDateTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12"></el-col>
                <el-col :md="12" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('PlaceOfIssueDropDown-onChange', val) }"
                    v-bind="{ ...PlaceOfIssueDropDown, ...configObject.PlaceOfIssueDropDown }"
                    v-if="configObject.PlaceOfIssueDropDown.isVisible"
                    :defaultValue="configObject.PlaceOfIssueDropDown.placeIssueValue"
                    :values="configObject.PlaceOfIssueDropDown.list" name="PlaceOfIssueDropDown"
                    ref="refPlaceOfIssueDropDown" />
                </el-col>
              </el-row>
            </fieldset>
          </el-tab-pane>
          <el-tab-pane v-if="configObject.ContactInfo.isVisible" :disabled="configObject.ContactInfo.isDisabled" label="Contact Info" name="third">
            <label style="font-weight: bold;">Permanent / Resedential Address</label>
            <fieldset>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('PAHFBNameTextBox-onBlur', val) }"
                    v-bind="{ ...PAHFBNameTextBox, ...configObject.PAHFBNameTextBox }"
                    v-if="configObject.PAHFBNameTextBox.isVisible" :values="configObject.PAHFBNameTextBox.hfbNameValue"
                    name="PAHFBNameTextBox" ref="refPAHFBNameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('PACountryDropDown-onChange', val) }"
                    v-bind="{ ...PACountryDropDown, ...configObject.PACountryDropDown }"
                    v-if="configObject.PACountryDropDown.isVisible"
                    :defaultValue="configObject.PACountryDropDown.countryValue"
                    :values="configObject.PACountryDropDown.list" name="PACountryDropDown" ref="refPACountryDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('PASLANameTextBox-onBlur', val) }"
                    v-bind="{ ...PASLANameTextBox, ...configObject.PASLANameTextBox }"
                    v-if="configObject.PASLANameTextBox.isVisible" :values="configObject.PASLANameTextBox.slaNameValue"
                    name="PASLANameTextBox" ref="refPASLANameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('PACityDropDown-onChange', val) }"
                    v-bind="{ ...PACityDropDown, ...configObject.PACityDropDown }"
                    v-if="configObject.PACityDropDown.isVisible" :defaultValue="configObject.PACityDropDown.cityValue"
                    :values="configObject.PACityDropDown.list" name="PACityDropDown" ref="refPACityDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('PAATVNameTextBox-onBlur', val) }"
                    v-bind="{ ...PAATVNameTextBox, ...configObject.PAATVNameTextBox }"
                    v-if="configObject.PAATVNameTextBox.isVisible" :values="configObject.PAATVNameTextBox.atvNameValue"
                    name="PAATVNameTextBox" ref="refPAATVNameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('PAProvinceTextBox-onBlur', val) }"
                    v-bind="{ ...PAProvinceTextBox, ...configObject.PAProvinceTextBox }"
                    v-if="configObject.PAProvinceTextBox.isVisible" :values="configObject.PAProvinceTextBox.provinceValue"
                    name="PAProvinceTextBox" ref="refPAProvinceTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('PAPostalCodeTextBox-onBlur', val) }"
                    v-bind="{ ...PAPostalCodeTextBox, ...configObject.PAPostalCodeTextBox }"
                    v-if="configObject.PAPostalCodeTextBox.isVisible"
                    :values="configObject.PAPostalCodeTextBox.postalCodeValue" name="PAPostalCodeTextBox"
                    ref="refPAPostalCodeTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('PADistrictDropDown-onChange', val) }"
                    v-bind="{ ...PADistrictDropDown, ...configObject.PADistrictDropDown }"
                    v-if="configObject.PADistrictDropDown.isVisible"
                    :defaultValue="configObject.PADistrictDropDown.districtValue"
                    :values="configObject.PADistrictDropDown.list" name="PADistrictDropDown"
                    ref="refPADistrictDropDown" />
                </el-col>
              </el-row>
            </fieldset>
            <label style="font-weight: bold;">Current / Mailing Address</label>
            <fieldset>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('CAHFBNameTextBox-onBlur', val) }"
                    v-bind="{ ...CAHFBNameTextBox, ...configObject.CAHFBNameTextBox }"
                    v-if="configObject.CAHFBNameTextBox.isVisible" :values="configObject.CAHFBNameTextBox.hfbNameValue"
                    name="CAHFBNameTextBox" ref="refCAHFBNameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('CACountryDropDown-onChange', val) }"
                    v-bind="{ ...CACountryDropDown, ...configObject.CACountryDropDown }"
                    v-if="configObject.CACountryDropDown.isVisible"
                    :defaultValue="configObject.CACountryDropDown.countryValue"
                    :values="configObject.CACountryDropDown.list" name="CACountryDropDown" ref="refCACountryDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('CASLANameTextBox-onBlur', val) }"
                    v-bind="{ ...CASLANameTextBox, ...configObject.CASLANameTextBox }"
                    v-if="configObject.CASLANameTextBox.isVisible" :values="configObject.CASLANameTextBox.slaNameValue"
                    name="CASLANameTextBox" ref="refCASLANameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('CACityDropDown-onChange', val) }"
                    v-bind="{ ...CACityDropDown, ...configObject.CACityDropDown }"
                    v-if="configObject.CACityDropDown.isVisible" :defaultValue="configObject.CACityDropDown.cityValue"
                    :values="configObject.CACityDropDown.list" name="CACityDropDown" ref="refCACityDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('CAATVNameTextBox-onBlur', val) }"
                    v-bind="{ ...CAATVNameTextBox, ...configObject.CAATVNameTextBox }"
                    v-if="configObject.CAATVNameTextBox.isVisible" :values="configObject.CAATVNameTextBox.atvNameValue"
                    name="CAATVNameTextBox" ref="refCAATVNameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('CAProvinceTextBox-onBlur', val) }"
                    v-bind="{ ...CAProvinceTextBox, ...configObject.CAProvinceTextBox }"
                    v-if="configObject.CAProvinceTextBox.isVisible" :values="configObject.CAProvinceTextBox.provinceValue"
                    name="CAProvinceTextBox" ref="refCAProvinceTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="8" :lg="7">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('CAPostalCodeTextBox-onBlur', val) }"
                    v-bind="{ ...CAPostalCodeTextBox, ...configObject.CAPostalCodeTextBox }"
                    v-if="configObject.CAPostalCodeTextBox.isVisible"
                    :values="configObject.CAPostalCodeTextBox.postalCodeValue" name="CAPostalCodeTextBox"
                    ref="refCAPostalCodeTextBox" />
                </el-col>
                <el-col :md="3" :lg="3">
                  <GenericButton @GenericButton-onClick="$emit('SameAsAboveButton-onClick')" name="SameAsAboveButton"
                    ref="refSameAsAboveButton" v-bind="{ ...SameAsAboveButton, ...configObject.SameAsAboveButton }"
                    v-if="configObject.SameAsAboveButton.isVisible" />
                </el-col>
                <el-col :md="3" :lg="2"></el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('CADistrictDropDown-onChange', val) }"
                    v-bind="{ ...CADistrictDropDown, ...configObject.CADistrictDropDown }"
                    v-if="configObject.CADistrictDropDown.isVisible"
                    :defaultValue="configObject.CADistrictDropDown.districtValue"
                    :values="configObject.CADistrictDropDown.list" name="CADistrictDropDown"
                    ref="refCADistrictDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :lg="4" :md="4">
                  <el-form-item style="font-family: Arial, Helvetica, sans-serif;">Change of Address</el-form-item>
                </el-col>
                <el-col :lg="3" :md="3">
                  <GenericCheckBox @GenericCheckBox-onChange="(val) => { $emit('ChangeOfAddressCheckBox-onChange', val) }"
                    v-bind="{ ...ChangeOfAddressCheckBox, ...configObject.ChangeOfAddressCheckBox }"
                    v-if="configObject.ChangeOfAddressCheckBox.isVisible"
                    :values="configObject.ChangeOfAddressCheckBox.changeAddressValue" name="ChangeOfAddressCheckBox"
                    ref="refChangeOfAddressCheckBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="3" :lg="3">
                  <el-form-item style="font-family: Arial, Helvetica, sans-serif;">Mailing Address</el-form-item>
                </el-col>
                <el-col :md="3" :lg="3"></el-col>
                <el-col :md="5" :lg="5">
                  <GenericCheckBox @GenericCheckBox-onChange="(val) => { $emit('CurrentAddressCheckBox1-onChange', val) }"
                    v-bind="{ ...CurrentAddressCheckBox1, ...configObject.CurrentAddressCheckBox1 }"
                    v-if="configObject.CurrentAddressCheckBox1.isVisible"
                    :values="configObject.CurrentAddressCheckBox1.value" name="CurrentAddressCheckBox1"
                    ref="refCurrentAddressCheckBox1" />
                </el-col>
                <el-col :md="5" :lg="5">
                  <GenericCheckBox
                    @GenericCheckBox-onChange="(val) => { $emit('PermanentAddressCheckBox1-onChange', val) }"
                    v-bind="{ ...PermanentAddressCheckBox1, ...configObject.PermanentAddressCheckBox1 }"
                    v-if="configObject.PermanentAddressCheckBox1.isVisible"
                    :values="configObject.PermanentAddressCheckBox1.value" name="PermanentAddressCheckBox1"
                    ref="refPermanentAddressCheckBox1" />
                </el-col>
                <el-col :md="5" :lg="5">
                  <GenericCheckBox
                    @GenericCheckBox-onChange="(val) => { $emit('BusinessOfficeAddressCheckBox1-onChange', val) }"
                    v-bind="{ ...BusinessOfficeAddressCheckBox1, ...configObject.BusinessOfficeAddressCheckBox1 }"
                    v-if="configObject.BusinessOfficeAddressCheckBox1.isVisible"
                    :values="configObject.BusinessOfficeAddressCheckBox1.value" name="BusinessOfficeAddressCheckBox1"
                    ref="refBusinessOfficeAddressCheckBox1" />
                </el-col>
              </el-row>
            </fieldset>
            <fieldset>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('CountryTelOffDropDown-onChange', val) }"
                    v-bind="{ ...CountryTelOffDropDown, ...configObject.CountryTelOffDropDown }"
                    v-if="configObject.CountryTelOffDropDown.isVisible"
                    :defaultValue="configObject.CountryTelOffDropDown.countryTelValue"
                    :values="configObject.CountryTelOffDropDown.list" name="CountryTelOffDropDown"
                    ref="refCountryTelOffDropDown" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('TelOffTextBox-onBlur', val) }"
                    v-bind="{ ...TelOffTextBox, ...configObject.TelOffTextBox }"
                    v-if="configObject.TelOffTextBox.isVisible" :values="configObject.TelOffTextBox.telOffValue"
                    name="TelOffTextBox" ref="refTelOffTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('CountryTelResDropDown-onChange', val) }"
                    v-bind="{ ...CountryTelResDropDown, ...configObject.CountryTelResDropDown }"
                    v-if="configObject.CountryTelResDropDown.isVisible"
                    :defaultValue="configObject.CountryTelResDropDown.countryTelValue"
                    :values="configObject.CountryTelResDropDown.list" name="CountryTelResDropDown"
                    ref="refCountryTelResDropDown" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('TelResTextBox-onBlur', val) }"
                    v-bind="{ ...TelResTextBox, ...configObject.TelResTextBox }"
                    v-if="configObject.TelResTextBox.isVisible" :values="configObject.TelResTextBox.telResValue"
                    name="TelResTextBox" ref="refTelResTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown
                    @GenericDropDown-onChange="(val) => { $emit('CountryTelMobileDropDown-onChange', val) }"
                    v-bind="{ ...CountryTelMobileDropDown, ...configObject.CountryTelMobileDropDown }"
                    v-if="configObject.CountryTelMobileDropDown.isVisible"
                    :defaultValue="configObject.CountryTelMobileDropDown.countryTelValue"
                    :values="configObject.CountryTelMobileDropDown.list" name="CountryTelMobileDropDown"
                    ref="refCountryTelMobileDropDown" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('MobileTextBox-onBlur', val) }"
                    v-bind="{ ...MobileTextBox, ...configObject.MobileTextBox }"
                    v-if="configObject.MobileTextBox.isVisible" :values="configObject.MobileTextBox.mobileValue"
                    name="MobileTextBox" ref="refMobileTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('FaxNoTextBox-onBlur', val) }"
                    v-bind="{ ...FaxNoTextBox, ...configObject.FaxNoTextBox }" v-if="configObject.FaxNoTextBox.isVisible"
                    :values="configObject.FaxNoTextBox.faxValue" name="FaxNoTextBox" ref="refFaxNoTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('EmailTextBox-onBlur', val) }"
                    v-bind="{ ...EmailTextBox, ...configObject.EmailTextBox }" v-if="configObject.EmailTextBox.isVisible"
                    :values="configObject.EmailTextBox.emailValue" name="EmailTextBox" ref="refEmailTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('EmailTextBox1-onBlur', val) }"
                    v-bind="{ ...EmailTextBox1, ...configObject.EmailTextBox1 }"
                    v-if="configObject.EmailTextBox1.isVisible" :values="configObject.EmailTextBox1.emailValue"
                    name="EmailTextBox1" ref="refEmailTextBox1" />
                </el-col>
                <el-col :lg="1" :md="1"></el-col>
                <el-col :lg="4" :md="4">
                  <GenericCheckBox @GenericCheckBox-onChange="(val) => { $emit('eStatementCheckBox-onChange', val) }"
                    v-bind="{ ...eStatementCheckBox, ...configObject.eStatementCheckBox }"
                    v-if="configObject.eStatementCheckBox.isVisible"
                    :values="configObject.eStatementCheckBox.eStatementValue" name="eStatementCheckBox"
                    ref="refeStatementCheckBox" />
                </el-col>
                <el-col :lg="1" :md="1"></el-col>
                <el-col :lg="3" :md="3">
                  <GenericButton @GenericButton-onClick="$emit('ViewButton-onClick')" name="ViewButton"
                    ref="refViewButton" v-bind="{ ...ViewButton, ...configObject.ViewButton }"
                    v-if="configObject.ViewButton.isVisible" />
                </el-col>
              </el-row>
            </fieldset>
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('EStatementEmailTextBox-onBlur', val) }"
                  v-bind="{ ...EStatementEmailTextBox, ...configObject.EStatementEmailTextBox }"
                  v-if="configObject.EStatementEmailTextBox.isVisible"
                  :values="configObject.EStatementEmailTextBox.emailValue" name="EStatementEmailTextBox"
                  ref="refEStatementEmailTextBox" />
              </el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane v-if="configObject.YngSaversGuardianInfo.isVisible" :disabled="configObject.YngSaversGuardianInfo.isDisabled" label="Young Savers Guardian Info" name="fourth">
            <el-row>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('GuardianTextBox-onBlur', val) }"
                  v-bind="{ ...GuardianTextBox, ...configObject.GuardianTextBox }"
                  v-if="configObject.GuardianTextBox.isVisible" :values="configObject.GuardianTextBox.guardianValue"
                  name="GuardianTextBox" ref="refGuardianTextBox" />
              </el-col>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('MotherNameTextBox2-onBlur', val) }"
                  v-bind="{ ...MotherNameTextBox2, ...configObject.MotherNameTextBox2 }"
                  v-if="configObject.MotherNameTextBox2.isVisible" :values="configObject.MotherNameTextBox2.motherValue"
                  name="MotherNameTextBox2" ref="refMotherNameTextBox2" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('FatherHusbandNameTextBox1-onBlur', val) }"
                  v-bind="{ ...FatherHusbandNameTextBox1, ...configObject.FatherHusbandNameTextBox1 }"
                  v-if="configObject.FatherHusbandNameTextBox1.isVisible"
                  :values="configObject.FatherHusbandNameTextBox1.fatherValue" name="FatherHusbandNameTextBox1"
                  ref="refFatherHusbandNameTextBox1" />
              </el-col>
              <el-col :md="12" :lg="12">
                <CnicNumberNumericDashes15
                  @CnicNumberNumericDashes15-onBlur="(val) => { $emit('CNICTextBox1-onBlur', val) }"
                  v-bind="{ ...CNICTextBox1, ...configObject.CNICTextBox1 }" v-if="configObject.CNICTextBox1.isVisible"
                  :values="configObject.CNICTextBox1.cnicValue" name="CNICTextBox1" ref="CNICTextBox1" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :md="12" :lg="12">
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('DOBTextBox2-onBlur', val) }"
                  v-bind="{ ...DOBTextBox2, ...configObject.DOBTextBox2 }" v-if="configObject.DOBTextBox2.isVisible"
                  :values="configObject.DOBTextBox2.dobValue" name="DOBTextBox2" ref="refDOBTextBox2" />
              </el-col>
              <el-col :md="12" :lg="12">
                <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('ExpiryDateTextBox2-onBlur', val) }"
                  v-bind="{ ...ExpiryDateTextBox2, ...configObject.ExpiryDateTextBox2 }"
                  v-if="configObject.ExpiryDateTextBox2.isVisible" :values="configObject.ExpiryDateTextBox2.expiryValue"
                  name="ExpiryDateTextBox2" ref="refExpiryDateTextBox2" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :md="12" :lg="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('NationalityDropDown1-onChange', val) }"
                  v-bind="{ ...NationalityDropDown1, ...configObject.NationalityDropDown1 }"
                  v-if="configObject.NationalityDropDown1.isVisible"
                  :defaultValue="configObject.NationalityDropDown1.nationalityValue"
                  :values="configObject.NationalityDropDown1.list" name="NationalityDropDown1"
                  ref="refNationalityDropDown1" />
              </el-col>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('RelationshipTextBox-onBlur', val) }"
                  v-bind="{ ...RelationshipTextBox, ...configObject.RelationshipTextBox }"
                  v-if="configObject.RelationshipTextBox.isVisible"
                  :values="configObject.RelationshipTextBox.relationValue" name="RelationshipTextBox"
                  ref="refRelationshipTextBox" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :md="12" :lg="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('GenderDropDown-onChange', val) }"
                  v-bind="{ ...GenderDropDown, ...configObject.GenderDropDown }"
                  v-if="configObject.GenderDropDown.isVisible" :defaultValue="configObject.GenderDropDown.genderValue"
                  :values="configObject.GenderDropDown.list" name="GenderDropDown" ref="refGenderDropDown" />
              </el-col>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('PassportNoTextBox-onBlur', val) }"
                  v-bind="{ ...PassportNoTextBox, ...configObject.PassportNoTextBox }"
                  v-if="configObject.PassportNoTextBox.isVisible" :values="configObject.PassportNoTextBox.passValue"
                  name="PassportNoTextBox" ref="refPassportNoTextBox" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('EmailTextBox2-onBlur', val) }"
                  v-bind="{ ...EmailTextBox2, ...configObject.EmailTextBox2 }" v-if="configObject.EmailTextBox2.isVisible"
                  :values="configObject.EmailTextBox2.emailValue" name="EmailTextBox2" ref="refEmailTextBox2" />
              </el-col>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('TelResTextBox1-onBlur', val) }"
                  v-bind="{ ...TelResTextBox1, ...configObject.TelResTextBox1 }"
                  v-if="configObject.TelResTextBox1.isVisible" :values="configObject.TelResTextBox1.telResValue"
                  name="TelResTextBox1" ref="refTelResTextBox1" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :md="12" :lg="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('OccupationDropDown1-onChange', val) }"
                  v-bind="{ ...OccupationDropDown1, ...configObject.OccupationDropDown1 }"
                  v-if="configObject.OccupationDropDown1.isVisible"
                  :defaultValue="configObject.OccupationDropDown1.occupationValue"
                  :values="configObject.OccupationDropDown1.list" name="OccupationDropDown1"
                  ref="refOccupationDropDown1" />
              </el-col>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AddressTextBox-onBlur', val) }"
                  v-bind="{ ...AddressTextBox, ...configObject.AddressTextBox }"
                  v-if="configObject.AddressTextBox.isVisible" :values="configObject.AddressTextBox.addressValue"
                  name="AddressTextBox" ref="refAddressTextBox" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('EmployerBusinessAddTextBox-onBlur', val) }"
                  v-bind="{ ...EmployerBusinessAddTextBox, ...configObject.EmployerBusinessAddTextBox }"
                  v-if="configObject.EmployerBusinessAddTextBox.isVisible"
                  :values="configObject.EmployerBusinessAddTextBox.empBusValue" name="EmployerBusinessAddTextBox"
                  ref="refEmployerBusinessAddTextBox" />
              </el-col>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('NameOfEmpBusTextBox-onBlur', val) }"
                  v-bind="{ ...NameOfEmpBusTextBox, ...configObject.NameOfEmpBusTextBox }"
                  v-if="configObject.NameOfEmpBusTextBox.isVisible"
                  :values="configObject.NameOfEmpBusTextBox.nameOfEmpBusValue" name="NameOfEmpBusTextBox"
                  ref="refNameOfEmpBusTextBox" />
              </el-col>
            </el-row>
            <el-row>
              <el-col :md="12" :lg="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('TelOffTextBox1-onBlur', val) }"
                  v-bind="{ ...TelOffTextBox1, ...configObject.TelOffTextBox1 }"
                  v-if="configObject.TelOffTextBox1.isVisible" :values="configObject.TelOffTextBox1.telOffValue"
                  name="TelOffTextBox1" ref="refTelOffTextBox1" />
              </el-col>
              <el-col :md="12" :lg="12"></el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane v-if="configObject.FATCAInfo.isVisible" :disabled="configObject.FATCAInfo.isDisabled" label="FATCA Info." name="fifth">
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('USCitizenDropDown-onChange', val) }"
                  v-bind="{ ...USCitizenDropDown, ...configObject.USCitizenDropDown }"
                  v-if="configObject.USCitizenDropDown.isVisible"
                  :defaultValue="configObject.USCitizenDropDown.usCitizenValue"
                  :values="configObject.USCitizenDropDown.list" name="USCitizenDropDown" ref="refUSCitizenDropDown" />
              </el-col>
              <el-col :lg="12" :md="12"></el-col>
            </el-row>
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('USGreenCardHolderDropDown-onChange', val) }"
                  v-bind="{ ...USGreenCardHolderDropDown, ...configObject.USGreenCardHolderDropDown }"
                  v-if="configObject.USGreenCardHolderDropDown.isVisible"
                  :defaultValue="configObject.USGreenCardHolderDropDown.usGreenCardValue"
                  :values="configObject.USGreenCardHolderDropDown.list" name="USGreenCardHolderDropDown"
                  ref="refUSGreenCardHolderDropDown" />
              </el-col>
              <el-col :lg="12" :md="12"></el-col>
            </el-row>
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('USResidentDropDown-onChange', val) }"
                  v-bind="{ ...USResidentDropDown, ...configObject.USResidentDropDown }"
                  v-if="configObject.USResidentDropDown.isVisible"
                  :defaultValue="configObject.USResidentDropDown.usResidentValue"
                  :values="configObject.USResidentDropDown.list" name="USResidentDropDown" ref="refUSResidentDropDown" />
              </el-col>
              <el-col :lg="12" :md="12"></el-col>
            </el-row>
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('BornInUSDropDown-onChange', val) }"
                  v-bind="{ ...BornInUSDropDown, ...configObject.BornInUSDropDown }"
                  v-if="configObject.BornInUSDropDown.isVisible"
                  :defaultValue="configObject.BornInUSDropDown.bornInUSValue" :values="configObject.BornInUSDropDown.list"
                  name="BornInUSDropDown" ref="refBornInUSDropDown" />
              </el-col>
              <el-col :lg="12" :md="12"></el-col>
            </el-row>
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('TaxResidentDropDown-onChange', val) }"
                  v-bind="{ ...TaxResidentDropDown, ...configObject.TaxResidentDropDown }"
                  v-if="configObject.TaxResidentDropDown.isVisible"
                  :defaultValue="configObject.TaxResidentDropDown.taxResidentValue"
                  :values="configObject.TaxResidentDropDown.list" name="TaxResidentDropDown"
                  ref="refTaxResidentDropDown" />
              </el-col>
              <el-col :lg="12" :md="12"></el-col>
            </el-row>
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('TaxIDNoTypeDropDown-onChange', val) }"
                  v-bind="{ ...TaxIDNoTypeDropDown, ...configObject.TaxIDNoTypeDropDown }"
                  v-if="configObject.TaxIDNoTypeDropDown.isVisible"
                  :defaultValue="configObject.TaxIDNoTypeDropDown.taxIdNoValue"
                  :values="configObject.TaxIDNoTypeDropDown.list" name="TaxIDNoTypeDropDown"
                  ref="refTaxIDNoTypeDropDown" />
              </el-col>
              <el-col :lg="12" :md="12"></el-col>
            </el-row>
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('TaxIdentificationNoTextBox-onBlur', val) }"
                  v-bind="{ ...TaxIdentificationNoTextBox, ...configObject.TaxIdentificationNoTextBox }"
                  v-if="configObject.TaxIdentificationNoTextBox.isVisible"
                  :values="configObject.TaxIdentificationNoTextBox.taxIdentificationNoValue"
                  name="TaxIdentificationNoTextBox" ref="refTaxIdentificationNoTextBox" />
              </el-col>
              <el-col :lg="12" :md="12"></el-col>
            </el-row>
            <el-row>
              <el-col :lg="12" :md="12">
                <GenericDropDown
                  @GenericDropDown-onChange="(val) => { $emit('FATCAClassificationDropDown-onChange', val) }"
                  v-bind="{ ...FATCAClassificationDropDown, ...configObject.FATCAClassificationDropDown }"
                  v-if="configObject.FATCAClassificationDropDown.isVisible"
                  :defaultValue="configObject.FATCAClassificationDropDown.fatcaValue"
                  :values="configObject.FATCAClassificationDropDown.list" name="FATCAClassificationDropDown"
                  ref="refFATCAClassificationDropDown" />
              </el-col>
              <el-col :lg="12" :md="12"></el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane v-if="configObject.CACTProfile.isVisible" :disabled="configObject.CACTProfile.isDisabled" label="Company/Association/Club/Trust Profile" name="sixth">
            <fieldset>
              <el-row>
                <el-col :md="12" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('NameTextBox-onBlur', val) }"
                    v-bind="{ ...NameTextBox, ...configObject.NameTextBox }" v-if="configObject.NameTextBox.isVisible"
                    :values="configObject.NameTextBox.nameValue" name="NameTextBox" ref="refNameTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('STRegNoTextBox-onBlur', val) }"
                    v-bind="{ ...STRegNoTextBox, ...configObject.STRegNoTextBox }"
                    v-if="configObject.STRegNoTextBox.isVisible" :values="configObject.STRegNoTextBox.stRegValue"
                    name="STRegNoTextBox" ref="refSTRegNoTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <CnicNumberNumericDashes15
                    @CnicNumberNumericDashes15-onBlur="(val) => { $emit('NTNNoTextBox-onBlur', val) }"
                    v-bind="{ ...NTNNoTextBox, ...configObject.NTNNoTextBox }" v-if="configObject.NTNNoTextBox.isVisible"
                    :values="configObject.NTNNoTextBox.ntnValue" name="NTNNoTextBox" ref="NTNNoTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('FaxNoTextBox1-onBlur', val) }"
                    v-bind="{ ...FaxNoTextBox1, ...configObject.FaxNoTextBox1 }"
                    v-if="configObject.FaxNoTextBox1.isVisible" :values="configObject.FaxNoTextBox1.faxValue"
                    name="FaxNoTextBox1" ref="refFaxNoTextBox1" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('TelephoneNoTextBox-onBlur', val) }"
                    v-bind="{ ...TelephoneNoTextBox, ...configObject.TelephoneNoTextBox }"
                    v-if="configObject.TelephoneNoTextBox.isVisible" :values="configObject.TelephoneNoTextBox.telValue"
                    name="TelephoneNoTextBox" ref="refTelephoneNoTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('WebPageTextBox-onBlur', val) }"
                    v-bind="{ ...WebPageTextBox, ...configObject.WebPageTextBox }"
                    v-if="configObject.WebPageTextBox.isVisible" :values="configObject.WebPageTextBox.webValue"
                    name="WebPageTextBox" ref="refWebPageTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('EmailTextBox3-onBlur', val) }"
                    v-bind="{ ...EmailTextBox3, ...configObject.EmailTextBox3 }"
                    v-if="configObject.EmailTextBox3.isVisible" :values="configObject.EmailTextBox3.emailValue"
                    name="EmailTextBox3" ref="refEmailTextBox3" />
                </el-col>
                <el-col :lg="1" :md="1"></el-col>
                <el-col :lg="4" :md="4">
                  <GenericCheckBox @GenericCheckBox-onChange="(val) => { $emit('eStatementCheckBox1-onChange', val) }"
                    v-bind="{ ...eStatementCheckBox1, ...configObject.eStatementCheckBox1 }"
                    v-if="configObject.eStatementCheckBox1.isVisible"
                    :values="configObject.eStatementCheckBox1.eStatementValue" name="eStatementCheckBox1"
                    ref="refeStatementCheckBox1" />
                </el-col>
                <el-col :lg="1" :md="1"></el-col>
                <el-col :lg="3" :md="3">
                  <GenericButton @GenericButton-onClick="$emit('ViewButton2-onClick')" name="ViewButton2"
                    ref="refViewButton2" v-bind="{ ...ViewButton2, ...configObject.ViewButton2 }"
                    v-if="configObject.ViewButton2.isVisible" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('EntityRegNoTextBox-onBlur', val) }"
                    v-bind="{ ...EntityRegNoTextBox, ...configObject.EntityRegNoTextBox }"
                    v-if="configObject.EntityRegNoTextBox.isVisible" :values="configObject.EntityRegNoTextBox.entityValue"
                    name="EntityRegNoTextBox" ref="refEntityRegNoTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('EntityRegDateTextBox-onBlur', val) }"
                    v-bind="{ ...EntityRegDateTextBox, ...configObject.EntityRegDateTextBox }"
                    v-if="configObject.EntityRegDateTextBox.isVisible"
                    :values="configObject.EntityRegDateTextBox.dateValue" name="EntityRegDateTextBox"
                    ref="refEntityRegDateTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('From29DateTextBox-onBlur', val) }"
                    v-bind="{ ...From29DateTextBox, ...configObject.From29DateTextBox }"
                    v-if="configObject.From29DateTextBox.isVisible" :values="configObject.From29DateTextBox.dateValue"
                    name="From29DateTextBox" ref="refFrom29DateTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('FromABDateTextBox-onBlur', val) }"
                    v-bind="{ ...FromABDateTextBox, ...configObject.FromABDateTextBox }"
                    v-if="configObject.FromABDateTextBox.isVisible" :values="configObject.FromABDateTextBox.dateValue"
                    name="FromABDateTextBox" ref="refFromABDateTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('INCDateTextBox-onBlur', val) }"
                    v-bind="{ ...INCDateTextBox, ...configObject.INCDateTextBox }"
                    v-if="configObject.INCDateTextBox.isVisible" :values="configObject.INCDateTextBox.dateValue"
                    name="INCDateTextBox" ref="refINCDateTextBox" />
                </el-col>
                <el-col :md="12" :lg="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => { $emit('FromCDateTextBox-onBlur', val) }"
                    v-bind="{ ...FromCDateTextBox, ...configObject.FromCDateTextBox }"
                    v-if="configObject.FromCDateTextBox.isVisible" :values="configObject.FromCDateTextBox.dateValue"
                    name="FromCDateTextBox" ref="refFromCDateTextBox" />
                </el-col>
              </el-row>
            </fieldset>
            <label style="font-weight: bold;">Head Office Address / Permanent / Resedential Address</label>
            <fieldset>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociatePAHFBNameTextBox-onBlur', val) }"
                    v-bind="{ ...AssociatePAHFBNameTextBox, ...configObject.AssociatePAHFBNameTextBox }"
                    v-if="configObject.AssociatePAHFBNameTextBox.isVisible"
                    :values="configObject.AssociatePAHFBNameTextBox.hfbNameValue" name="AssociatePAHFBNameTextBox"
                    ref="refAssociatePAHFBNameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown
                    @GenericDropDown-onChange="(val) => { $emit('AssociatePACountryDropDown-onChange', val) }"
                    v-bind="{ ...AssociatePACountryDropDown, ...configObject.AssociatePACountryDropDown }"
                    v-if="configObject.AssociatePACountryDropDown.isVisible"
                    :defaultValue="configObject.AssociatePACountryDropDown.countryValue"
                    :values="configObject.AssociatePACountryDropDown.list" name="AssociatePACountryDropDown"
                    ref="refAssociatePACountryDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociatePASLANameTextBox-onBlur', val) }"
                    v-bind="{ ...AssociatePASLANameTextBox, ...configObject.AssociatePASLANameTextBox }"
                    v-if="configObject.AssociatePASLANameTextBox.isVisible"
                    :values="configObject.AssociatePASLANameTextBox.slaNameValue" name="AssociatePASLANameTextBox"
                    ref="refAssociatePASLANameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('AssociatePACityDropDown-onChange', val) }"
                    v-bind="{ ...AssociatePACityDropDown, ...configObject.AssociatePACityDropDown }"
                    v-if="configObject.AssociatePACityDropDown.isVisible"
                    :defaultValue="configObject.AssociatePACityDropDown.cityValue"
                    :values="configObject.AssociatePACityDropDown.list" name="AssociatePACityDropDown"
                    ref="refAssociatePACityDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociatePAATVNameTextBox-onBlur', val) }"
                    v-bind="{ ...AssociatePAATVNameTextBox, ...configObject.AssociatePAATVNameTextBox }"
                    v-if="configObject.AssociatePAATVNameTextBox.isVisible"
                    :values="configObject.AssociatePAATVNameTextBox.atvNameValue" name="AssociatePAATVNameTextBox"
                    ref="refAssociatePAATVNameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociatePAProvinceTextBox-onBlur', val) }"
                    v-bind="{ ...AssociatePAProvinceTextBox, ...configObject.AssociatePAProvinceTextBox }"
                    v-if="configObject.AssociatePAProvinceTextBox.isVisible"
                    :values="configObject.AssociatePAProvinceTextBox.provinceValue" name="AssociatePAProvinceTextBox"
                    ref="refAssociatePAProvinceTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociatePAPostalCodeTextBox-onBlur', val) }"
                    v-bind="{ ...AssociatePAPostalCodeTextBox, ...configObject.AssociatePAPostalCodeTextBox }"
                    v-if="configObject.AssociatePAPostalCodeTextBox.isVisible"
                    :values="configObject.AssociatePAPostalCodeTextBox.postalCodeValue"
                    name="AssociatePAPostalCodeTextBox" ref="refAssociatePAPostalCodeTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown
                    @GenericDropDown-onChange="(val) => { $emit('AssociatePADistrictDropDown-onChange', val) }"
                    v-bind="{ ...AssociatePADistrictDropDown, ...configObject.AssociatePADistrictDropDown }"
                    v-if="configObject.AssociatePADistrictDropDown.isVisible"
                    :defaultValue="configObject.AssociatePADistrictDropDown.districtValue"
                    :values="configObject.AssociatePADistrictDropDown.list" name="AssociatePADistrictDropDown"
                    ref="refAssociatePADistrictDropDown" />
                </el-col>
              </el-row>
            </fieldset>
            <label style="font-weight: bold;">Registered Office Address / Current / Mailing Address</label>
            <fieldset>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociateCAHFBNameTextBox-onBlur', val) }"
                    v-bind="{ ...AssociateCAHFBNameTextBox, ...configObject.AssociateCAHFBNameTextBox }"
                    v-if="configObject.AssociateCAHFBNameTextBox.isVisible"
                    :values="configObject.AssociateCAHFBNameTextBox.hfbNameValue" name="AssociateCAHFBNameTextBox"
                    ref="refAssociateCAHFBNameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown
                    @GenericDropDown-onChange="(val) => { $emit('AssociateCACountryDropDown-onChange', val) }"
                    v-bind="{ ...AssociateCACountryDropDown, ...configObject.AssociateCACountryDropDown }"
                    v-if="configObject.AssociateCACountryDropDown.isVisible"
                    :defaultValue="configObject.AssociateCACountryDropDown.countryValue"
                    :values="configObject.AssociateCACountryDropDown.list" name="AssociateCACountryDropDown"
                    ref="refAssociateCACountryDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociateCASLANameTextBox-onBlur', val) }"
                    v-bind="{ ...AssociateCASLANameTextBox, ...configObject.AssociateCASLANameTextBox }"
                    v-if="configObject.AssociateCASLANameTextBox.isVisible"
                    :values="configObject.AssociateCASLANameTextBox.slaNameValue" name="AssociateCASLANameTextBox"
                    ref="refAssociateCASLANameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('AssociateCACityDropDown-onChange', val) }"
                    v-bind="{ ...AssociateCACityDropDown, ...configObject.AssociateCACityDropDown }"
                    v-if="configObject.AssociateCACityDropDown.isVisible"
                    :defaultValue="configObject.AssociateCACityDropDown.cityValue"
                    :values="configObject.AssociateCACityDropDown.list" name="AssociateCACityDropDown"
                    ref="refAssociateCACityDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="14" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociateCAATVNameTextBox-onBlur', val) }"
                    v-bind="{ ...AssociateCAATVNameTextBox, ...configObject.AssociateCAATVNameTextBox }"
                    v-if="configObject.AssociateCAATVNameTextBox.isVisible"
                    :values="configObject.AssociateCAATVNameTextBox.atvNameValue" name="AssociateCAATVNameTextBox"
                    ref="refAssociateCAATVNameTextBox" />
                </el-col>
                <el-col :md="10" :lg="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociateCAProvinceTextBox-onBlur', val) }"
                    v-bind="{ ...AssociateCAProvinceTextBox, ...configObject.AssociateCAProvinceTextBox }"
                    v-if="configObject.AssociateCAProvinceTextBox.isVisible"
                    :values="configObject.AssociateCAProvinceTextBox.provinceValue" name="AssociateCAProvinceTextBox"
                    ref="refAssociateCAProvinceTextBox" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :md="8" :lg="7">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => { $emit('AssociateCAPostalCodeTextBox-onBlur', val) }"
                    v-bind="{ ...AssociateCAPostalCodeTextBox, ...configObject.AssociateCAPostalCodeTextBox }"
                    v-if="configObject.AssociateCAPostalCodeTextBox.isVisible"
                    :values="configObject.AssociateCAPostalCodeTextBox.postalCodeValue"
                    name="AssociateCAPostalCodeTextBox" ref="refAssociateCAPostalCodeTextBox" />
                </el-col>
                <el-col :md="3" :lg="3">
                  <GenericButton @GenericButton-onClick="$emit('AssociateSameAsAboveButton-onClick')"
                    name="AssociateSameAsAboveButton" ref="refAssociateSameAsAboveButton"
                    v-bind="{ ...AssociateSameAsAboveButton, ...configObject.AssociateSameAsAboveButton }"
                    v-if="configObject.AssociateSameAsAboveButton.isVisible" />
                </el-col>
                <el-col :md="3" :lg="2"></el-col>
                <el-col :md="10" :lg="12">
                  <GenericDropDown
                    @GenericDropDown-onChange="(val) => { $emit('AssociateCADistrictDropDown-onChange', val) }"
                    v-bind="{ ...AssociateCADistrictDropDown, ...configObject.AssociateCADistrictDropDown }"
                    v-if="configObject.AssociateCADistrictDropDown.isVisible"
                    :defaultValue="configObject.AssociateCADistrictDropDown.districtValue"
                    :values="configObject.AssociateCADistrictDropDown.list" name="AssociateCADistrictDropDown"
                    ref="refAssociateCADistrictDropDown" />
                </el-col>
              </el-row>
              <el-row>
                <el-col :lg="4" :md="4">
                  <el-form-item style="font-family: Arial, Helvetica, sans-serif;">Change of Address</el-form-item>
                </el-col>
                <el-col :lg="3" :md="3">
                  <GenericCheckBox
                    @GenericCheckBox-onChange="(val) => { $emit('AssociateChangeOfAddressCheckBox-onChange', val) }"
                    v-bind="{ ...AssociateChangeOfAddressCheckBox, ...configObject.AssociateChangeOfAddressCheckBox }"
                    v-if="configObject.AssociateChangeOfAddressCheckBox.isVisible"
                    :values="configObject.AssociateChangeOfAddressCheckBox.changeAddressValue"
                    name="AssociateChangeOfAddressCheckBox" ref="refAssociateChangeOfAddressCheckBox" />
                </el-col>
              </el-row>
            </fieldset>
            <label style="font-weight: bold;">Tagging CIF Entity with Entity Account(s)</label>
            <fieldset>
              <el-row>
                <el-col :lg="3" :md="3">
                  <GenericButton @GenericButton-onClick="$emit('TagCIFButton-onClick')" name="TagCIFButton"
                    ref="refTagCIFButton" v-bind="{ ...TagCIFButton, ...configObject.TagCIFButton }"
                    v-if="configObject.TagCIFButton.isVisible" />
                </el-col>
                <el-col :lg="2" :md="2"></el-col>
                <el-col :lg="2" :md="2">
                  <label class="cifText">{{ configObject.CIFText1.label }}</label><br>
                  <label class="cifText">{{ configObject.CIFText2.label }}</label>
                </el-col>
                <el-col :lg="4" :md="4"></el-col>
                <el-col :lg="10" :md="10">
                  <label style="font-family: Arial,Helvetica, sans-serif;">Hint: Tagging is mandatory</label>
                </el-col>
              </el-row>
            </fieldset>
          </el-tab-pane>
          <el-tab-pane v-if="configObject.KYC.isVisible" :disabled="configObject.KYC.isDisabled" label="KYC" name="seventh">
            <fieldset>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('SalaryAccountDropDown-onChange', val);
                  }" name="SalaryAccountDropDown" ref="refSalaryAccountDropDown"
                    v-bind="{ ...configObject.SalaryAccountDropDown, ...SalaryAccountDropDown }"
                    :values="configObject.SalaryAccountDropDown.SalaryAccountDropDownList"
                    v-if="configObject.SalaryAccountDropDown.isVisible" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <br>
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('IntroducerTypeDropDown-onChange', val);
                  }" name="IntroducerTypeDropDown" ref="refIntroducerTypeDropDown"
                    v-bind="{ ...configObject.IntroducerTypeDropDown, ...IntroducerTypeDropDown }"
                    :values="configObject.IntroducerTypeDropDown.IntroducerTypeDropDownList"
                    v-if="configObject.IntroducerTypeDropDown.isVisible" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('AccountPurposeDropDown-onChange', val);
                  }" name="AccountPurposeDropDown" ref="refAccountPurposeDropDown"
                    v-bind="{ ...configObject.AccountPurposeDropDown, ...AccountPurposeDropDown }"
                    :values="configObject.AccountPurposeDropDown.AccountPurposeDropDownList"
                    v-if="configObject.AccountPurposeDropDown.isVisible" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('PepDropDown-onChange', val);
                  }" name="PepDropDown" ref="refPepDropDown" v-bind="{ ...configObject.PepDropDown, ...PepDropDown }"
                    :values="configObject.PepDropDown.PepDropDownList" v-if="configObject.PepDropDown.isVisible" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('RelatedToPepDropDown-onChange', val);
                  }" name="RelatedToPepDropDown" ref="refRelatedToPepDropDown"
                    v-bind="{ ...configObject.RelatedToPepDropDown, ...RelatedToPepDropDown }"
                    :values="configObject.RelatedToPepDropDown.RelatedToPepDropDownList"
                    v-if="configObject.RelatedToPepDropDown.isVisible" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('CBBDropDown-onChange', val);
                  }" name="CBBDropDown" ref="refCBBDropDown" v-bind="{ ...configObject.CBBDropDown, ...CBBDropDown }"
                    :values="configObject.CBBDropDown.CBBDropDownList" v-if="configObject.CBBDropDown.isVisible" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('OriginalDSDropDown-onChange', val);
                  }" name="OriginalDSDropDown" ref="refOriginalDSDropDown"
                    v-bind="{ ...configObject.OriginalDSDropDown, ...OriginalDSDropDown }"
                    :values="configObject.OriginalDSDropDown.OriginalDSDropDownList"
                    v-if="configObject.OriginalDSDropDown.isVisible" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('SCTDropDown-onChange', val);
                  }" name="SCTDropDown" ref="refSCTDropDown" v-bind="{ ...configObject.SCTDropDown, ...SCTDropDown }"
                    :values="configObject.SCTDropDown.SCTDropDownList" v-if="configObject.SCTDropDown.isVisible" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('SFRDropDown-onChange', val);
                  }" name="SFRDropDown" ref="refSFRDropDown" v-bind="{ ...configObject.SFRDropDown, ...SFRDropDown }"
                    :values="configObject.SFRDropDown.SFRDropDownList" v-if="configObject.SFRDropDown.isVisible" />
                </el-col>
              </el-row>

            </fieldset>
            <br>
            <fieldset>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('AnnualSalaryTextBox-onBlur', val);
                  }
                    " ref="RefAnnualSalaryTextBox"
                    v-bind="{ ...AnnualSalaryTextBox, ...configObject.AnnualSalaryTextBox }"
                    :values="configObject.AnnualSalaryTextBox.AnnualSalaryTextBoxValue"
                    v-if="configObject.AnnualSalaryTextBox.isVisible" name="AnnualSalaryTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <br>
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('NoExpectedDepositsTextBox-onBlur', val);
                  }
                    " ref="RefNoExpectedDepositsTextBox"
                    v-bind="{ ...NoExpectedDepositsTextBox, ...configObject.NoExpectedDepositsTextBox }"
                    :values="configObject.NoExpectedDepositsTextBox.NoExpectedDepositsTextBoxValue"
                    v-if="configObject.NoExpectedDepositsTextBox.isVisible" name="NoExpectedDepositsTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('ExpectedDepositsTextBox-onBlur', val);
                  }
                    " ref="RefExpectedDepositsTextBox"
                    v-bind="{ ...ExpectedDepositsTextBox, ...configObject.ExpectedDepositsTextBox }"
                    :values="configObject.ExpectedDepositsTextBox.ExpectedDepositsTextBoxValue"
                    v-if="configObject.ExpectedDepositsTextBox.isVisible" name="ExpectedDepositsTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('NoExpectedWithdrawlsTextBox-onBlur', val);
                  }
                    " ref="RefNoExpectedWithdrawlsTextBox"
                    v-bind="{ ...NoExpectedWithdrawlsTextBox, ...configObject.NoExpectedWithdrawlsTextBox }"
                    :values="configObject.NoExpectedWithdrawlsTextBox.NoExpectedWithdrawlsTextBoxValue"
                    v-if="configObject.NoExpectedWithdrawlsTextBox.isVisible" name="NoExpectedWithdrawlsTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('ExpectedWithdrawlsTextBox-onBlur', val);
                  }
                    " ref="RefExpectedWithdrawlsTextBox"
                    v-bind="{ ...ExpectedWithdrawlsTextBox, ...configObject.ExpectedWithdrawlsTextBox }"
                    :values="configObject.ExpectedWithdrawlsTextBox.ExpectedWithdrawlsTextBoxValue"
                    v-if="configObject.ExpectedWithdrawlsTextBox.isVisible" name="ExpectedWithdrawlsTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('ExpectedBalanceTextBox-onBlur', val);
                  }
                    " ref="RefExpectedBalanceTextBox"
                    v-bind="{ ...ExpectedBalanceTextBox, ...configObject.ExpectedBalanceTextBox }"
                    :values="configObject.ExpectedBalanceTextBox.ExpectedBalanceTextBoxValue"
                    v-if="configObject.ExpectedBalanceTextBox.isVisible" name="ExpectedBalanceTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('RiskCategoryDropDown-onChange', val);
                  }" name="RiskCategoryDropDown" ref="refRiskCategoryDropDown"
                    v-bind="{ ...configObject.RiskCategoryDropDown, ...RiskCategoryDropDown }"
                    :values="configObject.RiskCategoryDropDown.RiskCategoryDropDownList"
                    v-if="configObject.RiskCategoryDropDown.isVisible" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="24" :md="24">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('TransactionReasonTextBox-onBlur', val);
                  }
                    " ref="RefTransactionReasonTextBox"
                    v-bind="{ ...TransactionReasonTextBox, ...configObject.TransactionReasonTextBox }"
                    :values="configObject.TransactionReasonTextBox.TransactionReasonTextBoxValue"
                    v-if="configObject.TransactionReasonTextBox.isVisible" name="TransactionReasonTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="24" :md="24">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('RemarksTextBox-onBlur', val);
                  }
                    " ref="RefRemarksTextBox" v-bind="{ ...RemarksTextBox, ...configObject.RemarksTextBox }"
                    :values="configObject.RemarksTextBox.RemarksTextBoxValue" v-if="configObject.RemarksTextBox.isVisible"
                    name="RemarksTextBox" />
                </el-col>
              </el-row>
            </fieldset>
          </el-tab-pane>
          <el-tab-pane v-if="configObject.FamilyInfo.isVisible" :disabled="configObject.FamilyInfo.isDisabled" label="Family Info" name="eight">
            <fieldset>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('SpouseNameTextBox-onBlur', val);
                  }
                    " ref="RefSpouseNameTextBox" v-bind="{ ...SpouseNameTextBox, ...configObject.SpouseNameTextBox }"
                    :values="configObject.SpouseNameTextBox.SpouseNameTextBoxValue"
                    v-if="configObject.SpouseNameTextBox.isVisible" name="SpouseNameTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <br>
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('NumberOfChildTextBox-onBlur', val);
                  }
                    " ref="RefNumberOfChildTextBox"
                    v-bind="{ ...NumberOfChildTextBox, ...configObject.NumberOfChildTextBox }"
                    :values="configObject.NumberOfChildTextBox.NumberOfChildTextBoxValue"
                    v-if="configObject.NumberOfChildTextBox.isVisible" name="NumberOfChildTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('OtherDependantsTextBox-onBlur', val);
                  }
                    " ref="RefOtherDependantsTextBox"
                    v-bind="{ ...OtherDependantsTextBox, ...configObject.OtherDependantsTextBox }"
                    :values="configObject.OtherDependantsTextBox.OtherDependantsTextBoxValue"
                    v-if="configObject.OtherDependantsTextBox.isVisible" name="OtherDependantsTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('MakeCarTextBox-onBlur', val);
                  }
                    " ref="RefMakeCarTextBox" v-bind="{ ...MakeCarTextBox, ...configObject.MakeCarTextBox }"
                    :values="configObject.MakeCarTextBox.MakeCarTextBoxValue" v-if="configObject.MakeCarTextBox.isVisible"
                    name="MakeCarTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('ModelTextBox-onBlur', val);
                  }
                    " ref="RefModelTextBox" v-bind="{ ...ModelTextBox, ...configObject.ModelTextBox }"
                    :values="configObject.ModelTextBox.ModelTextBoxValue" v-if="configObject.ModelTextBox.isVisible"
                    name="ModelTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('NRDropDown-onChange', val);
                  }" name="NRDropDown" ref="refNRDropDown" v-bind="{ ...configObject.NRDropDown, ...NRDropDown }"
                    :values="configObject.NRDropDown.NRDropDownList" v-if="configObject.NRDropDown.isVisible" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('TRDropDown-onChange', val);
                  }" name="TRDropDown" ref="refTRDropDown" v-bind="{ ...configObject.TRDropDown, ...TRDropDown }"
                    :values="configObject.TRDropDown.TRDropDownList" v-if="configObject.TRDropDown.isVisible" />
                </el-col>
              </el-row>

            </fieldset>

            <fieldset>
              <Legend style="font-family: Arial, Helvetica, sans-serif !important; font-weight: bold !important">
                Next of Kin
              </legend>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('NextKinTextBox-onBlur', val);
                  }
                    " ref="RefNextKinTextBox" v-bind="{ ...NextKinTextBox, ...configObject.NextKinTextBox }"
                    :values="configObject.NextKinTextBox.NextKinTextBox" v-if="configObject.NextKinTextBox.isVisible"
                    name="NextKinTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('RelationshipTextBox1-onBlur', val);
                  }
                    " ref="RefRelationshipTextBox"
                    v-bind="{ ...RelationshipTextBox1, ...configObject.RelationshipTextBox1 }"
                    :values="configObject.RelationshipTextBox1.RelationshipTextBoxValue"
                    v-if="configObject.RelationshipTextBox1.isVisible" name="RelationshipTextBox1" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('AddressTextBox1-onBlur', val);
                  }
                    " ref="RefAddressTextBox1" v-bind="{ ...AddressTextBox1, ...configObject.AddressTextBox1 }"
                    :values="configObject.AddressTextBox1.AddressTextBoxValue"
                    v-if="configObject.AddressTextBox1.isVisible" name="AddressTextBox1" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <CnicNumberNumericDashes15 @CnicNumberNumericDashes15-onBlur="(val) => {
                    $emit('CNICTextBox-onBlur', val);
                  }
                    " ref="RefCNICTextBox" v-bind="{ ...CNICTextBox, ...configObject.CNICTextBox }"
                    :values="configObject.CNICTextBox.CNICTextBoxValue" v-if="configObject.CNICTextBox.isVisible"
                    name="CNICTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('Address1TextBox-onBlur', val);
                  }
                    " ref="RefAddress1TextBox" v-bind="{ ...Address1TextBox, ...configObject.Address1TextBox }"
                    :values="configObject.Address1TextBox.Address1TextBoxValue"
                    v-if="configObject.Address1TextBox.isVisible" name="Address1TextBox" />
                </el-col>
                <el-col :lg="12" :md="12">

                </el-col>
              </el-row>

            </fieldset>

            <fieldset>
              <Legend style="font-family: Arial, Helvetica, sans-serif !important; font-weight: bold !important">
                Guardian (in case of Minor)
              </legend>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('GuardianTextBox1-onBlur', val);
                  }
                    " ref="RefGuardianTextBox1" v-bind="{ ...GuardianTextBox1, ...configObject.GuardianTextBox1 }"
                    :values="configObject.GuardianTextBox1.GuardianTextBoxValue"
                    v-if="configObject.GuardianTextBox1.isVisible" name="GuardianTextBox1" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('GRelationshipTextBox-onBlur', val);
                  }
                    " ref="RefGRelationshipTextBox"
                    v-bind="{ ...GRelationshipTextBox, ...configObject.GRelationshipTextBox }"
                    :values="configObject.GRelationshipTextBox.GRelationshipTextBoxValue"
                    v-if="configObject.GRelationshipTextBox.isVisible" name="GRelationshipTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('GAddressTextBox-onBlur', val);
                  }
                    " ref="RefGAddressTextBox" v-bind="{ ...GAddressTextBox, ...configObject.GAddressTextBox }"
                    :values="configObject.GAddressTextBox.GAddressTextBoxValue"
                    v-if="configObject.GAddressTextBox.isVisible" name="GAddressTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <CnicNumberNumericDashes15 @CnicNumberNumericDashes15-onBlur="(val) => {
                    $emit('GCNICTextBox-onBlur', val);
                  }
                    " ref="RefGCNICTextBox" v-bind="{ ...GCNICTextBox, ...configObject.GCNICTextBox }"
                    :values="configObject.GCNICTextBox.GCNICTextBoxValue" v-if="configObject.GCNICTextBox.isVisible"
                    name="GCNICTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">

                </el-col>
                <el-col :lg="12" :md="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                    $emit('ExpiryDateTextBox1-onBlur', val);
                  }
                    " ref="RefExpiryDateTextBox" v-bind="{ ...ExpiryDateTextBox1, ...configObject.ExpiryDateTextBox1 }"
                    :values="configObject.ExpiryDateTextBox1.ExpiryDateTextBoxValue"
                    v-if="configObject.ExpiryDateTextBox1.isVisible" name="ExpiryDateTextBox1" />

                </el-col>
              </el-row>

            </fieldset>

          </el-tab-pane>
          <el-tab-pane v-if="configObject.MinorCNICPassport.isVisible" :disabled="configObject.MinorCNICPassport.isDisabled" label="Minor CNIC Passport" name="nine">
            <fieldset>
              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('MCPIdTypeDropDown-onChange', val);
                  }" name="MCPIdTypeDropDown" ref="refMCPIdTypeDropDown"
                    v-bind="{ ...configObject.MCPIdTypeDropDown, ...MCPIdTypeDropDown }"
                    :values="configObject.MCPIdTypeDropDown.MCPIdTypeDropDownList"
                    v-if="configObject.MCPIdTypeDropDown.isVisible" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('MCPassportNumberTextBox-onBlur', val);
                  }
                    " ref="RefMCPassportNumberTextBox"
                    v-bind="{ ...MCPassportNumberTextBox, ...configObject.MCPassportNumberTextBox }"
                    :values="configObject.MCPassportNumberTextBox.MCPassportNumberTextBoxValue"
                    v-if="configObject.MCPassportNumberTextBox.isVisible" name="MCPassportNumberTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('MCPIdNoTextBox-onBlur', val);
                  }
                    " ref="RefMCPIdNoTextBox" v-bind="{ ...MCPIdNoTextBox, ...configObject.MCPIdNoTextBox }"
                    :values="configObject.MCPIdNoTextBox.MCPIdNoTextBoxValue" v-if="configObject.MCPIdNoTextBox.isVisible"
                    name="MCPIdNoTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('MCPlaceOfIssuetextBox-onBlur', val);
                  }
                    " ref="RefMCPlaceOfIssuetextBox"
                    v-bind="{ ...MCPlaceOfIssuetextBox, ...configObject.MCPlaceOfIssuetextBox }"
                    :values="configObject.MCPlaceOfIssuetextBox.MCPlaceOfIssuetextBoxValue"
                    v-if="configObject.MCPlaceOfIssuetextBox.isVisible" name="MCPlaceOfIssuetextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                    $emit('MCPIssuanceDateTextBox-onBlur', val);
                  }
                    " ref="RefMCPIssuanceDateTextBox"
                    v-bind="{ ...MCPIssuanceDateTextBox, ...configObject.MCPIssuanceDateTextBox }"
                    :values="configObject.MCPIssuanceDateTextBox.MCPIssuanceDateTextBoxValue"
                    v-if="configObject.MCPIssuanceDateTextBox.isVisible" name="MCPIssuanceDateTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                    $emit('MCPassportExpiryDateTextBox-onBlur', val);
                  }
                    " ref="RefMCPassportEntryDateTextBox"
                    v-bind="{ ...MCPassportExpiryDateTextBox, ...configObject.MCPassportExpiryDateTextBox }"
                    :values="configObject.MCPassportExpiryDateTextBox.MCPassportExpiryDateTextBoxValue"
                    v-if="configObject.MCPassportExpiryDateTextBox.isVisible" name="MCPassportExpiryDateTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                    $emit('MCPExpiryDateTextBox-onBlur', val);
                  }
                    " ref="RefMCPExpiryDateTextBox"
                    v-bind="{ ...MCPExpiryDateTextBox, ...configObject.MCPExpiryDateTextBox }"
                    :values="configObject.MCPExpiryDateTextBox.MCPExpiryDateTextBoxValue"
                    v-if="configObject.MCPExpiryDateTextBox.isVisible" name="MCPExpiryDateTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                    $emit('MCPassportIssueDateTextBox-onBlur', val);
                  }
                    " ref="RefMCPassportIssueDateTextBox"
                    v-bind="{ ...MCPassportIssueDateTextBox, ...configObject.MCPassportIssueDateTextBox }"
                    :values="configObject.MCPassportIssueDateTextBox.MCPassportIssueDateTextBoxValue"
                    v-if="configObject.MCPassportIssueDateTextBox.isVisible" name="MCPassportIssueDateTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('MCPFamilyNoTextBox-onBlur', val);
                  }
                    " ref="RefMCPFamilyNoTextBox"
                    v-bind="{ ...MCPFamilyNoTextBox, ...configObject.MCPFamilyNoTextBox }"
                    :values="configObject.MCPFamilyNoTextBox.MCPFamilyNoTextBoxValue"
                    v-if="configObject.MCPFamilyNoTextBox.isVisible" name="MCPFamilyNoTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('MCPCnicIdMarkTextBox-onBlur', val);
                  }
                    " ref="RefMCPCnicIdMarkTextBox"
                    v-bind="{ ...MCPCnicIdMarkTextBox, ...configObject.MCPCnicIdMarkTextBox }"
                    :values="configObject.MCPCnicIdMarkTextBox.MCPCnicIdMarkTextBoxValue"
                    v-if="configObject.MCPCnicIdMarkTextBox.isVisible" name="MCPCnicIdMarkTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <CnicNumberNumericDashes15 @CnicNumberNumericDashes15-onBlur="(val) => {
                    $emit('MCPOldNicTextBox-onBlur', val);
                  }
                    " ref="RefMCPOldNicTextBox" v-bind="{ ...MCPOldNicTextBox, ...configObject.MCPOldNicTextBox }"
                    :values="configObject.MCPOldNicTextBox.MCPOldNicTextBoxValue"
                    v-if="configObject.MCPOldNicTextBox.isVisible" name="MCPOldNicTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('MCPCountryOfBirthDropDown-onChange', val);
                  }" name="MCPCountryOfBirthDropDown" ref="refMCPCountryOfBirthDropDown"
                    v-bind="{ ...configObject.MCPCountryOfBirthDropDown, ...MCPCountryOfBirthDropDown }"
                    :values="configObject.MCPCountryOfBirthDropDown.MCPCountryOfBirthDropDownList"
                    v-if="configObject.MCPCountryOfBirthDropDown.isVisible" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericDropDown @GenericDropDown-onChange="(val) => {
                    $emit('MCPlaceOfIssueDropDown-onChange', val);
                  }" name="MCPlaceOfIssueDropDown" ref="refMCPlaceOfIssueDropDown"
                    v-bind="{ ...configObject.MCPlaceOfIssueDropDown, ...MCPlaceOfIssueDropDown }"
                    :values="configObject.MCPlaceOfIssueDropDown.MCPlaceOfIssueDropDownList"
                    v-if="configObject.MCPlaceOfIssueDropDown.isVisible" />
                </el-col>
              </el-row>
            </fieldset>
          </el-tab-pane>
          <el-tab-pane v-if="configObject.PropOtherInfo.isVisible" :disabled="configObject.PropOtherInfo.isDisabled" label="Prop Other Info" name="ten">
            <fieldset>
              <el-row>
                <el-col :lg="12" :md="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                    $emit('YSCnicExpiryDateTextBox-onBlur', val);
                  }
                    " ref="RefYSCnicExpiryDateTextBox"
                    v-bind="{ ...YSCnicExpiryDateTextBox, ...configObject.YSCnicExpiryDateTextBox }"
                    :values="configObject.YSCnicExpiryDateTextBox.YSCnicExpiryDateTextBoxValue"
                    v-if="configObject.YSCnicExpiryDateTextBox.isVisible" name="YSCnicExpiryDateTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('YSPassportPlaceIssueTextBox-onBlur', val);
                  }
                    " ref="RefYSPassportPlaceIssueTextBox"
                    v-bind="{ ...YSPassportPlaceIssueTextBox, ...configObject.YSPassportPlaceIssueTextBox }"
                    :values="configObject.YSPassportPlaceIssueTextBox.YSPassportPlaceIssueTextBoxValue"
                    v-if="configObject.YSPassportPlaceIssueTextBox.isVisible" name="YSPassportPlaceIssueTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                    $emit('YSPassportExpiryDateTextBox-onBlur', val);
                  }
                    " ref="RefYSPassportExpiryDateTextBox"
                    v-bind="{ ...YSPassportExpiryDateTextBox, ...configObject.YSPassportExpiryDateTextBox }"
                    :values="configObject.YSPassportExpiryDateTextBox.YSPassportExpiryDateTextBoxValue"
                    v-if="configObject.YSPassportExpiryDateTextBox.isVisible" name="YSPassportExpiryDateTextBox" />
                </el-col>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('YSMotherNameTextBox-onBlur', val);
                  }
                    " ref="RefYSMotherNameTextBox"
                    v-bind="{ ...YSMotherNameTextBox, ...configObject.YSMotherNameTextBox }"
                    :values="configObject.YSMotherNameTextBox.YSMotherNameTextBoxValue"
                    v-if="configObject.YSMotherNameTextBox.isVisible" name="YSMotherNameTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('YSPassportPlaceIssue1TextBox-onBlur', val);
                  }
                    " ref="RefYSPassportPlaceIssue1TextBox"
                    v-bind="{ ...YSPassportPlaceIssue1TextBox, ...configObject.YSPassportPlaceIssue1TextBox }"
                    :values="configObject.YSPassportPlaceIssue1TextBox.YSPassportPlaceIssue1TextBoxValue"
                    v-if="configObject.YSPassportPlaceIssue1TextBox.isVisible" name="YSPassportPlaceIssue1TextBox" />
                </el-col>
                <el-col :lg="7" :md="7">
                  <GenericCheckBox name="YSOtherNationalsCheckBox" @GenericCheckBox-onChange="(val) => {
                    $emit('YSOtherNationalsCheckBox-onChange', val);
                  }
                    " ref="refYSOtherNationalsCheckBox"
                    v-bind="{ ...YSOtherNationalsCheckBox, ...configObject.YSOtherNationalsCheckBox }"
                    :values="configObject.YSOtherNationalsCheckBox.YSOtherNationalsCheckBoxValue"
                    v-if="configObject.YSOtherNationalsCheckBox.isVisible" />
                </el-col>
                <el-col :lg="3" :md="3">
                  <GenericButton name="YSAddViewButton" @GenericButton-onClick="$emit('YSAddViewButton-onClick')"
                    ref="refYSAddViewButton" v-bind="{ ...YSAddViewButton, ...configObject.YSAddViewButton }"
                    v-if="configObject.YSAddViewButton.isVisible" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <DateDdMmYyyy @DateDdMmYyyy-onBlur="(val) => {
                    $emit('YSDobDateTextBox-onBlur', val);
                  }
                    " ref="RefDobDateTextBox" v-bind="{ ...YSDobDateTextBox, ...configObject.YSDobDateTextBox }"
                    :values="configObject.YSDobDateTextBox.YSDobDateTextBoxValue"
                    v-if="configObject.YSDobDateTextBox.isVisible" name="YSDobDateTextBox" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="6" :md="6">
                  <GenericCheckBox name="YSOtherNationals1CheckBox" @GenericCheckBox-onChange="(val) => {
                    $emit('YSOtherNationals1CheckBox-onChange', val);
                  }
                    " ref="refYSOtherNationals1CheckBox"
                    v-bind="{ ...YSOtherNationals1CheckBox, ...configObject.YSOtherNationals1CheckBox }"
                    :values="configObject.YSOtherNationals1CheckBox.YSOtherNationals1CheckBoxValue"
                    v-if="configObject.YSOtherNationals1CheckBox.isVisible" />
                </el-col>
                <el-col :lg="3" :md="3">
                  <GenericButton name="YSAddButton" @GenericButton-onClick="$emit('YSAddButton-onClick')"
                    ref="refYSAddButton" v-bind="{ ...YSAddButton, ...configObject.YSAddButton }"
                    v-if="configObject.YSAddButton.isVisible" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="6" :md="6">
                  <el-form-item style=" font-family:Arial" v-if="configObject.CheckBoxLabel.isVisible">{{
                    configObject.CheckBoxLabel.label }}
                  </el-form-item>
                </el-col>
                <el-col :lg="6" :md="6">
                  <GenericCheckBox name="YSCurrentAddressCheckBox" @GenericCheckBox-onChange="(val) => {
                    $emit('YSCurrentAddressCheckBox-onChange', val);
                  }
                    " ref="refYSCurrentAddressCheckBox"
                    v-bind="{ ...YSCurrentAddressCheckBox, ...configObject.YSCurrentAddressCheckBox }"
                    :values="configObject.YSCurrentAddressCheckBox.YSCurrentAddressCheckBoxValue"
                    v-if="configObject.YSCurrentAddressCheckBox.isVisible" />
                </el-col>
                <el-col :lg="6" :md="6">
                  <GenericCheckBox name="YSPermanentAddressCheckBox" @GenericCheckBox-onChange="(val) => {
                    $emit('YSPermanentAddressCheckBox-onChange', val);
                  }
                    " ref="refYSPermanentAddressCheckBox"
                    v-bind="{ ...YSPermanentAddressCheckBox, ...configObject.YSPermanentAddressCheckBox }"
                    :values="configObject.YSPermanentAddressCheckBox.YSPermanentAddressCheckBoxValue"
                    v-if="configObject.YSPermanentAddressCheckBox.isVisible" />
                </el-col>
                <el-col :lg="6" :md="6">
                  <GenericCheckBox name="YSOfficeBusinessCheckBox" @GenericCheckBox-onChange="(val) => {
                    $emit('YSOfficeBusinessCheckBox-onChange', val);
                  }
                    " ref="refYSOfficeBusinessCheckBox"
                    v-bind="{ ...YSOfficeBusinessCheckBox, ...configObject.YSOfficeBusinessCheckBox }"
                    :values="configObject.YSOfficeBusinessCheckBox.YSOfficeBusinessCheckBoxValue"
                    v-if="configObject.YSOfficeBusinessCheckBox.isVisible" />
                </el-col>
              </el-row>

              <el-row>
                <el-col :lg="12" :md="12">
                  <GenericTextBox @GenericTextBox-onBlur="(val) => {
                    $emit('YSStnNoTextBox-onBlur', val);
                  }
                    " ref="RefYSStnNoTextBox" v-bind="{ ...YSStnNoTextBox, ...configObject.YSStnNoTextBox }"
                    :values="configObject.YSStnNoTextBox.YSStnNoTextBoxValue" v-if="configObject.YSStnNoTextBox.isVisible"
                    name="YSStnNoTextBox" />
                </el-col>
              </el-row>
            </fieldset>
          </el-tab-pane>

          <fieldset>
            <el-row :gutter="10">
              <el-col :md="3" :lg="3">
                <GenericButton @GenericButton-onClick="$emit('OkButton-onClick')" name="OkButton" ref="refOkButton"
                  v-bind="{ ...OkButton, ...configObject.OkButton }" v-if="configObject.OkButton.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('JointCustInfoButton1-onClick')" name="JointCustInfoButton1"
                  ref="refJointCustInfoButton1" v-bind="{ ...JointCustInfoButton1, ...configObject.JointCustInfoButton1 }"
                  v-if="configObject.JointCustInfoButton1.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('DirectorInfoButton-onClick')" name="DirectorInfoButton"
                  ref="refDirectorInfoButton" v-bind="{ ...DirectorInfoButton, ...configObject.DirectorInfoButton }"
                  v-if="configObject.DirectorInfoButton.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('TrusteeInfoButton-onClick')" name="TrusteeInfoButton"
                  ref="refTrusteeInfoButton" v-bind="{ ...TrusteeInfoButton, ...configObject.TrusteeInfoButton }"
                  v-if="configObject.TrusteeInfoButton.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('PartnersInfoButton-onClick')" name="PartnersInfoButton"
                  ref="refPartnersInfoButton" v-bind="{ ...PartnersInfoButton, ...configObject.PartnersInfoButton }"
                  v-if="configObject.PartnersInfoButton.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('ProprietersInfo1-onClick')" name="ProprietersInfo1"
                  ref="refProprietersInfo1" v-bind="{ ...ProprietersInfo1, ...configObject.ProprietersInfo1 }"
                  v-if="configObject.ProprietersInfo1.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('MembersInfoButton-onClick')" name="MembersInfoButton"
                  ref="refMembersInfoButton" v-bind="{ ...MembersInfoButton, ...configObject.MembersInfoButton }"
                  v-if="configObject.MembersInfoButton.isVisible" />
              </el-col>
              <el-col :md="3" :lg="3">
                <GenericButton @GenericButton-onClick="$emit('ProprietersInfo-onClick')" name="ProprietersInfo"
                  ref="refProprietersInfo" v-bind="{ ...ProprietersInfo, ...configObject.ProprietersInfo }"
                  v-if="configObject.ProprietersInfo.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('DirectorInfoButton1-onClick')" name="DirectorInfoButton1"
                  ref="refDirectorInfoButton1" v-bind="{ ...DirectorInfoButton1, ...configObject.DirectorInfoButton1 }"
                  v-if="configObject.DirectorInfoButton1.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('PartnersInfoButton1-onClick')" name="PartnersInfoButton1"
                  ref="refPartnersInfoButton1" v-bind="{ ...PartnersInfoButton1, ...configObject.PartnersInfoButton1 }"
                  v-if="configObject.PartnersInfoButton1.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('MembersInfoButton1-onClick')" name="MembersInfoButton1"
                  ref="refMembersInfoButton1" v-bind="{ ...MembersInfoButton1, ...configObject.MembersInfoButton1 }"
                  v-if="configObject.MembersInfoButton1.isVisible" />
                <GenericButton @GenericButton-onClick="$emit('TrusteeInfoButton1-onClick')" name="TrusteeInfoButton1"
                  ref="refTrusteeInfoButton1" v-bind="{ ...TrusteeInfoButton1, ...configObject.TrusteeInfoButton1 }"
                  v-if="configObject.TrusteeInfoButton1.isVisible" />
              </el-col>
              <el-col :md="4" :lg="3">
                <GenericButton @GenericButton-onClick="$emit('JointCustInfoButton-onClick')" name="JointCustInfoButton"
                  ref="refJointCustInfoButton" v-bind="{ ...JointCustInfoButton, ...configObject.JointCustInfoButton }"
                  v-if="configObject.JointCustInfoButton.isVisible" />
              </el-col>
              <el-col :md="2" :lg="2"></el-col>
              <el-col :md="3" :lg="3">
                <GenericButton @GenericButton-onClick="$emit('SMSAlertButton-onClick')" name="SMSAlertButton"
                  ref="refSMSAlertButton" v-bind="{ ...SMSAlertButton, ...configObject.SMSAlertButton }"
                  v-if="configObject.SMSAlertButton.isVisible" />
              </el-col>
              <el-col :md="1" :lg="1"></el-col>
              <el-col :md="3" :lg="3">
                <GenericButton @GenericButton-onClick="$emit('SignatureButton-onClick')" name="SignatureButton"
                  ref="refSignatureButton" v-bind="{ ...SignatureButton, ...configObject.SignatureButton }"
                  v-if="configObject.SignatureButton.isVisible" />
              </el-col>
              <el-col :md="2" :lg="3"></el-col>
              <el-col :md="3" :lg="3">
                <GenericButton @GenericButton-onClick="$emit('BackButton-onClick')" name="BackButton" ref="refBackButton"
                  v-bind="{ ...BackButton, ...configObject.BackButton }" v-if="configObject.BackButton.isVisible" />
              </el-col>
            </el-row>
          </fieldset>
        </el-tabs>
      </el-col>
    </el-row> -->
  </Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import {
  GenericTextBox,
  GenericButton,
  GenericDatePicker,
  CurrencyAlphaNumericSpecial25,
  GenericSortableTableView,
  FinancialInstrumentAlphaNumericSpecialDashes23,
  AccountNumberWithoutBranchCodeNumericDashes16,
  NtnNumericDashes9,
  AccountTitleString45,
  AmountNumericDecimal15Point2,
  GenericRadioButton,
  DateDdMmYyyy,
  RateNumericDecimal3Point2,
  AmountNumericDecimal11Point3,
  GenericCompositeAlphaNumericSpecialWithButton,
  GenericDropDown
} from '@teresol-v2/ui-components';
import { reactive } from 'vue';
export default {
  name: 'MegaSet0001',

  components: {
    Form,
    GenericTextBox,
    GenericDatePicker,
    CurrencyAlphaNumericSpecial25,
    GenericSortableTableView,
    GenericButton,
    FinancialInstrumentAlphaNumericSpecialDashes23,
    AccountNumberWithoutBranchCodeNumericDashes16,
    NtnNumericDashes9,
    AccountTitleString45,
    AmountNumericDecimal15Point2,
    GenericRadioButton,
    DateDdMmYyyy,
    RateNumericDecimal3Point2,
    AmountNumericDecimal11Point3,
    GenericCompositeAlphaNumericSpecialWithButton,
    GenericDropDown
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive({
      ...props.configObj.componentProps
    });
    return {
      onSubmit,
      configObject,
      FinancialInstrumentNoTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      FinancialInstrumentAmountTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      FinancialInstrumentInCurrencyTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      SumOfGDConsValTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      CertificationDateTextBox: {
        spanInputs: 12,
        spanLabels: 12
      },
      AlphaNumericSpecialWithButton: {
        spanInputs: 12,
        spanLabels: 12
      },
      TermOfContractTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      TenorTextBox: {
        spanInputs: 9,
        spanLabels: 13
      },
      TenorPercentTextBox: {
        spanInputs: 12,
        spanLabels: 12
      },
      Advance: {
        spanInputs: 15,
        spanLabels: 8
      },
      SightDPTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },
      UsanceDATextBox: {
        spanInputs: 9,
        spanLabels: 13
      },
      FinancialInInfoTable1: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 0,
        tableHeight: '200px',
        tableWidth: '100',
        tableLabel: ''
      },
      FinancialInInfoTable2: {
        spanInputs: 24, // this property to be set on screen level
        spanLabels: 0,
        tableHeight: '200px',
        tableWidth: '100',
        tableLabel: ''
      },
      OkButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      ExitButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      LinkButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      UnLinkButton: {
        spanInputs: 24,
        nativeType: 'button'
      },
      // ////////////////////////////////////////////////////////////////
      AccountNumberTextBox: {
        spanInputs: 16,
        spanLabel: 2
      },
      NtnNumberTextBox: {
        spanInputs: 15,
        spanLabels: 9
      },
      AccountTitleTextBox: {
        spanInputs: 16,
        spanLabel: 2
      },
      CCINumberTextBox: {
        spanInputs: 15,
        spanLabels: 9
      },
      //bills info tab
      LDBC_AccountNumberTextBox: {
        spanInputs: 15,
        spanLabels: 9
      },

      LDBP_AccountNumberTextBox: {
        spanInputs: 15,
        spanLabels: 9
      },
      DateTextBox: {
        spanInputs: 14,
        spanLabels: 5
      },
      ContractLCRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },

      ExportSalesRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },
      TermTextBox: {
        spanInputs: 18,
        spanLabels: 5
      },

      TenorDaysTextBox: {
        spanInputs: 15,
        spanLabels: 8
      },

      DateRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },
      ShipDateTextBox: {
        spanInputs: 14,
        spanLabels: 10
      },

      DueDateTextBox: {
        spanInputs: 14,
        spanLabels: 10
      },

      BankTextBox: {
        spanInputs: 20,
        spanLabels: 4
      },
      BranchTextBox: {
        spanInputs: 20,
        spanLabels: 4
      },

      BeneficiaryBuyerRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },
      RoadRailRadioButton: {
        spanInputs: 10,
        spanLabels: 0
      },

      DiscountInfoDays: {
        spanInputs: 12,
        spanLabels: 7
      },

      RateTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },

      BuyerTextBox: {
        spanInputs: 17,
        spanLabels: 6
      },

      BillAmountTextBox1: {
        spanInputs: 17,
        spanLabels: 6
      },

      BalanceAmountTextBox1: {
        spanInputs: 17,
        spanLabels: 6
      },
      CommodityTextBox: {
        spanInputs: 17,
        spanLabels: 6
      },

      OriginTextBox: {
        spanInputs: 17,
        spanLabels: 6
      },

      DestinationTextBox: {
        spanInputs: 17,
        spanLabels: 6
      },
      InvoiveNumberTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },

      InvoiceAmountTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      InvoiceDateTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },

      CourierRefTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      CourierAmountTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      CourierDateTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      //Instrument Info tab
      BillAmountTextBox2: {
        spanInputs: 16,
        spanLabels: 8
      },
      BalanceAmountTextBox2: {
        spanInputs: 16,
        spanLabels: 8
      },
      InstrumentBalAmountTextBox: {
        spanInputs: 16,
        spanLabels: 8
      },
      SBPChequeDDPORadioButton: {
        spanInputs: 23,
        spanLabels: 1
      },
      InstTypeTextBox: {
        spanInputs: 18,
        spanLabels: 6
      },
      InstNoTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      InstAmountTextBox: {
        spanInputs: 18,
        spanLabels: 6
      },
      InstDateTextBox: {
        spanInputs: 16,
        spanLabels: 8
      },
      MaturityTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      BillAmountTextBox3: {
        spanInputs: 12,
        spanLabels: 8
      },
      ReversedAmountTextBox: {
        spanInputs: 17,
        spanLabels: 7
      },
      ConvertedAmountTextBox: {
        spanInputs: 12,
        spanLabels: 8
      },
      OKButton: {
        spanInputs: 23
      },
      BackButton: {
        spanInputs: 23
      },
      ExitButton: {
        spanInputs: 24
      },
      ReturnButton: {
        spanInputs: 23
      },
      CancelButton: {
        spanInputs: 23
      },
      DuplicateCDRNoTextBox: { spanInputs: 12, spanLabels: 6 },
      CDRNoTextBox: { spanInputs: 12, spanLabels: 6 },
      IssuingDate: { spanInputs: 12, spanLabels: 6 },
      AmountTextBox: { spanInputs: 12, spanLabels: 6 },
      BeneficiaryTextBox: { spanInputs: 17, spanLabels: 6 },
      RemarksTextBox: { spanInputs: 17, spanLabels: 6 },
      NoLabelTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusIDTextBox: { spanInputs: 17, spanLabels: 6 },
      StatusDate: { spanInputs: 17, spanLabels: 6 },
      RenewedTextBox: { spanInputs: 17, spanLabels: 6 },
      ModeOfPayment: { spanInputs: 17, spanLabels: 6 },
      ProcessOrgButton: { spanInputs: 21 },
      ProcessDupButton: { spanInputs: 23 },
      ProcessDupCDRButton: { spanInputs: 23 },
      BackButton: { spanInputs: 23 },
      ExitButton: { spanInputs: 23 }
    };
  }
};
</script>
<style>
.el-tabs__nav {
  white-space: normal !important;
}
</style>
