<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row>
      <el-col :md="24" :lg="24">
        <GenericSortableTableView
          @GenericSortableTableView-onCurrentRow="
            (val) => {
              $emit('ExportVoucherTableView-onCurrentRow', val);
            }
          "
          @GenericSortableTableView-onDoubleClickRow="
            (val) => {
              $emit('ExportVoucherTableView-onDoubleClickRow', val);
            }
          "
          @GenericSortableTableView-onClickRow="
            (val) => {
              $emit('ExportVoucherTableView-onClickRow', val);
            }
          "
          name="ExportVoucherTableView"
          ref="RefExportVoucherTableView"
          v-if="configObject.ExportVoucherTableView != undefined ? configObject.ExportVoucherTableView.isVisible : false"
          v-bind="{ ...ExportVoucherTableView, ...configObject.ExportVoucherTableView }"
        />
      </el-col>
    </el-row>
    <el-row>
      <el-col :sm="20" :md="20" :lg="20">
        <fieldset v-if="configObject.section1 != undefined ? configObject.section1.isVisible : false">
          <el-row>
            <el-col :sm="4" :md="4" :lg="4">
              <GenericButton
                @GenericButton-onClick="$emit('ViewVoucherButton-onClick')"
                @GenericButton-onFocus="$emit('ViewVoucherButton-onFocus')"
                name="ViewVoucherButton"
                ref="RefViewVoucherButton"
                v-if="configObject.ViewVoucherButton != undefined ? configObject.ViewVoucherButton.isVisible : false"
                v-bind="{
                  ...ViewVoucherButton,
                  ...configObject.ViewVoucherButton
                }"
              />
            </el-col>
            <el-col :sm="4" :md="4" :lg="4">
              <GenericButton
                @GenericButton-onClick="$emit('ViewAdviceButton-onClick')"
                @GenericButton-onFocus="$emit('ViewAdviceButton-onFocus')"
                name="ViewAdviceButton"
                ref="RefViewAdviceButton"
                v-if="configObject.ViewAdviceButton != undefined ? configObject.ViewAdviceButton.isVisible : false"
                v-bind="{
                  ...ViewAdviceButton,
                  ...configObject.ViewAdviceButton
                }"
              />
            </el-col>
            <el-col :sm="4" :md="4" :lg="4">
              <GenericButton
                @GenericButton-onClick="$emit('ViewAmendmentsButton-onClick')"
                @GenericButton-onFocus="$emit('ViewAmendmentsButton-onFocus')"
                name="ViewAmendmentsButton"
                ref="RefViewAmendmentsButton"
                v-if="configObject.ViewAmendmentsButton != undefined ? configObject.ViewAmendmentsButton.isVisible : false"
                v-bind="{
                  ...ViewAmendmentsButton,
                  ...configObject.ViewAmendmentsButton
                }"
              />
            </el-col>
            <el-col :sm="9" :md="9" :lg="9"></el-col>
            <el-col  :sm="3" :md="3" :lg="3">
              <GenericButton
                @GenericButton-onClick="$emit('OkButton-onClick')"
                @GenericButton-onFocus="$emit('OkButton-onFocus')"
                name="OkButton"
                ref="RefOkButton"
                v-if="configObject.OkButton != undefined ? configObject.OkButton.isVisible : false"
                v-bind="{
                  ...OkButton,
                  ...configObject.OkButton
                }"
              />
            </el-col>
          </el-row>
        </fieldset>
      </el-col>
    </el-row>
  </Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import { reactive } from 'vue';

import { GenericSortableTableView, GenericButton } from '@teresol-v2/ui-components';
export default {
  name: 'MegaSet1157',

  components: {
    Form,
    GenericSortableTableView,
    GenericButton
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive({
      ...props.configObj.componentProps
    });

    return {
      onSubmit,
      configObject,
      ExportVoucherTableView: {
        spanLabels: 0,
        spanInputs: 20
      },
      OkButton: {
        spanInputs: 24
      },
      ViewVoucherButton: {
        spanInputs: 22
      },
      ViewAdviceButton: {
        spanInputs: 22
      },
      ViewAmendmentsButton: {
        spanInputs: 24
      }
    };
  }
};
</script>
