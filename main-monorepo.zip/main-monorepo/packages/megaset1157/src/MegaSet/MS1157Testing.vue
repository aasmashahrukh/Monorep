<template>
  <MegaSet1157
    :configObj="configurationObject"
    @onSubmit="onSubmit"
    @ExportVoucherTableView-onCurrentRow="ExportVoucherTableViewOnCurrentRow"
    @OkButton-onClick="OkButtonOnClick"
    @ViewVoucherButton-onClick="ViewVoucherButtonOnClick"
    @ViewAdviceButton-onClick="ViewAdviceButtonOnClick"
     @ViewAmendmentsButton-onClick="ViewAmendmentsButtonOnClick"
  />
</template>
<script>
import MegaSet1157 from '../MegaSet/MegaSet1157.vue';
import { reactive } from 'vue';
export default {
  components: {
    MegaSet1157
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    },
    ExportVoucherTableViewOnCurrentRow(val) {
      console.log('ExportVoucherTableViewOnCurrentRow', val);
    },
    OkButtonOnClick() {
      console.log('OkButtonOnClick');
    },
    ViewVoucherButtonOnClick() {
      console.log('ViewVoucherButtonOnClick');
    },
    ViewAdviceButtonOnClick() {
      console.log('ViewAdviceButtonOnClick');
    },
    ViewAmendmentsButtonOnClick() {
      console.log('ViewAmendmentsButtonOnClick');
    }
  },
  setup() {
    return reactive({
      configurationObject: {
        componentProps: {
          ExportVoucherTableView: {
            tableWidth: 250,
            tableHeight: '350px',
            ExportVoucherTableViewTableData: [
              {
                vouch_no: '123',
                vouch_dt: '123/1111',
                description: 'Karachi',
                amount: '1112',
                status: 'yes',
                sett_method: '124',
                advice_branch: 'desf',
                advice_no: '12s4',
                date: '21/11/23',
                advice_date: '22/1/2023',
                trans_currency: 'efdr',
                advice_currency: 'dfrd',
                amount: '123',
                id_type: '12ed',
                identification_no: '124frd',
                remitting_inst: 'kdheh',
                iban_account_no: '890cjwk'
              }
            ],
            tableColumns: [
              {
                prop: 'vouch_no',
                label: 'Vouch No.',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'vouch_dt',
                label: 'Vouch Dt',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'description',
                label: 'Description',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'amount',
                label: 'Amount',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'status',
                label: 'Status',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'sett_method',
                label: 'Sett. Method',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'advice_branch',
                label: 'Advice Branch',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'advice_no',
                label: 'Advice No.',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'date',
                label: 'Date',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'advice_date',
                label: 'Advice Date',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'trans_currency',
                label: 'Tran. Currency',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'advice_currency',
                label: 'Advice Currency',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'amount',
                label: 'Amount',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'id_type',
                label: 'ID Type',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'identification_no',
                label: 'Identification No.',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'remitting_inst',
                label: 'Remitting Inst.',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'iban_account_no',
                label: 'IBAN/Account NO',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'exch_rate',
                label: 'Exch rate',
                align: 'center',
                columnsWidth: '10'
              },
              {
                prop: 'loc_eqv',
                label: 'Loc Eqv',
                align: 'center',
                columnsWidth: '10'
              }
            ],
            isDisabled: false,
            isVisible: true
          },
          OkButton: {
            isDisabled: false,
            isVisible: true,
            nativeType: 'Button',
            label: 'Ok'
          },

          ViewVoucherButton: {
            isDisabled: false,
            isVisible: true,
            nativeType: 'Button',
            label: 'View Voucher'
          },
          ViewAdviceButton: {
            isDisabled: false,
            isVisible: true,
            nativeType: 'Button',
            label: 'View Advice'
          },
           ViewAmendmentsButton: {
            isDisabled: false,
            isVisible: true,
            nativeType: 'Button',
            label: 'View Amendments'
          },

          section1: {
            isVisible: true
          }
        }
      }
    });
  }
};
</script>
