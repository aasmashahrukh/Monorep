// MegaSet1157.stories.js

import MegaSet1157 from '../MegaSet/MegaSet1157.vue';
import { ref } from 'vue';
import { action, config } from '@storybook/addon-actions';

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: 'MegaSet1157',
  component: MegaSet1157
};

const configurationObject = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          vouch_dt: '123/1111',
          description: 'Karachi',
          amount: '1112',
          status: 'yes',
          sett_method: '124',
          advice_branch: 'desf',
          advice_no: '12s4',
          date: '21/11/23',
          advice_date: '22/1/2023',
          trans_currency: 'efdr',
          advice_currency: 'dfrd',
          amount: '123',
          id_type: '12ed',
          identification_no: '124frd',
          remitting_inst: 'kdheh',
          iban_account_no: '890cjwk'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'vouch_dt',
          label: 'Vouch Dt',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'sett_method',
          label: 'Sett. Method',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_branch',
          label: 'Advice Branch',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_no',
          label: 'Advice No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_date',
          label: 'Advice Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'trans_currency',
          label: 'Tran. Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_currency',
          label: 'Advice Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'id_type',
          label: 'ID Type',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'identification_no',
          label: 'Identification No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'remitting_inst',
          label: 'Remitting Inst.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'iban_account_no',
          label: 'IBAN/Account NO',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'exch_rate',
          label: 'Exch rate',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'loc_eqv',
          label: 'Loc Eqv',
          align: 'center',
          columnsWidth: '10'
        }
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};

const configurationObject_SS_174_Set1 = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          vouch_dt: '123/1111',
          description: 'Karachi',
          amount: '1112',
          status: 'yes',
          sett_method: '124',
          advice_branch: 'desf',
          advice_no: '12s4',
          date: '21/11/23',
          advice_date: '22/1/2023',
          trans_currency: 'efdr',
          advice_currency: 'dfrd',
          amount: '123',
          id_type: '12ed',
          identification_no: '124frd',
          remitting_inst: 'kdheh',
          iban_account_no: '890cjwk'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'vouch_dt',
          label: 'Vouch Dt',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'sett_method',
          label: 'Sett. Method',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_branch',
          label: 'Advice Branch',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_no',
          label: 'Advice No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_date',
          label: 'Advice Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'trans_currency',
          label: 'Tran. Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_currency',
          label: 'Advice Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'id_type',
          label: 'ID Type',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'identification_no',
          label: 'Identification No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'remitting_inst',
          label: 'Remitting Inst.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'iban_account_no',
          label: 'IBAN/Account NO',
          align: 'center',
          columnsWidth: '10'
        }
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};

const configurationObject_SS_174_Set2 = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          description: 'Karachi',
          amount: '1112',
          status: 'yes',
          sett_method: '124',
          advice_no: '12s4',
          date: '21/11/23',
          advice_date: '22/1/2023',
          trans_currency: 'efdr',
          advice_currency: 'dfrd',
          id_type: '12ed',
          identification_no: '124frd',
          remitting_inst: 'kdheh',
          iban_account_no: '890cjwk'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'sett_method',
          label: 'Sett. Method',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_no',
          label: 'Advice No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'id_type',
          label: 'ID Type',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'identification_no',
          label: 'Identification No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'remitting_inst',
          label: 'Remitting Inst.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'iban_account_no',
          label: 'IBAN/Account NO',
          align: 'center',
          columnsWidth: '10'
        }
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};

const configurationObject_SS_174_Set3 = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          vouch_dt: '123/1111',
          description: 'Karachi',
          amount: '1112',
          status: 'yes',
          sett_method: '124',
          advice_branch: 'desf',
          advice_no: '12s4',
          advice_date: '22/1/2023',
          trans_currency: 'efdr',
          advice_currency: 'dfrd',
          amount: '123',
          id_type: '12ed',
          identification_no: '124frd',
          remitting_inst: 'kdheh',
          iban_account_no: '890cjwk'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'vouch_dt',
          label: 'Vouch Dt',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'sett_method',
          label: 'Sett. Method',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_branch',
          label: 'Advice Branch',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_no',
          label: 'Advice No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_date',
          label: 'Advice Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'trans_currency',
          label: 'Tran. Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_currency',
          label: 'Advice Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'id_type',
          label: 'ID Type',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'identification_no',
          label: 'Identification No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'remitting_inst',
          label: 'Remitting Inst.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'iban_account_no',
          label: 'IBAN/Account NO',
          align: 'center',
          columnsWidth: '10'
        }
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};
const configurationObject_SS_342_Set1 = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          date: '21/11/23',
          description: 'Karachi',
          amount: '1112',
          status: 'yes',
          sett_method: '124',
          
          advice_no: '12s4',
         
        
          id_type: '12ed',
          identification_no: '124frd',
          remitting_inst: 'kdheh',
          iban_account_no: '890cjwk'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'exch_rate',
          label: 'Exch rate',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'loc_eqv',
          label: 'Loc Eqv',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'sett_method',
          label: 'Sett. Method',
          align: 'center',
          columnsWidth: '10'
        },
      
        {
          prop: 'advice_no',
          label: 'Advice No.',
          align: 'center',
          columnsWidth: '10'
        },
       
        {
          prop: 'id_type',
          label: 'ID Type',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'identification_no',
          label: 'Identification No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'remitting_inst',
          label: 'Remitting Inst.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'iban_account_no',
          label: 'IBAN/Account NO',
          align: 'center',
          columnsWidth: '10'
        },
        
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};
const configurationObject_SS_346_Set1 = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          vouch_dt: '123/1111',
          description: 'Karachi',
          amount: '1112',
          status: 'yes'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'vouch_dt',
          label: 'Vouch Dt',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        }
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};

const configurationObject_SS_366_Set1 = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          description: 'Karachi',
          amount: '1112',
          status: 'yes',
          sett_method: '124',
          advice_branch: 'desf',
          advice_no: '12s4',
          date: '21/11/23',
          advice_date: '22/1/2023',
          trans_currency: 'efdr',
          advice_currency: 'dfrd',
          amount: '123',
          id_type: '12ed',
          identification_no: '124frd',
          remitting_inst: 'kdheh',
          iban_account_no: '890cjwk'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'sett_method',
          label: 'Sett. Method',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_branch',
          label: 'Advice Branch',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_no',
          label: 'Advice No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_date',
          label: 'Advice Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'trans_currency',
          label: 'Tran. Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_currency',
          label: 'Advice Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'id_type',
          label: 'ID Type',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'identification_no',
          label: 'Identification No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'remitting_inst',
          label: 'Remitting Inst.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'iban_account_no',
          label: 'IBAN/Account NO',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'exch_rate',
          label: 'Exch rate',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'loc_eqv',
          label: 'Loc Eqv',
          align: 'center',
          columnsWidth: '10'
        }
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};

const configurationObject_SS_366_Set2 = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          description: 'Karachi',
          amount: '1112',
          status: 'yes',
          sett_method: '124',
          advice_no: '12s4',
          date: '21/11/23',
          id_type: '12ed',
          identification_no: '124frd',
          remitting_inst: 'kdheh',
          iban_account_no: '890cjwk'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'sett_method',
          label: 'Sett. Method',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_no',
          label: 'Advice No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'id_type',
          label: 'ID Type',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'identification_no',
          label: 'Identification No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'remitting_inst',
          label: 'Remitting Inst.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'iban_account_no',
          label: 'IBAN/Account NO',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'exch_rate',
          label: 'Exch rate',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'loc_eqv',
          label: 'Loc Eqv',
          align: 'center',
          columnsWidth: '10'
        }
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};

const configurationObject_SS_366_Set3 = {
  componentProps: {
    ExportVoucherTableView: {
      tableWidth: 250,
      tableHeight: '350px',
      ExportVoucherTableViewTableData: [
        {
          vouch_no: '123',
          description: 'Karachi',
          amount: '1112',
          status: 'yes',
          sett_method: '124',
          advice_branch: 'desf',
          advice_no: '12s4',
          date: '21/11/23',
          advice_date: '22/1/2023',
          trans_currency: 'efdr',
          advice_currency: 'dfrd',
          amount: '123',
          id_type: '12ed',
          identification_no: '124frd',
          remitting_inst: 'kdheh',
          iban_account_no: '890cjwk'
        }
      ],
      tableColumns: [
        {
          prop: 'vouch_no',
          label: 'Vouch No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'description',
          label: 'Description',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'status',
          label: 'Status',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'sett_method',
          label: 'Sett. Method',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_branch',
          label: 'Advice Branch',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_no',
          label: 'Advice No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'date',
          label: 'Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_date',
          label: 'Advice Date',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'trans_currency',
          label: 'Tran. Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'advice_currency',
          label: 'Advice Currency',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'amount',
          label: 'Amount',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'id_type',
          label: 'ID Type',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'identification_no',
          label: 'Identification No.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'remitting_inst',
          label: 'Remitting Inst.',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'iban_account_no',
          label: 'IBAN/Account NO',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'exch_rate',
          label: 'Exch rate',
          align: 'center',
          columnsWidth: '10'
        },
        {
          prop: 'loc_eqv',
          label: 'Loc Eqv',
          align: 'center',
          columnsWidth: '10'
        }
      ],
      isDisabled: false,
      isVisible: true
    },
    OkButton: {
      isDisabled: false,
      isVisible: true,
      nativeType: 'Button',
      label: 'Ok'
    },

    ViewVoucherButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Voucher'
    },
    ViewAdviceButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Advice'
    },
    ViewAmendmentsButton: {
      isDisabled: false,
      isVisible: false,
      nativeType: 'Button',
      label: 'View Amendments'
    },
    section1: {
      isVisible: true
    }
  }
};

const Template = (args) => ({
  components: { MegaSet1157 },
  template: `<MegaSet1157 v-bind="args" />`,
  setup() {
    return {
      args: {
        configObj: {
          componentProps: {
            ExportVoucherTableView: {
              tableWidth: 250,
              tableHeight: '350px',
              ExportVoucherTableViewTableData: [
                {
                  vouch_no: '123',
                  vouch_dt: '123/1111',
                  description: 'Karachi',
                  amount: '1112',
                  status: 'yes',
                  sett_method: '124',
                  advice_branch: 'desf',
                  advice_no: '12s4',
                  date: '21/11/23',
                  advice_date: '22/1/2023',
                  trans_currency: 'efdr',
                  advice_currency: 'dfrd',
                  amount: '123',
                  id_type: '12ed',
                  identification_no: '124frd',
                  remitting_inst: 'kdheh',
                  iban_account_no: '890cjwk'
                }
              ],
              tableColumns: [
                {
                  prop: 'vouch_no',
                  label: 'Vouch No.',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'vouch_dt',
                  label: 'Vouch Dt',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'description',
                  label: 'Description',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'amount',
                  label: 'Amount',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'status',
                  label: 'Status',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'sett_method',
                  label: 'Sett. Method',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'advice_branch',
                  label: 'Advice Branch',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'advice_no',
                  label: 'Advice No.',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'date',
                  label: 'Date',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'advice_date',
                  label: 'Advice Date',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'trans_currency',
                  label: 'Tran. Currency',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'advice_currency',
                  label: 'Advice Currency',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'amount',
                  label: 'Amount',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'id_type',
                  label: 'ID Type',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'identification_no',
                  label: 'Identification No.',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'remitting_inst',
                  label: 'Remitting Inst.',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'iban_account_no',
                  label: 'IBAN/Account NO',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'exch_rate',
                  label: 'Exch rate',
                  align: 'center',
                  columnsWidth: '10'
                },
                {
                  prop: 'loc_eqv',
                  label: 'Loc Eqv',
                  align: 'center',
                  columnsWidth: '10'
                }
              ],
              isDisabled: false,
              isVisible: true
            },
            OkButton: {
              isDisabled: false,
              isVisible: true,
              nativeType: 'Button',
              label: 'Ok'
            },

            ViewVoucherButton: {
              isDisabled: false,
              isVisible: true,
              nativeType: 'Button',
              label: 'View Voucher'
            },
            ViewAdviceButton: {
              isDisabled: false,
              isVisible: true,
              nativeType: 'Button',
              label: 'View Advice'
            },
            ViewAmendmentsButton: {
              isDisabled: false,
              isVisible: true,
              nativeType: 'Button',
              label: 'View Amendments'
            },

            section1: {
              isVisible: true
            }
          }
        }
      }
    };
  }
});

const Template_SS = (args) => ({
  components: { MegaSet1157 },
  template: `<MegaSet1157 v-bind="args"/>`,
  setup() {
    return { args };
  }
});

export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };

export const SS_174_Set1 = Template_SS.bind({});
SS_174_Set1.args = { configObj: configurationObject_SS_174_Set1 };

export const SS_174_Set2 = Template_SS.bind({});
SS_174_Set2.args = { configObj: configurationObject_SS_174_Set2 };

export const SS_174_Set3 = Template_SS.bind({});
SS_174_Set3.args = { configObj: configurationObject_SS_174_Set3 };

export const SS_342_Set1 = Template_SS.bind({});
SS_342_Set1.args = { configObj: configurationObject_SS_342_Set1 };

export const SS_346_Set1 = Template_SS.bind({});
SS_346_Set1.args = { configObj: configurationObject_SS_346_Set1 };

export const SS_366_Set1 = Template_SS.bind({});
SS_366_Set1.args = { configObj: configurationObject_SS_366_Set1 };

export const SS_366_Set2 = Template_SS.bind({});
SS_366_Set2.args = { configObj: configurationObject_SS_366_Set2 };

export const SS_366_Set3 = Template_SS.bind({});
SS_366_Set3.args = { configObj: configurationObject_SS_366_Set3 };
