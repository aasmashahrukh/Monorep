// MegaSet242.stories.js

import MegaSet89 from "../MegaSet/MegaSet242.vue";
import { ref } from "vue";
import { action } from "@storybook/addon-actions";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "MegaSet242",
  component: MegaSet242,
};

const configurationObject = {
  
};

const Template = (args) => ({
  components: { MegaSet242 },
  setup() {
    return { args };
  },
  template: `<MegaSet242 v-bind="args" 
    @NameTextBox-onBlur="NameTextBox-onBlur" 
    @AddressTextBox-onBlur="AddressTextBox-onBlur"
    />`,
  methods: {
    "NameTextBox-onBlur": action("NameTextBox-onBlur"),
    "AddressTextBox-onBlur": action("AddressTextBox-onBlur"),
  },
});

export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };
