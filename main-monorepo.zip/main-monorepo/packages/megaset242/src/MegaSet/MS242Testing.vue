<template>
  <MegaSet242 :configObj="configurationObject" @onSubmit="onSubmit" />
</template>
<script>
import MegaSet242 from '../MegaSet/MegaSet242.vue';
import { reactive } from 'vue';
export default {
  components: {
    MegaSet242
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    },
  },
  setup() {
    return reactive({
      configurationObject: {
        componentProps: {
          accountInformation: "JOINT - INDIVIUAL - J / SINGLY - S",
          accountNumber: "1001-0081-001594-01-5",
          activeName: 'sixth',
          PersonalInfo:{
            isVisible: true,
            isDisabled: false
          },
          CNICPassportInfo:{
            isVisible: true,
            isDisabled: false
          },
          ContactInfo:{
            isVisible: true,
            isDisabled: false
          },
          YngSaversGuardianInfo:{
            isVisible: true,
            isDisabled: false
          },
          FATCAInfo:{
            isVisible: true,
            isDisabled: false
          },
          CACTProfile:{
            isVisible: true,
            isDisabled: false
          },
          KYC:{
            isVisible: true,
            isDisabled: false
          },
          FamilyInfo:{
            isVisible: true,
            isDisabled: false
          },
          MinorCNICPassport:{
            isVisible: true,
            isDisabled: false
          },
          PropOtherInfo:{
            isVisible: true,
            isDisabled: false
          },
          IdDocTypeDropDown: {
            idDocTypeValue: '111',
            isVisible: true,
            isDisabled: false
          },
          IdDocNoTextBox: {
            isVisible: true,
            isDisabled: false,
            idDocNumberValue: '65656'
          },
          IdDocTypeDropDown1: {
            idDocTypeValue1: '1133',
            isVisible: true,
            isDisabled: false
          },
          IdDocNoTextBox1: {
            isVisible: true,
            isDisabled: false,
            idDocNumberValue1: '+66+6+'
          },
          CustomerNameDropDown: {
            customerTitle: 'Mr',
            isVisible: true,
            isDisabled: false,
            list: [
              {
                option: 'Mr',
                value: 'Mr'
              },
              {
                option: 'Miss',
                value: 'Miss'
              },
              {
                option: 'Mrs',
                value: 'Mrs'
              }
            ]
          },
          CustomerNameTextBox: {
            isVisible: true,
            isDisabled: false,
            customerNameValue: 'Ali'
          },
          MotherNameTextBox: {
            isVisible: true,
            isDisabled: false,
            motherNameValue: 'unknown'
          },
          YoungSaverDropDown: {
            youngSaverTitle: 'Mr',
            isVisible: true,
            isDisabled: false,
            list: [
              {
                option: 'Mr',
                value: 'Mr'
              },
              {
                option: 'Miss',
                value: 'Miss'
              },
              {
                option: 'Mrs',
                value: 'Mrs'
              }
            ]
          },
          YoungSaverTextBox: {
            isVisible: true,
            isDisabled: false,
            YoungSaverNameValue: 'Ali'
          },
          MartialStatusTextBox: {
            isVisible: true,
            isDisabled: false,
            martialStatusValue: 'unknown'
          },
          FatherHusbandNameTextBox: {
            isVisible: true,
            isDisabled: false,
            fatherHusbandNameValue: 'Ali'
          },
          DOBTextBox: {
            isVisible: true,
            isDisabled: false,
            dobValue: '10/10/2022'
          },
          QualificationDropDown: {
            qualificationValue: 'BSCS',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          NationalityDropDown: {
            nationalityValue: 'Pakistani',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          OtherNationalityCheckBox: {
            otherNationalityValue: true,
            isVisible: true,
            isDisabled: false,
          },
          AddViewButton: {
            isDisabled: false,
            isVisible: true
          },
          OccupationDropDown: {
            occupationValue: 'SE',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          NatTaxNoTextBox: {
            isVisible: true,
            isDisabled: false,
            natTaxNoValue: '42501-0973525-7'
          },
          BirthCertificateNoTextBox: {
            isVisible: true,
            isDisabled: false,
            birthCertNoValue: '465465'
          },
          STNNoTextBox: {
            isVisible: true,
            isDisabled: false,
            stnNoValue: '465465'
          },
          EISection: {
            isVisible: true,
          },
          SINameOfEmployerTextBox: {
            isVisible: true,
            isDisabled: false,
            nameOfEmployerValue: '465465'
          },
          SIJobTitleTextBox: {
            isVisible: true,
            isDisabled: false,
            jobTitleValue: '465465'
          },
          SIATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          SIProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          SIEmployerAddressTextBox: {
            isVisible: true,
            isDisabled: false,
            employerAddressValue: '465465'
          },
          SICountryDropDown: {
            countryValue: 'PAK',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          SISLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          SICityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          SIPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          SIDistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ////////////////
          BISection: {
            isVisible: true,
          },
          BINameOfBusinessTextBox: {
            isVisible: true,
            isDisabled: false,
            nameOfBusinessValue: '465465'
          },
          BIJobTitleTextBox: {
            isVisible: true,
            isDisabled: false,
            jobTitleValue: '465465'
          },
          BIATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          BIProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          BIBusinessAddressTextBox: {
            isVisible: true,
            isDisabled: false,
            businessAddressValue: '465465'
          },
          BICountryDropDown: {
            countryValue: 'PAK',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          BISLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          BICityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          BIPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          BIDistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ///////////////
          SDSection: {
            isVisible: true,
          },
          SDNameOfStudentTextBox: {
            isVisible: true,
            isDisabled: false,
            nameOfStudentValue: '465465'
          },
          SDJobTitleTextBox: {
            isVisible: true,
            isDisabled: false,
            jobTitleValue: '465465'
          },
          SDATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          SDProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          SDStudentAddressTextBox: {
            isVisible: true,
            isDisabled: false,
            studentAddressValue: '465465'
          },
          SDCountryDropDown: {
            countryValue: 'PAK',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          SDSLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          SDCityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          SDPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          SDDistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ///////////////
          OISection: {
            isVisible: true,
          },
          OIOthersNameTextBox: {
            isVisible: true,
            isDisabled: false,
            othersNameValue: '465465'
          },
          OIJobTitleTextBox: {
            isVisible: true,
            isDisabled: false,
            jobTitleValue: '465465'
          },
          OIATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          OIProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          OIOthersAddressTextBox: {
            isVisible: true,
            isDisabled: false,
            othersAddressValue: '465465'
          },
          OICountryDropDown: {
            countryValue: 'PAK',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          OISLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          OICityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          OIPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          OIDistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ///////////////
          DPSection: {
            isVisible: true,
          },
          DPNameTextBox: {
            isVisible: true,
            isDisabled: false,
            nameValue: '465465'
          },
          DPJobTitleTextBox: {
            isVisible: true,
            isDisabled: false,
            jobTitleValue: '465465'
          },
          DPATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          DPProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          DPAddressTextBox: {
            isVisible: true,
            isDisabled: false,
            addressValue: '465465'
          },
          DPCountryDropDown: {
            countryValue: 'PAK',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          DPSLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          DPCityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          DPPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          DPDistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ///////////////
          HDSection: {
            isVisible: true,
          },
          HDNameTextBox: {
            isVisible: true,
            isDisabled: false,
            nameValue: '465465'
          },
          HDJobTitleTextBox: {
            isVisible: true,
            isDisabled: false,
            jobTitleValue: '465465'
          },
          HDATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          HDProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          HDAddressTextBox: {
            isVisible: true,
            isDisabled: false,
            addressValue: '465465'
          },
          HDCountryDropDown: {
            countryValue: 'PAK',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          HDSLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          HDCityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          HDPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          HDDistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ///////////////
          ODSection: {
            isVisible: true,
          },
          ODNameofEmpBusTextBox: {
            isVisible: true,
            isDisabled: false,
            nameValue: '465465'
          },
          ODJobTitleTextBox: {
            isVisible: true,
            isDisabled: false,
            jobTitleValue: '465465'
          },
          ODATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          ODProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          ODHFBNameTextBox: {
            isVisible: true,
            isDisabled: false,
            hfbNameValue: '465465'
          },
          ODCountryDropDown: {
            countryValue: 'PAK',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ODSLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          ODCityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ODPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          ODDistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          //////////
          ComputerizedCNICTextBox: {
            isVisible: true,
            isDisabled: false,
            cnicValue: '465465'
          },
          PassportNumberTextBox: {
            passportValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          CNICExpityDateTextBox: {
            cnicExpiryValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          PassportPlaceIssueTextBox: {
            passPlaceValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          MotherNameTextBox1: {
            motherValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          PassportExpiryDateTextBox: {
            passportExpiryValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          PassportPlaceIssueTextBox1: {
            passPlaceValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          OtherNationalityCheckBox1: {
            otherNationalityValue: true,
            isVisible: true,
            isDisabled: false,
          },
          AddViewButton1: {
            isDisabled: false,
            isVisible: true
          },
          DOBTextBox1: {
            isVisible: true,
            isDisabled: false,
            dobValue: '10/10/2022'
          },
          CurrentAddressCheckBox: {
            value: true,
            isVisible: true,
            isDisabled: false,
          },
          PermanentAddressCheckBox: {
            value: true,
            isVisible: true,
            isDisabled: false,
          },
          BusinessOfficeAddressCheckBox: {
            value: true,
            isVisible: true,
            isDisabled: false,
          },
          PassportExpiryDateTextBox1: {
            passportExpiryValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          CNICIssuanceDateTextBox: {
            dateValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          FamilyNoTextBox: {
            familyValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          PassportIssueDateTextBox: {
            passValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          IdDocTypeDropDown2: {
            idDocTypeValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          CNICIdMarkTextBox: {
            cnicValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          OldNICTextBox: {
            nicValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          IDNoTextBox: {
            idNoValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          CountryOfBirthDropDown: {
            countryBirthValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          IssuanceDateTextBox: {
            issueValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          ExpiryDateTextBox: {
            expiryValue: 'AA656565656',
            isVisible: true,
            isDisabled: false,
          },
          PlaceOfIssueDropDown: {
            placeIssueValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          //////////
          PAATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          PAProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          PAHFBNameTextBox: {
            isVisible: true,
            isDisabled: false,
            hfbNameValue: '465465'
          },
          PACountryDropDown: {
            countryValue: 'INDIA',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          PASLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          PACityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          PAPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          PADistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          CAATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          CAProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          CAHFBNameTextBox: {
            isVisible: true,
            isDisabled: false,
            hfbNameValue: '465465'
          },
          CACountryDropDown: {
            countryValue: 'SRILANKA',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          CASLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          CACityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          CAPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          CADistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          SameAsAboveButton: {
            isVisible: true,
            isDisabled: false,
          },
          ChangeOfAddressCheckBox: {
            changeAddressValue: true,
            isDisabled: true,
            isVisible: true
          },
          CurrentAddressCheckBox1: {
            value: false,
            isVisible: true,
            isDisabled: false,
          },
          PermanentAddressCheckBox1: {
            value: true,
            isVisible: true,
            isDisabled: false,
          },
          BusinessOfficeAddressCheckBox1: {
            value: true,
            isVisible: true,
            isDisabled: false,
          },
          CountryTelOffDropDown: {
            countryTelValue: 'AUS',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          TelOffTextBox: {
            telOffValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          CountryTelResDropDown: {
            countryTelValue: 'AUS',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          TelResTextBox: {
            telResValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          CountryTelMobileDropDown: {
            countryTelValue: 'AUS',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          MobileTextBox: {
            mobileValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          FaxNoTextBox: {
            faxValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          EmailTextBox: {
            emailValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          EmailTextBox1: {
            emailValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          eStatementCheckBox: {
            eStatementValue: false,
            isVisible: true,
            isDisabled: true,
          },
          EStatementEmailTextBox: {
            emailValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          ViewButton: {
            isDisabled: false,
            isVisible: true
          },
          ///////////
          GuardianTextBox: {
            guardianValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          MotherNameTextBox2: {
            motherValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          FatherHusbandNameTextBox1: {
            fatherValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          CNICTextBox1: {
            cnicValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          ExpiryDateTextBox2: {
            expiryValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          DOBTextBox2: {
            dobValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          NationalityDropDown1: {
            nationalityValue: 'Pakistani',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          RelationshipTextBox: {
            relationValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          GenderDropDown: {
            genderValue: 'Male',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          PassportNoTextBox: {
            passValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          EmailTextBox2: {
            emailValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          TelResTextBox1: {
            telResValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          OccupationDropDown1: {
            occupationValue: 'Male',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          AddressTextBox: {
            addressValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          EmployerBusinessAddTextBox: {
            empBusValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          NameOfEmpBusTextBox: {
            nameOfEmpBusValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          TelOffTextBox1: {
            telOffValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          ///////////
          USCitizenDropDown: {
            usCitizenValue: '2-NO',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          USGreenCardHolderDropDown: {
            usGreenCardValue: '2-NO',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          USResidentDropDown: {
            usResidentValue: '2-NO',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          BornInUSDropDown: {
            bornInUSValue: '2-NO',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          TaxResidentDropDown: {
            taxResidentValue: '2-NO',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          TaxIDNoTypeDropDown: {
            taxIdNoValue: '2-NO',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          TaxIdentificationNoTextBox: {
            taxIdentificationNoValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          FATCAClassificationDropDown: {
            fatcaValue: '2-NO',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          ///////////
          /******************KYC*******************/
          SalaryAccountDropDown: {
            isDisabled: false,
            isVisible: true,
            SalaryAccountDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          IntroducerTypeDropDown: {
            isDisabled: false,
            isVisible: true,
            IntroducerTypeDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          AccountPurposeDropDown: {
            isDisabled: false,
            isVisible: true,
            AccountPurposeDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          PepDropDown: {
            isDisabled: false,
            isVisible: true,
            PepDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          RelatedToPepDropDown: {
            isDisabled: false,
            isVisible: true,
            RelatedToPepDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          CBBDropDown: {
            isDisabled: false,
            isVisible: true,
            CBBDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          OriginalDSDropDown: {
            isDisabled: false,
            isVisible: true,
            OriginalDSDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          SCTDropDown: {
            isDisabled: false,
            isVisible: true,
            SCTDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          SFRDropDown: {
            isDisabled: false,
            isVisible: true,
            SFRDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          RiskCategoryDropDown: {
            isDisabled: false,
            isVisible: true,
            RiskCategoryDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          AnnualSalaryTextBox: {
            isDisabled: false,
            isVisible: true,
            AnnualSalaryTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          NoExpectedDepositsTextBox: {
            isDisabled: false,
            isVisible: true,
            NoExpectedDepositsTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          ExpectedDepositsTextBox: {
            isDisabled: false,
            isVisible: true,
            ExpectedDepositsTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          NoExpectedWithdrawlsTextBox: {
            isDisabled: false,
            isVisible: true,
            NoExpectedWithdrawlsTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          ExpectedWithdrawlsTextBox: {
            isDisabled: false,
            isVisible: true,
            ExpectedWithdrawlsTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          ExpectedBalanceTextBox: {
            isDisabled: false,
            isVisible: true,
            ExpectedBalanceTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          TransactionReasonTextBox: {
            isDisabled: false,
            isVisible: true,
            TransactionReasonTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          RemarksTextBox: {
            isDisabled: false,
            isVisible: true,
            RemarksTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          //////////
          SpouseNameTextBox: {
            isDisabled: false,
            isVisible: true,
            RemarksTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          NumberOfChildTextBox: {
            isDisabled: false,
            isVisible: true,
            NumberOfChildTextBoxValue: '',
            inputLength: 25,
            dataType: 'numeric',
          },
          OtherDependantsTextBox: {
            isDisabled: false,
            isVisible: true,
            OtherDependantsTextBoxValue: '',
            inputLength: 25,
            dataType: 'numeric',
          },
          MakeCarTextBox: {
            isDisabled: false,
            isVisible: true,
            MakeCarTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          ModelTextBox: {
            isDisabled: false,
            isVisible: true,
            ModelTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          NRDropDown: {
            isDisabled: false,
            isVisible: true,
            NRDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          TRDropDown: {
            isDisabled: false,
            isVisible: true,
            TRDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          NextKinTextBox: {
            isDisabled: false,
            isVisible: true,
            NextKinTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          RelationshipTextBox1: {
            isDisabled: false,
            isVisible: true,
            RelationshipTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          AddressTextBox1: {
            isDisabled: false,
            isVisible: true,
            AddressTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          CNICTextBox: {
            isDisabled: false,
            isVisible: true,
            CNICTextBoxValue: '',
            inputLength: 25,
          },
          Address1TextBox: {
            isDisabled: false,
            isVisible: true,
            Address1TextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          ExpiryDateTextBox1: {
            isDisabled: false,
            isVisible: true,
            ExpiryDateTextBoxValue: ''
          },
          GuardianTextBox1: {
            isDisabled: false,
            isVisible: true,
            GuardianTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          GRelationshipTextBox: {
            isDisabled: false,
            isVisible: true,
            GRelationshipTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          GAddressTextBox: {
            isDisabled: false,
            isVisible: true,
            GAddressTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          GCNICTextBox: {
            isDisabled: false,
            isVisible: true,
            GCNICTextBoxValue: '',
            inputLength: 25,
          },
          MCPIssuanceDateTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPIssuanceDateTextBoxValue: ''
          },
          MCPassportExpiryDateTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPassportExpiryDateTextBoxValue: '11/11/1111'
          },
          MCPExpiryDateTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPExpiryDateTextBoxValue: ''
          },
          MCPassportIssueDateTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPassportIssueDateTextBoxValue: ''
          },
          MCPassportNumberTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPassportNumberTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          MCPIdNoTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPIdNoTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          MCPlaceOfIssuetextBox: {
            isDisabled: false,
            isVisible: true,
            MCPlaceOfIssuetextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          MCPFamilyNoTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPFamilyNoTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          MCPCnicIdMarkTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPCnicIdMarkTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          MCPOldNicTextBox: {
            isDisabled: false,
            isVisible: true,
            MCPOldNicTextBoxValue: '',
            inputLength: 15,
          },
          MCPIdTypeDropDown: {
            isDisabled: false,
            isVisible: true,
            MCPIdTypeDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          MCPCountryOfBirthDropDown: {
            isDisabled: false,
            isVisible: true,
            MCPCountryOfBirthDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          MCPlaceOfIssueDropDown: {
            isDisabled: false,
            isVisible: true,
            MCPlaceOfIssueDropDownList: [
              {
                value: '1',
                option: '1'
              }
            ],
            defaultValue: 'Select',
          },
          YSOtherNationalsCheckBox: {
            YSOtherNationalsCheckBoxValue: false,
            isDisable: false,
            isVisible: true,
          },
          YSOtherNationals1CheckBox: {
            YSOtherNationals1CheckBoxValue: false,
            isDisable: false,
            isVisible: true,
          },
          YSOfficeBusinessCheckBox: {
            YSOfficeBusinessCheckBoxValue: false,
            isDisable: false,
            isVisible: true,
          },
          YSPermanentAddressCheckBox: {
            YSPermanentAddressCheckBoxValue: false,
            isDisable: false,
            isVisible: true,
          },
          YSCurrentAddressCheckBox: {
            YSCurrentAddressCheckBoxValue: true,
            isDisable: false,
            isVisible: true,
          },
          YSAddViewButton: {
            isDisabled: false,
            isVisible: true,
            nativeType: "button",
          },
          YSAddButton: {
            isDisabled: false,
            isVisible: true,
            nativeType: "button",
          },
          YSCnicExpiryDateTextBox: {
            isDisabled: false,
            isVisible: true,
            YSCnicExpiryDateTextBoxValue: '11/11/1111'
          },
          YSPassportExpiryDateTextBox: {
            isDisabled: false,
            isVisible: true,
            YSPassportExpiryDateTextBoxValue: '11/11/1111'
          },
          YSDobDateTextBox: {
            isDisabled: false,
            isVisible: true,
            YSDobDateTextBoxValue: '11/11/1111'
          },
          YSPassportPlaceIssueTextBox: {
            isDisabled: false,
            isVisible: true,
            YSPassportPlaceIssueTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          YSMotherNameTextBox: {
            isDisabled: false,
            isVisible: true,
            YSMotherNameTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          YSPassportPlaceIssue1TextBox: {
            isDisabled: false,
            isVisible: true,
            YSPassportPlaceIssue1TextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          YSStnNoTextBox: {
            isDisabled: false,
            isVisible: true,
            YSStnNoTextBoxValue: '',
            inputLength: 25,
            dataType: 'alphaNumericSpecial',
          },
          CheckBoxLabel: {
            isVisible: true,
            label: 'Mailing Address'
          },
          ///////////
          NameTextBox: {
            nameValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          STRegNoTextBox: {
            stRegValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          NTNNoTextBox: {
            ntnValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          FaxNoTextBox1: {
            faxValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          TelephoneNoTextBox: {
            telValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          WebPageTextBox: {
            webValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          EmailTextBox3: {
            emailValue: '65656565',
            isVisible: true,
            isDisabled: false,
          },
          eStatementCheckBox1: {
            eStatementValue: false,
            isVisible: true,
            isDisabled: true,
          },
          ViewButton2: {
            isDisabled: false,
            isVisible: true
          },
          EntityRegNoTextBox: {
            entityValue: '65656565',
            isVisible: true,
            isDisabled: true,
          },
          EntityRegDateTextBox: {
            dateValue: '65656565',
            isVisible: true,
            isDisabled: true,
          },
          From29DateTextBox: {
            dateValue: '65656565',
            isVisible: true,
            isDisabled: true,
          },
          FromABDateTextBox: {
            dateValue: '65656565',
            isVisible: true,
            isDisabled: true,
          },
          INCDateTextBox: {
            dateValue: '65656565',
            isVisible: true,
            isDisabled: true,
          },
          FromCDateTextBox: {
            dateValue: '65656565',
            isVisible: true,
            isDisabled: true,
          },
          AssociatePAATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          AssociatePAProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          AssociatePAHFBNameTextBox: {
            isVisible: true,
            isDisabled: false,
            hfbNameValue: '465465'
          },
          AssociatePACountryDropDown: {
            countryValue: 'INDIA',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          AssociatePASLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          AssociatePACityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          AssociatePAPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          AssociatePADistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          AssociateCAATVNameTextBox: {
            isVisible: true,
            isDisabled: false,
            atvNameValue: '465465'
          },
          AssociateCAProvinceTextBox: {
            isVisible: true,
            isDisabled: false,
            provinceValue: '465465'
          },
          AssociateCAHFBNameTextBox: {
            isVisible: true,
            isDisabled: false,
            hfbNameValue: '465465'
          },
          AssociateCACountryDropDown: {
            countryValue: 'SRILANKA',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          AssociateCASLANameTextBox: {
            isVisible: true,
            isDisabled: false,
            slaNameValue: '465465'
          },
          AssociateCACityDropDown: {
            cityValue: 'ISB',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          AssociateCAPostalCodeTextBox: {
            isVisible: true,
            isDisabled: false,
            postalCodeValue: '465465'
          },
          AssociateCADistrictDropDown: {
            districtValue: 'Chakwal',
            isVisible: true,
            isDisabled: false,
            list: []
          },
          AssociateSameAsAboveButton: {
            isVisible: true,
            isDisabled: false,
          },
          AssociateChangeOfAddressCheckBox: {
            changeAddressValue: true,
            isDisabled: true,
            isVisible: true
          },
          TagCIFButton: {
            isDisabled: false,
            isVisible: true
          },
          CIFText1: {
            label: 'NEW CIF'
          },
          CIFText2: {
            label: 'CIF 65656556'
          },
          ///////////
          OkButton: {
            isDisabled: false,
            isVisible: true
          },
          JointCustInfoButton1: {
            isDisabled: false,
            isVisible: true
          },
          DirectorInfoButton: {
            isDisabled: false,
            isVisible: true
          },
          TrusteeInfoButton: {
            isDisabled: false,
            isVisible: true
          },
          PartnersInfoButton: {
            isDisabled: false,
            isVisible: true
          },
          ProprietersInfo1: {
            isDisabled: false,
            isVisible: true
          },
          MembersInfoButton: {
            isDisabled: false,
            isVisible: true
          },
          ProprietersInfo: {
            isDisabled: false,
            isVisible: true
          },
          DirectorInfoButton1: {
            isDisabled: false,
            isVisible: true
          },
          PartnersInfoButton1: {
            isDisabled: false,
            isVisible: true
          },
          ProprietersInfo: {
            isDisabled: false,
            isVisible: true
          },
          MembersInfoButton1: {
            isDisabled: false,
            isVisible: true
          },
          TrusteeInfoButton1: {
            isDisabled: false,
            isVisible: true
          },
          JointCustInfoButton: {
            isDisabled: false,
            isVisible: true
          },
          SMSAlertButton: {
            isDisabled: false,
            isVisible: true
          },
          SignatureButton: {
            isDisabled: false,
            isVisible: true
          },
          BackButton: {
            isDisabled: false,
            isVisible: true
          },
        }
      }
    });
  }
};
</script>