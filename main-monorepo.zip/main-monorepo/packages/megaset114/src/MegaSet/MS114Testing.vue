<template>
  <MegaSet114 :configObj="configurationObject" @onSubmit="onSubmit" />
</template>
<script>
import MegaSet114 from '../MegaSet/MegaSet114.vue';
import { reactive,ref } from 'vue';
export default {
  components: {
    MegaSet114
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    }
  },
  setup() {
    return reactive({
      configurationObject: {
       

        //components object
        componentProps: {
          title:{
            screenTitle:''

          },

          BranchDropDown: {
            isDisable: ref(false),
            dropDownLabel: 'Branch    ',
            colorLabel: ref(''),
            colorinput: ref(''),
            isVisible: ref(true),
            BranchDropDownList: [
              {
                option: '123',
                value: '123'
              },
              {
                option: '0997',
                value: '0997'
              },
              {
                option: '3423',
                value: '3423'
              }
            ],
            BranchDropDownValue: ref('Branch')
          },
          StatusDropDown: {
            isDisable: ref(false),
            dropDownLabel: 'Status',
            colorLabel: ref(''),
            colorinput: ref(''),
            isVisible: ref(true),
            StatusDropDownList: [
              {
                option: '123',
                value: '123'
              },
              {
                option: '0997',
                value: '0997'
              },
              {
                option: '3423',
                value: '3423'
              }
            ],
            StatusDropDownValue: ref('Status')
          },
          ChargeDescriptionDropDown: {
            isDisable: ref(false),
            dropDownLabel: 'Charge Description',
            colorLabel: ref(''),
            colorinput: ref(''),
            isVisible: ref(true),
            ChargeDescriptionDropDownList: [
              {
                option: '123',
                value: '123'
              },
              {
                option: '0997',
                value: '0997'
              },
              {
                option: '3423',
                value: '3423'
              }
            ],
            ChargeDescriptionDropDownValue: ref('Charge Description')
          },
          VendorNameDropDown: {
            isDisable: ref(false),
            dropDownLabel: 'Vendor Name',
            colorLabel: ref(''),
            colorinput: ref(''),
            isVisible: ref(true),
            VendorNameDropDownList: [
              {
                option: '123',
                value: '123'
              },
              {
                option: '0997',
                value: '0997'
              },
              {
                option: '3423',
                value: '3423'
              }
            ],
            VendorNameDropDownValue: ref('Vendor Name')
          },
          AmountTextBox: {
            label:'Amount',
            backgroundColor:'white',
            colorLabel: ref(''),
            colorinput: ref(''),
            AmountTextBoxValue: ref(''),
            isVisible: ref(true),
            amountLength: ref(6),
            mandatory: ref()
          },
          AmountCriteriaRadioButtonVisibilty: {
            isVisible: true
          },
          AmountCriteriaRadioButton: {
            radioDisplay:'grid',
            label: 'Amount Criteria',
            selectedValue: '1',
            AmountCriteriaRadioButton: [
              {
                value: '1',
                label: '< ',
                isDisabled: false
              },
              {
                value: '2',
                label: '= ',
                isDisabled: false
              },
              {
                value: '3',
                label: '> ',
                isDisabled: false
              }
            ]
          },
          OkButton: {
            isVisible: ref(true)
          },
          FromDateTextBox: {
            label:'From',
            backgroundColor:'white',
            colorLabel: ref(''),
            colorinput: ref(''),
            FromDateTextBoxValue: ref(''),
            isVisible: ref(true)
          },
          ToDateTextBox: {
            label:'To',
            backgroundColor:'white', 
            colorLabel: ref(''),
            colorinput: ref(''),
            ToDateTextBoxValue: ref(''),
            isVisible: ref(true)
          },

          DetailsButton: {
            label:'Detail',
            isVisible: ref(true)
          },
          BackButton: {
            label:'Back',
            isVisible: ref(true)
          },
          WithHoldingTaxChargesServicesSuppliesInquiryTable: {
            isVisible: ref(true),
            label: '',
            tableHeight: 300,
            tableWidth: 100,
            tableColumns: [
              {
                prop: 'Serial_vouch',
                label: 'Serial/Vouch #',
                align: 'left',
                columnsWidth: '100%'
              },
              {
                prop: 'Charge_Desc',
                label: 'Charge Desc',
                align: 'left',
                columnsWidth: '100%'
              },
              {
                prop: 'Supplier_Name',
                label: 'Supplier Name',
                align: 'left',
                columnsWidth: '100%'
              },
              {
                prop: 'Category',
                label: 'Category',
                align: 'right',
                columnsWidth: '100%'
              },
              {
                prop: 'Reg_Un_Reg',
                label: 'Reg/Un-Reg',
                align: 'right',
                columnsWidth: '100%'
              },
              {
                prop: 'Filer',
                label: 'Filer',
                align: 'right',
                columnsWidth: '100%'
              },

              {
                prop: 'Wht_Exempted',
                label: 'Wht Exempted',
                align: 'right',
                columnsWidth: '100%'
              },

              {
                prop: 'Invoice',
                label: 'Invoice #',
                align: 'right',
                columnsWidth: '100%'
              },

              {
                prop: 'InvoiceDate',
                label: 'Invoice Date',
                align: 'right',
                columnsWidth: '100%'
              },
              {
                prop: 'Invoice_Charge_Amount',
                label: 'Invoice/Charge Amount',
                align: 'right',
                columnsWidth: '100%'
              },
              {
                prop: 'Net_Payment_Amount',
                label: 'Net Payment Amount',
                align: 'right',
                columnsWidth: '100%'
              }
            ],
            tableData: [
              {
                Serial_vouch: '7689',
                Charge_Desc: '',
                Supplier_Name: '',
                Category: '',
                Reg_Un_Reg: '',
                Filer: '',
                Wht_Exempted: '',
                Invoice: '965231',
                InvoiceDate: '',
                Invoice_Charge_Amount: '',
                Net_Payment_Amount: ''
              }
            ]
          }
        }
      }
    });
  }
};
</script>
