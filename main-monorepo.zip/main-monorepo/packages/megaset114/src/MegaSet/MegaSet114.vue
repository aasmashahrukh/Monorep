<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row>
      <el-col :lg="24" :md="24" :sm="24">
        <h2>{{ configObject.title.screenTitle }}</h2>
      </el-col>
    </el-row>
    <br />

    <fieldset>
      <legend><b>Selection Criteria</b></legend>
      <el-row>
        <el-col :lg="18" :md="18" :sm="18">
          <GenericDropDown
            name="BranchDropDown"
            ref="RefBranchDropDown"
            @GenericDropDown-onChange="
              (val) => {
                $emit('BranchDropDown-onChange', val);
              }
            "
            v-bind="{...BranchDropDown,...configObject.BranchDropDown}"
            :values="configObject.BranchDropDown.BranchDropDownList"
            v-if="configObject.BranchDropDown != undefined ? configObject.BranchDropDown.isVisible : false"
          />
        </el-col>
        <el-col :lg="6" :md="6" :sm="6">
          <GenericDropDown
            name="StatusDropDown"
            ref="RefStatusDropDown"
            @GenericDropDown-onChange="
              (val) => {
                $emit('StatusDropDown-onChange', val);
              }
            "
            v-bind="{...StatusDropDown,...configObject.StatusDropDown}"
            :values="configObject.StatusDropDown.StatusDropDownList"
            v-if="configObject.StatusDropDown != undefined ? configObject.StatusDropDown.isVisible : false"
          />
        </el-col>
      </el-row>
      <el-row>
        <el-col :lg="24" :md="24" :sm="24">
          <GenericDropDown
            name="ChargeDescriptionDropDown"
            ref="RefChargeDescriptionDropDown"
            @GenericDropDown-onChange="
              (val) => {
                $emit('ChargeDescriptionDropDown-onChange', val);
              }
            "
            v-bind="{...ChargeDescriptionDropDown,...configObject.ChargeDescriptionDropDown}"
            :values="configObject.ChargeDescriptionDropDown.ChargeDescriptionDropDownList"
            v-if="configObject.ChargeDescriptionDropDown != undefined ? configObject.ChargeDescriptionDropDown.isVisible : false"
          />
        </el-col>
      </el-row>
      <el-row>
        <el-col :lg="24" :md="24" :sm="24">
          <GenericDropDown
            name="VendorNameDropDown"
            ref="RefVendorNameDropDown"
            @GenericDropDown-onChange="
              (val) => {
                $emit('VendorNameDropDown-onChange', val);
              }
            "
            v-bind="{...VendorNameDropDown,...configObject.VendorNameDropDown}"
            :values="configObject.VendorNameDropDown.VendorNameDropDownList"
            v-if="configObject.VendorNameDropDown != undefined ? configObject.VendorNameDropDown.isVisible : false"
          />
        </el-col>
      </el-row>
      <el-row>
        <el-col :lg="8" :md="8" :sm="8">
          <AmountNumericDecimal12Point2
            style="margin-top: 3px"
            name="AmountTextBox"
            ref="RefAmountTextBox"
            @AmountNumericDecimal12Point2-onBlur="
              (val) => {
                $emit('AmountTextBox-onBlur', val);
              }
            "
            v-bind="{...AmountTextBox,...configObject.AmountTextBox}"
            
            :values="configObject.AmountTextBox.AmountTextBoxValue"
            v-if="configObject.AmountTextBox != undefined ? configObject.AmountTextBox.isVisible : false"
          />
        </el-col>
        <el-col :lg="12" :md="11" :sm="11">
          <el-row>
            <el-col :lg="6" :md="6">
              <el-form-item
                v-if="configObject.AmountCriteriaRadioButtonVisibilty != undefined ? configObject.AmountCriteriaRadioButtonVisibilty.isVisible : false"
                style="font-size: 24px !important; font-family: Arial !important; margin: 6px 0 !important"
              >
                {{ configObject.AmountCriteriaRadioButton.label }}
              </el-form-item>
            </el-col>
            <el-col :lg="18" :md="18">
              <fieldset class="custom-amountCriteriaRadioButton" v-if="configObject.AmountCriteriaRadioButtonVisibilty != undefined ? configObject.AmountCriteriaRadioButtonVisibilty.isVisible : false">
                <GenericRadioButton
                  @GenericRadioButton-onClick="
                    (val) => {
                      $emit('AmountCriteriaRadioButton-onClick', val);
                    }
                  "
                  @GenericRadioButton-onBlur="
                    (val) => {
                      $emit('AmountCriteriaRadioButton-onBlur', val);
                    }
                  "
                  @GenericRadioButton-onChange="
                    (val) => {
                      $emit('AmountCriteriaRadioButton-onChange', val);
                    }
                  "
                  :mandatory="false"
                  name="AmountCriteriaRadioButton"
                  ref="RefAmountCriteriaRadioButton"
                  :radioGroup="configObject.AmountCriteriaRadioButton.AmountCriteriaRadioButton"
                 
                />
              </fieldset>
            </el-col>
          </el-row>
        </el-col>
        <el-col :lg="4" :md="5" :sm="5">
          <fieldset style="width: 155px">
            <GenericButton
              v-bind="{...OkButton,...configObject.OkButton}"              
              v-if="configObject.OkButton != undefined ? configObject.OkButton.isVisible : false"
              @GenericButton-onClick="$emit('OkButton-onClick')"
              name="OkButton"
              ref="RefOkButton"
            />
          </fieldset>
        </el-col>
      </el-row>
      <el-row>
        <el-col :lg="3" :md="3" :sm="3">
          <el-form-item style="font-size: 24px !important; font-family: Arial !important; margin: 15px 0 !important"> Date Criteria </el-form-item>
        </el-col>

        <el-col :lg="21" :md="21">
          <fieldset style="width: 555px; height: 40px; padding-top: 12px">
            <el-col :lg="12" :md="12" :sm="12">
              <DateDdMmYyyy
                name="FromDateTextBox"
                ref="FRefromDateTextBox"
                @DateDdMmYyyy-onBlur="
                  (val) => {
                    $emit('FromDateTextBox-onBlur', val);
                  }
                "
                v-bind="{...FromDateTextBox,...configObject.FromDateTextBox}"
                :values="configObject.FromDateTextBox.FromDateTextBoxValue"
                v-if="configObject.FromDateTextBox != undefined ? configObject.FromDateTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="12" :md="12" :sm="12">
              <DateDdMmYyyy
                name="ToDateTextBox"
                ref="RefToDateTextBox"
                @DateDdMmYyyy-onBlur="
                  (val) => {
                    $emit('ToDateTextBox-onBlur', val);
                  }
                "
                v-bind="{...ToDateTextBox,...configObject.ToDateTextBox}"
                :values="configObject.ToDateTextBox.ToDateTextBoxValue"
                v-if="configObject.ToDateTextBox != undefined ? configObject.ToDateTextBox.isVisible : false"
              />
            </el-col>
          </fieldset>
        </el-col>
      </el-row>
    </fieldset>
    <br />

    <el-row>
      <el-col :lg="24" :md="24" :sm="24">
        <GenericSortableTableView
          @GenericSortableTableView-onCurrentRow="
            (val) => {
              $emit('WithHoldingTaxChargesServicesSuppliesInquiryTable-onCurrentRow', val);
            }
          "
          v-bind="{...WithHoldingTaxChargesServicesSuppliesInquiryTable,...configObject.WithHoldingTaxChargesServicesSuppliesInquiryTable}"
          v-if="configObject.WithHoldingTaxChargesServicesSuppliesInquiryTable != undefined ? configObject.WithHoldingTaxChargesServicesSuppliesInquiryTable.isVisible : false"
          name="WithHoldingTaxChargesServicesSuppliesInquiryTable"
          ref="RefWithHoldingTaxChargesServicesSuppliesInquiryTable"
        />
      </el-col>
    </el-row>

    <br />
    <fieldset>
      <el-row>
        <el-col :md="4" :lg="4" :sm="4">
         <GenericButton

            v-bind="{...DetailsButton,...configObject.DetailsButton}"
            @GenericButton-onClick="$emit('DetailsButton-onClick')"
            name="DetailsButton"
            ref="RefDetailsButton"
            v-if="configObject.DetailsButton != undefined ? configObject.DetailsButton.isVisible : false"
          />
        </el-col>
        <el-col :md="16" :lg="16" :sm="16"></el-col>
        <el-col :md="4" :lg="4" :sm="4">
          <GenericButton
            v-bind="{...BackButton,...configObject.BackButton}"
            v-if="configObject.BackButton != undefined ? configObject.BackButton.isVisible : false"
            @GenericButton-onClick="$emit('BackButton-onClick')"
            name="BackButton"
            ref="RefBackButton"
          />
        </el-col>
      </el-row>
    </fieldset>
  </Form>
</template>

<script>
import {
  AmountNumericDecimal12Point2,
  DateDdMmYyyy,
  GenericDropDown,
  GenericButton,
  GenericRadioButton,
  GenericSortableTableView,

} from '@teresol-v2/ui-components';
import { Form, useForm } from 'vee-validate';
import { reactive ,ref} from 'vue';
export default {
  name: 'MegaSet114',

  components: {
    Form,
  AmountNumericDecimal12Point2,
  DateDdMmYyyy,
  GenericDropDown,
  GenericButton,
  GenericRadioButton,
  GenericSortableTableView,

  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive({
      ...props.configObj.componentProps
    });

    return {
      onSubmit,
      configObject,

      BranchDropDown: {
        spanInputs: ref(19),
        spanLabels: ref(4)
      },
      StatusDropDown: {
        spanInputs: ref(14),
        spanLabels: ref(6)
      },
      ChargeDescriptionDropDown: {
        spanInputs: ref(20),
        spanLabels: ref(3)
      },
      VendorNameDropDown: {
        spanInputs: ref(20),
        spanLabels: ref(3)
      },
      AmountTextBox: {
        spanInputs: ref(11),
        spanLabels: ref(9)
      },
      AmountCriteriaRadioButton: {
        spanInputss: ref(24),
        spanLabels: ref(0)
      },
      OkButton: {
        spanInputs: ref(24),
        nativeType: 'submit' // this property to be set on screen level
      },
      FromDateTextBox: {
        spanInputs: ref(16),
        spanLabels: ref(7)
      },
      ToDateTextBox: {
        spanInputs: ref(17),
        spanLabels: ref(6)
      },

      BackButton: {
        spanInputs: ref(24), // this property to be set on screen level
        nativeType: 'button' // this property to be set on screen level
      },
      DetailsButton: {
        spanInputs: ref(24), // this property to be set on screen level
        nativeType: 'button' // this property to be set on screen level
      },
      WithHoldingTaxChargesServicesSuppliesInquiryTable: {
        spanInputs: 24, // this property to be set on screen level
        tableHeight: 300,
        tableWidth: 100,
        spanLabels: 0
      }
    };
  }
};
</script>
