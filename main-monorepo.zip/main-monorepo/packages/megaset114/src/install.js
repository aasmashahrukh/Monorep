import MegaSet114 from './MegaSet/MegaSet114.vue'

function install(Vue) {
	if (install.installed) return;
	install.installed = true;

	Vue.component("MegaSet114",MegaSet114);
}

const plugin = {
	install,
};

let GlobalVue = null;
if (typeof window !== "undefined") {
	GlobalVue = window.Vue;
} else if (typeof global !== "undefined") {
	GlobalVue = global.vue;
}
if (GlobalVue) {
	GlobalVue.use(plugin);
}

MegaSet114.install = install;

export default MegaSet114;