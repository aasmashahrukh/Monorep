// MegaSet1168.stories.js

import MegaSet1168 from "../MegaSet/MegaSet1168.vue";
import { ref } from "vue";
import { action } from "@storybook/addon-actions";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "MegaSet1168",
  component: MegaSet1168,
};

const configurationObject = {
  title: 'MS_1168',
    componentProps: {
      Section1: {
        isVisible: true
      },
      RealAmountTextBox: {
        label: 'Real Amount',
        isDisabled: false,
        RealAmountTextBoxValue: '10890000000000000.67',
        isVisible: true,
        mandatory: false,
        backgroundColor: 'white'
      },
      RealAmountLabel: {
        label: 'USD',
        isVisible: true,
        color: ''
      },
      ShortAmountTextBox: {
        label: 'Short Amount',
        isDisabled: false,
        ShortAmountTextBoxValue: '10890000000000000.67',
        isVisible: true,
        mandatory: false,
        backgroundColor: 'white'
      },
      ShortAmountLabel: {
        label: 'USD',
        isVisible: true,
        color: ''
      },
      ConvAmtUSDTextBox: {
        label: 'Converted Amount USD',
        isDisabled: false,
        ConvAmtUSDTextBoxValue: '10890000000000000.67',
        isVisible: true,
        mandatory: false,
        backgroundColor: 'white'
      },
      ShipQtyTextBox: {
        label: 'Ship Qty',
        isDisabled: false,
        ShipQtyTextBoxValue: '1',
        isVisible: true,
        mandatory: false,
        backgroundColor: 'white',
        inputLength: 100,
        dataType: 'alphaNumeric'
      },
      Section2: {
        isVisible: true
      },
      OkButton: {
        label: 'OK',
        isDisabled: false,
        isVisible: true,
        mandatory: true,
        backgroundColor: 'white'
      },
      BackButton: {
        label: 'Back',
        isDisabled: false,
        isVisible: true,
        mandatory: true,
        backgroundColor: 'white'
      }
    }
  
};

const ConfigurationObject_SS_EXP_204_SET1 = {
  screenTitle: 'SS_EXP_204_SET1',
  componentProps: {
    Section1: {
      isVisible: true
    },
    RealAmountTextBox: {
      label: 'Real Amount',
      isDisabled: false,
      RealAmountTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    RealAmountLabel: {
      label: 'USD',
      isVisible: true,
      color: ''
    },
    ShortAmountTextBox: {
      label: 'Short Amount',
      isDisabled: false,
      ShortAmountTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShortAmountLabel: {
      label: 'USD',
      isVisible: true,
      color: ''
    },
    ConvAmtUSDTextBox: {
      label: 'Converted Amount USD',
      isDisabled: false,
      ConvAmtUSDTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShipQtyTextBox: {
      label: 'Ship Qty',
      isDisabled: false,
      ShipQtyTextBoxValue: '1',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric'
    },
    Section2: {
      isVisible: true
    },
    OkButton: {
      label: 'OK',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },
    BackButton: {
      label: 'Back',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    }
  }
};


const ConfigurationObject_SS_EXP_207_SET1 = {
  screenTitle: 'SS_EXP_207_SET1',
  componentProps: {
    Section1: {
      isVisible: true
    },
    RealAmountTextBox: {
      label: 'Real Amount',
      isDisabled: false,
      RealAmountTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    RealAmountLabel: {
      label: 'USD',
      isVisible: false,
      color: ''
    },
    ShortAmountTextBox: {
      label: 'Short Amount',
      isDisabled: false,
      ShortAmountTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShortAmountLabel: {
      label: 'USD',
      isVisible: false,
      color: ''
    },
    ConvAmtUSDTextBox: {
      label: 'Converted Amount USD',
      isDisabled: false,
      ConvAmtUSDTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShipQtyTextBox: {
      label: 'Ship Qty',
      isDisabled: false,
      ShipQtyTextBoxValue: '1',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric'
    },
    Section2: {
      isVisible: true
    },
    OkButton: {
      label: 'OK',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },
    BackButton: {
      label: 'Back',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    }
  }
};


const ConfigurationObject_SS_EXP_250_SET1 = {
  screenTitle: 'SS_EXP_250_SET1',
  componentProps: {
    Section1: {
      isVisible: true
    },
    RealAmountTextBox: {
      label: 'Real Amount',
      isDisabled: false,
      RealAmountTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    RealAmountLabel: {
      label: 'USD',
      isVisible: true,
      color: ''
    },
    ShortAmountTextBox: {
      label: 'Short Amount',
      isDisabled: false,
      ShortAmountTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShortAmountLabel: {
      label: 'USD',
      isVisible: true,
      color: ''
    },
    ConvAmtUSDTextBox: {
      label: 'Converted Amount USD',
      isDisabled: false,
      ConvAmtUSDTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShipQtyTextBox: {
      label: 'Ship Qty',
      isDisabled: false,
      ShipQtyTextBoxValue: '1',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric'
    },
    Section2: {
      isVisible: true
    },
    OkButton: {
      label: 'OK',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },
    BackButton: {
      label: 'Back',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    }
  }
};


const ConfigurationObject_SS_EXP_259_SET1 = {
  screenTitle: 'SS_EXP_259_SET1',
  componentProps: {
    Section1: {
      isVisible: true
    },
    RealAmountTextBox: {
      label: 'Real Amount',
      isDisabled: false,
      RealAmountTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    RealAmountLabel: {
      label: 'USD',
      isVisible: false,
      color: ''
    },
    ShortAmountTextBox: {
      label: 'Short Amount',
      isDisabled: false,
      ShortAmountTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShortAmountLabel: {
      label: 'USD',
      isVisible: false,
      color: ''
    },
    ConvAmtUSDTextBox: {
      label: 'Converted Amount USD',
      isDisabled: false,
      ConvAmtUSDTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShipQtyTextBox: {
      label: 'Ship Qty',
      isDisabled: false,
      ShipQtyTextBoxValue: '1',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric'
    },
    Section2: {
      isVisible: true
    },
    OkButton: {
      label: 'OK',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },
    BackButton: {
      label: 'Back',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    }
  }
};

const ConfigurationObject_SS_EXP_326_SET1 = {
  screenTitle: 'SS_EXP_326_SET1',
  componentProps: {
    Section1: {
      isVisible: true
    },
    RealAmountTextBox: {
      label: 'Real Amount',
      isDisabled: false,
      RealAmountTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    RealAmountLabel: {
      label: 'USD',
      isVisible: true,
      color: ''
    },
    ShortAmountTextBox: {
      label: 'Short Amount',
      isDisabled: false,
      ShortAmountTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShortAmountLabel: {
      label: 'USD',
      isVisible: true,
      color: ''
    },
    ConvAmtUSDTextBox: {
      label: 'Converted Amount USD',
      isDisabled: false,
      ConvAmtUSDTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShipQtyTextBox: {
      label: 'Ship Qty',
      isDisabled: false,
      ShipQtyTextBoxValue: '1',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric'
    },
    Section2: {
      isVisible: true
    },
    OkButton: {
      label: 'OK',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },
    BackButton: {
      label: 'Back',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    }
  }
};


const ConfigurationObject_SS_EXP_333_SET1 = {
  screenTitle: 'SS_EXP_333_SET1',
  componentProps: {
    Section1: {
      isVisible: true
    },
    RealAmountTextBox: {
      label: 'Real Amount',
      isDisabled: false,
      RealAmountTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    RealAmountLabel: {
      label: 'USD',
      isVisible: false,
      color: ''
    },
    ShortAmountTextBox: {
      label: 'Short Amount',
      isDisabled: false,
      ShortAmountTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShortAmountLabel: {
      label: 'USD',
      isVisible: false,
      color: ''
    },
    ConvAmtUSDTextBox: {
      label: 'Converted Amount USD',
      isDisabled: false,
      ConvAmtUSDTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShipQtyTextBox: {
      label: 'Ship Qty',
      isDisabled: false,
      ShipQtyTextBoxValue: '1',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric'
    },
    Section2: {
      isVisible: true
    },
    OkButton: {
      label: 'OK',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },
    BackButton: {
      label: 'Back',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    }
  }
};


const ConfigurationObject_SS_EXP_387_SET1 = {
  screenTitle: 'SS_EXP_387_SET1',
  componentProps: {
    Section1: {
      isVisible: true
    },
    RealAmountTextBox: {
      label: 'Real Amount',
      isDisabled: false,
      RealAmountTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    RealAmountLabel: {
      label: 'USD',
      isVisible: true,
      color: ''
    },
    ShortAmountTextBox: {
      label: 'Short Amount',
      isDisabled: false,
      ShortAmountTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShortAmountLabel: {
      label: 'USD',
      isVisible: true,
      color: ''
    },
    ConvAmtUSDTextBox: {
      label: 'Converted Amount USD',
      isDisabled: false,
      ConvAmtUSDTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShipQtyTextBox: {
      label: 'Ship Qty',
      isDisabled: false,
      ShipQtyTextBoxValue: '1',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric'
    },
    Section2: {
      isVisible: true
    },
    OkButton: {
      label: 'OK',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },
    BackButton: {
      label: 'Back',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    }
  }
};


const ConfigurationObject_SS_EXP_396_SET1 = {
  screenTitle: 'SS_EXP_396_SET1',
  componentProps: {
    Section1: {
      isVisible: true
    },
    RealAmountTextBox: {
      label: 'Real Amount',
      isDisabled: false,
      RealAmountTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    RealAmountLabel: {
      label: 'USD',
      isVisible: false,
      color: ''
    },
    ShortAmountTextBox: {
      label: 'Short Amount',
      isDisabled: false,
      ShortAmountTextBoxValue: '10890000000000000.67',
      isVisible: false,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShortAmountLabel: {
      label: 'USD',
      isVisible: false,
      color: ''
    },
    ConvAmtUSDTextBox: {
      label: 'Converted Amount USD',
      isDisabled: false,
      ConvAmtUSDTextBoxValue: '10890000000000000.67',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white'
    },
    ShipQtyTextBox: {
      label: 'Ship Qty',
      isDisabled: false,
      ShipQtyTextBoxValue: '1',
      isVisible: true,
      mandatory: false,
      backgroundColor: 'white',
      inputLength: 100,
      dataType: 'alphaNumeric'
    },
    Section2: {
      isVisible: true
    },
    OkButton: {
      label: 'OK',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    },
    BackButton: {
      label: 'Back',
      isDisabled: false,
      isVisible: true,
      mandatory: true,
      backgroundColor: 'white'
    }
  }
};







const Template = (args) => ({
  components: { MegaSet1168 },
  setup() {
    return {
      args: {
        configObj: {
          componentProps: {
            Section1: {
              isVisible: true
            },
            RealAmountTextBox: {
              label: 'Real Amount',
              isDisabled: false,
              RealAmountTextBoxValue: '10890000000000000.67',
              isVisible: true,
              mandatory: false,
              backgroundColor: 'white'
            },
            RealAmountLabel: {
              label: 'USD',
              isVisible: true,
              color: ''
            },
            ShortAmountTextBox: {
              label: 'Short Amount',
              isDisabled: false,
              ShortAmountTextBoxValue: '10890000000000000.67',
              isVisible: true,
              mandatory: false,
              backgroundColor: 'white'
            },
            ShortAmountLabel: {
              label: 'USD',
              isVisible: true,
              color: ''
            },
            ConvAmtUSDTextBox: {
              label: 'Converted Amount USD',
              isDisabled: false,
              ConvAmtUSDTextBoxValue: '10890000000000000.67',
              isVisible: true,
              mandatory: false,
              backgroundColor: 'white'
            },
            ShipQtyTextBox: {
              label: 'Ship Qty',
              isDisabled: false,
              ShipQtyTextBoxValue: '1',
              isVisible: true,
              mandatory: false,
              backgroundColor: 'white',
              inputLength: 100,
              dataType: 'alphaNumeric'
            },
            Section2: {
              isVisible: true
            },
            OkButton: {
              label: 'OK',
              isDisabled: false,
              isVisible: true,
              mandatory: true,
              backgroundColor: 'white'
            },
            BackButton: {
              label: 'Back',
              isDisabled: false,
              isVisible: true,
              mandatory: true,
              backgroundColor: 'white'
            }
          }
        }
      }
    };
  },
  template: `<MegaSet1168 v-bind="args"   />`,
    // @NameTextBox-onBlur="NameTextBox-onBlur" 
    // @AddressTextBox-onBlur="AddressTextBox-onBlur"
    // />`,
  methods: {
    // "NameTextBox-onBlur": action("NameTextBox-onBlur"),
    // "AddressTextBox-onBlur": action("AddressTextBox-onBlur"),
  },
});

const Set_Template = (args) => ({
  components: { MegaSet1168 },
  setup() {
    return { args };
  },

  template: `<MegaSet1168 v-bind="args" />`,
  methods: {}
});


export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };

export const SS_EXP_204_SET1 = Set_Template.bind({});
SS_EXP_204_SET1.args = { configObj: ConfigurationObject_SS_EXP_204_SET1 };

export const SS_EXP_207_SET1 = Set_Template.bind({});
SS_EXP_207_SET1.args = { configObj: ConfigurationObject_SS_EXP_207_SET1 };

export const SS_EXP_250_SET1 = Set_Template.bind({});
SS_EXP_250_SET1.args = { configObj: ConfigurationObject_SS_EXP_250_SET1 };

export const SS_EXP_259_SET1 = Set_Template.bind({});
SS_EXP_259_SET1.args = { configObj: ConfigurationObject_SS_EXP_259_SET1 };

export const SS_EXP_326_SET1 = Set_Template.bind({});
SS_EXP_326_SET1.args = { configObj: ConfigurationObject_SS_EXP_326_SET1 };

export const SS_EXP_333_SET1 = Set_Template.bind({});
SS_EXP_333_SET1.args = { configObj: ConfigurationObject_SS_EXP_333_SET1 };

export const SS_EXP_387_SET1 = Set_Template.bind({});
SS_EXP_387_SET1.args = { configObj: ConfigurationObject_SS_EXP_387_SET1 };

export const SS_EXP_396_SET1 = Set_Template.bind({});
SS_EXP_396_SET1.args = { configObj: ConfigurationObject_SS_EXP_396_SET1 };