<template>
<Form as="el-form" @submit="onSubmit">
  <el-row>
    <el-col :lg="4" :md="4"></el-col>
    <el-col :lg="16" :md="16">
  <fieldset v-if="configObject.Section1 != undefined ? configObject.Section1.isVisible : false">
    <el-row>
    
      <el-col :lg="22" :md="22">
        <AmountNumericDecimal17Point2
          @AmountNumericDecimal17Point2-onFocus="
            (val) => {
              $emit('RealAmountTextBox-onFocus', val);
            }
          "
          @AmountNumericDecimal17Point2-onKeyUp="
            (val) => {
              $emit('RealAmountTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal17Point2-onKeyPress="
            (val) => {
              $emit('RealAmountTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal17Point2-onBlur="
            (val) => {
              $emit('RealAmountTextBox-onBlur', val);
            }
          "
          name="RealAmountTextBox"
          ref="RefRealAmountTextBox"
          v-bind="{ ...RealAmountTextBox, ...configObject.RealAmountTextBox }"
          :values="configObject.RealAmountTextBox.RealAmountTextBoxValue"
          v-if="configObject.RealAmountTextBox != undefined ? configObject.RealAmountTextBox.isVisible : false"
        />
        <AmountNumericDecimal17Point2
          @AmountNumericDecimal17Point2-onFocus="
            (val) => {
              $emit('ShortAmountTextBox-onFocus', val);
            }
          "
          @AmountNumericDecimal17Point2-onKeyUp="
            (val) => {
              $emit('ShortAmountTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal17Point2-onKeyPress="
            (val) => {
              $emit('ShortAmountTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal17Point2-onBlur="
            (val) => {
              $emit('ShortAmountTextBox-onBlur', val);
            }
          "
          name="ShortAmountTextBox"
          ref="RefShortAmountTextBox"
          v-bind="{ ...ShortAmountTextBox, ...configObject.ShortAmountTextBox }"
          :values="configObject.ShortAmountTextBox.ShortAmountTextBoxValue"
          v-if="configObject.ShortAmountTextBox != undefined ? configObject.ShortAmountTextBox.isVisible : false"
        />
        <AmountNumericDecimal17Point2
          @AmountNumericDecimal17Point2-onFocus="
            (val) => {
              $emit('ConvAmtUSDTextBox-onFocus', val);
            }
          "
          @AmountNumericDecimal17Point2-onKeyUp="
            (val) => {
              $emit('ConvAmtUSDTextBox-onKeyUp', val);
            }
          "
          @AmountNumericDecimal17Point2-onKeyPress="
            (val) => {
              $emit('ConvAmtUSDTextBox-onKeyPress', val);
            }
          "
          @AmountNumericDecimal17Point2-onBlur="
            (val) => {
              $emit('ConvAmtUSDTextBox-onBlur', val);
            }
          "
          name="ConvAmtUSDTextBox"
          ref="RefConvAmtUSDTextBox"
          v-bind="{ ...ConvAmtUSDTextBox, ...configObject.ConvAmtUSDTextBox }"
          :values="configObject.ConvAmtUSDTextBox.ConvAmtUSDTextBoxValue"
          v-if="configObject.ConvAmtUSDTextBox != undefined ? configObject.ConvAmtUSDTextBox.isVisible : false"
        />
        <GenericTextBox
            @GenericTextBox-onFocus="
              (val) => {
                $emit('ShipQtyTextBox-onFocus', val);
              }
            "
            @GenericTextBox-onKeyUp="
              (val) => {
                $emit('ShipQtyTextBox-onKeyUp', val);
              }
            "
            @GenericTextBox-onKeyPress="
              (val) => {
                $emit('ShipQtyTextBox-onKeyPress', val);
              }
            "
            @GenericTextBox-onBlur="
              (val) => {
                $emit('ShipQtyTextBox-onBlur', val);
              }
            "
            name="ShipQtyTextBox"
            ref="RefShipQtyTextBox"
            v-bind="{ ...ShipQtyTextBox, ...configObject.ShipQtyTextBox }"
            :values="configObject.ShipQtyTextBox.ShipQtyTextBoxValue"
            v-if="configObject.ShipQtyTextBox != undefined ? configObject.ShipQtyTextBox.isVisible : false"
          />
      </el-col>
    


      <el-col :lg="2" :md="2">
              <el-form-item
                class="color1"
                v-if="configObject.RealAmountLabel != undefined ? configObject.RealAmountLabel.isVisible : false"
              >
                {{ configObject.RealAmountLabel.label }}
              </el-form-item>
              <el-form-item
                class="color2"
                v-if="configObject.ShortAmountLabel != undefined ? configObject.ShortAmountLabel.isVisible : false"
              >
                {{ configObject.ShortAmountLabel.label }}
              </el-form-item>
            </el-col>

  
    </el-row>
    </fieldset>
    <fieldset v-if="configObject.Section2 != undefined ? configObject.Section2.isVisible : false">
      <el-row>
        <el-col :lg="3" :md="3">
        <GenericButton
                  name="OkButton"
                  ref="RefOkButton"
                  @GenericButton-onClick="$emit('OkButton-onClick')"
                  @GenericButton-onFocus="$emit('OkButton-onFocus')"
                  v-bind="{ ...OkButton, ...configObject.OkButton }"
                  v-if="configObject.OkButton != undefined ? configObject.OkButton.isVisible : false"
                />
              </el-col>
              <el-col :lg="18" :md="18"></el-col>
              <el-col :lg="3" :md="3">
                <GenericButton
                  name="BackButton"
                  ref="RefBackButton"
                  @GenericButton-onClick="$emit('BackButton-onClick')"
                  @GenericButton-onFocus="$emit('BackButton-onFocus')"
                  v-bind="{ ...BackButton, ...configObject.BackButton }"
                  v-if="configObject.BackButton != undefined ? configObject.BackButton.isVisible : false"
                />
              </el-col>
            
      </el-row>
      </fieldset>
  </el-col>
  

      <el-col :lg="4" :md="4"></el-col>
    </el-row>
</Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import { reactive } from 'vue';

import {
  GenericTextBox,
  GenericButton,
  AmountNumericDecimal17Point2,
} from '@teresol-v2/ui-components';
export default {
  name: 'MegaSet1168',

  components: {
    Form,
    GenericTextBox,
  GenericButton,
  AmountNumericDecimal17Point2,
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
   
    const configObject = reactive(
      props.configObj.componentProps
    );

    return {
      onSubmit,
     
      configObject,

      RealAmountTextBox: {
        spanInputs: 15,
        spanLabels: 7
      },
      ShortAmountTextBox: {
        spanInputs: 15,
        spanLabels: 7
      },
      ConvAmtUSDTextBox: {
        spanInputs: 15,
        spanLabels: 7
      },
      ShipQtyTextBox: {
        spanInputs: 15,
        spanLabels: 7
      },
      OkButton: {
        spanInputs: 24,
        spanLabels: 0
      },
      BackButton: {
        spanInputs: 24,
        spanLabels: 0
      },
    };
  }
};
</script>
<style scoped>
:deep(.color1) {
  color: v-bind('configObject.RealAmountLabel.color!=undefined? configObject.RealAmountLabel.color:"black"');
}
:deep(.color2) {
  color: v-bind('configObject.ShortAmountLabel.color!=undefined? configObject.ShortAmountLabel.color:"black"');
}

</style>