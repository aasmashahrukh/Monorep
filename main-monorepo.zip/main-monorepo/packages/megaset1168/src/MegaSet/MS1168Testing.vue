<template>
  <MegaSet1168 :configObj="configurationObject" @onSubmit="onSubmit" />
</template>
<script>
import MegaSet1168 from '../MegaSet/MegaSet1168.vue';
import { reactive } from 'vue';
export default {
  components: {
    MegaSet1168
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    }
  },
  setup() {
    return reactive({
      configurationObject: {
        componentProps: {
          Section1: {
            isVisible: true
          },
          RealAmountTextBox: {
            label: 'Real Amount',
            isDisabled: false,
            RealAmountTextBoxValue: '10890000000000000.67',
            isVisible: true,
            mandatory: false,
            backgroundColor: 'white'
          },
          RealAmountLabel: {
            label: 'USD',
            isVisible: true,
            color: ''
          },
          ShortAmountTextBox: {
            label: 'Short Amount',
            isDisabled: false,
            ShortAmountTextBoxValue: '10890000000000000.67',
            isVisible: true,
            mandatory: false,
            backgroundColor: 'white'
          },
          ShortAmountLabel: {
            label: 'USD',
            isVisible: true,
            color: ''
          },
          ConvAmtUSDTextBox: {
            label: 'Converted Amount USD',
            isDisabled: false,
            ConvAmtUSDTextBoxValue: '10890000000000000.67',
            isVisible: true,
            mandatory: false,
            backgroundColor: 'white'
          },
          ShipQtyTextBox: {
            label: 'Ship Qty',
            isDisabled: false,
            ShipQtyTextBoxValue: '1',
            isVisible: true,
            mandatory: false,
            backgroundColor: 'white',
            inputLength: 100,
            dataType: 'alphaNumeric'
          },
          Section2: {
            isVisible: true
          },
          OkButton: {
            label: 'OK',
            isDisabled: false,
            isVisible: true,
            mandatory: true,
            backgroundColor: 'white'
          },
          BackButton: {
            label: 'Back',
            isDisabled: false,
            isVisible: true,
            mandatory: true,
            backgroundColor: 'white'
          }
        }
      }
    });
  }
};
</script>
