<template>
  <Form as="el-form" @submit="onSubmit">
    <el-row>
      <el-col :lg="20" :md="20">
        <fieldset>
          <el-row>
            <el-col :lg="4" :md="4">
              <el-form-item>Copy Images in</el-form-item>
            </el-col>
            <el-col :lg="4" :md="4">
              <GenericButton
                @GenericButton-onClick="$emit('ScanButton-onClick')"
                v-if="configObject.ScanButton != undefined ? configObject.ScanButton.isVisible : false"
                v-bind="{
                  ...ScanButton,
                  ...configObject.ScanButton
                }"
                name="ScanButton"
                ref="RefScanButton"
              />
            </el-col>
            <el-col :lg="12" :md="12">
              <GenericTextBox
                name="FileTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('FileTextBox-onBlur', val);
                  }
                "
                @GenericTextBox-onKeyPress="
                  (val) => {
                    $emit('FileTextBox-onKeyPress', val);
                  }
                "
                @GenericTextBox-onKeyDown="
                  (val) => {
                    $emit('FileTextBox-onKeyDown', val);
                  }
                "
                @GenericTextBox-onKeyUp="
                  (val) => {
                    $emit('FileTextBox-onKeyUp', val);
                  }
                "
                ref="RefFileTextBox"
                v-bind="{ ...FileTextBox, ...configObject.FileTextBox }"
                :values="configObject.FileTextBox.FileTextBoxTextvalue"
                v-if="configObject.FileTextBox != undefined ? configObject.FileTextBox.isVisible : false"
              />
            </el-col>
          </el-row>
          <el-row>
            <el-col :lg="24" :md="24">
              <el-form-item>File Format is TIFF(*.TIF)</el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :lg="8" :md="8"> <el-form-item v-if="configObject.LCNoTextBox != undefined ? configObject.LCNoTextBox.isVisible : false"> {{ configObject.LCNoTextBox.label }}</el-form-item> </el-col>
            <el-col :lg="12" :md="12">
              <GenericTextBox
                name="LCNoTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('LCNoTextBox-onBlur', val);
                  }
                "
                @GenericTextBox-onKeyPress="
                  (val) => {
                    $emit('LCNoTextBox-onKeyPress', val);
                  }
                "
                @GenericTextBox-onKeyDown="
                  (val) => {
                    $emit('LCNoTextBox-onKeyDown', val);
                  }
                "
                @GenericTextBox-onKeyUp="
                  (val) => {
                    $emit('LCNoTextBox-onKeyUp', val);
                  }
                "
                ref="RefLCNoTextBox"
                v-bind="{ ...LCNoTextBox, ...configObject.LCNoTextBox }"
                :values="configObject.LCNoTextBox.LCNoTextBoxTextvalue"
                v-if="configObject.LCNoTextBox != undefined ? configObject.LCNoTextBox.isVisible : false"
              />
            </el-col>
          </el-row>
          <el-row v-if="configObject.section1 != undefined ? configObject.section1.isVisible : false">
            <el-col :lg="12" :md="12">
              <BranchCodeNumeric4
                name="BranchCodeTextBox"
                @BranchCodeNumeric4-onBlur="
                  (val) => {
                    $emit('BranchCodeTextBox-onBlur', val);
                  }
                "
                @BranchCodeNumeric4-onKeyPress="
                  (val) => {
                    $emit('BranchCodeTextBox-onKeyPress', val);
                  }
                "
                @BranchCodeNumeric4-onKeyDown="
                  (val) => {
                    $emit('BranchCodeTextBox-onKeyDown', val);
                  }
                "
                @BranchCodeNumeric4-onKeyUp="
                  (val) => {
                    $emit('BranchCodeTextBox-onKeyUp', val);
                  }
                "
                ref="RefBranchCodeTextBox"
                v-bind="{ ...BranchCodeTextBox, ...configObject.BranchCodeTextBox }"
                :values="configObject.BranchCodeTextBox.BranchCodeTextBoxValue"
                v-if="configObject.BranchCodeTextBox != undefined ? configObject.BranchCodeTextBox.isVisible : false"
              />
            </el-col>
            <el-col :lg="4" :md="4">
              <GenericTextBox
                name="RefNoTextBox"
                @GenericTextBox-onBlur="
                  (val) => {
                    $emit('RefNoTextBox-onBlur', val);
                  }
                "
                @GenericTextBox-onKeyPress="
                  (val) => {
                    $emit('RefNoTextBox-onKeyPress', val);
                  }
                "
                @GenericTextBox-onKeyDown="
                  (val) => {
                    $emit('RefNoTextBox-onKeyDown', val);
                  }
                "
                @GenericTextBox-onKeyUp="
                  (val) => {
                    $emit('RefNoTextBox-onKeyUp', val);
                  }
                "
                ref="RefRefNoTextBox"
                v-bind="{ ...RefNoTextBox, ...configObject.RefNoTextBox }"
                :values="configObject.RefNoTextBox.RefNoTextBoxTextFieldValue"
                v-if="configObject.RefNoTextBox != undefined ? configObject.RefNoTextBox.isVisible : false"
              />
            </el-col>

            <el-col :lg="6" :md="6">
              <YearNumeric4
                name="YearTextBox"
                @YearNumeric4-onBlur="
                  (val) => {
                    $emit('YearTextBox-onBlur', val);
                  }
                "
                @YearNumeric4-onKeyPress="
                  (val) => {
                    $emit('YearTextBox-onKeyPress', val);
                  }
                "
                @YearNumeric4-onKeyDown="
                  (val) => {
                    $emit('YearTextBox-onKeyDown', val);
                  }
                "
                @YearNumeric4-onKeyUp="
                  (val) => {
                    $emit('YearTextBox-onKeyUp', val);
                  }
                "
                ref="RefYearTextBox"
                v-bind="{ ...YearTextBox, ...configObject.YearTextBox }"
                :values="configObject.YearTextBox.YearTextBoxTextFieldValue"
                v-if="configObject.YearTextBox != undefined ? configObject.YearTextBox.isVisible : false"
              />
            </el-col>
            <el-co :lg="2" :md="2"></el-co>
          </el-row></fieldset
      ></el-col>
      <el-col :lg="4" :md="4"></el-col>
    </el-row>
    <el-row>
      <el-col :lg="20" :md="20">
        <fieldset>
          <el-row>
            <el-col :lg="4" :md="4">
              <el-row>
                <el-col :lg="20" :md="20">
                  <GenericButton
                    @GenericButton-onClick="$emit('SaveButton-onClick')"
                    v-if="configObject.SaveButton != undefined ? configObject.SaveButton.isVisible : false"
                    v-bind="{
                      ...SaveButton,
                      ...configObject.SaveButton
                    }"
                    name="SaveButton"
                    ref="RefSaveButton"
                  />
                </el-col>
                <el-col :lg="4" :md="4"></el-col>
              </el-row>
              <el-row>
                <el-col :lg="20" :md="20">
                  <GenericButton
                    @GenericButton-onClick="$emit('SendToCPUButton-onClick')"
                    v-if="configObject.SendToCPUButton != undefined ? configObject.SendToCPUButton.isVisible : false"
                    v-bind="{
                      ...SendToCPUButton,
                      ...configObject.SendToCPUButton
                    }"
                    name="SendToCPUButton"
                    ref="RefSendToCPUButton"
                  />
                </el-col>
                <el-col :lg="4" :md="4"></el-col>
              </el-row>
            </el-col>
            <el-col :lg="17" :md="17"></el-col>
            <el-col :lg="3" :md="3">
              <GenericButton
                @GenericButton-onClick="$emit('BackButton-onClick')"
                v-if="configObject.BackButton != undefined ? configObject.BackButton.isVisible : false"
                v-bind="{
                  ...BackButton,
                  ...configObject.BackButton
                }"
                name="BackButton"
                ref="RefBackButton"
              />
            </el-col>
          </el-row>
        </fieldset>
      </el-col>
      <el-col :lg="4" :md="4" />
    </el-row>
  </Form>
</template>

<script>
import { reactive } from 'vue';
import { Form, useForm } from 'vee-validate';
import { GenericTextBox, GenericButton, YearNumeric4, BranchCodeNumeric4 } from '@teresol-v2/ui-components';
export default {
  name: 'Megaset1124',
  components: {
    Form,
    GenericTextBox,
    GenericButton,
    YearNumeric4,
    BranchCodeNumeric4
  },
  props: {
    //Add configuration object details
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive(props.configObj.componentProps);

    return {
      onSubmit,
      configObject,
      SaveButton: {
        spanInputs: 24, // this property to be set on screen level
        nativeType: 'button' // this property to be set on screen level
      },
      BackButton: {
        spanInputs: 24, // this property to be set on screen level
        nativeType: 'button' // this property to be set on screen level
      },
      SendToCPUButton: {
        spanInputs: 24, // this property to be set on screen level
        nativeType: 'button' // this property to be set on screen level
      },
      ScanButton: {
        spanInputs: 15, // this property to be set on screen level
        nativeType: 'button' // this property to be set on screen level
      },
      FileTextBox: {
        spanInputs: 24,
        spanLabels: 0
      },
      LCNoTextBox: {
        spanInputs: 24,
        spanLabels: 0
      },
      BranchCodeTextBox: {
        spanInputs: 7,
        spanLabels: 16
      },
      RefNoTextBox: {
        spanInputs: 17,
        spanLabels: 4
      },
      YearTextBox: {
        spanInputs: 12,
        spanLabels: 4
      }
    };
  }
};
</script>