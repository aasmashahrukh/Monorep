<template>
  <Megaset1124 :configObj="configurationObject" />
</template>
<script>
import Megaset1124 from './MegaSet1124.vue';
import { reactive, ref } from 'vue';
export default {
  components: {
    Megaset1124
  },
  methods: {},
  setup() {
    return reactive({
      configurationObject: {
        componentProps: {
          SaveButton: {
            isVisible: true,
            isDisabled: false,
            label: 'Save',
            labelFontWeight: 'bold'
          },
          BackButton: {
            isVisible: true,
            isDisabled: false,
            label: 'Back',
            labelFontWeight: 'bold'
          },
          SendToCPUButton: {
            isVisible: true,
            isDisabled: false,
            label: 'Send to CPU',
            labelFontWeight: 'bold'
          },
          ScanButton: {
            isVisible: true,
            isDisabled: false,
            label: 'Scan',
            labelFontWeight: 'bold'
          },
          FileTextBox: {
            label: '',
            FileTextBoxTextvalue: '',
            isDisabled: true,
            backgroundColor: 'white',
            isVisible: ref(true)
          },
          LCNoTextBox: {
            label: 'L/C No.',
            LCNoTextBoxTextvalue: '',
            isDisabled: false,
            backgroundColor: 'white',
            isVisible: ref(true),
            inputLength: 24
          },
          BranchCodeTextBox: {
            label: 'Branch Code - Ref No / Year',
            BranchCodeTextBoxValue: '',
            isDisabled: false,
            backgroundColor: 'white',
            isVisible: ref(true),
            inputLength: 24
          },
          RefNoTextBox:{
            label: '-',
            RefNoTextBoxTextFieldValue: '',
            isDisabled: false,
            backgroundColor: 'white',
            isVisible: ref(true),
            inputLength: 24,
            labelFontWeight: "bold"
          },
          YearTextBox:{
            label: '/',
            YearTextBoxTextFieldValue: '',
            isDisabled: false,
            backgroundColor: 'white',
            isVisible: ref(true),
            labelFontWeight: "bold"

          },
          section1: {
            isVisible: true
          },
          section2: {
            isVisible: true
          },
          section3: {
            isVisible: true
          }
        }
      }
    });
  }
};
</script>