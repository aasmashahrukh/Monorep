// Megaset1124.stories.js

import Megaset1124 from "../MegaSet/MegaSet1124.vue";
import { ref } from "vue";

export default {
  /* 👇 The title prop is optional.
   * See https://storybook.js.org/docs/vue/configure/overview#configure-story-loading
   * to learn how to generate automatic titles
   */
  title: "Megaset1124",
  component: Megaset1124,
};

const configurationObject = {
  componentProps: {
    SaveButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Save',
      labelFontWeight: 'bold'
    },
    BackButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Back',
      labelFontWeight: 'bold'
    },
    SendToCPUButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Send to CPU',
      labelFontWeight: 'bold'
    },
    ScanButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Scan',
      labelFontWeight: 'bold'
    },
    FileTextBox: {
      label: '',
      FileTextBoxTextvalue: '',
      isDisabled: true,
      backgroundColor: 'white',
      isVisible: ref(true)
    },
    LCNoTextBox: {
      label: 'L/C No.',
      LCNoTextBoxTextvalue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    BranchCodeTextBox: {
      label: 'Branch Code - Ref No / Year',
      BranchCodeTextBoxValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    RefNoTextBox:{
      label: '-',
      RefNoTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24,
      labelFontWeight: "bold"
    },
    YearTextBox:{
      label: '/',
      YearTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      labelFontWeight: "bold"

    },
    section1: {
      isVisible: true
    },
    section2: {
      isVisible: true
    },
    section3: {
      isVisible: true
    }
  }
}

const configurationObject_SS_EXP_36_Set_1 = {
  componentProps: {
    SaveButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Save',
      labelFontWeight: 'bold'
    },
    BackButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Back',
      labelFontWeight: 'bold'
    },
    SendToCPUButton: {
      isVisible: false,
      isDisabled: false,
      label: 'Send to CPU',
      labelFontWeight: 'bold'
    },
    ScanButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Scan',
      labelFontWeight: 'bold'
    },
    FileTextBox: {
      label: '',
      FileTextBoxTextvalue: '',
      isDisabled: true,
      backgroundColor: 'white',
      isVisible: ref(true)
    },
    LCNoTextBox: {
      label: 'L/C No.',
      LCNoTextBoxTextvalue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    BranchCodeTextBox: {
      label: 'Branch Code - Ref No / Year',
      BranchCodeTextBoxValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    RefNoTextBox:{
      label: '-',
      RefNoTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24,
      labelFontWeight: "bold"
    },
    YearTextBox:{
      label: '/',
      YearTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      labelFontWeight: "bold"

    },
    section1: {
      isVisible: false
    },
    section2: {
      isVisible: true
    },
    section3: {
      isVisible: true
    }
  }
};

const configurationObject_SS_EXP_36_Set_2 = {
  componentProps: {
    SaveButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Save',
      labelFontWeight: 'bold'
    },
    BackButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Back',
      labelFontWeight: 'bold'
    },
    SendToCPUButton: {
      isVisible: false,
      isDisabled: false,
      label: 'Send to CPU',
      labelFontWeight: 'bold'
    },
    ScanButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Scan',
      labelFontWeight: 'bold'
    },
    FileTextBox: {
      label: '',
      FileTextBoxTextvalue: '',
      isDisabled: true,
      backgroundColor: 'white',
      isVisible: ref(true)
    },
    LCNoTextBox: {
      label: 'L/C No.',
      LCNoTextBoxTextvalue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(false),
      inputLength: 24
    },
    BranchCodeTextBox: {
      label: 'Branch Code - Ref No / Year',
      BranchCodeTextBoxValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    RefNoTextBox:{
      label: '-',
      RefNoTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24,
      labelFontWeight: "bold"
    },
    YearTextBox:{
      label: '/',
      YearTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      labelFontWeight: "bold"

    },
    section1: {
      isVisible: true
    },
    section2: {
      isVisible: true
    },
    section3: {
      isVisible: true
    }
  }
};

const configurationObject_SS_EXP_36_Set_3 = {
  componentProps: {
    SaveButton: {
      isVisible: false,
      isDisabled: false,
      label: 'Save',
      labelFontWeight: 'bold'
    },
    BackButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Back',
      labelFontWeight: 'bold'
    },
    SendToCPUButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Send to CPU',
      labelFontWeight: 'bold'
    },
    ScanButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Scan',
      labelFontWeight: 'bold'
    },
    FileTextBox: {
      label: '',
      FileTextBoxTextvalue: '',
      isDisabled: true,
      backgroundColor: 'white',
      isVisible: ref(true)
    },
    LCNoTextBox: {
      label: 'L/C No.',
      LCNoTextBoxTextvalue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    BranchCodeTextBox: {
      label: 'Branch Code - Ref No / Year',
      BranchCodeTextBoxValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    RefNoTextBox:{
      label: '-',
      RefNoTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24,
      labelFontWeight: "bold"
    },
    YearTextBox:{
      label: '/',
      YearTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      labelFontWeight: "bold"

    },
    section1: {
      isVisible: false
    },
    section2: {
      isVisible: true
    },
    section3: {
      isVisible: true
    }
  }
};

const configurationObject_SS_EXP_36_Set_4 = {
  componentProps: {
    SaveButton: {
      isVisible: false,
      isDisabled: false,
      label: 'Save',
      labelFontWeight: 'bold'
    },
    BackButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Back',
      labelFontWeight: 'bold'
    },
    SendToCPUButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Send to CPU',
      labelFontWeight: 'bold'
    },
    ScanButton: {
      isVisible: true,
      isDisabled: false,
      label: 'Scan',
      labelFontWeight: 'bold'
    },
    FileTextBox: {
      label: '',
      FileTextBoxTextvalue: '',
      isDisabled: true,
      backgroundColor: 'white',
      isVisible: ref(true)
    },
    LCNoTextBox: {
      label: 'L/C No.',
      LCNoTextBoxTextvalue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    BranchCodeTextBox: {
      label: 'Branch Code - Ref No / Year',
      BranchCodeTextBoxValue: '1001',
      isDisabled: true,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24
    },
    RefNoTextBox:{
      label: '-',
      RefNoTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      inputLength: 24,
      labelFontWeight: "bold"
    },
    YearTextBox:{
      label: '/',
      YearTextBoxTextFieldValue: '',
      isDisabled: false,
      backgroundColor: 'white',
      isVisible: ref(true),
      labelFontWeight: "bold"

    },
    section1: {
      isVisible: true
    },
    section2: {
      isVisible: true
    },
    section3: {
      isVisible: true
    }
  }
};

const Template = (args) => ({
  components: { Megaset1124 },
  setup() {
    return {
      args: {
        configObj: {
          componentProps: {
            SaveButton: {
              isVisible: true,
              isDisabled: false,
              label: 'Save',
              labelFontWeight: 'bold'
            },
            BackButton: {
              isVisible: true,
              isDisabled: false,
              label: 'Back',
              labelFontWeight: 'bold'
            },
            SendToCPUButton: {
              isVisible: true,
              isDisabled: false,
              label: 'Send to CPU',
              labelFontWeight: 'bold'
            },
            ScanButton: {
              isVisible: true,
              isDisabled: false,
              label: 'Scan',
              labelFontWeight: 'bold'
            },
            FileTextBox: {
              label: '',
              FileTextBoxTextvalue: '',
              isDisabled: true,
              backgroundColor: 'white',
              isVisible: ref(true)
            },
            LCNoTextBox: {
              label: 'L/C No.',
              LCNoTextBoxTextvalue: '',
              isDisabled: false,
              backgroundColor: 'white',
              isVisible: ref(true),
              inputLength: 24
            },
            BranchCodeTextBox: {
              label: 'Branch Code - Ref No / Year',
              BranchCodeTextBoxValue: '',
              isDisabled: false,
              backgroundColor: 'white',
              isVisible: ref(true),
              inputLength: 24
            },
            RefNoTextBox:{
              label: '-',
              RefNoTextBoxTextFieldValue: '',
              isDisabled: false,
              backgroundColor: 'white',
              isVisible: ref(true),
              inputLength: 24,
              labelFontWeight: "bold"
            },
            YearTextBox:{
              label: '/',
              YearTextBoxTextFieldValue: '',
              isDisabled: false,
              backgroundColor: 'white',
              isVisible: ref(true),
              labelFontWeight: "bold"
  
            },
            section1: {
              isVisible: true
            },
            section2: {
              isVisible: true
            },
            section3: {
              isVisible: true
            }
          }
        }
      }
    };
  },
  template: `<Megaset1124 v-bind="args" />`,
  methods: {},
});

const Sets_Template = (args) => ({
  components: { Megaset1124 },
  setup() {
    return { args };
  },
  template: `<Megaset1124 v-bind="args" />`,
  methods: {},
});

export const Primary = Template.bind({});
Primary.args = { configObj: configurationObject };

export const SS_EXP_36_Set_1 = Sets_Template.bind({});
SS_EXP_36_Set_1.args = { configObj: configurationObject_SS_EXP_36_Set_1 };

export const SS_EXP_36_Set_2 = Sets_Template.bind({});
SS_EXP_36_Set_2.args = { configObj: configurationObject_SS_EXP_36_Set_2 };

export const SS_EXP_36_Set_3 = Sets_Template.bind({});
SS_EXP_36_Set_3.args = { configObj: configurationObject_SS_EXP_36_Set_3 };


export const SS_EXP_36_Set_4 = Sets_Template.bind({});
SS_EXP_36_Set_4.args = { configObj: configurationObject_SS_EXP_36_Set_4 };