<template>
<MegaSet0001_1 :configObj="configurationObject"
  @onSubmit="onSubmit" />
</template>
<script>
import MegaSet0001_1 from '../MegaSet/MegaSet0001_1.vue';
import { reactive, ref } from 'vue';
export default {
  components: {
    MegaSet0001_1
  },
  methods: {
    onSubmit(val) {
      console.log(val);
    },
  },
  setup() {
    return reactive({
        configurationObject:{
          componentProps: {
          searchTypeRadioButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            radioLabel: '',
            backgroundColor: 'white',
            mandatory: ref(true),
            radioDisplay: '',
            searchTypeRadioButtonValues: 'WithoutAgency',
            radioGroup: [
              {
                label: 'Search By Customer',
                value: 'Search By Customer',
                isDisabled: false
              },

              {
                label: 'Search By Invoice',
                value: 'Search By Invoice',
                isDisabled: false
              }
            ]
          },
          Branch: {
            BranchList: [{
              value: "KARACHI MAIN-1001",
              option: ""
            }],
            isDisabled: ref(false),
            isVisible: ref(true),
            tabIndex: "",
            defaultValue: "",
            colorinput: "",
            colorLabel: "",
            dropDownLabel: "Branch",
            mandatory: ""

          },
          CustomerNumberTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            CustomerNumberTextBoxValue: "",
            textColor: "Black",
            labelColor: "Black",
            labelFontWeight: 12,
            mandatory: true,
            label: ref("Customer No."),
            backgroundColor: "White",
            maxlength: 30,
            dataType: "alphaNumericSpecial",
            inputLength: "",
            tabIndex: ""
          },
          SearchButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: "Search",
            nativeType: "button",
            tabIndex: ""
          },
          InvoiceNumberTextBox: {
            isDisabled: ref(false),
            isVisible: ref(true),
            InvoiceNumberTextBoxValue: "",
            textColor: "Black",
            labelColor: "Black",
            labelFontWeight: 12,
            mandatory: true,
            label: ref("Invoice No."),
            backgroundColor: "White",
            maxlength: 30,
            dataType: "alphaNumericSpecial",
            inputLength: "",
            tabIndex: ""
          },
          CustomerInformationTable: {
            tableWidth: "100",
            tableHeight: '350px',
            tableData: [],
            tableColumns: [
              {
                prop: 'BillNo',
                label: 'Bill No.',
                align: 'left',
                columnsWidth: '20'
              },
              {
                prop: 'InvoiceNo',
                label: 'Invoice No.',
                align: 'left',
                columnsWidth: '20'
              },
              {
                prop: 'AccountNo',
                label: 'Account No.',
                align: 'left',
                columnsWidth: '20'
              },
              {
                prop: 'BillDate',
                label: 'Bill Date',
                align: 'left',
                columnsWidth: '20'
              },
              {
                prop: 'BillAmount',
                label: 'Bill Amount',
                align: 'left',
                columnsWidth: '20'
              },
            ],
            isDisabled: ref(false),
            isVisible: ref(true)
          },
          OkButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: "Ok",
            nativeType: "button",
            tabIndex: ""
          },

          ExitButton: {
            isDisabled: ref(false),
            isVisible: ref(true),
            label: "Exit",
            nativeType: "button",
            tabIndex: ""
          },
          Section1: {
            isDisabled: false,
            isVisible: true,
          },

          Section2: {
            isDisabled: false,
            isVisible: true,
          },
          Section3: {
            isDisabled: false,
            isVisible: true,
          },
        }
        }
    });
  }
};
</script>