<template>
<Form as="el-form" @submit="onSubmit">
    <fieldset v-if="configObject.Section1.isVisible">
      <el-row>
        <el-col :md="19" :lg="19" id="searchRadio">
          <GenericRadioButton name="searchTypeRadioButton" @GenericRadioButton-onChange="(val) => { $emit('searchTypeRadioButton-onChange', val); }
            " ref="RefsearchTypeRadioButton" 
            v-bind="{...searchTypeRadioButton,...configObject.searchTypeRadioButton}" :values="configObject.searchTypeRadioButton.searchTypeRadioButtonValues"
            v-if="configObject.searchTypeRadioButton != undefined ? configObject.searchTypeRadioButton.isVisible : false" />
        </el-col>
      </el-row>
      <el-row>
        <el-col :md="1" :lg="1"></el-col>
        <el-col :md="22" :lg="22">
          <GenericDropDown @GenericDropDown-onChange="(val) => { $emit('Branch-onChange', val) }"
            v-bind="{ ...Branch, ...configObject.Branch }" :values="configObject.Branch.BranchList" name="Branch"
            ref="refBranch" 
            v-if="configObject.Branch.isVisible">
          </GenericDropDown>
        </el-col>
      </el-row>
      <el-row>
        <el-col :md="1" :lg="1"></el-col>
        <el-col :md="11" :lg="11">
          <GenericTextBox @GenericTextBox-onChange="(val) => { $emit('CustomerNumberTextBox-onChange', val); }"
            @GenericTextBox-onKeypress="(val) => { $emit('CustomerNumberTextBox-onKeypress', val); }"
            @GenericTextBox-onBlur="(val) => { $emit('CustomerNumberTextBox-onBlur', val); }"
            @GenericTextBox-onInput="(val) => { $emit('CustomerNumberTextBox-onInput', val); }"
            @GenericTextBox-onKeyup="(val) => { $emit('CustomerNumberTextBox-onKeyup', val); }"
            @GenericTextBox-onFocus="(val) => { $emit('CustomerNumberTextBox-onFocus', val); }"
            name="CustomerNumberTextBox" ref="refCustomerNumberTextBox"
            v-if="configObject.CustomerNumberTextBox.isVisible"
            v-bind="{ ...CustomerNumberTextBox, ...configObject.CustomerNumberTextBox }" :values="configObject.CustomerNumberTextBox.CustomerNumberTextBoxValue">
          </GenericTextBox>
        </el-col>
        <el-col :md="2" :lg="2">
          <GenericButton @GenericButton-onClick="$emit('SearchButton-onClick')"
            @GenericButton-onFocus="$emit('SearchButton-onFocus')" name="SearchButton" ref="refSearchButton"
            v-bind="{ ...SearchButton, ...configObject.SearchButton }" v-if="configObject.SearchButton.isVisible" />
        </el-col>
      </el-row>
      <el-row>
        <el-col :md="1" :lg="1"></el-col>
        <el-col :md="11" :lg="11">
          <GenericTextBox @GenericTextBox-onChange="(val) => { $emit('InvoiceNumberTextBox-onChange', val); }"
            @GenericTextBox-onKeypress="(val) => { $emit('InvoiceNumberTextBox-onKeypress', val); }"
            @GenericTextBox-onBlur="(val) => { $emit('InvoiceNumberTextBox-onBlur', val); }"
            @GenericTextBox-onInput="(val) => { $emit('InvoiceNumberTextBox-onInput', val); }"
            @GenericTextBox-onKeyup="(val) => { $emit('InvoiceNumberTextBox-onKeyup', val); }"
            @GenericTextBox-onFocus="(val) => { $emit('InvoiceNumberTextBox-onFocus', val); }"
            name="InvoiceNumberTextBox" ref="refInvoiceNumberTextBox" v-if="configObject.InvoiceNumberTextBox.isVisible"
            v-bind="{ ...InvoiceNumberTextBox, ...configObject.InvoiceNumberTextBox }" :values="configObject.InvoiceNumberTextBox.InvoiceNumberTextBoxValue">
          </GenericTextBox>
        </el-col>
      </el-row>
    </fieldset>
    <br>
    <el-row v-if="configObject.Section2 != undefined ? configObject.Section2.isVisible : false">
      <el-col :md="1" :lg="1"></el-col>
      <el-col :lg="24" :md="24" :sm="24">
        <el-col :md="1" :lg="1"></el-col>
        <GenericSortableTableView @GenericSortableTableView-onCurrentRow="(val) => { $emit('CustomerInformationTable-onCurrentRow', val); }
          " @GenericSortableTableView-onClickRow="(val) => { $emit('CustomerInformationTable-onClickRow', val); }
            " @GenericSortableTableView-onDoubleClickRow="(val) => { $emit('CustomerInformationTable-onDoubleClickRow', val); }
                " name="CustomerInformationTable" ref="RefCustomerInformationTable" 
                v-bind="{ ...CustomerInformationTable,...configObject.CustomerInformationTable}"
          v-if="configObject.CustomerInformationTable != undefined ? configObject.CustomerInformationTable.isVisible : false" />
      </el-col>
    </el-row>
    <fieldset v-if="configObject.Section3.isVisible">
      <el-row>
        <el-col :md="1" :lg="1"></el-col>
        <el-col :md="2" :lg="2">
          <GenericButton @GenericButton-onClick="$emit('OkButton-onClick')"
            @GenericButton-onFocus="$emit('OkButton-onFocus')" name="OkButton" ref="refOkButton"
            v-bind="{ ...OkButton, ...configObject.OkButton }" v-if="configObject.OkButton.isVisible" />
        </el-col>
        <el-col :md="16" :lg="16"></el-col>
        <el-col :md="2" :lg="2">
          <GenericButton @GenericButton-onClick="$emit('ExitButton-onClick')"
            @GenericButton-onFocus="$emit('ExitButton-onFocus')" name="ExitButton" ref="refExitButton"
            v-bind="{ ...ExitButton, ...configObject.ExitButton }" v-if="configObject.ExitButton.isVisible" />
        </el-col>
      </el-row>
    </fieldset>
  </Form>
</template>
<script>
import { Form, useForm } from 'vee-validate';
import { reactive } from 'vue';
import {
  GenericTextBox,
  GenericButton,
  GenericDropDown,
  GenericRadioButton,
  GenericSortableTableView,
} from '@teresol-v2/ui-components'
export default {
  name: 'MegaSet0001_1',

  components: {
    Form,
    GenericDropDown,
    GenericTextBox,
    GenericRadioButton,
    GenericButton,
    GenericSortableTableView,
  },
  props: {
    configObj: {}
  },
  setup(props, { emit }) {
    useForm();
    function onSubmit(values) {
      emit('onSubmit', values);
    }
    const configObject = reactive({
      ...props.configObj.componentProps
    });

    return {
      onSubmit,
      configObject,
      searchTypeRadioButton: { spanLabels: 6, spanInputs: 15 },
      Branch: { spanLabels: 4, spanInputs: 10 },
      CustomerNumberTextBox: { spanLabels: 8, spanInputs: 15 },
      SearchButton: { spanLabels: 0, spanInputs: 22 },
      InvoiceNumberTextBox: { spanLabels: 8, spanInputs: 15 },
      OkButton: { spanLabels: 0, spanInputs: 24 },
      ExitButton: { spanLabels: 0, spanInputs: 24 },
      CustomerInformationTable: {
        spanLabels: 24,
        spanInputs: 24,
     
      },
    };
  }
};
</script>
