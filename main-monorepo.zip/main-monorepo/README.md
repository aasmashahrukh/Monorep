# Create new Megset
To Create new Megaset we consider an example.

Following are the steps to clone monorepo and create your megaset folder:
clone monorepo repository: 
``` bash
$ git clone http://192.168.236.5:8040/r2-bcbs-projects/front-end-development/megaset-monorepo.git
```

run 
```bash
$ npm i
```

Run following Command to generate new Megaset

```bash
$ hygen megaset new --number <megaset number>
```
example: hygen megaset new --number 3

this will generate folder containing skeleton code structure of megaset in packages folder, remember newly generated megaset code exist on our local machine so we have to create megaset project on gitlab remote as well(in Teresol Megasets-v2 group) in order to push that generated megaset code.

**Megaset naming convention while Creating new project on gitlab remote should be as** MegaSet<> **e.g MegaSet10** 

Team Leads has been granted to create new megaset project on git lab remote, once project will be created on git lab we need to push the generated megaset code to this project repository.


# Modify An Existing Megaset

To Modify an existing megaset we consider an example. 

Following are the steps to clone monorepo and add your megaset as a submodule:
clone monorepo repository: 
``` bash
$ git clone http://192.168.236.5:8040/r2-bcbs-projects/front-end-development/megaset-monorepo.git
```

run 
```bash
$ npm i
```
add megaset as a submodule inside the packages folder (starter project will be provided in the repository)

in case of modifying Teresol Megasets

```bash
$ cd packages
$ git submodule add http://192.168.236.5:8040/r2-bcbs-projects/front-end-development/teresol-megasets/<>.git
```
in case of modifying Teresol Megasets-v2

```bash
$ cd packages
$ git submodule add http://192.168.236.5:8040/r2-bcbs-projects/front-end-development/teresol-megasets-v2/<>.git
```

```bash
$ cd <megaset-folder>
```	
Developers will now code the megaset.vue file and storybook.js file in order to run it.
To serve the megaset go inside the megaset folder and run” 
```bash
$ npm run serve
```
In order to run its storybook go back to the monrepo directory 
and run: 
```bash			
$ npm run storybook
```
Push the megaset to git, cd inside the megaset folder [this folder will include its own .git which will help developers to push the megaset code to its respective repository.] and push the megaset repository.



**Note that without proper story book running megaset will not be pushed to nexus. Developers will NOT publish megasets to nexus instead validation team will publish it**



## Architectural Notes

### Common Package.json:

After going through majority of already developed megasets in OBS and Teller module, it is observed that the package.json is inconsistent. The following points are observed:
Same dependencies with the different versions across majority of megasets.
Dependencies should only be included in devDependencies but in majority of megasets they are also included in dependencies part of the package.json which in result packages the dependencies with the megaset in nexus.

#### Solution:

Megaset repository with package.json in packaged branch of git would be provided (dependencies added should already be enough for the development) and it wont be changed  until a dependency is required which is not present in that package.json (Developer will contact the validation team for adding or updating the dependency). Only @teresol/ui-components versions can be updated.

### Dos/Donots in coding:

#### Props Binding

 One of the major issues in megaset<>.vue file is binding of props from megaset to lib-component. 
Consider the following example taken from existing megaset.

```html
<el-col :md="12" :lg="12">
<NameTextBox
    @NameTextBox-onBlur="
    (val) => {
        $emit('NameTextBox-onBlur', val);
    }
    "
    name="NameTextBox"
    :colorinput="configObject.NameTextBox.inputColor"
    :colorLabel="configObject.NameTextBox.labelColor"
    :isDisable="configObject.NameTextBox.isDisabled"
    :values="configObject.NameTextBox.NameTextBoxValue"
    :spanLabels="NameTextBox.spanLabel"
    :spanInputs="NameTextBox.spanInput"
    v-if="configObject.NameTextBox.isVisible"
/>
</el-col>
```
In the above example, every binding of props is done separately which is not correct way of binding instead v-bind should be used in order to bind the props to lib-components.
(Note that the props coming from configObject should be named same as what they are in lib-components which is the correct way of binding).

Here is an example of how to code it using v-bind:
```js
            <el-col :md="12" :lg="12">
              <NameTextBox
                name="NameTextBox"
                @NameTextBox-onBlur="
                  (val) => {
                    $emit('NameTextBox-onBlur', val);
                  }
                "
                v-bind="{ ...NameTextBox, ...configObject.NameTextBox }"
                :values="configObject.NameTextBox.NameTextBoxValue"
                v-if="configObject.NameTextBox.isVisible"
              />
            </el-col>
```

...configObject.TelephoneNumberTextBox  binds props coming from configObject are mapped through a loop provided by v-bind.
...TelephoneNumberTextBox binds props coming from TelephoneNumberTextBox local object within megaset (Mostly input-span and label-span are changed) are mapped by v-bind.

v-bind="{ ...TelephoneNumberTextBox, ...configObject.TelephoneNumberTextBox }"

both of the above binding are done within {} of v-bind.
 
Note that v-bind will only work if the props coming from outside have the same name as what lib-components are expecting.

This is the reason why :values prop is not binded using v-bind since the configObject doesnt have values instead it has TelephoneNumberTextBoxValue which means that names of the props are not same hence it is written outside the v-bind scope.

Same Case when populating configObject:


```js
 const configObject = reactive({
      title: props.configObj,
      NameTextBox: props.configObj.componentProps.NameTextBox,
      AddressTextBox: props.configObj.componentProps.AddressTextBox,
      NoLabelAddressTextBox:
        props.configObj.componentProps.NoLabelAddressTextBox,
      TelephoneNumberTextBox:
        props.configObj.componentProps.TelephoneNumberTextBox,
      AmountTextBox: props.configObj.componentProps.AmountTextBox,
      RemarksTextBox: props.configObj.componentProps.RemarksTextBox,
      OSWaivedTextBox: props.configObj.componentProps.OSWaivedTextBox
      ? props.configObj.componentProps.OSWaivedTextBox
      : props.configObj.componentProps,
      NostroBankTextBox: props.configObj.componentProps.NostroBankTextBox,
      AccountTextBox: props.configObj.componentProps.AccountTextBox,
      WaiverApplied: props.configObj.componentProps.WaiverApplied
        ? props.configObj.componentProps.WaiverApplied
        : props.configObj.componentProps,
      WaiverApplied1: props.configObj.componentProps.WaiverApplied1
        ? props.configObj.componentProps.WaiverApplied1
        : props.configObj.componentProps,
      ChargesinPKRAccountTextBox:
        props.configObj.componentProps.ChargesinPKRAccountTextBox,

      UsdToPkrRateTextBox:
        props.configObj.componentProps.UsdToPkrRateTextBox
        ? props.configObj.componentProps.UsdToPkrRateTextBox
        : props.configObj.componentProps,
        TreasuryRateTextBox:
        props.configObj.componentProps.TreasuryRateTextBox
        ? props.configObj.componentProps.TreasuryRateTextBox
        : props.configObj.componentProps,
      BeneficiaryTextBox: props.configObj.componentProps.BeneficiaryTextBox,

      ChargesTable: props.configObj.componentProps.ChargesTable,

      ChargesChequeTextBox: props.configObj.componentProps.ChargesChequeTextBox,
      ChargesInstructionTextBox:
        props.configObj.componentProps.ChargesInstructionTextBox,
      TotalLocalEquivalentTextBox:
        props.configObj.componentProps.TotalLocalEquivalentTextBox,

      TotalChargesPkrTextBox:
        props.configObj.componentProps.TotalChargesPkrTextBox,
      AddChargesButton: props.configObj.componentProps.AddChargesButton,

      ChangeChargesButton: props.configObj.componentProps.ChangeChargesButton,
      OkButton: props.configObj.componentProps.OkButton,

      ExitButton: props.configObj.componentProps.ExitButton,
      BackButton: props.configObj.componentProps.BackButton,
      section1: props.configObj.componentProps.section1,
      section2: props.configObj.componentProps.section2,
      section3: props.configObj.componentProps.section3,
      section4: props.configObj.componentProps.section4,
    });

```
This should also be binded using ... operator

```js
    const configObject = reactive({
      title: props.configObj,
      ...props.configObj.componentProps
    });

```
#### Refs

Consider the following case,reference should be removed from return object and should be added on components written in template.


```js
    return {
      onSubmit,
      configObject,
      NameTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      AddressTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      NoLabelAddressTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      TelephoneNumberTextBox: {
        spanInput: ref(12), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      BeneficiaryTextBox: {
        spanInput: ref(16),
        spanLabel: ref(6),
      },
      AmountTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      RemarksTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      OSWaivedTextBox: {
        spanInput: ref(24), // this property to be set on screen level
        spanLabel: ref(0), // this property to be set on screen level
      },
      NostroBankTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      AccountTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      TotalLocalEquivalentTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      ChargesChequeTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      ChargesInstructionTextBox: {
        spanInput: ref(16), // this property to be set on screen level
        spanLabel: ref(6), // this property to be set on screen level
      },
      ChargesinPKRAccountTextBox: {
        spanInput: ref(14), // this property to be set on screen level
        spanLabel: ref(7), // this property to be set on screen level
      },
      UsdToPkrRateTextBox: {
        spanInput: ref(24), // this property to be set on screen level
        spanLabel: ref(0), // this property to be set on screen level
      },
      TreasuryRateTextBox: {
        spanInput: ref(24), // this property to be set on screen level
        spanLabel: ref(0), // this property to be set on screen level
      },
      ChargesTable: {
        spanLabel: ref(0),
        spaninput: ref(24),
        tableHeight: ref(185),
        tableWidth: ref("100%"),
      },
      TotalChargesPkrTextBox: {
        spanInput: ref(24), // this property to be set on screen level
        spanLabel: ref(0), // this property to be set on screen level
      },
      AddChargesButton: {
        spanInput: ref(24), // this property to be set on screen level
        nativeType: "button", // this property to be set on screen level
      },
      ChangeChargesButton: {
        spanInput: ref(24), // this property to be set on screen level
        nativeType: "button", // this property to be set on screen level
      },
      OkButton: {
        spanInput: ref(24), // this property to be set on screen level
        nativeType: "submit", // this property to be set on screen level
      },
      ExitButton: {
        spanInput: ref(24), // this property to be set on screen level
        nativeType: "button", // this property to be set on screen level
      },
      BackButton: {
        spanInput: ref(24), // this property to be set on screen level
        nativeType: "button", // this property to be set on screen level
      },
    };
  },

```
It should be like this:

```js
  return {
      onSubmit,
      configObject,
      NameTextBox: { spanInputs: 16, spanLabels: 6 },
      AddressTextBox: { spanInputs: 16, spanLabels: 6 },
      NoLabelAddressTextBox: { spanInputs: 16, spanLabels: 6 },
      TelephoneNumberTextBox: { spanInputs: 12, spanLabels: 6 },
      BeneficiaryTextBox: { spanInputs: 16, spanLabels: 6 },
      AmountTextBox: { spanInputs: 16, spanLabels: 6 },
      RemarksTextBox: { spanInputs: 16, spanLabels: 6 },
      OSWaivedTextBox: { spanInputs: 24, spanLabels: 0 },
      NostroBankTextBox: { spanInputs: 16, spanLabels: 6 },
      AccountTextBox: { spanInputs: 16, spanLabels: 6 },
      TotalLocalEquivalentTextBox: { spanInputs: 16, spanLabels: 6 },
      ChargesChequeTextBox: { spanInputs: 16, spanLabels: 6 },
      ChargesInstructionTextBox: { spanInputs: 16, spanLabels: 6 },
      ChargesinPKRAccountTextBox: { spanInputs: 14, spanLabels: 7 },
      UsdToPkrRateTextBox: { spanInputs: 24, spanLabels: 0 },
      TreasuryRateTextBox: { spanInputs: 24, spanLabels: 0 },
      ChargesTable: {
        spanLabels: 0,
        spanInputs: 24,
        tableHeight: 185,
        tableWidth: '100%'
      },
      TotalChargesPkrTextBox: { spanInputs: 24, spanLabels: 0 },
      AddChargesButton: { spanInputs: 24, nativeType: 'button' },
      ChangeChargesButton: { spanInputs: 24, nativeType: 'button' },
      OkButton: { spanInputs: 24, nativeType: 'submit' },
      ExitButton: { spanInputs: 24, nativeType: 'button' },
      BackButton: { spanInputs: 24, nativeType: 'button' }
    };
  }

```
Refs should be added in component tag written in template and it should be like this:

```js
            <el-col :md="12" :lg="12">
              <NameTextBox
                name="NameTextBox"
                @NameTextBox-onBlur="
                  (val) => {
                    $emit('NameTextBox-onBlur', val);
                  }
                "
                ref="RefNameTextBox"
                v-bind="{ ...NameTextBox, ...configObject.NameTextBox }"
                :values="configObject.NameTextBox.NameTextBoxValue"
                v-if="configObject.NameTextBox.isVisible"
              />
            </el-col>
```
### Structrual change:

The following megaset structure should be followed. Repositories of respective megasets will be provided by default structure, developers will only have to code the megaset<>.vue and megaset<>.stories.js.
Note that without working story book megaset will not be pushed.

- babel.config.js
- dev
  - serve.js
  - serve.vue
- package.json
- src
  - install.js
  - MegaSet
    - MegaSet89.vue
    - MS89Testing.vue
  - router
    - index.js
  - stories
    - assets
      - code-brackets.svg
      - colors.svg
      - comments.svg
      - direction.svg
      - flow.svg
      - plugin.svg
      - repo.svg
      - stackalt.svg
    - MegaSet89.stories.js

### Story Book:


**TODO**


# Megaset Conventions and Rules

**The following document must be carefully studied and followed**



1.Dos/Donots in coding :

    1 Do not use ids instead use refs
    2 Do not bind props one by one instead use v-bind (... operator)








