import type { SideObject } from "../types";
export default function getFreshSideObject(): SideObject;
