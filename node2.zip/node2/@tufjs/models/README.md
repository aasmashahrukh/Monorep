# @tufjs/models

TUF metadata model objects.
