# Storybook Telemetry

Storybook collects completely anonymous telemetry data about general usage. Participation in this program is optional and it’s easy to opt-out.

For more information visit: [storybook.js.org/telemetry](https://storybook.js.org/telemetry)
