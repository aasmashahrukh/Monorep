// DEPRECATED
// Do not import @storybook/source-loader/extract-source directly.
// Import @storybook/source-loader instead.
export * from './dist/ts3.9/extract-source.d';