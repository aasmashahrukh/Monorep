// DEPRECATED
// Do not import @storybook/source-loader/extract-source directly.
// Import @storybook/source-loader instead.
module.exports = require('./dist/cjs/extract-source');
