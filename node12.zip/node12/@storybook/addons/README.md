# Storybook Addons

Storybook Addons is a node module which is used to load custom addons to storybook.

It stores addon loaders, communication channel and other resources which can be used by storybook implementations where required.

* * *

For more information visit: [storybook.js.org](https://storybook.js.org)
