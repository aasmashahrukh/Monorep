import LinkTo from './dist/esm/react';

export default LinkTo;
