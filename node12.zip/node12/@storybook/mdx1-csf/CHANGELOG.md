# v0.0.1 (Mon May 23 2022)

#### 🐛 Bug Fix

- Add MDXv1 compiler, tests, example [#1](https://github.com/storybookjs/mdx1-csf/pull/1) ([@shilman](https://github.com/shilman))

#### ⚠️ Pushed to `main`

- Initial commit ([@shilman](https://github.com/shilman))

#### Authors: 1

- Michael Shilman ([@shilman](https://github.com/shilman))
