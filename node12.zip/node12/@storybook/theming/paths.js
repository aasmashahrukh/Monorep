// We used to alias paths, but now that we are bundling dependencies, we do not need to
module.exports = {};
