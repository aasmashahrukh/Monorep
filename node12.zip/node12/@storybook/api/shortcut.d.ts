export * from './dist/ts3.9/lib/shortcut.d';
