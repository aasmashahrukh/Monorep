# Storybook Docs Utils

Shared utility functions for frameworks to implement docs:

- ArgType extraction
- Dynamic snippet generation
- Is the user using docs or controls?

This library is used by most framework packages so it and its dependencies should be minimized
