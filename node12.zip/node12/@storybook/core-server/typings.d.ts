declare module 'global';
declare module '@storybook/semver';
declare module 'unfetch/dist/unfetch';
declare module 'lazy-universal-dotenv';
declare module 'pnp-webpack-plugin';
declare module '@storybook/theming/paths';
declare module '@storybook/ui/paths';
declare module 'better-opn';
declare module 'open';
declare module 'x-default-browser';
declare module '@storybook/ui';
declare module '@discoveryjs/json-ext';
declare module 'watchpack';

