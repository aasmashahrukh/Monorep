const build = require('./dist/cjs/standalone').default;

module.exports = build;
