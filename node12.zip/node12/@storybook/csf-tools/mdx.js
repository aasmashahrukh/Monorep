module.exports = require('@storybook/mdx1-csf');
