import { CsfFile, CsfOptions } from './dist/ts3.9/index.d';

export declare const readCsfOrMdx: (fileName: string, options: CsfOptions) => Promise<CsfFile>;
export * from './dist/ts3.9/index.d';
