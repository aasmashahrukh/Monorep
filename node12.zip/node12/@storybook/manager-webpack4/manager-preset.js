module.exports = require('./dist/cjs/presets/manager-preset');
