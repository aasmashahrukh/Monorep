module.exports = require('../dist/frameworks/common/index');
