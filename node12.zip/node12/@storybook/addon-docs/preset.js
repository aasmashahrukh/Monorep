module.exports = require('./dist/cjs/preset');
