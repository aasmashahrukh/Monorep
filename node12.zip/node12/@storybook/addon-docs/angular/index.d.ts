export declare const setCompodocJson: (compodocJson: any) => void;
