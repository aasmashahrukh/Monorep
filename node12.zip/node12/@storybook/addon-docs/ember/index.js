/* eslint-disable no-underscore-dangle */
/* global window */

export const setJSONDoc = (jsondoc) => {
  window.__EMBER_GENERATED_DOC_JSON__ = jsondoc;
};
