module.exports = require('@storybook/core-server/standalone');
