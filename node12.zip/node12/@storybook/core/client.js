// @storybook/core was split into core-client and core-server.  This file is for backwards-compat.
export * from './dist/esm/index';
