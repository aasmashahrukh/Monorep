import type { CSSProperties } from 'vue';
declare const _default: import("vue").DefineComponent<{
    readonly type: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("../../../utils/props").BuildPropType<StringConstructor, "" | "default" | "primary" | "success" | "warning" | "info" | "danger" | "text", unknown>>, unknown, unknown, unknown, unknown>;
    readonly placement: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("@popperjs/core").Placement>, "bottom", unknown, unknown, unknown>;
    readonly popperOptions: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<Partial<import("@popperjs/core").Options>>, () => {}, unknown, unknown, unknown>;
    readonly size: import("../../../utils/props").BuildPropReturn<StringConstructor, "", unknown, unknown, unknown>;
    readonly splitButton: BooleanConstructor;
    readonly hideOnClick: import("../../../utils/props").BuildPropReturn<BooleanConstructor, true, unknown, unknown, unknown>;
    readonly loop: import("../../../utils/props").BuildPropReturn<BooleanConstructor, unknown, unknown, unknown, unknown>;
    readonly showTimeout: import("../../../utils/props").BuildPropReturn<NumberConstructor, 150, unknown, unknown, unknown>;
    readonly hideTimeout: import("../../../utils/props").BuildPropReturn<NumberConstructor, 150, unknown, unknown, unknown>;
    readonly tabindex: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | number>, 0, unknown, unknown, unknown>;
    readonly maxHeight: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | number>, "", unknown, unknown, unknown>;
    readonly popperClass: import("../../../utils/props").BuildPropReturn<StringConstructor, "", unknown, unknown, unknown>;
    readonly trigger: {
        type: import("vue").PropType<"click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[]>;
        default: string;
    };
    readonly effect: {
        readonly default: "light";
        readonly type: import("vue").PropType<string>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        readonly __elPropsReservedKey: true;
    };
}, {
    scrollbar: import("vue").Ref<null>;
    wrapStyle: import("vue").ComputedRef<CSSProperties>;
    dropdownTriggerKls: import("vue").ComputedRef<string[][]>;
    dropdownSize: import("vue").ComputedRef<import("../../../utils/types").ComponentSize>;
    currentTabId: import("vue").Ref<string | null>;
    handleCurrentTabIdChange: (id: string) => void;
    handlerMainButtonClick: (event: MouseEvent) => void;
    handleEntryFocus: (e: Event) => void;
    handleClose: () => void;
    handleOpen: () => void;
    onMountOnFocus: (e: Event) => void;
    popperRef: import("vue").Ref<({
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            disabled: boolean;
            style: import("vue").StyleValue;
            transition: string;
            offset: number;
            effect: string;
            visible: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<boolean | null>, unknown, unknown>;
            arrowOffset: number;
            boundariesPadding: number;
            fallbackPlacements: import("@popperjs/core").Placement[];
            gpuAcceleration: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], unknown, unknown>;
            placement: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>))[], unknown, unknown>;
            popperOptions: Partial<import("@popperjs/core").Options>;
            strategy: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], unknown, unknown>;
            className: string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[];
            enterable: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            pure: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            popperClass: string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[];
            popperStyle: import("vue").StyleValue;
            referenceEl: HTMLElement;
            stopPopperMouseEvent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            content: string;
            showAfter: number;
            hideAfter: number;
            appendTo: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | HTMLElement>, unknown, unknown>;
            rawContent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            persistent: boolean;
            teleported: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            trigger: "click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[];
            virtualRef: import("../..").Measurable;
            virtualTriggering: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            openDelay: number;
            visibleArrow: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            showArrow: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
        }> & Omit<Readonly<import("vue").ExtractPropTypes<{
            openDelay: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
            visibleArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            hideAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
            showArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            arrowOffset: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
            disabled: BooleanConstructor;
            trigger: {
                type: import("vue").PropType<"click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[]>;
                default: string;
            };
            virtualRef: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("../..").Measurable>, unknown, unknown, unknown, unknown>;
            virtualTriggering: import("../../../utils/props").BuildPropReturn<BooleanConstructor, unknown, unknown, unknown, unknown>;
            appendTo: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | HTMLElement>, string | (() => string) | undefined, unknown, unknown, unknown>;
            content: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            rawContent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            persistent: BooleanConstructor;
            ariaLabel: StringConstructor;
            visible: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | null>, (() => null) | null | undefined, unknown, unknown, unknown>;
            transition: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            teleported: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            style: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | CSSProperties | (() => string) | (() => CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
            className: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
                [x: string]: any;
            }) | (() => (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
            effect: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            enterable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            pure: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            popperClass: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
                [x: string]: any;
            }) | (() => (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
            popperStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | CSSProperties | (() => string) | (() => CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
            referenceEl: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<HTMLElement>, HTMLElement | (() => HTMLElement) | undefined, unknown, unknown, unknown>;
            stopPopperMouseEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            zIndex: NumberConstructor;
            boundariesPadding: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 0 | (() => 0) | undefined, false, unknown, unknown>;
            fallbackPlacements: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("@popperjs/core").Placement[]) | (() => import("@popperjs/core").Placement[]) | ((new (...args: any[]) => import("@popperjs/core").Placement[]) | (() => import("@popperjs/core").Placement[]))[], (() => never[]) | undefined, false, unknown, unknown>;
            gpuAcceleration: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], true | (() => true) | undefined, false, unknown, unknown>;
            offset: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 12 | (() => 12) | undefined, false, unknown, unknown>;
            placement: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>))[], "bottom" | (() => "bottom") | undefined, false, unknown, unknown>;
            popperOptions: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => Partial<import("@popperjs/core").Options>) | (() => Partial<import("@popperjs/core").Options>) | ((new (...args: any[]) => Partial<import("@popperjs/core").Options>) | (() => Partial<import("@popperjs/core").Options>))[], (() => {}) | undefined, false, unknown, unknown>;
            strategy: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], "absolute" | (() => "absolute") | undefined, false, unknown, unknown>;
            showAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
        }>> & {
            [x: string & `on${string}`]: ((...args: any[]) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "style" | "transition" | "offset" | "effect" | "visible" | "arrowOffset" | "boundariesPadding" | "fallbackPlacements" | "gpuAcceleration" | "placement" | "popperOptions" | "strategy" | "className" | "enterable" | "pure" | "popperClass" | "popperStyle" | "referenceEl" | "stopPopperMouseEvent" | "content" | "showAfter" | "hideAfter" | "appendTo" | "rawContent" | "persistent" | "teleported" | "trigger" | "virtualRef" | "virtualTriggering" | "openDelay" | "visibleArrow" | "showArrow">;
        $attrs: {
            [x: string]: unknown;
        };
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $emit: (event: string, ...args: any[]) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            openDelay: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
            visibleArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            hideAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
            showArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            arrowOffset: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
            disabled: BooleanConstructor;
            trigger: {
                type: import("vue").PropType<"click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[]>;
                default: string;
            };
            virtualRef: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("../..").Measurable>, unknown, unknown, unknown, unknown>;
            virtualTriggering: import("../../../utils/props").BuildPropReturn<BooleanConstructor, unknown, unknown, unknown, unknown>;
            appendTo: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | HTMLElement>, string | (() => string) | undefined, unknown, unknown, unknown>;
            content: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            rawContent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            persistent: BooleanConstructor;
            ariaLabel: StringConstructor;
            visible: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | null>, (() => null) | null | undefined, unknown, unknown, unknown>;
            transition: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            teleported: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            style: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | CSSProperties | (() => string) | (() => CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
            className: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
                [x: string]: any;
            }) | (() => (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
            effect: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            enterable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            pure: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            popperClass: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
                [x: string]: any;
            }) | (() => (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
            popperStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | CSSProperties | (() => string) | (() => CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
            referenceEl: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<HTMLElement>, HTMLElement | (() => HTMLElement) | undefined, unknown, unknown, unknown>;
            stopPopperMouseEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            zIndex: NumberConstructor;
            boundariesPadding: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 0 | (() => 0) | undefined, false, unknown, unknown>;
            fallbackPlacements: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("@popperjs/core").Placement[]) | (() => import("@popperjs/core").Placement[]) | ((new (...args: any[]) => import("@popperjs/core").Placement[]) | (() => import("@popperjs/core").Placement[]))[], (() => never[]) | undefined, false, unknown, unknown>;
            gpuAcceleration: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], true | (() => true) | undefined, false, unknown, unknown>;
            offset: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 12 | (() => 12) | undefined, false, unknown, unknown>;
            placement: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>))[], "bottom" | (() => "bottom") | undefined, false, unknown, unknown>;
            popperOptions: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => Partial<import("@popperjs/core").Options>) | (() => Partial<import("@popperjs/core").Options>) | ((new (...args: any[]) => Partial<import("@popperjs/core").Options>) | (() => Partial<import("@popperjs/core").Options>))[], (() => {}) | undefined, false, unknown, unknown>;
            strategy: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], "absolute" | (() => "absolute") | undefined, false, unknown, unknown>;
            showAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
        }>> & {
            [x: string & `on${string}`]: ((...args: any[]) => any) | undefined;
        }, {
            compatShowAfter: import("vue").ComputedRef<number>;
            compatShowArrow: import("vue").ComputedRef<import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>>;
            popperRef: import("vue").Ref<({
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: Partial<{}> & Omit<Readonly<import("vue").ExtractPropTypes<{}>> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never>;
                $attrs: {
                    [x: string]: unknown;
                };
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
                $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
                $emit: ((event: string, ...args: any[]) => void) | ((event: string, ...args: any[]) => void);
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{}>>, import("../..").ElPopperInjectionContext, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, import("vue").EmitsOptions, string, {}> & {
                    beforeCreate?: ((() => void) | (() => void)[]) | undefined;
                    created?: ((() => void) | (() => void)[]) | undefined;
                    beforeMount?: ((() => void) | (() => void)[]) | undefined;
                    mounted?: ((() => void) | (() => void)[]) | undefined;
                    beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
                    updated?: ((() => void) | (() => void)[]) | undefined;
                    activated?: ((() => void) | (() => void)[]) | undefined;
                    deactivated?: ((() => void) | (() => void)[]) | undefined;
                    beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
                    beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
                    destroyed?: ((() => void) | (() => void)[]) | undefined;
                    unmounted?: ((() => void) | (() => void)[]) | undefined;
                    renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
                    renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
                    errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
            } & Readonly<import("vue").ExtractPropTypes<{}>> & import("vue").ShallowUnwrapRef<import("../..").ElPopperInjectionContext> & {} & {} & import("vue").ComponentCustomProperties) | null>;
            open: import("vue").Ref<boolean>;
            hide: () => void;
            updatePopper: () => void;
            onOpen: () => void;
            onClose: () => void;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], string, {
            disabled: boolean;
            style: import("vue").StyleValue;
            transition: string;
            offset: number;
            effect: string;
            visible: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<boolean | null>, unknown, unknown>;
            arrowOffset: number;
            boundariesPadding: number;
            fallbackPlacements: import("@popperjs/core").Placement[];
            gpuAcceleration: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], unknown, unknown>;
            placement: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>))[], unknown, unknown>;
            popperOptions: Partial<import("@popperjs/core").Options>;
            strategy: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], unknown, unknown>;
            className: string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[];
            enterable: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            pure: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            popperClass: string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[];
            popperStyle: import("vue").StyleValue;
            referenceEl: HTMLElement;
            stopPopperMouseEvent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            content: string;
            showAfter: number;
            hideAfter: number;
            appendTo: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | HTMLElement>, unknown, unknown>;
            rawContent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            persistent: boolean;
            teleported: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            trigger: "click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[];
            virtualRef: import("../..").Measurable;
            virtualTriggering: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            openDelay: number;
            visibleArrow: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            showArrow: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
        }> & {
            beforeCreate?: ((() => void) | (() => void)[]) | undefined;
            created?: ((() => void) | (() => void)[]) | undefined;
            beforeMount?: ((() => void) | (() => void)[]) | undefined;
            mounted?: ((() => void) | (() => void)[]) | undefined;
            beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
            updated?: ((() => void) | (() => void)[]) | undefined;
            activated?: ((() => void) | (() => void)[]) | undefined;
            deactivated?: ((() => void) | (() => void)[]) | undefined;
            beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
            beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
            destroyed?: ((() => void) | (() => void)[]) | undefined;
            unmounted?: ((() => void) | (() => void)[]) | undefined;
            renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
    } & Readonly<import("vue").ExtractPropTypes<{
        openDelay: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
        visibleArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        hideAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
        showArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        arrowOffset: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
        disabled: BooleanConstructor;
        trigger: {
            type: import("vue").PropType<"click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[]>;
            default: string;
        };
        virtualRef: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("../..").Measurable>, unknown, unknown, unknown, unknown>;
        virtualTriggering: import("../../../utils/props").BuildPropReturn<BooleanConstructor, unknown, unknown, unknown, unknown>;
        appendTo: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | HTMLElement>, string | (() => string) | undefined, unknown, unknown, unknown>;
        content: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
        rawContent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        persistent: BooleanConstructor;
        ariaLabel: StringConstructor;
        visible: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | null>, (() => null) | null | undefined, unknown, unknown, unknown>;
        transition: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
        teleported: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        style: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | CSSProperties | (() => string) | (() => CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
        className: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
            [x: string]: any;
        }) | (() => (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
        effect: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
        enterable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        pure: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        popperClass: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
            [x: string]: any;
        }) | (() => (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
        popperStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | CSSProperties | (() => string) | (() => CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
        referenceEl: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<HTMLElement>, HTMLElement | (() => HTMLElement) | undefined, unknown, unknown, unknown>;
        stopPopperMouseEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        zIndex: NumberConstructor;
        boundariesPadding: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 0 | (() => 0) | undefined, false, unknown, unknown>;
        fallbackPlacements: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("@popperjs/core").Placement[]) | (() => import("@popperjs/core").Placement[]) | ((new (...args: any[]) => import("@popperjs/core").Placement[]) | (() => import("@popperjs/core").Placement[]))[], (() => never[]) | undefined, false, unknown, unknown>;
        gpuAcceleration: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], true | (() => true) | undefined, false, unknown, unknown>;
        offset: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 12 | (() => 12) | undefined, false, unknown, unknown>;
        placement: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("@popperjs/core").Placement, unknown>))[], "bottom" | (() => "bottom") | undefined, false, unknown, unknown>;
        popperOptions: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => Partial<import("@popperjs/core").Options>) | (() => Partial<import("@popperjs/core").Options>) | ((new (...args: any[]) => Partial<import("@popperjs/core").Options>) | (() => Partial<import("@popperjs/core").Options>))[], (() => {}) | undefined, false, unknown, unknown>;
        strategy: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], "absolute" | (() => "absolute") | undefined, false, unknown, unknown>;
        showAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
    }>> & {
        [x: string & `on${string}`]: ((...args: any[]) => any) | undefined;
    } & import("vue").ShallowUnwrapRef<{
        compatShowAfter: import("vue").ComputedRef<number>;
        compatShowArrow: import("vue").ComputedRef<import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>>;
        popperRef: import("vue").Ref<({
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: Partial<{}> & Omit<Readonly<import("vue").ExtractPropTypes<{}>> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never>;
            $attrs: {
                [x: string]: unknown;
            };
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
            $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
            $emit: ((event: string, ...args: any[]) => void) | ((event: string, ...args: any[]) => void);
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{}>>, import("../..").ElPopperInjectionContext, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, import("vue").EmitsOptions, string, {}> & {
                beforeCreate?: ((() => void) | (() => void)[]) | undefined;
                created?: ((() => void) | (() => void)[]) | undefined;
                beforeMount?: ((() => void) | (() => void)[]) | undefined;
                mounted?: ((() => void) | (() => void)[]) | undefined;
                beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
                updated?: ((() => void) | (() => void)[]) | undefined;
                activated?: ((() => void) | (() => void)[]) | undefined;
                deactivated?: ((() => void) | (() => void)[]) | undefined;
                beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
                beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
                destroyed?: ((() => void) | (() => void)[]) | undefined;
                unmounted?: ((() => void) | (() => void)[]) | undefined;
                renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
                renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
                errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
        } & Readonly<import("vue").ExtractPropTypes<{}>> & import("vue").ShallowUnwrapRef<import("../..").ElPopperInjectionContext> & {} & {} & import("vue").ComponentCustomProperties) | null>;
        open: import("vue").Ref<boolean>;
        hide: () => void;
        updatePopper: () => void;
        onOpen: () => void;
        onClose: () => void;
    }> & {} & {} & import("vue").ComponentCustomProperties) | null>;
    triggeringElementRef: import("vue").Ref<any>;
    referenceElementRef: import("vue").Ref<any>;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "visible-change" | "command")[], "click" | "visible-change" | "command", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    readonly type: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("../../../utils/props").BuildPropType<StringConstructor, "" | "default" | "primary" | "success" | "warning" | "info" | "danger" | "text", unknown>>, unknown, unknown, unknown, unknown>;
    readonly placement: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("@popperjs/core").Placement>, "bottom", unknown, unknown, unknown>;
    readonly popperOptions: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<Partial<import("@popperjs/core").Options>>, () => {}, unknown, unknown, unknown>;
    readonly size: import("../../../utils/props").BuildPropReturn<StringConstructor, "", unknown, unknown, unknown>;
    readonly splitButton: BooleanConstructor;
    readonly hideOnClick: import("../../../utils/props").BuildPropReturn<BooleanConstructor, true, unknown, unknown, unknown>;
    readonly loop: import("../../../utils/props").BuildPropReturn<BooleanConstructor, unknown, unknown, unknown, unknown>;
    readonly showTimeout: import("../../../utils/props").BuildPropReturn<NumberConstructor, 150, unknown, unknown, unknown>;
    readonly hideTimeout: import("../../../utils/props").BuildPropReturn<NumberConstructor, 150, unknown, unknown, unknown>;
    readonly tabindex: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | number>, 0, unknown, unknown, unknown>;
    readonly maxHeight: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | number>, "", unknown, unknown, unknown>;
    readonly popperClass: import("../../../utils/props").BuildPropReturn<StringConstructor, "", unknown, unknown, unknown>;
    readonly trigger: {
        type: import("vue").PropType<"click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[]>;
        default: string;
    };
    readonly effect: {
        readonly default: "light";
        readonly type: import("vue").PropType<string>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        readonly __elPropsReservedKey: true;
    };
}>> & {
    onClick?: ((...args: any[]) => any) | undefined;
    "onVisible-change"?: ((...args: any[]) => any) | undefined;
    onCommand?: ((...args: any[]) => any) | undefined;
}, {
    type: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<import("../../../utils/props").BuildPropType<StringConstructor, "" | "default" | "primary" | "success" | "warning" | "info" | "danger" | "text", unknown>>, unknown, unknown>;
    size: string;
    effect: string;
    placement: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<import("@popperjs/core").Placement>, unknown, unknown>;
    popperOptions: Partial<import("@popperjs/core").Options>;
    popperClass: string;
    maxHeight: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | number>, unknown, unknown>;
    trigger: "click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[];
    tabindex: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | number>, unknown, unknown>;
    loop: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
    hideOnClick: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
    showTimeout: number;
    hideTimeout: number;
    splitButton: boolean;
}>;
export default _default;
