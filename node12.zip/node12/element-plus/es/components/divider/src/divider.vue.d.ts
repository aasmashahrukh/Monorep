import type { CSSProperties } from 'vue';
declare const _default: import("vue").DefineComponent<{
    readonly direction: import("../../../utils/props").BuildPropReturn<StringConstructor, "horizontal", unknown, "horizontal" | "vertical", unknown>;
    readonly contentPosition: import("../../../utils/props").BuildPropReturn<StringConstructor, "center", unknown, "right" | "left" | "center", unknown>;
    readonly borderStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string>, "solid", unknown, unknown, unknown>;
}, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string | undefined) => string;
        m: (modifier?: string | undefined) => string;
        be: (blockSuffix?: string | undefined, element?: string | undefined) => string;
        em: (element?: string | undefined, modifier?: string | undefined) => string;
        bm: (blockSuffix?: string | undefined, modifier?: string | undefined) => string;
        bem: (blockSuffix?: string | undefined, element?: string | undefined, modifier?: string | undefined) => string;
        is: (name: string, state?: boolean) => string;
    };
    dividerStyle: import("vue").ComputedRef<CSSProperties>;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    readonly direction: import("../../../utils/props").BuildPropReturn<StringConstructor, "horizontal", unknown, "horizontal" | "vertical", unknown>;
    readonly contentPosition: import("../../../utils/props").BuildPropReturn<StringConstructor, "center", unknown, "right" | "left" | "center", unknown>;
    readonly borderStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string>, "solid", unknown, unknown, unknown>;
}>>, {
    direction: import("../../../utils/props").BuildPropType<StringConstructor, "horizontal" | "vertical", unknown>;
    borderStyle: string;
    contentPosition: import("../../../utils/props").BuildPropType<StringConstructor, "right" | "left" | "center", unknown>;
}>;
export default _default;
