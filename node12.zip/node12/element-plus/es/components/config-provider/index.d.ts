export declare const ElConfigProvider: import("../../utils/types").SFCWithInstall<import("vue").DefineComponent<{
    readonly locale: import("../../utils/props").BuildPropReturn<import("../../utils/props").PropWrapper<import("../../locale").Language>, unknown, unknown, unknown, unknown>;
    readonly size: import("../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, "small" | "default" | "large", unknown>;
    readonly button: import("../../utils/props").BuildPropReturn<import("../../utils/props").PropWrapper<import("..").ButtonConfigContext>, unknown, unknown, unknown, unknown>;
    readonly message: import("../../utils/props").BuildPropReturn<import("../../utils/props").PropWrapper<import("..").MessageConfigContext>, unknown, unknown, unknown, unknown>;
    readonly zIndex: import("../../utils/props").BuildPropReturn<NumberConstructor, unknown, unknown, unknown, unknown>;
    readonly namespace: import("../../utils/props").BuildPropReturn<StringConstructor, "el", unknown, unknown, unknown>;
}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    readonly locale: import("../../utils/props").BuildPropReturn<import("../../utils/props").PropWrapper<import("../../locale").Language>, unknown, unknown, unknown, unknown>;
    readonly size: import("../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, "small" | "default" | "large", unknown>;
    readonly button: import("../../utils/props").BuildPropReturn<import("../../utils/props").PropWrapper<import("..").ButtonConfigContext>, unknown, unknown, unknown, unknown>;
    readonly message: import("../../utils/props").BuildPropReturn<import("../../utils/props").PropWrapper<import("..").MessageConfigContext>, unknown, unknown, unknown, unknown>;
    readonly zIndex: import("../../utils/props").BuildPropReturn<NumberConstructor, unknown, unknown, unknown, unknown>;
    readonly namespace: import("../../utils/props").BuildPropReturn<StringConstructor, "el", unknown, unknown, unknown>;
}>>, {
    button: import("..").ButtonConfigContext;
    size: import("../../utils/props").BuildPropType<StringConstructor, "small" | "default" | "large", unknown>;
    locale: import("../../locale").Language;
    message: import("..").MessageConfigContext;
    zIndex: number;
    namespace: string;
}>> & Record<string, any>;
export default ElConfigProvider;
export * from './src/config-provider';
