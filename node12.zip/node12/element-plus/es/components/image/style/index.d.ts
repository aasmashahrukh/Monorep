import 'element-plus/es/components/base/style';
import 'element-plus/theme-chalk/src/image.scss';
import 'element-plus/es/components/image-viewer/style/index';
