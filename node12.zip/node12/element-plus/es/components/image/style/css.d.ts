import 'element-plus/es/components/base/style/css';
import 'element-plus/theme-chalk/el-image.css';
import 'element-plus/es/components/image-viewer/style/css';
