import 'element-plus/es/components/base/style/css';
import 'element-plus/theme-chalk/el-container.css';
import 'element-plus/theme-chalk/el-aside.css';
import 'element-plus/theme-chalk/el-footer.css';
import 'element-plus/theme-chalk/el-header.css';
import 'element-plus/theme-chalk/el-main.css';
