import 'element-plus/es/components/base/style';
import 'element-plus/theme-chalk/src/container.scss';
import 'element-plus/theme-chalk/src/aside.scss';
import 'element-plus/theme-chalk/src/footer.scss';
import 'element-plus/theme-chalk/src/header.scss';
import 'element-plus/theme-chalk/src/main.scss';
