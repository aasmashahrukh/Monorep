import { nextTick } from 'vue';
import type { Options } from 'element-plus/es/components/popper';
import type { ComputedRef, PropType, Ref } from 'vue';
import type { CascaderValue, CascaderNode, Tag } from 'element-plus/es/components/cascader-panel';
import type { ComponentSize } from 'element-plus/es/utils/types';
declare const _default: import("vue").DefineComponent<{
    size: {
        type: PropType<ComponentSize>;
        validator: (val: string) => boolean;
    };
    placeholder: {
        type: StringConstructor;
    };
    disabled: BooleanConstructor;
    clearable: BooleanConstructor;
    filterable: BooleanConstructor;
    filterMethod: {
        type: PropType<(node: CascaderNode, keyword: string) => boolean>;
        default: (node: CascaderNode, keyword: string) => boolean;
    };
    separator: {
        type: StringConstructor;
        default: string;
    };
    showAllLevels: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapseTags: BooleanConstructor;
    debounce: {
        type: NumberConstructor;
        default: number;
    };
    beforeFilter: {
        type: PropType<(value: string) => boolean | Promise<any>>;
        default: () => boolean;
    };
    popperClass: {
        type: StringConstructor;
        default: string;
    };
    popperAppendToBody: {
        type: BooleanConstructor;
        default: boolean;
    };
    modelValue: PropType<import("../../cascader-panel/src/node").CascaderValue>;
    options: {
        type: PropType<import("../../cascader-panel/src/node").CascaderOption[]>;
        default: () => import("../../cascader-panel/src/node").CascaderOption[];
    };
    props: {
        type: PropType<import("../../cascader-panel/src/node").CascaderProps>;
        default: () => import("../../cascader-panel/src/node").CascaderProps;
    };
}, {
    popperOptions: Partial<Options>;
    tooltipRef: Ref<({
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            disabled: boolean;
            style: import("vue").StyleValue;
            transition: string;
            offset: number;
            effect: string;
            visible: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<boolean | null>, unknown, unknown>;
            arrowOffset: number;
            boundariesPadding: number;
            fallbackPlacements: import("element-plus/es/components/popper").Placement[];
            gpuAcceleration: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], unknown, unknown>;
            placement: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>))[], unknown, unknown>;
            popperOptions: Partial<Options>;
            strategy: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], unknown, unknown>;
            className: string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[];
            enterable: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            pure: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            popperClass: string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[];
            popperStyle: import("vue").StyleValue;
            referenceEl: HTMLElement;
            stopPopperMouseEvent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            content: string;
            showAfter: number;
            hideAfter: number;
            appendTo: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | HTMLElement>, unknown, unknown>;
            rawContent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            persistent: boolean;
            teleported: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            trigger: "click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[];
            virtualRef: import("element-plus/es/components/popper").Measurable;
            virtualTriggering: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            openDelay: number;
            visibleArrow: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            showArrow: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
        }> & Omit<Readonly<import("vue").ExtractPropTypes<{
            openDelay: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
            visibleArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            hideAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
            showArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            arrowOffset: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
            disabled: BooleanConstructor;
            trigger: {
                type: PropType<"click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[]>;
                default: string;
            };
            virtualRef: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("element-plus/es/components/popper").Measurable>, unknown, unknown, unknown, unknown>;
            virtualTriggering: import("../../../utils/props").BuildPropReturn<BooleanConstructor, unknown, unknown, unknown, unknown>;
            appendTo: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | HTMLElement>, string | (() => string) | undefined, unknown, unknown, unknown>;
            content: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            rawContent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            persistent: BooleanConstructor;
            ariaLabel: StringConstructor;
            visible: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | null>, (() => null) | null | undefined, unknown, unknown, unknown>;
            transition: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            teleported: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            style: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | import("vue").CSSProperties | (() => string) | (() => import("vue").CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
            className: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
                [x: string]: any;
            }) | (() => (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
            effect: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            enterable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            pure: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            popperClass: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
                [x: string]: any;
            }) | (() => (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
            popperStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | import("vue").CSSProperties | (() => string) | (() => import("vue").CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
            referenceEl: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<HTMLElement>, HTMLElement | (() => HTMLElement) | undefined, unknown, unknown, unknown>;
            stopPopperMouseEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            zIndex: NumberConstructor;
            boundariesPadding: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 0 | (() => 0) | undefined, false, unknown, unknown>;
            fallbackPlacements: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("element-plus/es/components/popper").Placement[]) | (() => import("element-plus/es/components/popper").Placement[]) | ((new (...args: any[]) => import("element-plus/es/components/popper").Placement[]) | (() => import("element-plus/es/components/popper").Placement[]))[], (() => never[]) | undefined, false, unknown, unknown>;
            gpuAcceleration: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], true | (() => true) | undefined, false, unknown, unknown>;
            offset: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 12 | (() => 12) | undefined, false, unknown, unknown>;
            placement: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>))[], "bottom" | (() => "bottom") | undefined, false, unknown, unknown>;
            popperOptions: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => Partial<Options>) | (() => Partial<Options>) | ((new (...args: any[]) => Partial<Options>) | (() => Partial<Options>))[], (() => {}) | undefined, false, unknown, unknown>;
            strategy: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], "absolute" | (() => "absolute") | undefined, false, unknown, unknown>;
            showAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
        }>> & {
            [x: string & `on${string}`]: ((...args: any[]) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "style" | "transition" | "offset" | "effect" | "visible" | "arrowOffset" | "boundariesPadding" | "fallbackPlacements" | "gpuAcceleration" | "placement" | "popperOptions" | "strategy" | "className" | "enterable" | "pure" | "popperClass" | "popperStyle" | "referenceEl" | "stopPopperMouseEvent" | "content" | "showAfter" | "hideAfter" | "appendTo" | "rawContent" | "persistent" | "teleported" | "trigger" | "virtualRef" | "virtualTriggering" | "openDelay" | "visibleArrow" | "showArrow">;
        $attrs: {
            [x: string]: unknown;
        };
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $emit: (event: string, ...args: any[]) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            openDelay: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
            visibleArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            hideAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
            showArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            arrowOffset: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
            disabled: BooleanConstructor;
            trigger: {
                type: PropType<"click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[]>;
                default: string;
            };
            virtualRef: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("element-plus/es/components/popper").Measurable>, unknown, unknown, unknown, unknown>;
            virtualTriggering: import("../../../utils/props").BuildPropReturn<BooleanConstructor, unknown, unknown, unknown, unknown>;
            appendTo: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | HTMLElement>, string | (() => string) | undefined, unknown, unknown, unknown>;
            content: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            rawContent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            persistent: BooleanConstructor;
            ariaLabel: StringConstructor;
            visible: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | null>, (() => null) | null | undefined, unknown, unknown, unknown>;
            transition: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            teleported: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            style: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | import("vue").CSSProperties | (() => string) | (() => import("vue").CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
            className: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
                [x: string]: any;
            }) | (() => (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
            effect: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
            enterable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            pure: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            popperClass: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
                [x: string]: any;
            }) | (() => (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
            popperStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | import("vue").CSSProperties | (() => string) | (() => import("vue").CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
            referenceEl: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<HTMLElement>, HTMLElement | (() => HTMLElement) | undefined, unknown, unknown, unknown>;
            stopPopperMouseEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
            zIndex: NumberConstructor;
            boundariesPadding: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 0 | (() => 0) | undefined, false, unknown, unknown>;
            fallbackPlacements: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("element-plus/es/components/popper").Placement[]) | (() => import("element-plus/es/components/popper").Placement[]) | ((new (...args: any[]) => import("element-plus/es/components/popper").Placement[]) | (() => import("element-plus/es/components/popper").Placement[]))[], (() => never[]) | undefined, false, unknown, unknown>;
            gpuAcceleration: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], true | (() => true) | undefined, false, unknown, unknown>;
            offset: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 12 | (() => 12) | undefined, false, unknown, unknown>;
            placement: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>))[], "bottom" | (() => "bottom") | undefined, false, unknown, unknown>;
            popperOptions: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => Partial<Options>) | (() => Partial<Options>) | ((new (...args: any[]) => Partial<Options>) | (() => Partial<Options>))[], (() => {}) | undefined, false, unknown, unknown>;
            strategy: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], "absolute" | (() => "absolute") | undefined, false, unknown, unknown>;
            showAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
        }>> & {
            [x: string & `on${string}`]: ((...args: any[]) => any) | undefined;
        }, {
            compatShowAfter: ComputedRef<number>;
            compatShowArrow: ComputedRef<import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>>;
            popperRef: Ref<({
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: Partial<{}> & Omit<Readonly<import("vue").ExtractPropTypes<{}>> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never>;
                $attrs: {
                    [x: string]: unknown;
                };
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
                $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
                $emit: ((event: string, ...args: any[]) => void) | ((event: string, ...args: any[]) => void);
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{}>>, import("element-plus/es/components/popper").ElPopperInjectionContext, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, import("vue").EmitsOptions, string, {}> & {
                    beforeCreate?: ((() => void) | (() => void)[]) | undefined;
                    created?: ((() => void) | (() => void)[]) | undefined;
                    beforeMount?: ((() => void) | (() => void)[]) | undefined;
                    mounted?: ((() => void) | (() => void)[]) | undefined;
                    beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
                    updated?: ((() => void) | (() => void)[]) | undefined;
                    activated?: ((() => void) | (() => void)[]) | undefined;
                    deactivated?: ((() => void) | (() => void)[]) | undefined;
                    beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
                    beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
                    destroyed?: ((() => void) | (() => void)[]) | undefined;
                    unmounted?: ((() => void) | (() => void)[]) | undefined;
                    renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
                    renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
                    errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
                };
                $forceUpdate: () => void;
                $nextTick: typeof nextTick;
                $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
            } & Readonly<import("vue").ExtractPropTypes<{}>> & import("vue").ShallowUnwrapRef<import("element-plus/es/components/popper").ElPopperInjectionContext> & {} & {} & import("vue").ComponentCustomProperties) | null>;
            open: Ref<boolean>;
            hide: () => void;
            updatePopper: () => void;
            onOpen: () => void;
            onClose: () => void;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, string[], string, {
            disabled: boolean;
            style: import("vue").StyleValue;
            transition: string;
            offset: number;
            effect: string;
            visible: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<boolean | null>, unknown, unknown>;
            arrowOffset: number;
            boundariesPadding: number;
            fallbackPlacements: import("element-plus/es/components/popper").Placement[];
            gpuAcceleration: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], unknown, unknown>;
            placement: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>))[], unknown, unknown>;
            popperOptions: Partial<Options>;
            strategy: import("../../../utils/props").BuildPropType<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], unknown, unknown>;
            className: string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[];
            enterable: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            pure: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            popperClass: string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | (string | {
                [x: string]: any;
            } | any)[])[])[])[])[])[])[])[])[])[])[];
            popperStyle: import("vue").StyleValue;
            referenceEl: HTMLElement;
            stopPopperMouseEvent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            content: string;
            showAfter: number;
            hideAfter: number;
            appendTo: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | HTMLElement>, unknown, unknown>;
            rawContent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            persistent: boolean;
            teleported: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            trigger: "click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[];
            virtualRef: import("element-plus/es/components/popper").Measurable;
            virtualTriggering: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            openDelay: number;
            visibleArrow: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            showArrow: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
        }> & {
            beforeCreate?: ((() => void) | (() => void)[]) | undefined;
            created?: ((() => void) | (() => void)[]) | undefined;
            beforeMount?: ((() => void) | (() => void)[]) | undefined;
            mounted?: ((() => void) | (() => void)[]) | undefined;
            beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
            updated?: ((() => void) | (() => void)[]) | undefined;
            activated?: ((() => void) | (() => void)[]) | undefined;
            deactivated?: ((() => void) | (() => void)[]) | undefined;
            beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
            beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
            destroyed?: ((() => void) | (() => void)[]) | undefined;
            unmounted?: ((() => void) | (() => void)[]) | undefined;
            renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
    } & Readonly<import("vue").ExtractPropTypes<{
        openDelay: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
        visibleArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        hideAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number | (() => number) | undefined, unknown, unknown, unknown>;
        showArrow: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        arrowOffset: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
        disabled: BooleanConstructor;
        trigger: {
            type: PropType<"click" | "contextmenu" | "focus" | "hover" | ("click" | "contextmenu" | "focus" | "hover")[]>;
            default: string;
        };
        virtualRef: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("element-plus/es/components/popper").Measurable>, unknown, unknown, unknown, unknown>;
        virtualTriggering: import("../../../utils/props").BuildPropReturn<BooleanConstructor, unknown, unknown, unknown, unknown>;
        appendTo: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | HTMLElement>, string | (() => string) | undefined, unknown, unknown, unknown>;
        content: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
        rawContent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        persistent: BooleanConstructor;
        ariaLabel: StringConstructor;
        visible: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | null>, (() => null) | null | undefined, unknown, unknown, unknown>;
        transition: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
        teleported: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        style: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | import("vue").CSSProperties | (() => string) | (() => import("vue").CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
        className: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
            [x: string]: any;
        }) | (() => (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
        effect: import("../../../utils/props").BuildPropReturn<StringConstructor, string | (() => string) | undefined, unknown, unknown, unknown>;
        enterable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        pure: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        popperClass: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | any)[])[])[])[])[])[])[])[])[])[])[]>, string | (() => string) | (() => {
            [x: string]: any;
        }) | (() => (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | (string | {
            [x: string]: any;
        } | any)[])[])[])[])[])[])[])[])[])[])[]) | undefined, unknown, unknown, unknown>;
        popperStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, string | import("vue").CSSProperties | (() => string) | (() => import("vue").CSSProperties) | (() => import("vue").StyleValue[]) | undefined, unknown, unknown, unknown>;
        referenceEl: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<HTMLElement>, HTMLElement | (() => HTMLElement) | undefined, unknown, unknown, unknown>;
        stopPopperMouseEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, boolean | (() => false) | (() => true) | undefined, unknown, unknown, unknown>;
        zIndex: NumberConstructor;
        boundariesPadding: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 0 | (() => 0) | undefined, false, unknown, unknown>;
        fallbackPlacements: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("element-plus/es/components/popper").Placement[]) | (() => import("element-plus/es/components/popper").Placement[]) | ((new (...args: any[]) => import("element-plus/es/components/popper").Placement[]) | (() => import("element-plus/es/components/popper").Placement[]))[], (() => never[]) | undefined, false, unknown, unknown>;
        gpuAcceleration: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>))[], true | (() => true) | undefined, false, unknown, unknown>;
        offset: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => number & {}) | (() => number) | ((new (...args: any[]) => number & {}) | (() => number))[], 12 | (() => 12) | undefined, false, unknown, unknown>;
        placement: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, import("element-plus/es/components/popper").Placement, unknown>))[], "bottom" | (() => "bottom") | undefined, false, unknown, unknown>;
        popperOptions: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => Partial<Options>) | (() => Partial<Options>) | ((new (...args: any[]) => Partial<Options>) | (() => Partial<Options>))[], (() => {}) | undefined, false, unknown, unknown>;
        strategy: import("../../../utils/props").BuildPropReturn<(new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>) | ((new (...args: any[]) => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown> & {}) | (() => import("../../../utils/props").BuildPropType<StringConstructor, "fixed" | "absolute", unknown>))[], "absolute" | (() => "absolute") | undefined, false, unknown, unknown>;
        showAfter: import("../../../utils/props").BuildPropReturn<NumberConstructor, number, unknown, unknown, unknown>;
    }>> & {
        [x: string & `on${string}`]: ((...args: any[]) => any) | undefined;
    } & import("vue").ShallowUnwrapRef<{
        compatShowAfter: ComputedRef<number>;
        compatShowArrow: ComputedRef<import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>>;
        popperRef: Ref<({
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: Partial<{}> & Omit<Readonly<import("vue").ExtractPropTypes<{}>> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never>;
            $attrs: {
                [x: string]: unknown;
            };
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
            $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
            $emit: ((event: string, ...args: any[]) => void) | ((event: string, ...args: any[]) => void);
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{}>>, import("element-plus/es/components/popper").ElPopperInjectionContext, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, import("vue").EmitsOptions, string, {}> & {
                beforeCreate?: ((() => void) | (() => void)[]) | undefined;
                created?: ((() => void) | (() => void)[]) | undefined;
                beforeMount?: ((() => void) | (() => void)[]) | undefined;
                mounted?: ((() => void) | (() => void)[]) | undefined;
                beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
                updated?: ((() => void) | (() => void)[]) | undefined;
                activated?: ((() => void) | (() => void)[]) | undefined;
                deactivated?: ((() => void) | (() => void)[]) | undefined;
                beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
                beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
                destroyed?: ((() => void) | (() => void)[]) | undefined;
                unmounted?: ((() => void) | (() => void)[]) | undefined;
                renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
                renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
                errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
            };
            $forceUpdate: () => void;
            $nextTick: typeof nextTick;
            $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
        } & Readonly<import("vue").ExtractPropTypes<{}>> & import("vue").ShallowUnwrapRef<import("element-plus/es/components/popper").ElPopperInjectionContext> & {} & {} & import("vue").ComponentCustomProperties) | null>;
        open: Ref<boolean>;
        hide: () => void;
        updatePopper: () => void;
        onOpen: () => void;
        onClose: () => void;
    }> & {} & {} & import("vue").ComponentCustomProperties) | null>;
    popperPaneRef: ComputedRef<HTMLElement | null | undefined>;
    input: Ref<({
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            type: string;
            size: import("../../../utils/props").BuildPropType<StringConstructor, "small" | "default" | "large", never>;
            disabled: boolean;
            modelValue: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | number | null | undefined>, unknown, unknown>;
            label: string;
            form: string;
            resize: import("../../../utils/props").BuildPropType<StringConstructor, "none" | "both" | "horizontal" | "vertical", unknown>;
            autosize: boolean | {
                minRows?: number | undefined;
                maxRows?: number | undefined;
            };
            autocomplete: string;
            placeholder: string;
            readonly: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            clearable: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            showPassword: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            showWordLimit: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            suffixIcon: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, unknown, unknown>;
            prefixIcon: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, unknown, unknown>;
            tabindex: import("../../../utils/props").BuildPropType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
            validateEvent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            inputStyle: import("element-plus/es/utils/types").StyleValue;
        }> & Omit<Readonly<import("vue").ExtractPropTypes<{
            readonly size: import("../../../utils/props").BuildPropReturn<StringConstructor, never, false, "small" | "default" | "large", never>;
            readonly disabled: BooleanConstructor;
            readonly modelValue: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | number | null | undefined>, "", unknown, unknown, unknown>;
            readonly type: import("../../../utils/props").BuildPropReturn<StringConstructor, "text", unknown, unknown, unknown>;
            readonly resize: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, "none" | "both" | "horizontal" | "vertical", unknown>;
            readonly autosize: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | {
                minRows?: number | undefined;
                maxRows?: number | undefined;
            }>, false, unknown, unknown, unknown>;
            readonly autocomplete: import("../../../utils/props").BuildPropReturn<StringConstructor, "off", unknown, unknown, unknown>;
            readonly placeholder: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, unknown, unknown>;
            readonly form: import("../../../utils/props").BuildPropReturn<StringConstructor, "", unknown, unknown, unknown>;
            readonly readonly: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly clearable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly showPassword: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly showWordLimit: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly suffixIcon: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, "", unknown, unknown, unknown>;
            readonly prefixIcon: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, "", unknown, unknown, unknown>;
            readonly label: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, unknown, unknown>;
            readonly tabindex: import("../../../utils/props").BuildPropReturn<readonly [NumberConstructor, StringConstructor], unknown, unknown, unknown, unknown>;
            readonly validateEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, true, unknown, unknown, unknown>;
            readonly inputStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("element-plus/es/utils/types").StyleValue>, () => import("element-plus/es/utils/types").Mutable<{}>, unknown, unknown, unknown>;
        }>> & {
            onChange?: ((value: string) => any) | undefined;
            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
            onKeydown?: ((evt: KeyboardEvent) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onInput?: ((value: string) => any) | undefined;
            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
            onClear?: (() => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "type" | "size" | "disabled" | "modelValue" | "label" | "form" | "resize" | "autosize" | "autocomplete" | "placeholder" | "readonly" | "clearable" | "showPassword" | "showWordLimit" | "suffixIcon" | "prefixIcon" | "tabindex" | "validateEvent" | "inputStyle">;
        $attrs: {
            [x: string]: unknown;
        };
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $emit: ((event: "input", value: string) => void) & ((event: "update:modelValue", value: string) => void) & ((event: "change", value: string) => void) & ((event: "blur", evt: FocusEvent) => void) & ((event: "compositionend", evt: CompositionEvent) => void) & ((event: "compositionstart", evt: CompositionEvent) => void) & ((event: "compositionupdate", evt: CompositionEvent) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "keydown", evt: KeyboardEvent) => void) & ((event: "mouseenter", evt: MouseEvent) => void) & ((event: "mouseleave", evt: MouseEvent) => void) & ((event: "clear") => void);
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly size: import("../../../utils/props").BuildPropReturn<StringConstructor, never, false, "small" | "default" | "large", never>;
            readonly disabled: BooleanConstructor;
            readonly modelValue: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | number | null | undefined>, "", unknown, unknown, unknown>;
            readonly type: import("../../../utils/props").BuildPropReturn<StringConstructor, "text", unknown, unknown, unknown>;
            readonly resize: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, "none" | "both" | "horizontal" | "vertical", unknown>;
            readonly autosize: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | {
                minRows?: number | undefined;
                maxRows?: number | undefined;
            }>, false, unknown, unknown, unknown>;
            readonly autocomplete: import("../../../utils/props").BuildPropReturn<StringConstructor, "off", unknown, unknown, unknown>;
            readonly placeholder: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, unknown, unknown>;
            readonly form: import("../../../utils/props").BuildPropReturn<StringConstructor, "", unknown, unknown, unknown>;
            readonly readonly: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly clearable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly showPassword: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly showWordLimit: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly suffixIcon: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, "", unknown, unknown, unknown>;
            readonly prefixIcon: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, "", unknown, unknown, unknown>;
            readonly label: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, unknown, unknown>;
            readonly tabindex: import("../../../utils/props").BuildPropReturn<readonly [NumberConstructor, StringConstructor], unknown, unknown, unknown, unknown>;
            readonly validateEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, true, unknown, unknown, unknown>;
            readonly inputStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("element-plus/es/utils/types").StyleValue>, () => import("element-plus/es/utils/types").Mutable<{}>, unknown, unknown, unknown>;
        }>> & {
            onChange?: ((value: string) => any) | undefined;
            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
            onKeydown?: ((evt: KeyboardEvent) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onInput?: ((value: string) => any) | undefined;
            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
            onClear?: (() => any) | undefined;
        }, {
            input: Ref<HTMLInputElement | undefined>;
            textarea: Ref<HTMLTextAreaElement | undefined>;
            attrs: ComputedRef<Record<string, unknown>>;
            inputSize: ComputedRef<ComponentSize>;
            validateState: ComputedRef<string>;
            validateIcon: ComputedRef<any>;
            containerStyle: ComputedRef<import("element-plus/es/utils/types").StyleValue>;
            computedTextareaStyle: ComputedRef<import("element-plus/es/utils/types").StyleValue>;
            inputDisabled: ComputedRef<boolean>;
            showClear: ComputedRef<boolean>;
            showPwdVisible: ComputedRef<boolean>;
            isWordLimitVisible: ComputedRef<boolean>;
            textLength: ComputedRef<number>;
            hovering: Ref<boolean>;
            inputExceed: ComputedRef<boolean>;
            passwordVisible: Ref<boolean>;
            inputOrTextarea: ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
            suffixVisible: ComputedRef<boolean>;
            needStatusIcon: ComputedRef<boolean>;
            resizeTextarea: () => void;
            handleInput: (event: Event) => void;
            handleChange: (event: Event) => void;
            handleFocus: (event: FocusEvent) => void;
            handleBlur: (event: FocusEvent) => void;
            handleCompositionStart: (event: CompositionEvent) => void;
            handleCompositionUpdate: (event: CompositionEvent) => void;
            handleCompositionEnd: (event: CompositionEvent) => void;
            handlePasswordVisible: () => void;
            clear: () => void;
            select: () => void;
            focus: () => void;
            blur: () => void;
            onMouseLeave: (evt: MouseEvent) => void;
            onMouseEnter: (evt: MouseEvent) => void;
            handleKeydown: (evt: KeyboardEvent) => void;
            nsInput: {
                namespace: ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string | undefined) => string;
                m: (modifier?: string | undefined) => string;
                be: (blockSuffix?: string | undefined, element?: string | undefined) => string;
                em: (element?: string | undefined, modifier?: string | undefined) => string;
                bm: (blockSuffix?: string | undefined, modifier?: string | undefined) => string;
                bem: (blockSuffix?: string | undefined, element?: string | undefined, modifier?: string | undefined) => string;
                is: (name: string, state?: boolean) => string;
            };
            nsTextarea: {
                namespace: ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string | undefined) => string;
                m: (modifier?: string | undefined) => string;
                be: (blockSuffix?: string | undefined, element?: string | undefined) => string;
                em: (element?: string | undefined, modifier?: string | undefined) => string;
                bm: (blockSuffix?: string | undefined, modifier?: string | undefined) => string;
                bem: (blockSuffix?: string | undefined, element?: string | undefined, modifier?: string | undefined) => string;
                is: (name: string, state?: boolean) => string;
            };
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            "update:modelValue": (value: string) => boolean;
            input: (value: string) => boolean;
            change: (value: string) => boolean;
            focus: (evt: FocusEvent) => boolean;
            blur: (evt: FocusEvent) => boolean;
            clear: () => boolean;
            mouseleave: (evt: MouseEvent) => boolean;
            mouseenter: (evt: MouseEvent) => boolean;
            keydown: (evt: KeyboardEvent) => boolean;
            compositionstart: (evt: CompositionEvent) => boolean;
            compositionupdate: (evt: CompositionEvent) => boolean;
            compositionend: (evt: CompositionEvent) => boolean;
        }, string, {
            type: string;
            size: import("../../../utils/props").BuildPropType<StringConstructor, "small" | "default" | "large", never>;
            disabled: boolean;
            modelValue: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | number | null | undefined>, unknown, unknown>;
            label: string;
            form: string;
            resize: import("../../../utils/props").BuildPropType<StringConstructor, "none" | "both" | "horizontal" | "vertical", unknown>;
            autosize: boolean | {
                minRows?: number | undefined;
                maxRows?: number | undefined;
            };
            autocomplete: string;
            placeholder: string;
            readonly: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            clearable: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            showPassword: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            showWordLimit: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            suffixIcon: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, unknown, unknown>;
            prefixIcon: import("../../../utils/props").BuildPropType<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, unknown, unknown>;
            tabindex: import("../../../utils/props").BuildPropType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
            validateEvent: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            inputStyle: import("element-plus/es/utils/types").StyleValue;
        }> & {
            beforeCreate?: ((() => void) | (() => void)[]) | undefined;
            created?: ((() => void) | (() => void)[]) | undefined;
            beforeMount?: ((() => void) | (() => void)[]) | undefined;
            mounted?: ((() => void) | (() => void)[]) | undefined;
            beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
            updated?: ((() => void) | (() => void)[]) | undefined;
            activated?: ((() => void) | (() => void)[]) | undefined;
            deactivated?: ((() => void) | (() => void)[]) | undefined;
            beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
            beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
            destroyed?: ((() => void) | (() => void)[]) | undefined;
            unmounted?: ((() => void) | (() => void)[]) | undefined;
            renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
    } & Readonly<import("vue").ExtractPropTypes<{
        readonly size: import("../../../utils/props").BuildPropReturn<StringConstructor, never, false, "small" | "default" | "large", never>;
        readonly disabled: BooleanConstructor;
        readonly modelValue: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | number | null | undefined>, "", unknown, unknown, unknown>;
        readonly type: import("../../../utils/props").BuildPropReturn<StringConstructor, "text", unknown, unknown, unknown>;
        readonly resize: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, "none" | "both" | "horizontal" | "vertical", unknown>;
        readonly autosize: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<boolean | {
            minRows?: number | undefined;
            maxRows?: number | undefined;
        }>, false, unknown, unknown, unknown>;
        readonly autocomplete: import("../../../utils/props").BuildPropReturn<StringConstructor, "off", unknown, unknown, unknown>;
        readonly placeholder: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, unknown, unknown>;
        readonly form: import("../../../utils/props").BuildPropReturn<StringConstructor, "", unknown, unknown, unknown>;
        readonly readonly: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
        readonly clearable: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
        readonly showPassword: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
        readonly showWordLimit: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
        readonly suffixIcon: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, "", unknown, unknown, unknown>;
        readonly prefixIcon: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<string | import("vue").Component<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions>>, "", unknown, unknown, unknown>;
        readonly label: import("../../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, unknown, unknown>;
        readonly tabindex: import("../../../utils/props").BuildPropReturn<readonly [NumberConstructor, StringConstructor], unknown, unknown, unknown, unknown>;
        readonly validateEvent: import("../../../utils/props").BuildPropReturn<BooleanConstructor, true, unknown, unknown, unknown>;
        readonly inputStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("element-plus/es/utils/types").StyleValue>, () => import("element-plus/es/utils/types").Mutable<{}>, unknown, unknown, unknown>;
    }>> & {
        onChange?: ((value: string) => any) | undefined;
        onMouseenter?: ((evt: MouseEvent) => any) | undefined;
        onMouseleave?: ((evt: MouseEvent) => any) | undefined;
        onKeydown?: ((evt: KeyboardEvent) => any) | undefined;
        onFocus?: ((evt: FocusEvent) => any) | undefined;
        onBlur?: ((evt: FocusEvent) => any) | undefined;
        onInput?: ((value: string) => any) | undefined;
        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
        onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
        onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
        onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
        onClear?: (() => any) | undefined;
    } & import("vue").ShallowUnwrapRef<{
        input: Ref<HTMLInputElement | undefined>;
        textarea: Ref<HTMLTextAreaElement | undefined>;
        attrs: ComputedRef<Record<string, unknown>>;
        inputSize: ComputedRef<ComponentSize>;
        validateState: ComputedRef<string>;
        validateIcon: ComputedRef<any>;
        containerStyle: ComputedRef<import("element-plus/es/utils/types").StyleValue>;
        computedTextareaStyle: ComputedRef<import("element-plus/es/utils/types").StyleValue>;
        inputDisabled: ComputedRef<boolean>;
        showClear: ComputedRef<boolean>;
        showPwdVisible: ComputedRef<boolean>;
        isWordLimitVisible: ComputedRef<boolean>;
        textLength: ComputedRef<number>;
        hovering: Ref<boolean>;
        inputExceed: ComputedRef<boolean>;
        passwordVisible: Ref<boolean>;
        inputOrTextarea: ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
        suffixVisible: ComputedRef<boolean>;
        needStatusIcon: ComputedRef<boolean>;
        resizeTextarea: () => void;
        handleInput: (event: Event) => void;
        handleChange: (event: Event) => void;
        handleFocus: (event: FocusEvent) => void;
        handleBlur: (event: FocusEvent) => void;
        handleCompositionStart: (event: CompositionEvent) => void;
        handleCompositionUpdate: (event: CompositionEvent) => void;
        handleCompositionEnd: (event: CompositionEvent) => void;
        handlePasswordVisible: () => void;
        clear: () => void;
        select: () => void;
        focus: () => void;
        blur: () => void;
        onMouseLeave: (evt: MouseEvent) => void;
        onMouseEnter: (evt: MouseEvent) => void;
        handleKeydown: (evt: KeyboardEvent) => void;
        nsInput: {
            namespace: ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string | undefined) => string;
            m: (modifier?: string | undefined) => string;
            be: (blockSuffix?: string | undefined, element?: string | undefined) => string;
            em: (element?: string | undefined, modifier?: string | undefined) => string;
            bm: (blockSuffix?: string | undefined, modifier?: string | undefined) => string;
            bem: (blockSuffix?: string | undefined, element?: string | undefined, modifier?: string | undefined) => string;
            is: (name: string, state?: boolean) => string;
        };
        nsTextarea: {
            namespace: ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string | undefined) => string;
            m: (modifier?: string | undefined) => string;
            be: (blockSuffix?: string | undefined, element?: string | undefined) => string;
            em: (element?: string | undefined, modifier?: string | undefined) => string;
            bm: (blockSuffix?: string | undefined, modifier?: string | undefined) => string;
            bem: (blockSuffix?: string | undefined, element?: string | undefined, modifier?: string | undefined) => string;
            is: (name: string, state?: boolean) => string;
        };
    }> & {} & {} & import("vue").ComponentCustomProperties) | null>;
    tagWrapper: Ref<null>;
    panel: Ref<({
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            props: import("../../cascader-panel/src/node").CascaderProps;
            border: boolean;
            options: import("../../cascader-panel/src/node").CascaderOption[];
        }> & Omit<Readonly<import("vue").ExtractPropTypes<{
            border: {
                type: BooleanConstructor;
                default: boolean;
            };
            renderLabel: PropType<import("../../cascader-panel/src/node").RenderLabel>;
            modelValue: PropType<import("../../cascader-panel/src/node").CascaderValue>;
            options: {
                type: PropType<import("../../cascader-panel/src/node").CascaderOption[]>;
                default: () => import("../../cascader-panel/src/node").CascaderOption[];
            };
            props: {
                type: PropType<import("../../cascader-panel/src/node").CascaderProps>;
                default: () => import("../../cascader-panel/src/node").CascaderProps;
            };
        }>> & {
            onChange?: ((...args: any[]) => any) | undefined;
            onClose?: ((...args: any[]) => any) | undefined;
            "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
            "onExpand-change"?: ((...args: any[]) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "props" | "border" | "options">;
        $attrs: {
            [x: string]: unknown;
        };
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $emit: (event: "update:modelValue" | "change" | "close" | "expand-change", ...args: any[]) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            border: {
                type: BooleanConstructor;
                default: boolean;
            };
            renderLabel: PropType<import("../../cascader-panel/src/node").RenderLabel>;
            modelValue: PropType<import("../../cascader-panel/src/node").CascaderValue>;
            options: {
                type: PropType<import("../../cascader-panel/src/node").CascaderOption[]>;
                default: () => import("../../cascader-panel/src/node").CascaderOption[];
            };
            props: {
                type: PropType<import("../../cascader-panel/src/node").CascaderProps>;
                default: () => import("../../cascader-panel/src/node").CascaderProps;
            };
        }>> & {
            onChange?: ((...args: any[]) => any) | undefined;
            onClose?: ((...args: any[]) => any) | undefined;
            "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
            "onExpand-change"?: ((...args: any[]) => any) | undefined;
        }, {
            menuList: Ref<any[]>;
            menus: Ref<{
                readonly uid: number;
                readonly level: number;
                readonly value: import("../../cascader-panel/src/node").CascaderNodeValue;
                readonly label: string;
                readonly pathNodes: any[];
                readonly pathValues: import("../../cascader-panel/src/node").CascaderNodeValue[];
                readonly pathLabels: string[];
                childrenData: {
                    [x: string]: unknown;
                    label?: string | undefined;
                    value?: import("../../cascader-panel/src/node").CascaderNodeValue | undefined;
                    children?: any[] | undefined;
                    disabled?: boolean | undefined;
                    leaf?: boolean | undefined;
                }[] | undefined;
                children: any[];
                text: string;
                loaded: boolean;
                checked: boolean;
                indeterminate: boolean;
                loading: boolean;
                readonly data: {
                    [x: string]: unknown;
                    label?: string | undefined;
                    value?: import("../../cascader-panel/src/node").CascaderNodeValue | undefined;
                    children?: any[] | undefined;
                    disabled?: boolean | undefined;
                    leaf?: boolean | undefined;
                } | null;
                readonly config: {
                    expandTrigger: import("../../cascader-panel/src/node").ExpandTrigger;
                    multiple: boolean;
                    checkStrictly: boolean;
                    emitPath: boolean;
                    lazy: boolean;
                    lazyLoad: import("../../cascader-panel/src/node").LazyLoad;
                    value: string;
                    label: string;
                    children: string;
                    disabled: string | import("../../cascader-panel/src/node").isDisabled;
                    leaf: string | import("../../cascader-panel/src/node").isLeaf;
                    hoverThreshold: number;
                };
                readonly parent?: any | undefined;
                readonly root: boolean;
                readonly isDisabled: boolean;
                readonly isLeaf: boolean;
                readonly valueByOption: import("../../cascader-panel/src/node").CascaderNodeValue | import("../../cascader-panel/src/node").CascaderNodeValue[];
                appendChild: (childData: import("../../cascader-panel/src/node").CascaderOption) => CascaderNode;
                calcText: (allLevels: boolean, separator: string) => string;
                broadcast: (event: string, ...args: unknown[]) => void;
                emit: (event: string, ...args: unknown[]) => void;
                onParentCheck: (checked: boolean) => void;
                onChildCheck: () => void;
                setCheckState: (checked: boolean) => void;
                doCheck: (checked: boolean) => void;
            }[][]>;
            checkedNodes: Ref<{
                readonly uid: number;
                readonly level: number;
                readonly value: import("../../cascader-panel/src/node").CascaderNodeValue;
                readonly label: string;
                readonly pathNodes: any[];
                readonly pathValues: import("../../cascader-panel/src/node").CascaderNodeValue[];
                readonly pathLabels: string[];
                childrenData: {
                    [x: string]: unknown;
                    label?: string | undefined;
                    value?: import("../../cascader-panel/src/node").CascaderNodeValue | undefined;
                    children?: any[] | undefined;
                    disabled?: boolean | undefined;
                    leaf?: boolean | undefined;
                }[] | undefined;
                children: any[];
                text: string;
                loaded: boolean;
                checked: boolean;
                indeterminate: boolean;
                loading: boolean;
                readonly data: {
                    [x: string]: unknown;
                    label?: string | undefined;
                    value?: import("../../cascader-panel/src/node").CascaderNodeValue | undefined;
                    children?: any[] | undefined;
                    disabled?: boolean | undefined;
                    leaf?: boolean | undefined;
                } | null;
                readonly config: {
                    expandTrigger: import("../../cascader-panel/src/node").ExpandTrigger;
                    multiple: boolean;
                    checkStrictly: boolean;
                    emitPath: boolean;
                    lazy: boolean;
                    lazyLoad: import("../../cascader-panel/src/node").LazyLoad;
                    value: string;
                    label: string;
                    children: string;
                    disabled: string | import("../../cascader-panel/src/node").isDisabled;
                    leaf: string | import("../../cascader-panel/src/node").isLeaf;
                    hoverThreshold: number;
                };
                readonly parent?: any | undefined;
                readonly root: boolean;
                readonly isDisabled: boolean;
                readonly isLeaf: boolean;
                readonly valueByOption: import("../../cascader-panel/src/node").CascaderNodeValue | import("../../cascader-panel/src/node").CascaderNodeValue[];
                appendChild: (childData: import("../../cascader-panel/src/node").CascaderOption) => CascaderNode;
                calcText: (allLevels: boolean, separator: string) => string;
                broadcast: (event: string, ...args: unknown[]) => void;
                emit: (event: string, ...args: unknown[]) => void;
                onParentCheck: (checked: boolean) => void;
                onChildCheck: () => void;
                setCheckState: (checked: boolean) => void;
                doCheck: (checked: boolean) => void;
            }[]>;
            handleKeyDown: (e: KeyboardEvent) => void;
            handleCheckChange: (node: CascaderNode, checked: boolean, emitClose?: boolean | undefined) => void;
            getFlattedNodes: (leafOnly: boolean) => CascaderNode[] | undefined;
            getCheckedNodes: (leafOnly: boolean) => CascaderNode[] | undefined;
            clearCheckedNodes: () => void;
            calculateCheckedValue: () => void;
            scrollToExpandingNode: () => void;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:modelValue" | "change" | "close" | "expand-change")[], string, {
            props: import("../../cascader-panel/src/node").CascaderProps;
            border: boolean;
            options: import("../../cascader-panel/src/node").CascaderOption[];
        }> & {
            beforeCreate?: ((() => void) | (() => void)[]) | undefined;
            created?: ((() => void) | (() => void)[]) | undefined;
            beforeMount?: ((() => void) | (() => void)[]) | undefined;
            mounted?: ((() => void) | (() => void)[]) | undefined;
            beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
            updated?: ((() => void) | (() => void)[]) | undefined;
            activated?: ((() => void) | (() => void)[]) | undefined;
            deactivated?: ((() => void) | (() => void)[]) | undefined;
            beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
            beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
            destroyed?: ((() => void) | (() => void)[]) | undefined;
            unmounted?: ((() => void) | (() => void)[]) | undefined;
            renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
    } & Readonly<import("vue").ExtractPropTypes<{
        border: {
            type: BooleanConstructor;
            default: boolean;
        };
        renderLabel: PropType<import("../../cascader-panel/src/node").RenderLabel>;
        modelValue: PropType<import("../../cascader-panel/src/node").CascaderValue>;
        options: {
            type: PropType<import("../../cascader-panel/src/node").CascaderOption[]>;
            default: () => import("../../cascader-panel/src/node").CascaderOption[];
        };
        props: {
            type: PropType<import("../../cascader-panel/src/node").CascaderProps>;
            default: () => import("../../cascader-panel/src/node").CascaderProps;
        };
    }>> & {
        onChange?: ((...args: any[]) => any) | undefined;
        onClose?: ((...args: any[]) => any) | undefined;
        "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
        "onExpand-change"?: ((...args: any[]) => any) | undefined;
    } & import("vue").ShallowUnwrapRef<{
        menuList: Ref<any[]>;
        menus: Ref<{
            readonly uid: number;
            readonly level: number;
            readonly value: import("../../cascader-panel/src/node").CascaderNodeValue;
            readonly label: string;
            readonly pathNodes: any[];
            readonly pathValues: import("../../cascader-panel/src/node").CascaderNodeValue[];
            readonly pathLabels: string[];
            childrenData: {
                [x: string]: unknown;
                label?: string | undefined;
                value?: import("../../cascader-panel/src/node").CascaderNodeValue | undefined;
                children?: any[] | undefined;
                disabled?: boolean | undefined;
                leaf?: boolean | undefined;
            }[] | undefined;
            children: any[];
            text: string;
            loaded: boolean;
            checked: boolean;
            indeterminate: boolean;
            loading: boolean;
            readonly data: {
                [x: string]: unknown;
                label?: string | undefined;
                value?: import("../../cascader-panel/src/node").CascaderNodeValue | undefined;
                children?: any[] | undefined;
                disabled?: boolean | undefined;
                leaf?: boolean | undefined;
            } | null;
            readonly config: {
                expandTrigger: import("../../cascader-panel/src/node").ExpandTrigger;
                multiple: boolean;
                checkStrictly: boolean;
                emitPath: boolean;
                lazy: boolean;
                lazyLoad: import("../../cascader-panel/src/node").LazyLoad;
                value: string;
                label: string;
                children: string;
                disabled: string | import("../../cascader-panel/src/node").isDisabled;
                leaf: string | import("../../cascader-panel/src/node").isLeaf;
                hoverThreshold: number;
            };
            readonly parent?: any | undefined;
            readonly root: boolean;
            readonly isDisabled: boolean;
            readonly isLeaf: boolean;
            readonly valueByOption: import("../../cascader-panel/src/node").CascaderNodeValue | import("../../cascader-panel/src/node").CascaderNodeValue[];
            appendChild: (childData: import("../../cascader-panel/src/node").CascaderOption) => CascaderNode;
            calcText: (allLevels: boolean, separator: string) => string;
            broadcast: (event: string, ...args: unknown[]) => void;
            emit: (event: string, ...args: unknown[]) => void;
            onParentCheck: (checked: boolean) => void;
            onChildCheck: () => void;
            setCheckState: (checked: boolean) => void;
            doCheck: (checked: boolean) => void;
        }[][]>;
        checkedNodes: Ref<{
            readonly uid: number;
            readonly level: number;
            readonly value: import("../../cascader-panel/src/node").CascaderNodeValue;
            readonly label: string;
            readonly pathNodes: any[];
            readonly pathValues: import("../../cascader-panel/src/node").CascaderNodeValue[];
            readonly pathLabels: string[];
            childrenData: {
                [x: string]: unknown;
                label?: string | undefined;
                value?: import("../../cascader-panel/src/node").CascaderNodeValue | undefined;
                children?: any[] | undefined;
                disabled?: boolean | undefined;
                leaf?: boolean | undefined;
            }[] | undefined;
            children: any[];
            text: string;
            loaded: boolean;
            checked: boolean;
            indeterminate: boolean;
            loading: boolean;
            readonly data: {
                [x: string]: unknown;
                label?: string | undefined;
                value?: import("../../cascader-panel/src/node").CascaderNodeValue | undefined;
                children?: any[] | undefined;
                disabled?: boolean | undefined;
                leaf?: boolean | undefined;
            } | null;
            readonly config: {
                expandTrigger: import("../../cascader-panel/src/node").ExpandTrigger;
                multiple: boolean;
                checkStrictly: boolean;
                emitPath: boolean;
                lazy: boolean;
                lazyLoad: import("../../cascader-panel/src/node").LazyLoad;
                value: string;
                label: string;
                children: string;
                disabled: string | import("../../cascader-panel/src/node").isDisabled;
                leaf: string | import("../../cascader-panel/src/node").isLeaf;
                hoverThreshold: number;
            };
            readonly parent?: any | undefined;
            readonly root: boolean;
            readonly isDisabled: boolean;
            readonly isLeaf: boolean;
            readonly valueByOption: import("../../cascader-panel/src/node").CascaderNodeValue | import("../../cascader-panel/src/node").CascaderNodeValue[];
            appendChild: (childData: import("../../cascader-panel/src/node").CascaderOption) => CascaderNode;
            calcText: (allLevels: boolean, separator: string) => string;
            broadcast: (event: string, ...args: unknown[]) => void;
            emit: (event: string, ...args: unknown[]) => void;
            onParentCheck: (checked: boolean) => void;
            onChildCheck: () => void;
            setCheckState: (checked: boolean) => void;
            doCheck: (checked: boolean) => void;
        }[]>;
        handleKeyDown: (e: KeyboardEvent) => void;
        handleCheckChange: (node: CascaderNode, checked: boolean, emitClose?: boolean | undefined) => void;
        getFlattedNodes: (leafOnly: boolean) => CascaderNode[] | undefined;
        getCheckedNodes: (leafOnly: boolean) => CascaderNode[] | undefined;
        clearCheckedNodes: () => void;
        calculateCheckedValue: () => void;
        scrollToExpandingNode: () => void;
    }> & {} & {} & import("vue").ComponentCustomProperties) | null>;
    suggestionPanel: Ref<({
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            height: import("../../../utils/props").BuildPropType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            maxHeight: import("../../../utils/props").BuildPropType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            always: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            native: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            wrapStyle: import("vue").StyleValue;
            wrapClass: import("../../../utils/props").BuildPropType<readonly [StringConstructor, ArrayConstructor], unknown, unknown>;
            viewClass: import("../../../utils/props").BuildPropType<readonly [StringConstructor, ArrayConstructor], unknown, unknown>;
            viewStyle: import("../../../utils/props").BuildPropType<readonly [StringConstructor, ArrayConstructor], unknown, unknown>;
            tag: string;
            minSize: number;
            noresize: boolean;
        }> & Omit<Readonly<import("vue").ExtractPropTypes<{
            readonly height: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, NumberConstructor], "", unknown, unknown, unknown>;
            readonly maxHeight: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, NumberConstructor], "", unknown, unknown, unknown>;
            readonly native: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly wrapStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, "", unknown, unknown, unknown>;
            readonly wrapClass: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
            readonly viewClass: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
            readonly viewStyle: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
            readonly noresize: BooleanConstructor;
            readonly tag: import("../../../utils/props").BuildPropReturn<StringConstructor, "div", unknown, unknown, unknown>;
            readonly always: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly minSize: import("../../../utils/props").BuildPropReturn<NumberConstructor, 20, unknown, unknown, unknown>;
        }>> & {
            onScroll?: ((args_0: {
                scrollTop: number;
                scrollLeft: number;
            }) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "height" | "maxHeight" | "always" | "native" | "wrapStyle" | "wrapClass" | "viewClass" | "viewStyle" | "tag" | "minSize" | "noresize">;
        $attrs: {
            [x: string]: unknown;
        };
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $parent: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null;
        $emit: (event: "scroll", args_0: {
            scrollTop: number;
            scrollLeft: number;
        }) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly height: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, NumberConstructor], "", unknown, unknown, unknown>;
            readonly maxHeight: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, NumberConstructor], "", unknown, unknown, unknown>;
            readonly native: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly wrapStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, "", unknown, unknown, unknown>;
            readonly wrapClass: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
            readonly viewClass: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
            readonly viewStyle: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
            readonly noresize: BooleanConstructor;
            readonly tag: import("../../../utils/props").BuildPropReturn<StringConstructor, "div", unknown, unknown, unknown>;
            readonly always: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
            readonly minSize: import("../../../utils/props").BuildPropReturn<NumberConstructor, 20, unknown, unknown, unknown>;
        }>> & {
            onScroll?: ((args_0: {
                scrollTop: number;
                scrollLeft: number;
            }) => any) | undefined;
        }, {
            ns: {
                namespace: ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string | undefined) => string;
                m: (modifier?: string | undefined) => string;
                be: (blockSuffix?: string | undefined, element?: string | undefined) => string;
                em: (element?: string | undefined, modifier?: string | undefined) => string;
                bm: (blockSuffix?: string | undefined, modifier?: string | undefined) => string;
                bem: (blockSuffix?: string | undefined, element?: string | undefined, modifier?: string | undefined) => string;
                is: (name: string, state?: boolean) => string;
            };
            scrollbar$: Ref<HTMLDivElement | undefined>;
            wrap$: Ref<HTMLDivElement | undefined>;
            resize$: Ref<HTMLElement | undefined>;
            barRef: Ref<any>;
            moveX: Ref<number>;
            moveY: Ref<number>;
            ratioX: Ref<number>;
            ratioY: Ref<number>;
            sizeWidth: Ref<string>;
            sizeHeight: Ref<string>;
            style: ComputedRef<import("vue").StyleValue>;
            update: () => void;
            handleScroll: () => void;
            setScrollTop: (value: number) => void;
            setScrollLeft: (value: number) => void;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            scroll: ({ scrollTop, scrollLeft, }: {
                scrollTop: number;
                scrollLeft: number;
            }) => boolean;
        }, string, {
            height: import("../../../utils/props").BuildPropType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            maxHeight: import("../../../utils/props").BuildPropType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            always: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            native: import("../../../utils/props").BuildPropType<BooleanConstructor, unknown, unknown>;
            wrapStyle: import("vue").StyleValue;
            wrapClass: import("../../../utils/props").BuildPropType<readonly [StringConstructor, ArrayConstructor], unknown, unknown>;
            viewClass: import("../../../utils/props").BuildPropType<readonly [StringConstructor, ArrayConstructor], unknown, unknown>;
            viewStyle: import("../../../utils/props").BuildPropType<readonly [StringConstructor, ArrayConstructor], unknown, unknown>;
            tag: string;
            minSize: number;
            noresize: boolean;
        }> & {
            beforeCreate?: ((() => void) | (() => void)[]) | undefined;
            created?: ((() => void) | (() => void)[]) | undefined;
            beforeMount?: ((() => void) | (() => void)[]) | undefined;
            mounted?: ((() => void) | (() => void)[]) | undefined;
            beforeUpdate?: ((() => void) | (() => void)[]) | undefined;
            updated?: ((() => void) | (() => void)[]) | undefined;
            activated?: ((() => void) | (() => void)[]) | undefined;
            deactivated?: ((() => void) | (() => void)[]) | undefined;
            beforeDestroy?: ((() => void) | (() => void)[]) | undefined;
            beforeUnmount?: ((() => void) | (() => void)[]) | undefined;
            destroyed?: ((() => void) | (() => void)[]) | undefined;
            unmounted?: ((() => void) | (() => void)[]) | undefined;
            renderTracked?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            renderTriggered?: (((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[]) | undefined;
            errorCaptured?: (((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}>> | null, info: string) => boolean | void)[]) | undefined;
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch(source: string | Function, cb: Function, options?: import("vue").WatchOptions<boolean> | undefined): import("vue").WatchStopHandle;
    } & Readonly<import("vue").ExtractPropTypes<{
        readonly height: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, NumberConstructor], "", unknown, unknown, unknown>;
        readonly maxHeight: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, NumberConstructor], "", unknown, unknown, unknown>;
        readonly native: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
        readonly wrapStyle: import("../../../utils/props").BuildPropReturn<import("../../../utils/props").PropWrapper<import("vue").StyleValue>, "", unknown, unknown, unknown>;
        readonly wrapClass: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
        readonly viewClass: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
        readonly viewStyle: import("../../../utils/props").BuildPropReturn<readonly [StringConstructor, ArrayConstructor], "", unknown, unknown, unknown>;
        readonly noresize: BooleanConstructor;
        readonly tag: import("../../../utils/props").BuildPropReturn<StringConstructor, "div", unknown, unknown, unknown>;
        readonly always: import("../../../utils/props").BuildPropReturn<BooleanConstructor, false, unknown, unknown, unknown>;
        readonly minSize: import("../../../utils/props").BuildPropReturn<NumberConstructor, 20, unknown, unknown, unknown>;
    }>> & {
        onScroll?: ((args_0: {
            scrollTop: number;
            scrollLeft: number;
        }) => any) | undefined;
    } & import("vue").ShallowUnwrapRef<{
        ns: {
            namespace: ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string | undefined) => string;
            m: (modifier?: string | undefined) => string;
            be: (blockSuffix?: string | undefined, element?: string | undefined) => string;
            em: (element?: string | undefined, modifier?: string | undefined) => string;
            bm: (blockSuffix?: string | undefined, modifier?: string | undefined) => string;
            bem: (blockSuffix?: string | undefined, element?: string | undefined, modifier?: string | undefined) => string;
            is: (name: string, state?: boolean) => string;
        };
        scrollbar$: Ref<HTMLDivElement | undefined>;
        wrap$: Ref<HTMLDivElement | undefined>;
        resize$: Ref<HTMLElement | undefined>;
        barRef: Ref<any>;
        moveX: Ref<number>;
        moveY: Ref<number>;
        ratioX: Ref<number>;
        ratioY: Ref<number>;
        sizeWidth: Ref<string>;
        sizeHeight: Ref<string>;
        style: ComputedRef<import("vue").StyleValue>;
        update: () => void;
        handleScroll: () => void;
        setScrollTop: (value: number) => void;
        setScrollLeft: (value: number) => void;
    }> & {} & {} & import("vue").ComponentCustomProperties) | null>;
    popperVisible: Ref<boolean>;
    inputHover: Ref<boolean>;
    inputPlaceholder: ComputedRef<string>;
    filtering: Ref<boolean>;
    presentText: ComputedRef<string>;
    checkedValue: ComputedRef<CascaderValue>;
    inputValue: Ref<string>;
    searchInputValue: Ref<string>;
    presentTags: Ref<Tag[]>;
    suggestions: Ref<CascaderNode[]>;
    isDisabled: ComputedRef<boolean | undefined>;
    isOnComposition: Ref<boolean>;
    realSize: ComputedRef<ComponentSize>;
    tagSize: ComputedRef<"default" | "small">;
    multiple: ComputedRef<boolean>;
    readonly: ComputedRef<boolean>;
    clearBtnVisible: ComputedRef<boolean>;
    t: import("element-plus/es/hooks").Translator;
    togglePopperVisible: (visible?: boolean | undefined) => void;
    hideSuggestionPanel: () => void;
    deleteTag: (tag: Tag) => void;
    focusFirstNode: () => void;
    getCheckedNodes: (leafOnly: boolean) => CascaderNode[] | undefined;
    handleExpandChange: (value: CascaderValue) => void;
    handleKeyDown: (e: KeyboardEvent) => void;
    handleComposition: (event: CompositionEvent) => void;
    handleClear: () => void;
    handleSuggestionClick: (node: CascaderNode) => void;
    handleSuggestionKeyDown: (e: KeyboardEvent) => void;
    handleDelete: () => void;
    handleInput: (val: string, e?: KeyboardEvent | undefined) => void;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:modelValue" | "change" | "blur" | "focus" | "expand-change" | "visible-change" | "remove-tag")[], "update:modelValue" | "change" | "blur" | "focus" | "expand-change" | "visible-change" | "remove-tag", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    size: {
        type: PropType<ComponentSize>;
        validator: (val: string) => boolean;
    };
    placeholder: {
        type: StringConstructor;
    };
    disabled: BooleanConstructor;
    clearable: BooleanConstructor;
    filterable: BooleanConstructor;
    filterMethod: {
        type: PropType<(node: CascaderNode, keyword: string) => boolean>;
        default: (node: CascaderNode, keyword: string) => boolean;
    };
    separator: {
        type: StringConstructor;
        default: string;
    };
    showAllLevels: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapseTags: BooleanConstructor;
    debounce: {
        type: NumberConstructor;
        default: number;
    };
    beforeFilter: {
        type: PropType<(value: string) => boolean | Promise<any>>;
        default: () => boolean;
    };
    popperClass: {
        type: StringConstructor;
        default: string;
    };
    popperAppendToBody: {
        type: BooleanConstructor;
        default: boolean;
    };
    modelValue: PropType<import("../../cascader-panel/src/node").CascaderValue>;
    options: {
        type: PropType<import("../../cascader-panel/src/node").CascaderOption[]>;
        default: () => import("../../cascader-panel/src/node").CascaderOption[];
    };
    props: {
        type: PropType<import("../../cascader-panel/src/node").CascaderProps>;
        default: () => import("../../cascader-panel/src/node").CascaderProps;
    };
}>> & {
    onChange?: ((...args: any[]) => any) | undefined;
    onFocus?: ((...args: any[]) => any) | undefined;
    onBlur?: ((...args: any[]) => any) | undefined;
    "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
    "onExpand-change"?: ((...args: any[]) => any) | undefined;
    "onVisible-change"?: ((...args: any[]) => any) | undefined;
    "onRemove-tag"?: ((...args: any[]) => any) | undefined;
}, {
    separator: string;
    disabled: boolean;
    props: import("../../cascader-panel/src/node").CascaderProps;
    popperClass: string;
    clearable: boolean;
    debounce: number;
    popperAppendToBody: boolean;
    options: import("../../cascader-panel/src/node").CascaderOption[];
    filterable: boolean;
    filterMethod: (node: CascaderNode, keyword: string) => boolean;
    showAllLevels: boolean;
    collapseTags: boolean;
    beforeFilter: (value: string) => boolean | Promise<any>;
}>;
export default _default;
