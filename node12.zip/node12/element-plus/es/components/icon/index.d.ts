export declare const ElIcon: import("../../utils/types").SFCWithInstall<import("vue").DefineComponent<{
    readonly size: import("../../utils/props").BuildPropReturn<import("../../utils/props").PropWrapper<string | number>, unknown, unknown, unknown, unknown>;
    readonly color: import("../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, unknown, unknown>;
}, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string | undefined) => string;
        m: (modifier?: string | undefined) => string;
        be: (blockSuffix?: string | undefined, element?: string | undefined) => string;
        em: (element?: string | undefined, modifier?: string | undefined) => string;
        bm: (blockSuffix?: string | undefined, modifier?: string | undefined) => string;
        bem: (blockSuffix?: string | undefined, element?: string | undefined, modifier?: string | undefined) => string;
        is: (name: string, state?: boolean) => string;
    };
    style: import("vue").ComputedRef<import("vue").CSSProperties>;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    readonly size: import("../../utils/props").BuildPropReturn<import("../../utils/props").PropWrapper<string | number>, unknown, unknown, unknown, unknown>;
    readonly color: import("../../utils/props").BuildPropReturn<StringConstructor, unknown, unknown, unknown, unknown>;
}>>, {
    size: import("../../utils/props").BuildPropType<import("../../utils/props").PropWrapper<string | number>, unknown, unknown>;
    color: string;
}>> & Record<string, any>;
export default ElIcon;
export * from './src/icon';
