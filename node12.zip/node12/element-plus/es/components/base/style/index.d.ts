import 'element-plus/theme-chalk/src/base.scss';
