import type { LoadingInstance } from './loading';
import type { LoadingOptions } from './types';
export declare const Loading: (options?: LoadingOptions) => LoadingInstance;
