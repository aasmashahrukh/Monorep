import type { InjectionKey } from 'vue';
import type { IDescriptionsInject } from './descriptions.type';
export declare const elDescriptionsKey: InjectionKey<IDescriptionsInject>;
