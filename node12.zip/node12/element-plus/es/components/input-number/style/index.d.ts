import 'element-plus/es/components/base/style';
import 'element-plus/theme-chalk/src/input-number.scss';
import 'element-plus/es/components/input/style/index';
